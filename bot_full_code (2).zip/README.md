# Telegram Session Verification Bot

একটি Telegram বট যা session verification, country management, এবং withdrawal system পরিচালনা করে।

## Features

- 👤 User Management - ব্যবহারকারী registration এবং account tracking
- 🌍 Country Management - দেশ-ভিত্তিক rate এবং timeout settings
- 💰 Withdrawal System - USDT, TRX, এবং BKASH withdrawal
- 👑 Admin Panel - সম্পূর্ণ admin controls
- 📊 Statistics - User এবং session statistics
- 📢 Broadcast - সকল users এ message broadcast

## Available Commands

### User Commands:
- `/start` - বট শুরু করুন
- `/cap` - উপলব্ধ দেশের তালিকা দেখুন
- `/account` - আপনার account info দেখুন
- `/withdraw` - Withdrawal request করুন
- `/support` - Support contact

### Admin Commands:
- `/admin` - Admin panel খুলুন (শুধুমাত্র admin এর জন্য)

## Configuration

সব configuration `bot/config.py` তে আছে:

- **API Credentials**: Telegram API ID, Hash, এবং Bot Token
- **Channels**: বিভিন্ন notification channels
- **Admin ID**: Admin user ID
- **Currency Rates**: USD conversion rates
- **2FA Password**: Default session password

## Project Structure

```
CA/
├── bot/
│   ├── handlers/           # Command handlers
│   │   ├── start.py       # /start command
│   │   ├── cap.py         # /cap command
│   │   ├── account.py     # /account command
│   │   ├── withdraw.py    # /withdraw command
│   │   ├── support.py     # /support command
│   │   └── admin.py       # Admin panel
│   ├── utils/             # Utility modules
│   │   ├── storage.py     # Data storage
│   │   ├── session_handler.py
│   │   └── converter.py   # Currency converter
│   ├── config.py          # Configuration
│   └── main.py            # Main bot file
├── data/                  # Storage directory
├── requirements.txt       # Python dependencies
└── README.md             # এই ফাইল

```

## Running the Bot

বট Replit এ automatically চালু হয়। ম্যানুয়ালি চালাতে:

```bash
cd CA
python bot/main.py
```

## Admin Features

Admin panel এ access করতে আপনার user ID অবশ্যই `ADMIN_ID` এর সাথে match করতে হবে।

Admin capabilities:
- Country rates set করা
- Session timeout পরিবর্তন করা
- Users ban/unban করা
- Broadcast messages পাঠানো
- User stats দেখা
- Balance adjust করা
- এবং আরো অনেক...

## Data Storage

সব data `data/storage.json` ফাইলে JSON format এ সংরক্ষিত হয়।

## Support

Support এর জন্য যোগাযোগ করুন: @xrd_didox
