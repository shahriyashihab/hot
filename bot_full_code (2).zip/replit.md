# Telegram Session Bot

## Overview
This project is a Telegram bot designed for automated account verification and session management. It enables users to submit phone numbers for OTP verification, generate Telegram sessions, and earn USD based on country-specific rates. Key features include mandatory channel membership, 2FA setup, automatic session validation with country-specific timeouts, and a comprehensive admin panel for managing countries, a 3-tier pricing system (Spam Free, Spam, Limit accounts), withdrawals, and bot settings. Verified sessions are exported and sent to designated channels, streamlining session acquisition and monetization. The business vision is to provide a reliable and automated platform for Telegram session generation, addressing market needs for bulk Telegram accounts.

## User Preferences
- Language: Bengali (বাংলা) preferred
- Format: Emoji-rich, clear notifications
- Behavior: 24/7 uptime required
- Channel Requirement: Mandatory membership before bot access

## System Architecture
The bot enforces mandatory channel membership and utilizes a 3-tier pricing system that automatically detects an account's status (Spam Free, Spam, Limit) based on Telegram API indicators. Message templates are fully customizable via the admin panel, supporting dynamic content. An administrative country control system allows managing which countries accept phone number submissions. Minimum withdrawal amounts are configurable per payment method. The UI/UX emphasizes clear, emoji-rich messages and notifications for an intuitive user experience.

**Core Technical Implementations:**
-   **Channel Verification:** Real-time channel membership checks on every command.
-   **Session Flow:** Users submit phone numbers, undergo OTP and 2FA verification. Sessions are queued, validated after a country-specific timeout, exported as `.json` and `.SESSION` files, and sent to a designated channel.
-   **Account Status Detection:** Functions determine pricing based on Telegram API responses for spam, limit, or spam-free accounts.
-   **Message Templates:** Stored in `storage.json` with dynamic placeholder replacement.
-   **Country Control:** Manages submission availability for different countries.
-   **Stability:** Auto-recovery, comprehensive error handling, and a pending session monitor ensure continuous operation.
-   **Data Storage:** `bot/storage.json` for user data, configurations, and pending sessions; `verified_sessions/` for session files. PostgreSQL is used for audit logging (transaction_logs, admin_logs, failed_verifications, withdrawal_logs, session_analytics).
-   **Ultra-Fast Response System:** Zero-Blocking I/O architecture with memory-based caching, startup preloading, "Respond First" pattern, and background I/O operations.
-   **Precise Timing Architecture:** Strict monotonic timing for OTP delivery, 2FA setup, spam checks, and country timeouts.
-   **Universal Channel Guard:** Middleware protects all handlers with live API checks for channel membership.
-   **Duplicate Message Prevention:** An atomic finalization claim system prevents race conditions and ensures unique processing of final status messages and balance credits.
-   **Security Enhancements:** Wallet address validation, dangerous character sanitization in user inputs, and input length limits.
-   **Admin Panel:** Reorganized into a 9-category hierarchical menu for improved navigation. Features Add Admin and Remove Admin functionality with primary admin protection.
-   **Multi-Admin System:** Custom admin filter allows multiple admins to access the admin panel. New admins added via "Add New Admin" can immediately use `/admin` command and all admin features. Primary admin (ADMIN_ID from config) is always protected and cannot be removed.
-   **Session Export System:** Admin can export Active/Pending/All sessions as ZIP files from Session Management menu. Sessions are automatically deleted from bot storage after download, while channel reports remain intact. Optimized for high-volume traffic (5000-6000 sessions/day) with non-blocking async ZIP creation, proper error handling, and automatic cleanup.

## High-Scale Architecture (10,000+ Users Support)
The bot has been upgraded for enterprise-scale operations with the following enhancements:

-   **PostgreSQL Primary Storage:** Users, sessions, and pending_sessions now stored in PostgreSQL with connection pool (min=5, max=25).
-   **LRU Cache Engine (NEW):** High-performance sharded in-memory cache that works WITHOUT external Redis. Features:
    - 16 shards for concurrent access (reduced lock contention)
    - 50,000 total entry capacity
    - TTL enforcement with automatic cleanup
    - LRU (Least Recently Used) eviction
    - Memory pressure monitoring
    - Rate limiting support
    - Background garbage collection
-   **Redis Cache Layer (Optional):** External Redis caching can be enabled by setting REDIS_URL secret. When not set, LRU Cache Engine provides same functionality.
-   **Rate Limiting:** Per-user rate limiting to prevent abuse (verify_phone: 3/min, withdraw: 2/min).
-   **Memory Manager:** Automatic session cleanup with TTL (3600s), max 5000 active sessions with LRU eviction.
-   **Channel Guard v3.0:** Redis/LRU-backed caching with fallback, optimized for high concurrency.

**New Modules:**
-   `bot/utils/lru_cache_engine.py` - **High-performance sharded LRU cache (Redis-free 10k+ user support)**
-   `bot/utils/redis_cache.py` - Async Redis client with LRU Cache fallback
-   `bot/utils/rate_limiter.py` - Per-user rate limiting
-   `bot/utils/memory_manager.py` - Session cleanup and garbage collection
-   `bot/utils/high_scale_storage.py` - PostgreSQL-backed storage with smart caching

## External Dependencies
-   **Telegram API:** Used for all core Telegram interactions (account management, messaging, session creation).
-   **Replit Secrets:** For secure storage of sensitive credentials (`API_ID`, `API_HASH`, `BOT_TOKEN`).
-   **Telegram Channels:** Utilized for mandatory user membership and as output channels for various session and withdrawal reports.
-   **PostgreSQL:** Primary database for users, sessions, and audit logging. Connection pool optimized for high scale.
-   **Redis (Optional):** External Redis caching can be enabled for even higher performance. Set REDIS_URL secret to enable. **NOT REQUIRED** - LRU Cache Engine provides 10,000+ user support without Redis.