import os

# ==============================
#        TELEGRAM API
# ==============================

def load_secret(key, default=None):
    """Load secret from environment or Replit secrets"""
    value = os.getenv(key)
    if value:
        return value
    try:
        with open(f'/home/runner/{key}', 'r') as f:
            return f.read().strip()
    except (FileNotFoundError, IOError, PermissionError):
        pass
    return default

# Load credentials from environment/secrets
_bot_token = load_secret("BOT_TOKEN")
_api_id = load_secret("API_ID")
_api_hash = load_secret("API_HASH")

# Fallback: Use first EXTRA_API if main API credentials are not set
if not _api_id or not _api_hash:
    _extra_api_id = os.getenv("EXTRA_API_1_ID")
    _extra_api_hash = os.getenv("EXTRA_API_1_HASH")
    if _extra_api_id and _extra_api_hash:
        print("ℹ️ Using EXTRA_API_1 credentials as primary API")
        _api_id = _extra_api_id
        _api_hash = _extra_api_hash

# Validate required credentials - NO DEFAULTS for security
if not _api_id:
    raise ValueError("❌ API_ID is required! Please set API_ID or EXTRA_API_1_ID in Replit Secrets.")
if not _api_hash:
    raise ValueError("❌ API_HASH is required! Please set API_HASH or EXTRA_API_1_HASH in Replit Secrets.")
if not _bot_token:
    raise ValueError("❌ BOT_TOKEN is required! Please set BOT_TOKEN in Replit Secrets.")

API_ID = int(_api_id)
API_HASH = _api_hash
BOT_TOKEN = _bot_token

# ==============================
#          CHANNELS
# ==============================

def parse_channel_value(value, default):
    """
    Parse channel value - supports both:
    - Numeric ID: -1003403829620
    - Username: @channel_name
    
    Returns: int (for numeric ID) or str (for username)
    """
    if not value:
        return default
    
    value = value.strip()
    
    if value.startswith("@"):
        return value
    
    if value.lstrip('-').isdigit():
        return int(value)
    
    return default

import logging as _config_logging

_channel_submit_env = load_secret("CHANNEL_SUBMIT") or ""
_channel_verified_env = load_secret("CHANNEL_VERIFIED") or ""
_channel_rejected_env = load_secret("CHANNEL_REJECTED") or ""
_channel_withdraw_env = load_secret("CHANNEL_WITHDRAW_REPORT") or ""
_channel_24hr_env = load_secret("CHANNEL_24HR_UP") or ""
_required_channel_env = load_secret("REQUIRED_CHANNEL") or ""

_CHANNEL_DEFAULTS = {
    "CHANNEL_SUBMIT": "@cyitfitfgkfyffiyfyi",
    "CHANNEL_VERIFIED": "@my_verified_sessions",
    "CHANNEL_REJECTED": "@jsnsjsgsbwjwwbsjjsj",
    "CHANNEL_WITHDRAW_REPORT": "@sjsjsnshwmvsyssbsnajwbwwj",
    "CHANNEL_24HR_UP": "@sisjsbsbkshsbskssb",
    "REQUIRED_CHANNEL": "@newschannel457"
}

def _get_channel_with_fallback(name: str, value: str) -> str:
    """Get channel value with fallback to default. Logs warning if using default."""
    if value:
        return value
    default = _CHANNEL_DEFAULTS.get(name, "")
    if default:
        _config_logging.warning(
            f"{name} not set in secrets, using default. "
            f"For production, set {name} in Replit Secrets."
        )
        return default
    return ""

CHANNEL_SUBMIT = parse_channel_value(_get_channel_with_fallback("CHANNEL_SUBMIT", _channel_submit_env), None)
CHANNEL_VERIFIED = parse_channel_value(_get_channel_with_fallback("CHANNEL_VERIFIED", _channel_verified_env), None)
CHANNEL_REJECTED = parse_channel_value(_get_channel_with_fallback("CHANNEL_REJECTED", _channel_rejected_env), None)
CHANNEL_WITHDRAW_REPORT = parse_channel_value(_get_channel_with_fallback("CHANNEL_WITHDRAW_REPORT", _channel_withdraw_env), None)
CHANNEL_24HR_UP = parse_channel_value(_get_channel_with_fallback("CHANNEL_24HR_UP", _channel_24hr_env), None)
REQUIRED_CHANNEL = _get_channel_with_fallback("REQUIRED_CHANNEL", _required_channel_env)

# ==============================
#            ADMIN
# ==============================

_admin_id_env = load_secret("ADMIN_ID") or ""
if not _admin_id_env or not _admin_id_env.lstrip('-').isdigit():
    _config_logging.warning(
        "ADMIN_ID not set in secrets, using default. "
        "For production, set ADMIN_ID in Replit Secrets."
    )
    _admin_id_env = "6817555133"
ADMIN_ID = int(_admin_id_env)

# ==============================
#           SECURITY / 2FA
# ==============================

_2fa_password = os.getenv("SESSION_2FA_PASSWORD")
if not _2fa_password:
    import secrets
    import logging
    _generated_password = secrets.token_urlsafe(16)
    logging.warning("SESSION_2FA_PASSWORD not set! Generated temporary password.")
    logging.warning("For production: Set SESSION_2FA_PASSWORD in Replit Secrets")
    _2fa_password = _generated_password

SESSION_2FA_PASSWORD = _2fa_password
VERIFICATION_DELAY = int(os.getenv("VERIFICATION_DELAY", "5"))

# ==============================
#        CURRENCY RATES
# ==============================

USD_TO_TRX = float(os.getenv("USD_TO_TRX", "57.0"))
USD_TO_CARD_NAME = float(os.getenv("USD_TO_CARD_NAME", "108.0"))
USD_TO_USDT_BEP20 = float(os.getenv("USD_TO_USDT_BEP20", "1.0"))

# ==============================
#     EXTRA API CREDENTIALS
#     (For API Rotation - 5 APIs)
# ==============================

def load_extra_apis():
    """Load extra API credentials for rotation"""
    apis = []
    for i in range(1, 6):
        api_id = os.getenv(f"EXTRA_API_{i}_ID")
        api_hash = os.getenv(f"EXTRA_API_{i}_HASH")
        if api_id and api_hash:
            try:
                apis.append((int(api_id), api_hash))
            except ValueError:
                pass
    return apis

EXTRA_APIS = load_extra_apis()

# ==============================
#     ANTI-FREEZE SETTINGS
#     (0% Freeze Target)
# ==============================

ANTI_FREEZE_CONFIG = {
    "enabled": True,
    "2fa_setup_delay_min": 20,
    "2fa_setup_delay_max": 35,
    "session_warmup_enabled": True,
    "session_warmup_delay": 15,
    "verify_human_delay_min": 3.0,
    "verify_human_delay_max": 8.0,
    "otp_typing_delay_per_digit": 0.4,
    "between_action_delay_min": 2.0,
    "between_action_delay_max": 5.0,
    "max_sessions_per_ip_hour": 3,
    "max_sessions_per_api_hour": 25,
    "cooldown_after_fail_seconds": 60,
    "cooldown_after_flood_seconds": 300,
}
