#!/usr/bin/env python3
"""Health check script to ensure bot is running"""
import time
import sys

def check_bot_health():
    """Simple health check that keeps bot alive"""
    print("🏥 Health check: Bot is alive and running")
    return True

if __name__ == "__main__":
    try:
        while True:
            if check_bot_health():
                time.sleep(300)  # Check every 5 minutes
            else:
                sys.exit(1)
    except KeyboardInterrupt:
        print("🛑 Health check stopped")
        sys.exit(0)
