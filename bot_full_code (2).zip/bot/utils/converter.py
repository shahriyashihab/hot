"""
Currency converter utilities
"""
from bot.config import USD_TO_TRX, USD_TO_CARD_NAME, USD_TO_USDT_BEP20

def usd_to_trx(usd_amount):
    """Convert USD to TRX"""
    return usd_amount * USD_TO_TRX

def usd_to_card_name(usd_amount):
    """Convert USD to CARD NAME"""
    return usd_amount * USD_TO_CARD_NAME

def usd_to_usdt_bep20(usd_amount):
    """Convert USD to USDT (BEP20)"""
    return usd_amount * USD_TO_USDT_BEP20

def convert_balance(usd_amount, method):
    """Convert USD balance to specified method"""
    method = method.upper()
    if method == "TRX":
        return usd_to_trx(usd_amount)
    elif method == "CARDNAME":
        return usd_to_card_name(usd_amount)
    elif method in ["USDT", "USDT_BEP20"]:
        return usd_to_usdt_bep20(usd_amount)
    return usd_amount