"""
Memory Manager Module - High-Scale Resource Management
=======================================================
Manages memory, sessions, and cache for 10,000+ concurrent users.

Features:
- Active session cleanup with TTL
- Periodic garbage collection
- Cache size monitoring
- Memory usage tracking
- Automatic cleanup of stale data
"""

import gc
import sys
import asyncio
import logging
import time
from typing import Dict, Any, Optional, Set
from datetime import datetime, timedelta
from collections import defaultdict

logger = logging.getLogger(__name__)

MAX_ACTIVE_SESSIONS = 5000
SESSION_TTL_SECONDS = 3600
MAX_CACHE_SIZE_MB = 100
CLEANUP_INTERVAL_SECONDS = 300
MAX_PENDING_SESSIONS = 10000
PENDING_SESSION_TTL_HOURS = 24

_active_sessions: Dict[int, Dict[str, Any]] = {}
_session_last_activity: Dict[int, float] = {}
_cleanup_task: Optional[asyncio.Task] = None
_manager_lock = asyncio.Lock()
_stats = {
    "sessions_cleaned": 0,
    "gc_runs": 0,
    "last_cleanup": None,
    "peak_sessions": 0
}


async def register_session(user_id: int, session_data: Dict[str, Any]) -> bool:
    """Register an active session."""
    async with _manager_lock:
        _active_sessions[user_id] = session_data
        _session_last_activity[user_id] = time.time()
        
        current_count = len(_active_sessions)
        if current_count > _stats["peak_sessions"]:
            _stats["peak_sessions"] = current_count
        
        if current_count >= MAX_ACTIVE_SESSIONS:
            await _evict_oldest_sessions(count=100)
        
        return True


async def update_session_activity(user_id: int) -> None:
    """Update last activity timestamp for a session."""
    if user_id in _active_sessions:
        _session_last_activity[user_id] = time.time()


async def get_session(user_id: int) -> Optional[Dict[str, Any]]:
    """Get active session data."""
    async with _manager_lock:
        if user_id in _active_sessions:
            _session_last_activity[user_id] = time.time()
            return _active_sessions[user_id]
        return None


async def remove_session(user_id: int) -> bool:
    """Remove an active session."""
    async with _manager_lock:
        if user_id in _active_sessions:
            del _active_sessions[user_id]
            _session_last_activity.pop(user_id, None)
            return True
        return False


async def _evict_oldest_sessions(count: int = 100) -> int:
    """Evict oldest sessions based on last activity."""
    if not _session_last_activity:
        return 0
    
    sorted_sessions = sorted(
        _session_last_activity.items(),
        key=lambda x: x[1]
    )
    
    evicted = 0
    for user_id, _ in sorted_sessions[:count]:
        if user_id in _active_sessions:
            del _active_sessions[user_id]
            del _session_last_activity[user_id]
            evicted += 1
    
    logger.info(f"Evicted {evicted} oldest sessions")
    return evicted


async def cleanup_expired_sessions() -> int:
    """Clean up sessions that have exceeded TTL."""
    async with _manager_lock:
        now = time.time()
        cutoff = now - SESSION_TTL_SECONDS
        
        expired_users = [
            user_id for user_id, last_activity in _session_last_activity.items()
            if last_activity < cutoff
        ]
        
        for user_id in expired_users:
            _active_sessions.pop(user_id, None)
            _session_last_activity.pop(user_id, None)
        
        cleaned = len(expired_users)
        if cleaned > 0:
            _stats["sessions_cleaned"] += cleaned
            logger.info(f"Cleaned up {cleaned} expired sessions")
        
        return cleaned


async def run_garbage_collection() -> Dict[str, Any]:
    """Run Python garbage collection and return stats."""
    gc.collect()
    _stats["gc_runs"] += 1
    
    gc_stats = {
        "gc_runs_total": _stats["gc_runs"],
        "gc_counts": gc.get_count(),
        "gc_threshold": gc.get_threshold(),
        "objects_collected": gc.collect(0)
    }
    
    return gc_stats


def get_memory_usage() -> Dict[str, Any]:
    """Get current memory usage statistics."""
    try:
        import resource
        usage = resource.getrusage(resource.RUSAGE_SELF)
        max_rss = usage.ru_maxrss / 1024
    except ImportError:
        max_rss = 0
    
    active_sessions_size = sys.getsizeof(_active_sessions)
    for k, v in _active_sessions.items():
        active_sessions_size += sys.getsizeof(k) + sys.getsizeof(v)
    
    return {
        "active_sessions_count": len(_active_sessions),
        "peak_sessions": _stats["peak_sessions"],
        "active_sessions_size_kb": active_sessions_size / 1024,
        "max_rss_mb": max_rss,
        "sessions_cleaned_total": _stats["sessions_cleaned"],
        "gc_runs_total": _stats["gc_runs"],
        "last_cleanup": _stats["last_cleanup"]
    }


async def cleanup_pending_sessions_storage() -> int:
    """Clean up old pending sessions from storage."""
    try:
        from bot.utils.storage import get_all_pending_sessions, _storage, save_storage, _storage_lock
        
        with _storage_lock:
            pending = _storage.get("pending_sessions", {})
            now = datetime.now()
            cutoff = now - timedelta(hours=PENDING_SESSION_TTL_HOURS)
            
            sessions_to_remove = []
            for session_id, data in pending.items():
                created_str = data.get("created_at") or data.get("timestamp")
                if created_str:
                    try:
                        created = datetime.fromisoformat(created_str)
                        if created < cutoff:
                            sessions_to_remove.append(session_id)
                    except (ValueError, TypeError):
                        pass
            
            for session_id in sessions_to_remove:
                del pending[session_id]
            
            if sessions_to_remove:
                save_storage()
                logger.info(f"Cleaned up {len(sessions_to_remove)} old pending sessions from storage")
            
            return len(sessions_to_remove)
            
    except Exception as e:
        logger.error(f"Error cleaning pending sessions: {e}")
        return 0


async def cleanup_rate_limiter() -> int:
    """Clean up rate limiter data."""
    try:
        from bot.utils.rate_limiter import cleanup_old_rate_limits
        return await cleanup_old_rate_limits()
    except ImportError:
        return 0


async def cleanup_redis_cache() -> int:
    """Clean up expired Redis cache entries."""
    try:
        from bot.utils.redis_cache import is_redis_available
        
        if not is_redis_available():
            return 0
        
        return 0
        
    except ImportError:
        return 0


async def periodic_cleanup() -> None:
    """Periodic cleanup task that runs in the background."""
    while True:
        try:
            await asyncio.sleep(CLEANUP_INTERVAL_SECONDS)
            
            sessions_cleaned = await cleanup_expired_sessions()
            
            pending_cleaned = await cleanup_pending_sessions_storage()
            
            rate_limit_cleaned = await cleanup_rate_limiter()
            
            gc_stats = await run_garbage_collection()
            
            _stats["last_cleanup"] = datetime.now().isoformat()
            
            if sessions_cleaned > 0 or pending_cleaned > 0 or rate_limit_cleaned > 0:
                logger.info(
                    f"Cleanup completed: {sessions_cleaned} sessions, "
                    f"{pending_cleaned} pending, {rate_limit_cleaned} rate limits"
                )
            
        except asyncio.CancelledError:
            logger.info("Periodic cleanup task cancelled")
            break
        except Exception as e:
            logger.error(f"Error in periodic cleanup: {e}")
            await asyncio.sleep(60)


async def start_memory_manager() -> None:
    """Start the memory manager background task."""
    global _cleanup_task
    
    if _cleanup_task is not None and not _cleanup_task.done():
        logger.warning("Memory manager already running")
        return
    
    _cleanup_task = asyncio.create_task(periodic_cleanup())
    logger.info("Memory manager started")


async def stop_memory_manager() -> None:
    """Stop the memory manager background task."""
    global _cleanup_task
    
    if _cleanup_task is not None:
        _cleanup_task.cancel()
        try:
            await _cleanup_task
        except asyncio.CancelledError:
            pass
        _cleanup_task = None
        logger.info("Memory manager stopped")


def get_manager_stats() -> Dict[str, Any]:
    """Get memory manager statistics."""
    return {
        **get_memory_usage(),
        "cleanup_interval_seconds": CLEANUP_INTERVAL_SECONDS,
        "session_ttl_seconds": SESSION_TTL_SECONDS,
        "max_active_sessions": MAX_ACTIVE_SESSIONS,
        "manager_running": _cleanup_task is not None and not _cleanup_task.done()
    }


async def force_cleanup() -> Dict[str, Any]:
    """Force an immediate cleanup cycle."""
    results = {
        "sessions_cleaned": await cleanup_expired_sessions(),
        "pending_cleaned": await cleanup_pending_sessions_storage(),
        "rate_limits_cleaned": await cleanup_rate_limiter(),
        "gc_stats": await run_garbage_collection(),
        "timestamp": datetime.now().isoformat()
    }
    
    _stats["last_cleanup"] = results["timestamp"]
    return results


async def check_memory_pressure() -> bool:
    """Check if memory usage is too high."""
    try:
        import resource
        usage = resource.getrusage(resource.RUSAGE_SELF)
        current_mb = usage.ru_maxrss / 1024
        
        if current_mb > MAX_CACHE_SIZE_MB * 2:
            logger.warning(f"High memory pressure: {current_mb:.1f} MB")
            return True
            
    except ImportError:
        pass
    
    if len(_active_sessions) > MAX_ACTIVE_SESSIONS * 0.9:
        logger.warning(f"High session count: {len(_active_sessions)}")
        return True
    
    return False


async def emergency_cleanup() -> Dict[str, Any]:
    """Emergency cleanup when memory pressure is detected."""
    logger.warning("Running emergency cleanup due to memory pressure")
    
    evicted = await _evict_oldest_sessions(count=500)
    
    gc.collect(2)
    
    results = await force_cleanup()
    results["emergency_evicted"] = evicted
    
    return results


print("✅ Memory Manager Module Loaded")
print(f"   Max active sessions: {MAX_ACTIVE_SESSIONS}")
print(f"   Session TTL: {SESSION_TTL_SECONDS}s")
print(f"   Cleanup interval: {CLEANUP_INTERVAL_SECONDS}s")
