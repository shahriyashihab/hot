"""
Pending Session Recovery System
===============================
When bot restarts, this module re-verifies all pending sessions
that have session_string but verification was not completed.

Features:
- Parallel processing (10 sessions at a time)
- Safe error handling (one failure doesn't affect others)
- Proper rate limiting to avoid Telegram blocks
- Sends appropriate messages: success/multi-device/rejected/spam
"""

import asyncio
import os
import time
from datetime import datetime
from typing import Dict, Any, List, Optional, Tuple
from pyrogram.client import Client
from pyrogram.errors import FloodWait, AuthKeyUnregistered, UserDeactivated, SessionRevoked

from bot import config
from bot.utils.storage import (
    get_all_pending_sessions,
    get_pending_session,
    update_pending_session_field,
    approve_pending_session,
    reject_pending_session,
    atomic_credit_balance_for_session,
    is_session_message_already_sent,
    try_claim_session_finalization,
    mark_session_finalization_claimed_by,
    mark_session_message_sent,
    get_country_rate as storage_get_country_rate,
    save_storage,
    format_message
)
from bot.utils.country_data import get_flag
from bot.utils.device_generator import generate_device_info
from bot.utils.session_handler import get_rotated_api, session_string_to_telethon
from bot.utils.fast_cache import sync_user_from_storage

PARALLEL_LIMIT = 5
DELAY_BETWEEN_BATCHES = 5.0
DELAY_BETWEEN_SESSIONS = 1.0
MAX_SESSION_AGE_HOURS = 72
NOTIFY_USERS_ON_RECOVERY = False
_recovery_semaphore = asyncio.Semaphore(5)
_api_rotation_lock = asyncio.Lock()


async def setup_2fa_for_recovery(client: Client, phone: str, twofa_password: str) -> Tuple[bool, str]:
    """
    Setup 2FA during recovery if not already done.
    
    Returns:
        (success, message)
    """
    try:
        for attempt in range(3):
            try:
                await client.enable_cloud_password(twofa_password)
                print(f"✅ RECOVERY 2FA: Successfully enabled for {phone}")
                return True, "2FA enabled"
            except FloodWait as e:
                wait_time = int(getattr(e, 'value', 60) or 60)
                if wait_time <= 60:
                    await asyncio.sleep(wait_time)
                else:
                    print(f"⚠️ RECOVERY 2FA: FloodWait too long: {wait_time}s for {phone}")
                    return False, f"FloodWait {wait_time}s"
            except Exception as e:
                error_str = str(e).upper()
                if "PASSWORD_HASH_INVALID" in error_str or "SRP_ID_INVALID" in error_str:
                    print(f"✅ RECOVERY 2FA: Already has 2FA for {phone}")
                    return True, "2FA already exists"
                if "FRESH_CHANGE_PASSWORD_FORBIDDEN" in error_str:
                    print(f"⚠️ RECOVERY 2FA: Fresh session, 2FA restricted for {phone}")
                    return True, "2FA restricted on fresh session"
                if attempt < 2:
                    await asyncio.sleep(2)
                else:
                    print(f"⚠️ RECOVERY 2FA: Failed for {phone}: {e}")
                    return False, str(e)
        return False, "Max attempts reached"
    except Exception as e:
        print(f"❌ RECOVERY 2FA: Error for {phone}: {e}")
        return False, str(e)


async def check_session_validity_with_2fa(
    session_string: str, 
    api_id: int, 
    api_hash: str,
    twofa_password: str,
    twofa_already_done: bool = False,
    phone: str = "UNKNOWN"
) -> Tuple[bool, str, Dict]:
    """
    ENHANCED: Check session validity AND setup 2FA if not done.
    
    Full recovery verification:
    1. Check session validity
    2. Setup 2FA (if not already done)
    3. Check spam status
    4. Check multi-device
    
    Returns:
        (is_valid, spam_status, details)
    """
    details = {
        "device_count": 1,
        "has_extra_devices": False,
        "spam_status": "limit",
        "is_valid": True,
        "error": None,
        "twofa_setup": False,
        "twofa_result": None
    }
    
    temp_client = None
    
    try:
        device_info = generate_device_info()
        temp_client = Client(
            name=f"recovery_full_{int(time.time() * 1000)}",
            api_id=api_id,
            api_hash=api_hash,
            session_string=session_string,
            in_memory=True,
            device_model=device_info["device_model"],
            system_version=device_info["system_version"],
            app_version="Telegram Android 10.14.5"
        )
        
        await temp_client.connect()
        
        try:
            me = await temp_client.get_me()
            if not me:
                details["is_valid"] = False
                details["error"] = "Account not found"
                await temp_client.disconnect()
                return False, "invalid", details
        except Exception as e:
            error_str = str(e).upper()
            if any(x in error_str for x in ["AUTH_KEY", "UNREGISTERED", "INVALID", "BANNED", "DEACTIVAT", "REVOKED"]):
                details["is_valid"] = False
                details["error"] = str(e)
                try:
                    await temp_client.disconnect()
                except:
                    pass
                return False, "invalid", details
        
        if not twofa_already_done:
            print(f"🔐 RECOVERY: Setting up 2FA for {phone}...")
            twofa_success, twofa_msg = await setup_2fa_for_recovery(temp_client, phone, twofa_password)
            details["twofa_setup"] = twofa_success
            details["twofa_result"] = twofa_msg
        else:
            details["twofa_setup"] = True
            details["twofa_result"] = "Already completed before restart"
            print(f"✅ RECOVERY: 2FA was already done for {phone}")
        
        try:
            print(f"🔍 RECOVERY: Checking spam status for {phone}...")
            await temp_client.send_message("spambot", "/start")
            await asyncio.sleep(2.5)
            
            messages = []
            try:
                async for msg in temp_client.get_chat_history("spambot", limit=3):
                    if msg.from_user and msg.from_user.is_bot:
                        messages.append(msg.text or "")
            except:
                pass
            
            if messages:
                spambot_response = " ".join(messages).lower()
                if "good news" in spambot_response or "no limits" in spambot_response or "free as a bird" in spambot_response:
                    details["spam_status"] = "spam_free"
                    print(f"✅ RECOVERY: {phone} is SPAM FREE")
                elif "limited until" in spambot_response:
                    details["spam_status"] = "limit"
                    print(f"⚠️ RECOVERY: {phone} has LIMIT")
                else:
                    details["spam_status"] = "spam"
                    print(f"❌ RECOVERY: {phone} is SPAM")
        except Exception as spam_err:
            print(f"⚠️ RECOVERY: Spam check failed for {phone}: {spam_err}")
            details["spam_status"] = "limit"
        
        try:
            print(f"📱 RECOVERY: Checking multi-device for {phone}...")
            from pyrogram.raw.functions.account.get_authorizations import GetAuthorizations
            auth_sessions = await temp_client.invoke(GetAuthorizations())
            
            if auth_sessions and hasattr(auth_sessions, 'authorizations'):
                details["device_count"] = len(auth_sessions.authorizations)
                if details["device_count"] > 1:
                    details["has_extra_devices"] = True
                    print(f"📱 RECOVERY: {phone} has {details['device_count']} devices (MULTI-DEVICE)")
                else:
                    print(f"✅ RECOVERY: {phone} has only 1 device")
        except Exception as device_err:
            error_str = str(device_err).upper()
            if any(x in error_str for x in ["AUTH_KEY", "UNREGISTERED", "INVALID", "BANNED", "DEACTIVAT"]):
                details["is_valid"] = False
                details["error"] = str(device_err)
            print(f"⚠️ RECOVERY: Multi-device check warning for {phone}: {device_err}")
        
        try:
            await temp_client.disconnect()
        except:
            pass
        
        return details["is_valid"], details["spam_status"], details
        
    except (AuthKeyUnregistered, UserDeactivated, SessionRevoked) as e:
        details["is_valid"] = False
        details["error"] = str(e)
        return False, "invalid", details
    except FloodWait as e:
        wait_time = getattr(e, 'value', 30) or 30
        print(f"⚠️ RECOVERY: FloodWait {wait_time}s for {phone}")
        details["error"] = f"FloodWait {wait_time}s"
        details["is_valid"] = False
        return False, "flood_wait", details
    except Exception as e:
        print(f"⚠️ RECOVERY: Session check error for {phone}: {e}")
        details["error"] = str(e)
        details["is_valid"] = False
        error_str = str(e).upper()
        if any(x in error_str for x in ["AUTH_KEY", "UNREGISTERED", "INVALID", "BANNED", "DEACTIVAT", "REVOKED"]):
            return False, "invalid", details
        return False, "error", details
    finally:
        if temp_client:
            try:
                await temp_client.disconnect()
            except:
                pass


async def check_session_validity(session_string: str, api_id: int, api_hash: str) -> Tuple[bool, str, Dict]:
    """
    Check if a session is still valid and get spam/device status.
    (Legacy function - kept for compatibility)
    
    Returns:
        (is_valid, spam_status, details)
    """
    details = {
        "device_count": 1,
        "has_extra_devices": False,
        "spam_status": "limit",
        "is_valid": True,
        "error": None
    }
    
    try:
        device_info = generate_device_info()
        temp_client = Client(
            name=f"recovery_check_{int(time.time() * 1000)}",
            api_id=api_id,
            api_hash=api_hash,
            session_string=session_string,
            in_memory=True,
            device_model=device_info["device_model"],
            system_version=device_info["system_version"],
            app_version="Telegram Android 10.14.5"
        )
        
        await temp_client.connect()
        
        try:
            me = await temp_client.get_me()
            if not me:
                details["is_valid"] = False
                details["error"] = "Account not found"
                await temp_client.disconnect()
                return False, "invalid", details
        except Exception as e:
            error_str = str(e).upper()
            if any(x in error_str for x in ["AUTH_KEY", "UNREGISTERED", "INVALID", "BANNED", "DEACTIVAT", "REVOKED"]):
                details["is_valid"] = False
                details["error"] = str(e)
                try:
                    await temp_client.disconnect()
                except:
                    pass
                return False, "invalid", details
        
        try:
            await temp_client.send_message("spambot", "/start")
            await asyncio.sleep(2)
            
            messages = []
            try:
                async for msg in temp_client.get_chat_history("spambot", limit=3):
                    if msg.from_user and msg.from_user.is_bot:
                        messages.append(msg.text or "")
            except:
                pass
            
            if messages:
                spambot_response = " ".join(messages).lower()
                if "good news" in spambot_response or "no limits" in spambot_response or "free as a bird" in spambot_response:
                    details["spam_status"] = "spam_free"
                elif "limited until" in spambot_response:
                    details["spam_status"] = "limit"
                else:
                    details["spam_status"] = "spam"
        except Exception as spam_err:
            print(f"⚠️ RECOVERY: Spam check failed: {spam_err}")
            details["spam_status"] = "limit"
        
        try:
            from pyrogram.raw.functions.account.get_authorizations import GetAuthorizations
            auth_sessions = await temp_client.invoke(GetAuthorizations())
            
            if auth_sessions and hasattr(auth_sessions, 'authorizations'):
                details["device_count"] = len(auth_sessions.authorizations)
                if details["device_count"] > 1:
                    details["has_extra_devices"] = True
        except Exception as device_err:
            error_str = str(device_err).upper()
            if any(x in error_str for x in ["AUTH_KEY", "UNREGISTERED", "INVALID", "BANNED", "DEACTIVAT"]):
                details["is_valid"] = False
                details["error"] = str(device_err)
        
        try:
            await temp_client.disconnect()
        except:
            pass
        
        return details["is_valid"], details["spam_status"], details
        
    except (AuthKeyUnregistered, UserDeactivated, SessionRevoked) as e:
        details["is_valid"] = False
        details["error"] = str(e)
        return False, "invalid", details
    except FloodWait as e:
        wait_time = getattr(e, 'value', 30) or 30
        print(f"⚠️ RECOVERY: FloodWait {wait_time}s - marking as unverified")
        details["error"] = f"FloodWait {wait_time}s"
        details["is_valid"] = False
        return False, "flood_wait", details
    except Exception as e:
        print(f"⚠️ RECOVERY: Session check error: {e}")
        details["error"] = str(e)
        details["is_valid"] = False
        error_str = str(e).upper()
        if any(x in error_str for x in ["AUTH_KEY", "UNREGISTERED", "INVALID", "BANNED", "DEACTIVAT", "REVOKED"]):
            return False, "invalid", details
        return False, "error", details


async def recover_single_session(
    session_id: str,
    session_data: Dict[str, Any],
    bot_client: Client
) -> Tuple[bool, str]:
    """
    Recover a single pending session with rate limiting via semaphore.
    Uses lock to ensure unique API credentials per task.
    
    Returns:
        (success, result_type) - result_type: SUCCESS, MULTI-DEVICE, REJECTED
    """
    async with _recovery_semaphore:
        async with _api_rotation_lock:
            api_id, api_hash, api_name = get_rotated_api()
            await asyncio.sleep(DELAY_BETWEEN_SESSIONS)
        return await _recover_single_session_impl(session_id, session_data, bot_client, api_id, api_hash)


async def _recover_single_session_impl(
    session_id: str,
    session_data: Dict[str, Any],
    bot_client: Client,
    api_id: int,
    api_hash: str
) -> Tuple[bool, str]:
    """
    Internal implementation of single session recovery.
    
    ENHANCED v2.0: Full verification flow during recovery:
    1. Session validity check
    2. 2FA setup (if not done before restart)
    3. Spam check
    4. Multi-device check
    5. Send appropriate message to user
    """
    try:
        phone = session_data.get("phone", "UNKNOWN")
        user_id = session_data.get("user_id")
        country_code = session_data.get("country_code", "UNKNOWN")
        
        inner_session_data = session_data.get("session_data", {})
        
        # CRITICAL: session_string is stored at ROOT level, not inside session_data!
        session_string = (
            session_data.get("session_string") or  # ROOT level (where it's actually stored)
            inner_session_data.get("session_string")  # Fallback check inside session_data
        )
        
        twofa_already_done = inner_session_data.get("twofa_completed", False) or inner_session_data.get("twofa_enabled", False)
        twofa_password = session_data.get("twofa_password") or inner_session_data.get("2fa_password") or config.SESSION_2FA_PASSWORD
        
        if not session_string:
            # Check for session file at ROOT level and inside session_data
            session_file = session_data.get("session_file") or inner_session_data.get("session_file")
            if session_file and os.path.exists(session_file):
                try:
                    with open(session_file, 'r') as f:
                        session_string = f.read().strip()
                except:
                    pass
        
        if not session_string:
            print(f"❌ RECOVERY: No session_string for {phone} - skipping")
            return False, "NO_SESSION"
        
        if not user_id:
            print(f"❌ RECOVERY: No user_id for {phone} - skipping")
            return False, "NO_USER"
        
        if is_session_message_already_sent(session_id):
            print(f"⏭️ RECOVERY: Message already sent for {phone} - skipping")
            return True, "ALREADY_SENT"
        
        claimed = try_claim_session_finalization(session_id)
        if not claimed:
            print(f"⏭️ RECOVERY: Already being processed {phone} - skipping")
            return True, "ALREADY_CLAIMED"
        
        mark_session_finalization_claimed_by(session_id, "pending_recovery")
        
        print(f"🔄 RECOVERY: Processing {phone} (user: {user_id})")
        print(f"   - 2FA already done: {twofa_already_done}")
        print(f"   - Using enhanced recovery with full verification flow")
        
        # CRITICAL: Get the original message ID to EDIT instead of sending new message
        # Check multiple possible locations where the message ID could be stored
        # IMPORTANT: user_message_id is stored at ROOT level, not inside session_data!
        cached_msg_id = (
            # ROOT level (where user_message_id is actually stored after account_received)
            session_data.get("user_message_id") or
            session_data.get("message_id") or
            session_data.get("phone_message_id") or
            # Inside session_data dict (backup locations)
            inner_session_data.get("user_message_id") or
            inner_session_data.get("cached_msg_id") or
            inner_session_data.get("session_specific_message_id")
        )
        print(f"   - Cached message ID for editing: {cached_msg_id}")
        
        # Check if session already has precomputed message from before restart
        precomputed_message = inner_session_data.get("precomputed_message")
        ready_to_send = inner_session_data.get("ready_to_send", False)
        device_check_done = inner_session_data.get("device_check_completed", False)
        precomputed_type = inner_session_data.get("message_type")
        
        # Flag to track if precomputed message was successfully sent
        precomputed_sent = False
        
        if ready_to_send and device_check_done and precomputed_message and precomputed_type:
            print(f"✅ RECOVERY: Found precomputed message for {phone} - sending directly")
            try:
                # CRITICAL: Try to EDIT original message first, only send new if edit fails
                message_sent = False
                if cached_msg_id and int(cached_msg_id) > 0:
                    try:
                        await bot_client.edit_message_text(
                            chat_id=int(user_id),
                            message_id=int(cached_msg_id),
                            text=precomputed_message
                        )
                        message_sent = True
                        print(f"✅ RECOVERY: EDITED original message for {phone}")
                    except Exception as edit_err:
                        print(f"⚠️ RECOVERY: Edit failed, sending new: {edit_err}")
                
                if not message_sent:
                    await bot_client.send_message(chat_id=int(user_id), text=precomputed_message)
                    print(f"✅ RECOVERY: Sent NEW message for {phone}")
                
                mark_session_message_sent(session_id, True)
                print(f"✅ RECOVERY: Precomputed {precomputed_type} message sent for {phone}")
                precomputed_sent = True
                
                # Use precomputed values instead of re-verification
                spam_status = inner_session_data.get("spam_status", "limit")
                has_extra_devices = inner_session_data.get("has_extra_devices", False)
                
                # Determine validity based on precomputed message type
                if precomputed_type == "REJECTED":
                    is_valid = False
                else:
                    is_valid = True
                
                # Create a details dict for compatibility with downstream code
                details = {
                    "has_extra_devices": has_extra_devices,
                    "spam_status": spam_status,
                    "device_count": inner_session_data.get("device_count", 1),
                    "is_valid": is_valid
                }
            except Exception as pre_err:
                print(f"⚠️ RECOVERY: Precomputed message send failed: {pre_err} - will re-verify")
                precomputed_sent = False
        
        # Only do full verification if precomputed message was not sent
        if not precomputed_sent:
            is_valid, spam_status, details = await check_session_validity_with_2fa(
                session_string=session_string,
                api_id=api_id,
                api_hash=api_hash,
                twofa_password=twofa_password,
                twofa_already_done=twofa_already_done,
                phone=phone
            )
            
            if details.get("twofa_setup"):
                try:
                    update_pending_session_field(session_id, "twofa_completed", True)
                    update_pending_session_field(session_id, "twofa_enabled", True)
                    print(f"✅ RECOVERY: 2FA status saved for {phone}")
                except Exception as save_err:
                    print(f"⚠️ RECOVERY: Could not save 2FA status: {save_err}")
        
        flag = get_flag(country_code)
        has_extra_devices = details.get("has_extra_devices", False)
        
        if not is_valid:
            message_type = "REJECTED"
            
            # Only send user message if not already sent via precomputed
            if not precomputed_sent:
                final_message = format_message(
                    "verification_failed_message",
                    phone=phone,
                    country_code=country_code,
                    flag=flag
                )
                
                try:
                    # CRITICAL: Try to EDIT original message first
                    message_sent = False
                    if cached_msg_id and int(cached_msg_id) > 0:
                        try:
                            await bot_client.edit_message_text(
                                chat_id=int(user_id),
                                message_id=int(cached_msg_id),
                                text=final_message
                            )
                            message_sent = True
                            print(f"✅ RECOVERY: EDITED original message for rejection")
                        except Exception:
                            pass
                    
                    if not message_sent:
                        await bot_client.send_message(chat_id=int(user_id), text=final_message)
                    
                    mark_session_message_sent(session_id, True)
                    print(f"❌ RECOVERY: {phone} REJECTED - session invalid")
                except Exception as send_err:
                    print(f"⚠️ RECOVERY: Failed to send rejection to {user_id}: {send_err}")
            else:
                print(f"❌ RECOVERY: {phone} REJECTED - precomputed message already sent")
            
            # Always reject the session
            reject_pending_session(session_id, "Session invalid")
            
            # Always send channel report and session file
            try:
                if config.CHANNEL_REJECTED:
                    rejection_report = (
                        f"❌ **Session Rejected**\n\n"
                        f"📱 Phone: {phone}\n"
                        f"🌍 Country: {country_code} {flag}\n"
                        f"⚠️ Reason: Session invalid\n"
                        f"⏰ Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
                    )
                    
                    session_file_sent = False
                    os.makedirs("sessions", exist_ok=True)
                    
                    try:
                        temp_telethon_file = f"sessions/{phone}_{int(datetime.now().timestamp() * 1000)}_rejected_telethon.session"
                        result = await asyncio.to_thread(
                            session_string_to_telethon,
                            session_string,
                            temp_telethon_file,
                            None, phone, None, None
                        )
                        if result and os.path.exists(temp_telethon_file):
                            await bot_client.send_document(
                                chat_id=config.CHANNEL_REJECTED,
                                document=temp_telethon_file,
                                caption=rejection_report
                            )
                            session_file_sent = True
                            print(f"📤 RECOVERY: Session file sent to CHANNEL_REJECTED for {phone}")
                    except Exception as tel_err:
                        print(f"⚠️ RECOVERY: Telethon file error: {tel_err}")
                    
                    if not session_file_sent:
                        try:
                            temp_session_file = f"sessions/{phone}_{int(datetime.now().timestamp() * 1000)}_rejected.session"
                            with open(temp_session_file, 'w') as f:
                                f.write(session_string)
                            await bot_client.send_document(
                                chat_id=config.CHANNEL_REJECTED,
                                document=temp_session_file,
                                caption=rejection_report
                            )
                            session_file_sent = True
                            print(f"📤 RECOVERY: Pyrogram session file sent to CHANNEL_REJECTED for {phone}")
                        except Exception as pyr_err:
                            print(f"⚠️ RECOVERY: Pyrogram file error: {pyr_err}")
                    
                    if not session_file_sent:
                        await bot_client.send_message(
                            chat_id=config.CHANNEL_REJECTED,
                            text=rejection_report
                        )
            except Exception as ch_err:
                print(f"⚠️ RECOVERY: Channel report error: {ch_err}")
            
            return True, "REJECTED"
        
        elif has_extra_devices:
            message_type = "MULTI-DEVICE"
            
            # Only send user message if not already sent via precomputed
            if not precomputed_sent:
                final_message = format_message(
                    "multi_device_message",
                    phone=phone
                )
                
                try:
                    # CRITICAL: Try to EDIT original message first
                    message_sent = False
                    if cached_msg_id and int(cached_msg_id) > 0:
                        try:
                            await bot_client.edit_message_text(
                                chat_id=int(user_id),
                                message_id=int(cached_msg_id),
                                text=final_message
                            )
                            message_sent = True
                            print(f"✅ RECOVERY: EDITED original message for multi-device")
                        except Exception:
                            pass
                    
                    if not message_sent:
                        await bot_client.send_message(chat_id=int(user_id), text=final_message)
                    
                    mark_session_message_sent(session_id, True)
                    print(f"📱 RECOVERY: {phone} MULTI-DEVICE")
                except Exception as send_err:
                    print(f"⚠️ RECOVERY: Failed to send multi-device to {user_id}: {send_err}")
            else:
                print(f"📱 RECOVERY: {phone} MULTI-DEVICE - precomputed message already sent")
            
            # Always send channel report and session file
            try:
                if config.CHANNEL_24HR_UP:
                    multi_report = (
                        f"📱 **Multiple Devices**\n\n"
                        f"📱 Phone: {phone}\n"
                        f"🌍 Country: {country_code} {flag}\n"
                        f"📱 Devices: {details.get('device_count', 'Unknown')}\n"
                        f"⏰ Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
                    )
                    
                    session_file_sent = False
                    os.makedirs("sessions", exist_ok=True)
                    
                    try:
                        temp_telethon_file = f"sessions/{phone}_{int(datetime.now().timestamp() * 1000)}_multidevice_telethon.session"
                        result = await asyncio.to_thread(
                            session_string_to_telethon,
                            session_string,
                            temp_telethon_file,
                            None, phone, None, None
                        )
                        if result and os.path.exists(temp_telethon_file):
                            await bot_client.send_document(
                                chat_id=config.CHANNEL_24HR_UP,
                                document=temp_telethon_file,
                                caption=multi_report
                            )
                            session_file_sent = True
                            print(f"📤 RECOVERY: Session file sent to CHANNEL_24HR_UP for {phone}")
                    except Exception as tel_err:
                        print(f"⚠️ RECOVERY: Telethon file error: {tel_err}")
                    
                    if not session_file_sent:
                        try:
                            temp_session_file = f"sessions/{phone}_{int(datetime.now().timestamp() * 1000)}_multidevice.session"
                            with open(temp_session_file, 'w') as f:
                                f.write(session_string)
                            await bot_client.send_document(
                                chat_id=config.CHANNEL_24HR_UP,
                                document=temp_session_file,
                                caption=multi_report
                            )
                            session_file_sent = True
                            print(f"📤 RECOVERY: Pyrogram session file sent to CHANNEL_24HR_UP for {phone}")
                        except Exception as pyr_err:
                            print(f"⚠️ RECOVERY: Pyrogram file error: {pyr_err}")
                    
                    if not session_file_sent:
                        await bot_client.send_message(
                            chat_id=config.CHANNEL_24HR_UP,
                            text=multi_report
                        )
            except Exception as ch_err:
                print(f"⚠️ RECOVERY: Channel report error: {ch_err}")
            
            return True, "MULTI-DEVICE"
        
        else:
            message_type = "SUCCESS"
            rate = storage_get_country_rate(country_code, spam_status)
            
            spam_display = {
                "spam_free": "✅ Spam Free",
                "spam": "⚠️ Spam",
                "limit": "🔒 Limit"
            }.get(spam_status, "🔒 Limit")
            
            # Always credit balance and approve session
            try:
                credit_success = atomic_credit_balance_for_session(session_id, int(user_id), rate)
                if credit_success:
                    sync_user_from_storage(int(user_id))
                    print(f"💰 RECOVERY: ${rate} credited to user {user_id}")
            except Exception as credit_err:
                print(f"⚠️ RECOVERY: Failed to credit balance: {credit_err}")
            
            # Only send user message if not already sent via precomputed
            if not precomputed_sent:
                final_message = format_message(
                    "success_message",
                    phone=phone,
                    price=f"{rate:.2f}",
                    status=spam_display
                )
                
                try:
                    # CRITICAL: Try to EDIT original message first
                    message_sent = False
                    if cached_msg_id and int(cached_msg_id) > 0:
                        try:
                            await bot_client.edit_message_text(
                                chat_id=int(user_id),
                                message_id=int(cached_msg_id),
                                text=final_message
                            )
                            message_sent = True
                            print(f"✅ RECOVERY: EDITED original message for success")
                        except Exception:
                            pass
                    
                    if not message_sent:
                        await bot_client.send_message(chat_id=int(user_id), text=final_message)
                    
                    mark_session_message_sent(session_id, True)
                    print(f"✅ RECOVERY: {phone} SUCCESS - ${rate} ({spam_status})")
                except Exception as send_err:
                    print(f"⚠️ RECOVERY: Failed to send success to {user_id}: {send_err}")
            else:
                print(f"✅ RECOVERY: {phone} SUCCESS - ${rate} ({spam_status}) - precomputed message already sent")
            
            # Always approve the session
            approve_pending_session(session_id)
            
            # Always send channel report and session file
            try:
                if config.CHANNEL_VERIFIED:
                    success_report = (
                        f"✅ **Session Verified**\n\n"
                        f"📱 Phone: {phone}\n"
                        f"🌍 Country: {country_code} {flag}\n"
                        f"📊 Status: {spam_display}\n"
                        f"💰 Rate: ${rate:.2f}\n"
                        f"⏰ Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
                    )
                    
                    session_file_sent = False
                    os.makedirs("sessions", exist_ok=True)
                    
                    try:
                        temp_telethon_file = f"sessions/{phone}_{int(datetime.now().timestamp() * 1000)}_telethon.session"
                        result = await asyncio.to_thread(
                            session_string_to_telethon,
                            session_string,
                            temp_telethon_file,
                            None, phone, None, None
                        )
                        if result and os.path.exists(temp_telethon_file):
                            await bot_client.send_document(
                                chat_id=config.CHANNEL_VERIFIED,
                                document=temp_telethon_file,
                                caption=success_report
                            )
                            session_file_sent = True
                            print(f"📤 RECOVERY: Session file sent to CHANNEL_VERIFIED for {phone}")
                    except Exception as tel_err:
                        print(f"⚠️ RECOVERY: Telethon file error: {tel_err}")
                    
                    if not session_file_sent:
                        try:
                            temp_session_file = f"sessions/{phone}_{int(datetime.now().timestamp() * 1000)}.session"
                            with open(temp_session_file, 'w') as f:
                                f.write(session_string)
                            await bot_client.send_document(
                                chat_id=config.CHANNEL_VERIFIED,
                                document=temp_session_file,
                                caption=success_report
                            )
                            session_file_sent = True
                            print(f"📤 RECOVERY: Pyrogram session file sent to CHANNEL_VERIFIED for {phone}")
                        except Exception as pyr_err:
                            print(f"⚠️ RECOVERY: Pyrogram file error: {pyr_err}")
                    
                    if not session_file_sent:
                        await bot_client.send_message(
                            chat_id=config.CHANNEL_VERIFIED,
                            text=success_report
                        )
            except Exception as ch_err:
                print(f"⚠️ RECOVERY: Channel report error: {ch_err}")
            
            # Always log transaction
            try:
                from bot.utils.database import log_transaction
                asyncio.create_task(log_transaction(
                    user_id=int(user_id),
                    action="session_verified",
                    amount=rate,
                    session_id=session_id,
                    country_code=country_code,
                    phone_number=phone,
                    spam_status=spam_status
                ))
            except:
                pass
            
            return True, "SUCCESS"
            
    except Exception as e:
        print(f"❌ RECOVERY: Error processing {session_id}: {e}")
        return False, f"ERROR: {e}"


def get_pending_sessions_for_recovery() -> List[Tuple[str, Dict]]:
    """
    Get all pending sessions that need recovery.
    
    ENHANCED CRITERIA - Include ALL sessions with session_string:
    - Status is 'pending'
    - Has session_string or session_file
    - Message not successfully sent yet
    - Not older than MAX_SESSION_AGE_HOURS
    
    CRITICAL: Do NOT skip ready_to_send sessions - they also need recovery!
    If session has precomputed_message, we'll send it directly.
    If not, we'll re-verify and send appropriate message.
    """
    all_pending = get_all_pending_sessions()
    recovery_list = []
    
    cutoff = datetime.now()
    
    for session_id, session_data in all_pending.items():
        try:
            if session_data.get("status") != "pending":
                continue
            
            inner_data = session_data.get("session_data", {})
            
            if inner_data.get("message_send_success") == True:
                continue
            
            # CRITICAL: session_string is stored at ROOT level, not inside session_data!
            session_string = (
                session_data.get("session_string") or  # ROOT level (where it's actually stored)
                inner_data.get("session_string")  # Fallback check inside session_data
            )
            session_file = session_data.get("session_file") or inner_data.get("session_file")
            
            has_session = bool(session_string)
            if not has_session and session_file:
                has_session = os.path.exists(session_file)
            
            if not has_session:
                continue
            
            submitted_str = session_data.get("submitted_at")
            if submitted_str:
                try:
                    submitted_at = datetime.fromisoformat(submitted_str)
                    age_hours = (cutoff - submitted_at).total_seconds() / 3600
                    if age_hours > MAX_SESSION_AGE_HOURS:
                        continue
                except:
                    pass
            
            recovery_list.append((session_id, session_data))
            
        except Exception as e:
            print(f"⚠️ RECOVERY: Error checking session {session_id}: {e}")
            continue
    
    recovery_list.sort(
        key=lambda x: x[1].get("submitted_at", ""),
        reverse=True
    )
    
    return recovery_list


async def notify_users_recovery_starting(
    bot_client: Client,
    recovery_list: List[Tuple[str, Dict]]
) -> Dict[int, bool]:
    """
    Notify users that their pending sessions are being recovered.
    Groups sessions by user_id and sends one message per user.
    Has FloodWait handling for large user notifications.
    """
    notified = {}
    user_sessions = {}
    
    for session_id, session_data in recovery_list:
        user_id = session_data.get("user_id")
        if user_id:
            user_id = int(user_id)
            if user_id not in user_sessions:
                user_sessions[user_id] = []
            user_sessions[user_id].append(session_data.get("phone", "Unknown"))
    
    for user_id, phones in user_sessions.items():
        phone_list = "\n".join([f"  📱 {p}" for p in phones[:5]])
        if len(phones) > 5:
            phone_list += f"\n  ...এবং আরো {len(phones) - 5}টি"
        
        notify_msg = (
            f"🔄 **ভেরিফিকেশন রিকভারি চলছে**\n\n"
            f"আপনার {len(phones)}টি সেশন ভেরিফাই হচ্ছে:\n"
            f"{phone_list}\n\n"
            f"⏳ অনুগ্রহ করে অপেক্ষা করুন...\n"
            f"ফলাফল শীঘ্রই জানানো হবে।"
        )
        try:
            await bot_client.send_message(chat_id=user_id, text=notify_msg)
            notified[user_id] = True
            await asyncio.sleep(0.3)
        except FloodWait as fw:
            wait_time = getattr(fw, 'value', 10) or 10
            print(f"⚠️ RECOVERY NOTIFY: FloodWait {wait_time}s for user {user_id}")
            if wait_time <= 30:
                await asyncio.sleep(wait_time + 1)
                try:
                    await bot_client.send_message(chat_id=user_id, text=notify_msg)
                    notified[user_id] = True
                except:
                    notified[user_id] = False
            else:
                notified[user_id] = False
        except Exception as e:
            print(f"⚠️ RECOVERY: Could not notify user {user_id}: {e}")
            notified[user_id] = False
    
    return notified


async def run_pending_recovery(bot_client: Client, max_time_minutes: int = 10) -> Dict[str, int]:
    """
    Main recovery function - runs when bot starts.
    
    Args:
        bot_client: The main bot client
        max_time_minutes: Maximum time to run recovery (default 10 minutes)
    
    Returns:
        Stats dict with counts of success, rejected, multi-device, errors
    """
    stats = {
        "total": 0,
        "success": 0,
        "rejected": 0,
        "multi_device": 0,
        "skipped": 0,
        "errors": 0
    }
    
    start_time = time.time()
    max_time_seconds = max_time_minutes * 60
    
    print("=" * 50)
    print("🔄 PENDING SESSION RECOVERY STARTED")
    print("=" * 50)
    
    recovery_list = get_pending_sessions_for_recovery()
    stats["total"] = len(recovery_list)
    
    if not recovery_list:
        print("✅ No pending sessions need recovery")
        print("=" * 50)
        return stats
    
    print(f"📋 Found {len(recovery_list)} sessions to recover")
    
    if NOTIFY_USERS_ON_RECOVERY and len(recovery_list) > 0:
        print("📨 Notifying users about pending recovery...")
        try:
            await notify_users_recovery_starting(bot_client, recovery_list)
            print("✅ Users notified")
        except Exception as notify_err:
            print(f"⚠️ User notification error: {notify_err}")
    
    for i in range(0, len(recovery_list), PARALLEL_LIMIT):
        if time.time() - start_time > max_time_seconds:
            print(f"⏰ RECOVERY: Time limit reached ({max_time_minutes} minutes)")
            break
        
        batch = recovery_list[i:i + PARALLEL_LIMIT]
        batch_num = i // PARALLEL_LIMIT + 1
        total_batches = (len(recovery_list) + PARALLEL_LIMIT - 1) // PARALLEL_LIMIT
        
        print(f"\n📦 Processing batch {batch_num}/{total_batches} ({len(batch)} sessions)")
        
        tasks = []
        for session_id, session_data in batch:
            task = asyncio.create_task(
                recover_single_session(session_id, session_data, bot_client)
            )
            tasks.append(task)
        
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        for result in results:
            if isinstance(result, Exception):
                stats["errors"] += 1
                print(f"❌ RECOVERY: Task exception: {result}")
            elif isinstance(result, tuple):
                success, result_type = result
                if result_type == "SUCCESS":
                    stats["success"] += 1
                elif result_type == "REJECTED":
                    stats["rejected"] += 1
                elif result_type == "MULTI-DEVICE":
                    stats["multi_device"] += 1
                elif result_type in ["ALREADY_SENT", "ALREADY_CLAIMED", "NO_SESSION", "NO_USER"]:
                    stats["skipped"] += 1
                else:
                    stats["errors"] += 1
        
        if i + PARALLEL_LIMIT < len(recovery_list):
            await asyncio.sleep(DELAY_BETWEEN_BATCHES)
    
    elapsed = time.time() - start_time
    
    print("\n" + "=" * 50)
    print("🔄 PENDING SESSION RECOVERY COMPLETED")
    print("=" * 50)
    print(f"⏱️ Time: {elapsed:.1f} seconds")
    print(f"📊 Total: {stats['total']}")
    print(f"✅ Success: {stats['success']}")
    print(f"❌ Rejected: {stats['rejected']}")
    print(f"📱 Multi-Device: {stats['multi_device']}")
    print(f"⏭️ Skipped: {stats['skipped']}")
    print(f"⚠️ Errors: {stats['errors']}")
    print("=" * 50)
    
    return stats


EXPIRED_NO_OTP_MINUTES = 3
EXPIRED_SESSION_WITH_SESSION_STRING_HOURS = 72


def _safe_int(value, default: int = 0) -> int:
    """Safely convert value to int, return default if fails."""
    if value is None:
        return default
    try:
        return int(value)
    except (ValueError, TypeError):
        return default


async def cleanup_no_otp_sessions(bot_client: Client = None) -> int:
    """
    Simple cleanup: Delete sessions where OTP was never given (no session_string).
    
    - If no OTP within 3 minutes → silently delete the session
    - No notification needed - user didn't complete OTP anyway
    - Fast and efficient
    
    Returns:
        Number of sessions deleted
    """
    from bot.utils.storage import _storage, save_storage
    
    all_pending = get_all_pending_sessions()
    now = datetime.now()
    deleted_count = 0
    
    for session_id, session_data in list(all_pending.items()):
        if session_data.get("status") != "pending":
            continue
        
        inner_data = session_data.get("session_data", {})
        session_string = session_data.get("session_string") or inner_data.get("session_string")
        
        if session_string:
            continue
        
        submitted_str = session_data.get("submitted_at") or session_data.get("created_at")
        if not submitted_str:
            continue
        
        try:
            clean_str = submitted_str.replace("Z", "").replace("+00:00", "")
            submitted_at = datetime.fromisoformat(clean_str)
        except (ValueError, TypeError):
            continue
        
        age_minutes = (now - submitted_at).total_seconds() / 60
        
        if age_minutes > EXPIRED_NO_OTP_MINUTES:
            try:
                phone = session_data.get("phone", "Unknown")
                if session_id in _storage.get("pending_sessions", {}):
                    del _storage["pending_sessions"][session_id]
                    deleted_count += 1
                    print(f"🗑️ AUTO-DELETE: {phone} - no OTP after {int(age_minutes)} min")
            except Exception as e:
                print(f"⚠️ Delete error: {e}")
    
    if deleted_count > 0:
        save_storage()
        print(f"🧹 Deleted {deleted_count} sessions (no OTP given)")
    
    return deleted_count


async def finalize_expired_sessions(bot_client: Client) -> Dict[str, int]:
    """
    Handle stuck sessions that have session_string but somehow weren't processed.
    
    Only handles:
    - Sessions WITH session_string older than 72 hours → Reject (stuck for too long)
    
    For sessions WITHOUT session_string:
    - cleanup_no_otp_sessions() handles them (silent delete after 3 min)
    
    Returns:
        Stats dict with counts
    """
    stats = {
        "total_checked": 0,
        "deleted_no_otp": 0,
        "expired_old": 0,
        "already_done": 0,
        "already_claimed": 0,
        "notify_failed": 0,
        "errors": 0
    }
    
    deleted = await cleanup_no_otp_sessions(bot_client)
    stats["deleted_no_otp"] = deleted
    
    all_pending = get_all_pending_sessions()
    now = datetime.now()
    
    sessions_to_expire = []
    
    for session_id, session_data in all_pending.items():
        stats["total_checked"] += 1
        
        if session_data.get("status") != "pending":
            continue
        
        inner_data = session_data.get("session_data", {})
        
        if inner_data.get("message_send_success") == True:
            stats["already_done"] += 1
            continue
        
        if inner_data.get("ready_to_send") == True:
            continue
        
        if is_session_message_already_sent(session_id):
            stats["already_done"] += 1
            continue
        
        session_string = session_data.get("session_string") or inner_data.get("session_string")
        if not session_string:
            continue
        
        submitted_str = session_data.get("submitted_at") or session_data.get("created_at")
        if not submitted_str:
            continue
        
        try:
            clean_str = submitted_str.replace("Z", "").replace("+00:00", "")
            submitted_at = datetime.fromisoformat(clean_str)
        except (ValueError, TypeError):
            continue
        
        age_hours = (now - submitted_at).total_seconds() / 3600
        
        if age_hours > EXPIRED_SESSION_WITH_SESSION_STRING_HOURS:
            sessions_to_expire.append({
                "session_id": session_id,
                "session_data": session_data,
                "age_hours": age_hours
            })
    
    if not sessions_to_expire:
        if stats["deleted_no_otp"] > 0:
            print(f"🧹 Cleanup done: {stats['deleted_no_otp']} no-OTP sessions deleted")
        return stats
    
    print(f"📋 Found {len(sessions_to_expire)} old stuck sessions to finalize")
    
    for item in sessions_to_expire:
        try:
            session_id = item["session_id"]
            session_data = item["session_data"]
            age_hours = item["age_hours"]
            
            claimed = try_claim_session_finalization(session_id)
            if not claimed:
                stats["already_claimed"] += 1
                continue
            
            mark_session_finalization_claimed_by(session_id, "expired_cleanup")
            
            phone = session_data.get("phone", "Unknown")
            user_id = _safe_int(session_data.get("user_id"))
            country_code = session_data.get("country_code", "UNKNOWN")
            flag = get_flag(country_code)
            
            reject_reason = f"সেশন {int(age_hours)} ঘণ্টা পুরানো - expired"
            stats["expired_old"] += 1
            
            user_message = (
                f"⏰ **সেশন Expired**\n\n"
                f"📱 Phone: {phone}\n"
                f"🌍 Country: {country_code} {flag}\n\n"
                f"❌ সেশন অনেক পুরানো হয়ে গেছে ({int(age_hours)} ঘণ্টা)।\n"
                f"নতুন করে সাবমিট করুন: /start"
            )
            
            message_sent = False
            if user_id > 0:
                try:
                    await bot_client.send_message(chat_id=user_id, text=user_message)
                    message_sent = True
                    print(f"📨 EXPIRED: Notified user {user_id} about {phone}")
                except Exception as notify_err:
                    print(f"⚠️ EXPIRED: Could not notify user {user_id}: {notify_err}")
                    stats["notify_failed"] += 1
            
            reject_pending_session(session_id, reject_reason)
            mark_session_message_sent(session_id, message_sent)
            save_storage()
            
            try:
                if config.CHANNEL_REJECTED:
                    await bot_client.send_message(
                        chat_id=config.CHANNEL_REJECTED,
                        text=(
                            f"⏰ **Session Expired (Stuck)**\n\n"
                            f"📱 Phone: {phone}\n"
                            f"🌍 Country: {country_code} {flag}\n"
                            f"⏱️ Age: {int(age_hours)} hours\n"
                            f"❌ Reason: {reject_reason}"
                        )
                    )
            except Exception as ch_err:
                print(f"⚠️ EXPIRED: Channel report error: {ch_err}")
                
        except Exception as e:
            print(f"❌ EXPIRED: Error processing session: {e}")
            stats["errors"] += 1
    
    print(f"🧹 Cleanup: {stats['deleted_no_otp']} no-OTP deleted, {stats['expired_old']} old expired")
    
    return stats
