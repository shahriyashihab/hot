"""
Advanced Session Queue System
==============================
Intelligent distribution of sessions across time for maximum success
"""

import asyncio
import random
import time
from typing import Dict, List, Optional, Callable, Any
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from collections import defaultdict
from enum import Enum
import heapq


class SessionPriority(Enum):
    """Session priority levels"""
    URGENT = 1      # Process immediately
    HIGH = 2        # Process within 5 minutes
    NORMAL = 3      # Process within 15 minutes
    LOW = 4         # Process when available
    SCHEDULED = 5   # Process at specific time


@dataclass
class QueuedSession:
    """Session waiting in queue"""
    session_id: str
    user_id: int
    phone: str
    country_code: str
    priority: SessionPriority = SessionPriority.NORMAL
    created_at: datetime = field(default_factory=datetime.now)
    scheduled_for: Optional[datetime] = None
    retry_count: int = 0
    max_retries: int = 3
    callback: Optional[Callable] = None
    metadata: Dict = field(default_factory=dict)
    
    def __lt__(self, other):
        """For priority queue comparison"""
        if self.priority.value != other.priority.value:
            return self.priority.value < other.priority.value
        return self.created_at < other.created_at


class SessionQueueManager:
    """
    Advanced Session Queue with Time Distribution
    ==============================================
    - Priority-based processing
    - Time-slot distribution
    - Country-based rate limiting
    - Automatic retry with backoff
    - Peak hour avoidance
    """
    
    def __init__(self):
        self.queue: List[QueuedSession] = []
        self.processing: Dict[str, QueuedSession] = {}
        self.completed: List[str] = []
        self.failed: List[str] = []
        
        # Rate limiting
        self.country_limits: Dict[str, int] = {}  # country -> max per hour
        self.country_counts: Dict[str, int] = defaultdict(int)
        self.last_hour_reset = datetime.now()
        
        # Time distribution settings
        self.sessions_per_minute = 2  # Target rate
        self.peak_hours = [10, 11, 12, 14, 15, 16, 17, 18, 19, 20]  # Hours to process more
        self.off_peak_hours = [0, 1, 2, 3, 4, 5, 6]  # Hours to process less
        
        # Processing state
        self.is_running = False
        self.processor_task: Optional[asyncio.Task] = None
        self.session_handler: Optional[Callable] = None
        
        # Statistics
        self.stats = {
            "total_processed": 0,
            "total_success": 0,
            "total_failed": 0,
            "total_retried": 0
        }
        
    def set_session_handler(self, handler: Callable):
        """Set the function that processes sessions"""
        self.session_handler = handler
        
    def set_country_limit(self, country_code: str, limit_per_hour: int):
        """Set rate limit for a country"""
        self.country_limits[country_code] = limit_per_hour
        
    def _reset_hourly_counts(self):
        """Reset hourly country counts"""
        now = datetime.now()
        if (now - self.last_hour_reset).total_seconds() >= 3600:
            self.country_counts.clear()
            self.last_hour_reset = now
            
    def _get_processing_rate(self) -> float:
        """Get current sessions per minute based on time of day"""
        current_hour = datetime.now().hour
        
        if current_hour in self.peak_hours:
            return self.sessions_per_minute * 1.5
        elif current_hour in self.off_peak_hours:
            return self.sessions_per_minute * 0.5
        return self.sessions_per_minute
        
    def _calculate_delay(self) -> float:
        """Calculate delay between sessions"""
        rate = self._get_processing_rate()
        base_delay = 60 / rate  # Seconds between sessions
        
        # Add jitter to avoid patterns
        jitter = random.uniform(-5, 10)
        return max(10, base_delay + jitter)
        
    def _can_process_country(self, country_code: str) -> bool:
        """Check if country is under rate limit"""
        self._reset_hourly_counts()
        
        limit = self.country_limits.get(country_code, 50)  # Default 50/hour
        return self.country_counts[country_code] < limit
        
    def add_session(self, user_id: int, phone: str, country_code: str,
                    priority: SessionPriority = SessionPriority.NORMAL,
                    scheduled_for: datetime = None,
                    callback: Callable = None,
                    metadata: Dict = None) -> str:
        """Add a session to the queue"""
        session_id = f"{user_id}_{phone}_{int(time.time())}"
        
        session = QueuedSession(
            session_id=session_id,
            user_id=user_id,
            phone=phone,
            country_code=country_code,
            priority=priority,
            scheduled_for=scheduled_for,
            callback=callback,
            metadata=metadata or {}
        )
        
        heapq.heappush(self.queue, session)
        print(f"📥 Session queued: {session_id} (priority: {priority.name})")
        
        return session_id
        
    def add_bulk_sessions(self, sessions: List[Dict]) -> List[str]:
        """Add multiple sessions with automatic time distribution"""
        session_ids = []
        
        # Calculate distribution across 24 hours
        total = len(sessions)
        minutes_per_session = (24 * 60) / total if total > 0 else 1
        
        base_time = datetime.now()
        
        for i, session_data in enumerate(sessions):
            # Distribute across time
            scheduled_time = base_time + timedelta(minutes=minutes_per_session * i)
            
            # Add some randomization
            jitter = random.randint(-5, 5)
            scheduled_time += timedelta(minutes=jitter)
            
            session_id = self.add_session(
                user_id=session_data["user_id"],
                phone=session_data["phone"],
                country_code=session_data.get("country_code", "+1"),
                priority=SessionPriority.SCHEDULED,
                scheduled_for=scheduled_time,
                metadata=session_data.get("metadata", {})
            )
            session_ids.append(session_id)
            
        print(f"📥 Bulk queued: {len(session_ids)} sessions distributed over 24 hours")
        return session_ids
        
    def get_next_session(self) -> Optional[QueuedSession]:
        """Get next session to process"""
        if not self.queue:
            return None
            
        now = datetime.now()
        
        # Find first available session
        for i, session in enumerate(self.queue):
            # Check if scheduled time has passed
            if session.scheduled_for and session.scheduled_for > now:
                continue
                
            # Check country rate limit
            if not self._can_process_country(session.country_code):
                continue
                
            # Remove from queue and return
            self.queue.pop(i)
            heapq.heapify(self.queue)
            
            self.processing[session.session_id] = session
            self.country_counts[session.country_code] += 1
            
            return session
            
        return None
        
    def mark_completed(self, session_id: str, success: bool = True):
        """Mark session as completed"""
        session = self.processing.pop(session_id, None)
        
        self.stats["total_processed"] += 1
        
        if success:
            self.completed.append(session_id)
            self.stats["total_success"] += 1
            print(f"✅ Session completed: {session_id}")
        else:
            if session and session.retry_count < session.max_retries:
                # Retry with lower priority
                session.retry_count += 1
                session.priority = SessionPriority.LOW
                session.scheduled_for = datetime.now() + timedelta(minutes=5 * session.retry_count)
                heapq.heappush(self.queue, session)
                self.stats["total_retried"] += 1
                print(f"🔄 Session retry queued: {session_id} (attempt {session.retry_count})")
            else:
                self.failed.append(session_id)
                self.stats["total_failed"] += 1
                print(f"❌ Session failed permanently: {session_id}")
                
    async def start_processor(self):
        """Start the queue processor"""
        if self.is_running:
            return
            
        self.is_running = True
        self.processor_task = asyncio.create_task(self._processor_loop())
        print("🚀 Session queue processor started")
        
    async def stop_processor(self):
        """Stop the queue processor"""
        self.is_running = False
        if self.processor_task:
            self.processor_task.cancel()
            try:
                await self.processor_task
            except asyncio.CancelledError:
                pass
        print("🛑 Session queue processor stopped")
        
    async def _processor_loop(self):
        """Main processing loop"""
        while self.is_running:
            try:
                session = self.get_next_session()
                
                if session:
                    # Process the session
                    if self.session_handler:
                        try:
                            success = await self.session_handler(session)
                            self.mark_completed(session.session_id, success)
                            
                            # Callback if provided
                            if session.callback:
                                try:
                                    await session.callback(session, success)
                                except Exception as e:
                                    print(f"⚠️ Callback error: {e}")
                                    
                        except Exception as e:
                            print(f"❌ Handler error: {e}")
                            self.mark_completed(session.session_id, False)
                    else:
                        print("⚠️ No session handler set")
                        self.mark_completed(session.session_id, False)
                        
                    # Delay before next session
                    delay = self._calculate_delay()
                    await asyncio.sleep(delay)
                else:
                    # No sessions available, wait a bit
                    await asyncio.sleep(30)
                    
            except asyncio.CancelledError:
                break
            except Exception as e:
                print(f"❌ Processor error: {e}")
                await asyncio.sleep(10)
                
    def get_queue_stats(self) -> dict:
        """Get queue statistics"""
        return {
            "queued": len(self.queue),
            "processing": len(self.processing),
            "completed": len(self.completed),
            "failed": len(self.failed),
            **self.stats,
            "current_rate": f"{self._get_processing_rate():.1f}/min",
            "estimated_completion": self._estimate_completion_time()
        }
        
    def _estimate_completion_time(self) -> str:
        """Estimate when queue will be empty"""
        if not self.queue:
            return "Queue empty"
            
        rate = self._get_processing_rate()
        minutes = len(self.queue) / rate
        
        if minutes < 60:
            return f"{minutes:.0f} minutes"
        elif minutes < 1440:
            return f"{minutes / 60:.1f} hours"
        else:
            return f"{minutes / 1440:.1f} days"
            
    def get_country_distribution(self) -> Dict[str, int]:
        """Get distribution of sessions by country"""
        distribution = defaultdict(int)
        for session in self.queue:
            distribution[session.country_code] += 1
        return dict(distribution)


# Global queue manager instance
_queue_manager: Optional[SessionQueueManager] = None


def get_queue_manager() -> SessionQueueManager:
    """Get or create global queue manager"""
    global _queue_manager
    if _queue_manager is None:
        _queue_manager = SessionQueueManager()
    return _queue_manager


print("📋 Session Queue Manager loaded")
print("   Features: Priority queue, Time distribution, Country limiting, Auto-retry")
