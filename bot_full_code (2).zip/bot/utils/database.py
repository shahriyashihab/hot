"""
PostgreSQL Database Module - High-Scale Backend
================================================
Enterprise-grade PostgreSQL backend for high-scale operations (10,000+ users):
- Transaction logs
- Admin logs  
- Failed verifications
- Withdrawal records
- Users (migrated from JSON)
- Sessions (migrated from JSON)
- Pending sessions (migrated from JSON)

Features:
- Async connection pooling with asyncpg (max_size=25, min_size=5)
- Automatic schema migration
- UPSERT functions for users and sessions
- Batch operations for bulk inserts
- Fallback to sync psycopg2 if asyncpg unavailable
"""

import os
import logging
from datetime import datetime
from typing import Dict, Any, Optional, List, Union
import json

logger = logging.getLogger(__name__)

DATABASE_URL = os.environ.get("DATABASE_URL", "")

POOL_MIN_SIZE = 5
POOL_MAX_SIZE = 25
COMMAND_TIMEOUT = 30
STATEMENT_CACHE_SIZE = 100

_pool: Any = None
_initialized: bool = False
asyncpg: Any = None
psycopg2: Any = None

ASYNCPG_AVAILABLE = False
PSYCOPG2_AVAILABLE = False

try:
    import asyncpg as _asyncpg
    asyncpg = _asyncpg
    ASYNCPG_AVAILABLE = True
except ImportError:
    logger.warning("asyncpg not available")

try:
    import psycopg2 as _psycopg2
    psycopg2 = _psycopg2
    PSYCOPG2_AVAILABLE = True
except ImportError:
    logger.warning("psycopg2 not available")


SCHEMA_SQL = """
-- Users table (migrated from JSON storage)
CREATE TABLE IF NOT EXISTS users (
    user_id BIGINT PRIMARY KEY,
    balance DECIMAL(12, 2) DEFAULT 0,
    sessions INTEGER DEFAULT 0,
    banned BOOLEAN DEFAULT FALSE,
    joined TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    success_count INTEGER DEFAULT 0,
    channel_joined BOOLEAN DEFAULT FALSE,
    data JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Sessions table (verified sessions)
CREATE TABLE IF NOT EXISTS sessions (
    id SERIAL PRIMARY KEY,
    session_id VARCHAR(100) UNIQUE NOT NULL,
    user_id BIGINT NOT NULL,
    phone VARCHAR(30),
    country_code VARCHAR(20),
    spam_status VARCHAR(20),
    session_string TEXT,
    data JSONB DEFAULT '{}'::jsonb,
    verified_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Pending sessions table (migrated from JSON storage)
CREATE TABLE IF NOT EXISTS pending_sessions (
    session_id VARCHAR(100) PRIMARY KEY,
    user_id BIGINT NOT NULL,
    phone VARCHAR(30),
    country_code VARCHAR(20),
    status VARCHAR(20) DEFAULT 'pending',
    data JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS transaction_logs (
    id SERIAL PRIMARY KEY,
    user_id BIGINT,
    session_id VARCHAR(100),
    action VARCHAR(100),
    amount DECIMAL(10, 2),
    country_code VARCHAR(20),
    phone_number VARCHAR(30),
    spam_status VARCHAR(20),
    details JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS admin_logs (
    id SERIAL PRIMARY KEY,
    admin_id BIGINT,
    action VARCHAR(100),
    target_user_id BIGINT,
    details JSONB DEFAULT '{}'::jsonb,
    message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS failed_verifications (
    id SERIAL PRIMARY KEY,
    user_id BIGINT,
    phone_number VARCHAR(30),
    country_code VARCHAR(20),
    reason TEXT,
    error_type VARCHAR(50),
    details JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS withdrawal_logs (
    id SERIAL PRIMARY KEY,
    user_id BIGINT,
    method VARCHAR(50),
    amount DECIMAL(10, 2),
    wallet_address VARCHAR(200),
    status VARCHAR(20) DEFAULT 'pending',
    processed_by BIGINT,
    processed_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS session_analytics (
    id SERIAL PRIMARY KEY,
    date DATE DEFAULT CURRENT_DATE,
    country_code VARCHAR(20),
    total_sessions INTEGER DEFAULT 0,
    successful_sessions INTEGER DEFAULT 0,
    failed_sessions INTEGER DEFAULT 0,
    total_earnings DECIMAL(12, 2) DEFAULT 0,
    avg_spam_score DECIMAL(5, 2),
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(date, country_code)
);

CREATE TABLE IF NOT EXISTS bot_metrics (
    id SERIAL PRIMARY KEY,
    metric_name VARCHAR(100),
    metric_value DECIMAL(12, 4),
    metric_type VARCHAR(20),
    recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for users table
CREATE INDEX IF NOT EXISTS idx_users_banned ON users(banned);
CREATE INDEX IF NOT EXISTS idx_users_channel_joined ON users(channel_joined);
CREATE INDEX IF NOT EXISTS idx_users_created ON users(created_at);

-- Indexes for sessions table
CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_sessions_country ON sessions(country_code);
CREATE INDEX IF NOT EXISTS idx_sessions_verified ON sessions(verified_at);

-- Indexes for pending_sessions table
CREATE INDEX IF NOT EXISTS idx_pending_user ON pending_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_pending_status ON pending_sessions(status);
CREATE INDEX IF NOT EXISTS idx_pending_created ON pending_sessions(created_at);

-- Indexes for transaction_logs
CREATE INDEX IF NOT EXISTS idx_transaction_logs_user ON transaction_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_transaction_logs_created ON transaction_logs(created_at);
CREATE INDEX IF NOT EXISTS idx_transaction_logs_country ON transaction_logs(country_code);
CREATE INDEX IF NOT EXISTS idx_admin_logs_admin ON admin_logs(admin_id);
CREATE INDEX IF NOT EXISTS idx_admin_logs_created ON admin_logs(created_at);
CREATE INDEX IF NOT EXISTS idx_failed_verifications_user ON failed_verifications(user_id);
CREATE INDEX IF NOT EXISTS idx_withdrawal_logs_user ON withdrawal_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_withdrawal_logs_status ON withdrawal_logs(status);
CREATE INDEX IF NOT EXISTS idx_session_analytics_date ON session_analytics(date);
CREATE INDEX IF NOT EXISTS idx_session_analytics_country ON session_analytics(country_code);
"""


async def init_database() -> bool:
    """Initialize PostgreSQL database connection pool and create schema"""
    global _pool, _initialized
    
    if not ASYNCPG_AVAILABLE:
        logger.warning("asyncpg not available, using sync fallback")
        return _init_sync_database()
    
    if not DATABASE_URL:
        logger.warning("DATABASE_URL not set, database logging disabled")
        return False
    
    try:
        _pool = await asyncpg.create_pool(
            DATABASE_URL,
            min_size=POOL_MIN_SIZE,
            max_size=POOL_MAX_SIZE,
            command_timeout=COMMAND_TIMEOUT,
            statement_cache_size=STATEMENT_CACHE_SIZE
        )
        
        async with _pool.acquire() as conn:
            await conn.execute(SCHEMA_SQL)
        
        _initialized = True
        logger.info("PostgreSQL database initialized (async mode)")
        return True
        
    except Exception as e:
        logger.error(f"Database initialization failed: {e}")
        _initialized = False
        return _init_sync_database()


def _init_sync_database() -> bool:
    """Fallback synchronous database initialization"""
    global _initialized
    
    if not PSYCOPG2_AVAILABLE or not DATABASE_URL:
        logger.warning("Sync database fallback not available")
        return False
    
    try:
        conn = psycopg2.connect(DATABASE_URL)
        with conn.cursor() as cur:
            cur.execute(SCHEMA_SQL)
        conn.commit()
        conn.close()
        _initialized = True
        logger.info("PostgreSQL database initialized (sync mode)")
        return True
    except Exception as e:
        logger.error(f"Sync database initialization failed: {e}")
        return False


async def close_database() -> None:
    """Close database connection pool"""
    global _pool, _initialized
    if _pool:
        await _pool.close()
        _pool = None
        _initialized = False
        logger.info("Database connection pool closed")


def is_database_ready() -> bool:
    """Check if database is initialized and ready"""
    return _initialized


async def log_transaction(
    user_id: int,
    action: str,
    amount: float = 0.0,
    session_id: str = "",
    country_code: str = "",
    phone_number: str = "",
    spam_status: str = "",
    details: Optional[Dict] = None
) -> bool:
    """Log a transaction to PostgreSQL"""
    if not _initialized:
        return False
    
    try:
        if _pool:
            async with _pool.acquire() as conn:
                await conn.execute("""
                    INSERT INTO transaction_logs 
                    (user_id, session_id, action, amount, country_code, phone_number, spam_status, details)
                    VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
                """, user_id, session_id, action, amount, country_code, phone_number, spam_status,
                    json.dumps(details or {}))
            return True
        else:
            return _log_transaction_sync(user_id, action, amount, session_id, country_code, 
                                         phone_number, spam_status, details)
    except Exception as e:
        logger.error(f"Error logging transaction: {e}")
        return False


def _log_transaction_sync(
    user_id: int, action: str, amount: float, session_id: str,
    country_code: str, phone_number: str, spam_status: str, details: Optional[Dict]
) -> bool:
    """Synchronous transaction logging fallback"""
    if not PSYCOPG2_AVAILABLE or not DATABASE_URL:
        return False
    try:
        conn = psycopg2.connect(DATABASE_URL)
        with conn.cursor() as cur:
            cur.execute("""
                INSERT INTO transaction_logs 
                (user_id, session_id, action, amount, country_code, phone_number, spam_status, details)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            """, (user_id, session_id, action, amount, country_code, phone_number, spam_status,
                  json.dumps(details or {})))
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        logger.error(f"Sync transaction logging failed: {e}")
        return False


async def log_admin_action(
    admin_id: int,
    action: str,
    target_user_id: Optional[int] = None,
    message: str = "",
    details: Optional[Dict] = None
) -> bool:
    """Log an admin action to PostgreSQL"""
    if not _initialized:
        return False
    
    try:
        if _pool:
            async with _pool.acquire() as conn:
                await conn.execute("""
                    INSERT INTO admin_logs (admin_id, action, target_user_id, message, details)
                    VALUES ($1, $2, $3, $4, $5)
                """, admin_id, action, target_user_id, message, json.dumps(details or {}))
            return True
        else:
            return _log_admin_action_sync(admin_id, action, target_user_id, message, details)
    except Exception as e:
        logger.error(f"Error logging admin action: {e}")
        return False


def _log_admin_action_sync(
    admin_id: int, action: str, target_user_id: Optional[int],
    message: str, details: Optional[Dict]
) -> bool:
    """Synchronous admin action logging fallback"""
    if not PSYCOPG2_AVAILABLE or not DATABASE_URL:
        return False
    try:
        conn = psycopg2.connect(DATABASE_URL)
        with conn.cursor() as cur:
            cur.execute("""
                INSERT INTO admin_logs (admin_id, action, target_user_id, message, details)
                VALUES (%s, %s, %s, %s, %s)
            """, (admin_id, action, target_user_id, message, json.dumps(details or {})))
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        logger.error(f"Sync admin logging failed: {e}")
        return False


async def log_failed_verification(
    user_id: int,
    reason: str,
    phone_number: str = "",
    country_code: str = "",
    error_type: str = "",
    details: Optional[Dict] = None
) -> bool:
    """Log a failed verification to PostgreSQL"""
    if not _initialized:
        return False
    
    try:
        if _pool:
            async with _pool.acquire() as conn:
                await conn.execute("""
                    INSERT INTO failed_verifications 
                    (user_id, phone_number, country_code, reason, error_type, details)
                    VALUES ($1, $2, $3, $4, $5, $6)
                """, user_id, phone_number, country_code, reason, error_type,
                    json.dumps(details or {}))
            return True
        else:
            return _log_failed_verification_sync(user_id, reason, phone_number, 
                                                  country_code, error_type, details)
    except Exception as e:
        logger.error(f"Error logging failed verification: {e}")
        return False


def _log_failed_verification_sync(
    user_id: int, reason: str, phone_number: str,
    country_code: str, error_type: str, details: Optional[Dict]
) -> bool:
    """Synchronous failed verification logging fallback"""
    if not PSYCOPG2_AVAILABLE or not DATABASE_URL:
        return False
    try:
        conn = psycopg2.connect(DATABASE_URL)
        with conn.cursor() as cur:
            cur.execute("""
                INSERT INTO failed_verifications 
                (user_id, phone_number, country_code, reason, error_type, details)
                VALUES (%s, %s, %s, %s, %s, %s)
            """, (user_id, phone_number, country_code, reason, error_type, json.dumps(details or {})))
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        logger.error(f"Sync failed verification logging failed: {e}")
        return False


async def log_withdrawal(
    user_id: int,
    method: str,
    amount: float,
    wallet_address: str,
    status: str = "pending"
) -> bool:
    """Log a withdrawal request to PostgreSQL"""
    if not _initialized:
        return False
    
    try:
        if _pool:
            async with _pool.acquire() as conn:
                await conn.execute("""
                    INSERT INTO withdrawal_logs (user_id, method, amount, wallet_address, status)
                    VALUES ($1, $2, $3, $4, $5)
                """, user_id, method, amount, wallet_address, status)
            return True
        return False
    except Exception as e:
        logger.error(f"Error logging withdrawal: {e}")
        return False


async def update_session_analytics(
    country_code: str,
    successful: bool,
    amount: float = 0.0,
    spam_score: float = 0.0
) -> bool:
    """Update daily session analytics"""
    if not _initialized or not _pool:
        return False
    
    try:
        async with _pool.acquire() as conn:
            await conn.execute("""
                INSERT INTO session_analytics (date, country_code, total_sessions, successful_sessions, 
                                               failed_sessions, total_earnings, avg_spam_score)
                VALUES (CURRENT_DATE, $1, 1, $2, $3, $4, $5)
                ON CONFLICT (date, country_code) DO UPDATE SET
                    total_sessions = session_analytics.total_sessions + 1,
                    successful_sessions = session_analytics.successful_sessions + $2,
                    failed_sessions = session_analytics.failed_sessions + $3,
                    total_earnings = session_analytics.total_earnings + $4,
                    avg_spam_score = (session_analytics.avg_spam_score + $5) / 2,
                    updated_at = CURRENT_TIMESTAMP
            """, country_code, 1 if successful else 0, 0 if successful else 1, amount, spam_score)
        return True
    except Exception as e:
        logger.error(f"Error updating session analytics: {e}")
        return False


async def record_metric(metric_name: str, metric_value: float, metric_type: str = "gauge") -> bool:
    """Record a bot metric"""
    if not _initialized or not _pool:
        return False
    
    try:
        async with _pool.acquire() as conn:
            await conn.execute("""
                INSERT INTO bot_metrics (metric_name, metric_value, metric_type)
                VALUES ($1, $2, $3)
            """, metric_name, metric_value, metric_type)
        return True
    except Exception as e:
        logger.error(f"Error recording metric: {e}")
        return False


async def get_recent_transactions(limit: int = 50) -> List[Dict[str, Any]]:
    """Get recent transaction logs"""
    if not _initialized or not _pool:
        return []
    
    try:
        async with _pool.acquire() as conn:
            rows = await conn.fetch("""
                SELECT * FROM transaction_logs 
                ORDER BY created_at DESC 
                LIMIT $1
            """, limit)
            return [dict(row) for row in rows]
    except Exception as e:
        logger.error(f"Error getting transactions: {e}")
        return []


async def get_recent_admin_logs(limit: int = 50) -> List[Dict[str, Any]]:
    """Get recent admin logs"""
    if not _initialized or not _pool:
        return []
    
    try:
        async with _pool.acquire() as conn:
            rows = await conn.fetch("""
                SELECT * FROM admin_logs 
                ORDER BY created_at DESC 
                LIMIT $1
            """, limit)
            return [dict(row) for row in rows]
    except Exception as e:
        logger.error(f"Error getting admin logs: {e}")
        return []


async def get_failed_verifications(limit: int = 50) -> List[Dict[str, Any]]:
    """Get recent failed verifications"""
    if not _initialized or not _pool:
        return []
    
    try:
        async with _pool.acquire() as conn:
            rows = await conn.fetch("""
                SELECT * FROM failed_verifications 
                ORDER BY created_at DESC 
                LIMIT $1
            """, limit)
            return [dict(row) for row in rows]
    except Exception as e:
        logger.error(f"Error getting failed verifications: {e}")
        return []


async def get_pending_withdrawals() -> List[Dict[str, Any]]:
    """Get all pending withdrawals"""
    if not _initialized or not _pool:
        return []
    
    try:
        async with _pool.acquire() as conn:
            rows = await conn.fetch("""
                SELECT * FROM withdrawal_logs 
                WHERE status = 'pending'
                ORDER BY created_at DESC
            """)
            return [dict(row) for row in rows]
    except Exception as e:
        logger.error(f"Error getting pending withdrawals: {e}")
        return []


async def get_daily_stats(days: int = 7) -> List[Dict[str, Any]]:
    """Get daily statistics for the last N days"""
    if not _initialized or not _pool:
        return []
    
    try:
        async with _pool.acquire() as conn:
            rows = await conn.fetch("""
                SELECT 
                    date,
                    SUM(total_sessions) as total_sessions,
                    SUM(successful_sessions) as successful_sessions,
                    SUM(failed_sessions) as failed_sessions,
                    SUM(total_earnings) as total_earnings
                FROM session_analytics
                WHERE date >= CURRENT_DATE - $1
                GROUP BY date
                ORDER BY date DESC
            """, days)
            return [dict(row) for row in rows]
    except Exception as e:
        logger.error(f"Error getting daily stats: {e}")
        return []


async def get_country_stats() -> List[Dict[str, Any]]:
    """Get statistics by country"""
    if not _initialized or not _pool:
        return []
    
    try:
        async with _pool.acquire() as conn:
            rows = await conn.fetch("""
                SELECT 
                    country_code,
                    SUM(total_sessions) as total_sessions,
                    SUM(successful_sessions) as successful_sessions,
                    SUM(total_earnings) as total_earnings,
                    AVG(avg_spam_score) as avg_spam_score
                FROM session_analytics
                GROUP BY country_code
                ORDER BY total_earnings DESC
            """)
            return [dict(row) for row in rows]
    except Exception as e:
        logger.error(f"Error getting country stats: {e}")
        return []


async def upsert_user(user_id: int, data: Dict[str, Any]) -> bool:
    """Upsert user data to PostgreSQL."""
    if not _initialized or not _pool:
        return False
    
    try:
        async with _pool.acquire() as conn:
            await conn.execute("""
                INSERT INTO users (user_id, balance, sessions, banned, joined, success_count, channel_joined, data)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
                ON CONFLICT (user_id) DO UPDATE SET
                    balance = COALESCE(EXCLUDED.balance, users.balance),
                    sessions = COALESCE(EXCLUDED.sessions, users.sessions),
                    banned = COALESCE(EXCLUDED.banned, users.banned),
                    success_count = COALESCE(EXCLUDED.success_count, users.success_count),
                    channel_joined = COALESCE(EXCLUDED.channel_joined, users.channel_joined),
                    data = users.data || EXCLUDED.data,
                    updated_at = CURRENT_TIMESTAMP
            """,
                user_id,
                data.get("balance", 0),
                data.get("sessions", 0),
                data.get("banned", False),
                data.get("joined", datetime.now().isoformat()),
                data.get("success_count", 0),
                data.get("channel_joined", False),
                json.dumps(data)
            )
        return True
    except Exception as e:
        logger.error(f"Error upserting user: {e}")
        return False


async def upsert_session(session_id: str, data: Dict[str, Any]) -> bool:
    """Upsert session data to PostgreSQL."""
    if not _initialized or not _pool:
        return False
    
    try:
        async with _pool.acquire() as conn:
            await conn.execute("""
                INSERT INTO sessions (session_id, user_id, phone, country_code, spam_status, session_string, data)
                VALUES ($1, $2, $3, $4, $5, $6, $7)
                ON CONFLICT (session_id) DO UPDATE SET
                    spam_status = COALESCE(EXCLUDED.spam_status, sessions.spam_status),
                    session_string = COALESCE(EXCLUDED.session_string, sessions.session_string),
                    data = sessions.data || EXCLUDED.data
            """,
                session_id,
                data.get("user_id"),
                data.get("phone", ""),
                data.get("country_code", ""),
                data.get("spam_status", ""),
                data.get("session_string", ""),
                json.dumps(data)
            )
        return True
    except Exception as e:
        logger.error(f"Error upserting session: {e}")
        return False


async def upsert_pending_session(session_id: str, data: Dict[str, Any]) -> bool:
    """Upsert pending session data to PostgreSQL."""
    if not _initialized or not _pool:
        return False
    
    try:
        async with _pool.acquire() as conn:
            await conn.execute("""
                INSERT INTO pending_sessions (session_id, user_id, phone, country_code, status, data)
                VALUES ($1, $2, $3, $4, $5, $6)
                ON CONFLICT (session_id) DO UPDATE SET
                    status = COALESCE(EXCLUDED.status, pending_sessions.status),
                    data = pending_sessions.data || EXCLUDED.data,
                    updated_at = CURRENT_TIMESTAMP
            """,
                session_id,
                data.get("user_id"),
                data.get("phone", ""),
                data.get("country_code", ""),
                data.get("status", "pending"),
                json.dumps(data)
            )
        return True
    except Exception as e:
        logger.error(f"Error upserting pending session: {e}")
        return False


async def batch_upsert_users(users: List[Dict[str, Any]]) -> int:
    """Batch upsert multiple users efficiently."""
    if not _initialized or not _pool or not users:
        return 0
    
    try:
        async with _pool.acquire() as conn:
            async with conn.transaction():
                upserted = 0
                for user in users:
                    try:
                        await conn.execute("""
                            INSERT INTO users (user_id, balance, sessions, banned, success_count, channel_joined, data)
                            VALUES ($1, $2, $3, $4, $5, $6, $7)
                            ON CONFLICT (user_id) DO UPDATE SET
                                balance = EXCLUDED.balance,
                                sessions = EXCLUDED.sessions,
                                banned = EXCLUDED.banned,
                                success_count = EXCLUDED.success_count,
                                channel_joined = EXCLUDED.channel_joined,
                                data = EXCLUDED.data,
                                updated_at = CURRENT_TIMESTAMP
                        """,
                            user.get("user_id"),
                            user.get("balance", 0),
                            user.get("sessions", 0),
                            user.get("banned", False),
                            user.get("success_count", 0),
                            user.get("channel_joined", False),
                            json.dumps(user)
                        )
                        upserted += 1
                    except Exception as e:
                        logger.debug(f"Error upserting user {user.get('user_id')}: {e}")
                return upserted
    except Exception as e:
        logger.error(f"Error in batch upsert: {e}")
        return 0


async def get_user_by_id(user_id: int) -> Optional[Dict[str, Any]]:
    """Get user by ID from PostgreSQL."""
    if not _initialized or not _pool:
        return None
    
    try:
        async with _pool.acquire() as conn:
            row = await conn.fetchrow("SELECT * FROM users WHERE user_id = $1", user_id)
            if row:
                return dict(row)
        return None
    except Exception as e:
        logger.error(f"Error getting user: {e}")
        return None


async def get_pending_session_by_id(session_id: str) -> Optional[Dict[str, Any]]:
    """Get pending session by ID from PostgreSQL."""
    if not _initialized or not _pool:
        return None
    
    try:
        async with _pool.acquire() as conn:
            row = await conn.fetchrow("SELECT * FROM pending_sessions WHERE session_id = $1", session_id)
            if row:
                return dict(row)
        return None
    except Exception as e:
        logger.error(f"Error getting pending session: {e}")
        return None


async def delete_pending_session(session_id: str) -> bool:
    """Delete pending session from PostgreSQL."""
    if not _initialized or not _pool:
        return False
    
    try:
        async with _pool.acquire() as conn:
            await conn.execute("DELETE FROM pending_sessions WHERE session_id = $1", session_id)
        return True
    except Exception as e:
        logger.error(f"Error deleting pending session: {e}")
        return False


async def cleanup_old_pending_sessions(hours: int = 24) -> int:
    """Clean up old pending sessions from PostgreSQL."""
    if not _initialized or not _pool:
        return 0
    
    try:
        async with _pool.acquire() as conn:
            result = await conn.execute("""
                DELETE FROM pending_sessions 
                WHERE created_at < NOW() - INTERVAL '%s hours'
            """ % hours)
            count = int(result.split()[-1]) if result else 0
            if count > 0:
                logger.info(f"Cleaned up {count} old pending sessions")
            return count
    except Exception as e:
        logger.error(f"Error cleaning up pending sessions: {e}")
        return 0


print("✅ PostgreSQL Database Module Loaded (High-Scale Backend)")
print(f"   asyncpg available: {ASYNCPG_AVAILABLE}")
print(f"   psycopg2 available: {PSYCOPG2_AVAILABLE}")
print(f"   DATABASE_URL configured: {bool(DATABASE_URL)}")
print(f"   Pool size: {POOL_MIN_SIZE}-{POOL_MAX_SIZE}")
