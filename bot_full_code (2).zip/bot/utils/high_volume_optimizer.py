"""
High Volume Session Optimizer v2.0
===================================
Designed for 500-600+ sessions per day with maximum success rate

This module combines all optimization techniques:
- Proxy rotation
- API rotation
- Session queuing
- Advanced anti-detection
- Intelligent scheduling
"""

import asyncio
import random
import time
import os
from typing import Dict, List, Optional, Tuple, Any
from datetime import datetime, timedelta
from dataclasses import dataclass
from collections import defaultdict

from bot.utils.proxy_manager import get_proxy_manager, ProxyInfo
from bot.utils.api_rotation import get_api_manager, APICredentials
from bot.utils.session_queue import get_queue_manager, SessionPriority
from bot.utils.device_generator import generate_device_info, get_device_for_country
from bot.utils.anti_spam import (
    get_country_risk_profile,
    human_delay,
    record_verification_attempt
)


@dataclass
class SessionConfig:
    """Configuration for a single session"""
    phone: str
    country_code: str
    user_id: int
    proxy: Optional[ProxyInfo] = None
    api: Optional[APICredentials] = None
    device_info: Optional[Dict] = None
    priority: SessionPriority = SessionPriority.NORMAL


class HighVolumeOptimizer:
    """
    Master controller for high-volume session creation
    
    Coordinates:
    - Proxy rotation
    - API credential rotation
    - Device fingerprint randomization
    - Session queue management
    - Rate limiting and cooldowns
    - Statistics and monitoring
    """
    
    def __init__(self):
        self.proxy_manager = get_proxy_manager()
        self.api_manager = get_api_manager()
        self.queue_manager = get_queue_manager()
        
        # Session tracking
        self.active_sessions: Dict[str, SessionConfig] = {}
        self.session_results: List[Dict] = []
        
        # Rate limiting
        self.global_rate = {
            "sessions_per_minute": 3,
            "sessions_per_hour": 100,
            "sessions_per_day": 600,
            "current_minute": 0,
            "current_hour": 0,
            "current_day": 0,
            "last_minute_reset": datetime.now(),
            "last_hour_reset": datetime.now(),
            "last_day_reset": datetime.now()
        }
        
        # Country-specific limits
        self.country_limits = {
            "critical": {"per_hour": 10, "per_day": 50},
            "high": {"per_hour": 15, "per_day": 80},
            "medium": {"per_hour": 25, "per_day": 150},
            "low": {"per_hour": 50, "per_day": 300}
        }
        
        # Performance tracking
        self.performance = {
            "total_attempts": 0,
            "total_success": 0,
            "total_failed": 0,
            "total_frozen": 0,
            "avg_time_per_session": 0,
            "success_by_country": defaultdict(lambda: {"success": 0, "fail": 0}),
            "success_by_hour": defaultdict(lambda: {"success": 0, "fail": 0})
        }
        
        # Cooldown management
        self.cooldowns = {
            "global_cooldown": None,
            "country_cooldowns": {},
            "api_cooldowns": {}
        }
        
    def _reset_rate_counters(self):
        """Reset rate counters if time periods have passed"""
        now = datetime.now()
        
        # Reset minute counter
        if (now - self.global_rate["last_minute_reset"]).total_seconds() >= 60:
            self.global_rate["current_minute"] = 0
            self.global_rate["last_minute_reset"] = now
            
        # Reset hour counter
        if (now - self.global_rate["last_hour_reset"]).total_seconds() >= 3600:
            self.global_rate["current_hour"] = 0
            self.global_rate["last_hour_reset"] = now
            
        # Reset day counter
        if self.global_rate["last_day_reset"].date() != now.date():
            self.global_rate["current_day"] = 0
            self.global_rate["last_day_reset"] = now
            
    def can_create_session(self, country_code: str = None) -> Tuple[bool, str]:
        """Check if a new session can be created"""
        self._reset_rate_counters()
        
        # Check global cooldown
        if self.cooldowns["global_cooldown"] and datetime.now() < self.cooldowns["global_cooldown"]:
            remaining = (self.cooldowns["global_cooldown"] - datetime.now()).total_seconds()
            return False, f"Global cooldown: {remaining:.0f}s remaining"
            
        # Check global rate limits
        if self.global_rate["current_minute"] >= self.global_rate["sessions_per_minute"]:
            return False, "Minute rate limit reached"
        if self.global_rate["current_hour"] >= self.global_rate["sessions_per_hour"]:
            return False, "Hourly rate limit reached"
        if self.global_rate["current_day"] >= self.global_rate["sessions_per_day"]:
            return False, "Daily rate limit reached"
            
        # Check country cooldown
        if country_code and country_code in self.cooldowns["country_cooldowns"]:
            if datetime.now() < self.cooldowns["country_cooldowns"][country_code]:
                return False, f"Country {country_code} in cooldown"
                
        # Check proxy availability
        if not self.proxy_manager.proxies:
            # No proxies configured - still allow but warn
            pass
        elif not self.proxy_manager.get_best_proxy(country_code):
            return False, "No proxies available"
            
        # Check API availability
        if not self.api_manager.apis:
            # No extra APIs configured - still allow but warn
            pass
        elif not self.api_manager.get_best_api():
            return False, "No APIs available"
            
        return True, "OK"
        
    def prepare_session(self, phone: str, country_code: str, user_id: int) -> SessionConfig:
        """Prepare all components for a session"""
        session_id = f"{user_id}_{phone}_{int(time.time())}"
        
        # Get proxy
        proxy = self.proxy_manager.assign_proxy_to_session(session_id, country_code)
        
        # Get API credentials
        api = self.api_manager.assign_api_to_session(session_id)
        
        # Generate device info
        device_info = get_device_for_country(country_code)
        
        # Additional fingerprint randomization
        device_info = self._enhance_device_fingerprint(device_info, country_code)
        
        config = SessionConfig(
            phone=phone,
            country_code=country_code,
            user_id=user_id,
            proxy=proxy,
            api=api,
            device_info=device_info
        )
        
        self.active_sessions[session_id] = config
        
        # Update rate counters
        self.global_rate["current_minute"] += 1
        self.global_rate["current_hour"] += 1
        self.global_rate["current_day"] += 1
        
        return config
        
    def _enhance_device_fingerprint(self, device_info: Dict, country_code: str) -> Dict:
        """Add additional randomization to device fingerprint"""
        enhanced = device_info.copy()
        
        # Random connection type
        connection_types = ["wifi", "mobile", "4g", "5g", "lte"]
        enhanced["connection_type"] = random.choice(connection_types)
        
        # Random battery level
        enhanced["battery_level"] = random.randint(20, 95)
        
        # Random screen brightness
        enhanced["screen_brightness"] = random.randint(30, 100)
        
        # Timezone based on country
        timezone_offsets = {
            "+1": -5, "+44": 0, "+49": 1, "+91": 5.5, "+81": 9,
            "+86": 8, "+61": 10, "+55": -3, "+7": 3, "+880": 6
        }
        enhanced["timezone_offset"] = timezone_offsets.get(country_code, 0)
        
        # Random install date (within last 6 months)
        days_ago = random.randint(7, 180)
        install_date = datetime.now() - timedelta(days=days_ago)
        enhanced["install_date"] = install_date.strftime("%Y-%m-%d")
        
        return enhanced
        
    def complete_session(self, session_id: str, success: bool, frozen: bool = False):
        """Mark session as complete and update statistics"""
        config = self.active_sessions.pop(session_id, None)
        
        if not config:
            return
            
        # Update performance metrics
        self.performance["total_attempts"] += 1
        current_hour = datetime.now().hour
        
        if success:
            self.performance["total_success"] += 1
            self.performance["success_by_country"][config.country_code]["success"] += 1
            self.performance["success_by_hour"][current_hour]["success"] += 1
        else:
            self.performance["total_failed"] += 1
            self.performance["success_by_country"][config.country_code]["fail"] += 1
            self.performance["success_by_hour"][current_hour]["fail"] += 1
            
        if frozen:
            self.performance["total_frozen"] += 1
            
        # Release proxy
        if config.proxy:
            self.proxy_manager.release_session_proxy(session_id, success and not frozen)
            
        # Release API
        if config.api:
            self.api_manager.release_session_api(session_id, success)
            
        # Record for anti-spam
        record_verification_attempt(config.user_id, config.country_code, success)
        
        # Add cooldown if failed
        if not success:
            self._apply_failure_cooldown(config.country_code)
            
        # Store result
        self.session_results.append({
            "session_id": session_id,
            "phone": config.phone[-4:],  # Last 4 digits only
            "country_code": config.country_code,
            "success": success,
            "frozen": frozen,
            "timestamp": datetime.now().isoformat(),
            "proxy_used": config.proxy.host if config.proxy else None,
            "api_used": config.api.name if config.api else None
        })
        
    def _apply_failure_cooldown(self, country_code: str):
        """Apply cooldowns after a failure"""
        risk = get_country_risk_profile(country_code)
        risk_level = risk.get("risk_level", 2)
        
        # Country cooldown
        cooldown_seconds = 30 * risk_level
        self.cooldowns["country_cooldowns"][country_code] = datetime.now() + timedelta(seconds=cooldown_seconds)
        
        # Check if too many failures
        recent_fails = sum(1 for r in self.session_results[-20:] if not r["success"])
        if recent_fails >= 5:
            # Global cooldown
            global_cooldown = 60 * recent_fails
            self.cooldowns["global_cooldown"] = datetime.now() + timedelta(seconds=min(global_cooldown, 300))
            print(f"⚠️ Global cooldown activated: {global_cooldown}s")
            
    def get_optimal_timing(self) -> Dict:
        """Get optimal timing for next session"""
        now = datetime.now()
        current_hour = now.hour
        
        # Best hours (based on Telegram activity patterns)
        optimal_hours = [10, 11, 14, 15, 16, 19, 20, 21]
        good_hours = [9, 12, 13, 17, 18, 22]
        avoid_hours = [0, 1, 2, 3, 4, 5, 6, 7]
        
        if current_hour in optimal_hours:
            multiplier = 1.5
            status = "optimal"
        elif current_hour in good_hours:
            multiplier = 1.0
            status = "good"
        elif current_hour in avoid_hours:
            multiplier = 0.5
            status = "low"
        else:
            multiplier = 0.8
            status = "moderate"
            
        return {
            "current_hour": current_hour,
            "status": status,
            "rate_multiplier": multiplier,
            "recommended_rate": self.global_rate["sessions_per_minute"] * multiplier,
            "next_optimal_hour": min([h for h in optimal_hours if h > current_hour] or optimal_hours)
        }
        
    def get_statistics(self) -> Dict:
        """Get comprehensive statistics"""
        total = self.performance["total_attempts"]
        success = self.performance["total_success"]
        
        # Calculate success rate
        success_rate = (success / total * 100) if total > 0 else 0
        
        # Get proxy stats
        proxy_stats = self.proxy_manager.get_stats() if self.proxy_manager.proxies else {}
        
        # Get API stats
        api_stats = self.api_manager.get_stats() if self.api_manager.apis else {}
        
        # Get queue stats
        queue_stats = self.queue_manager.get_queue_stats()
        
        # Best performing countries
        country_performance = []
        for country, stats in self.performance["success_by_country"].items():
            total_c = stats["success"] + stats["fail"]
            if total_c > 0:
                rate = stats["success"] / total_c * 100
                country_performance.append({
                    "country": country,
                    "success_rate": f"{rate:.1f}%",
                    "total": total_c
                })
        country_performance.sort(key=lambda x: float(x["success_rate"].rstrip("%")), reverse=True)
        
        return {
            "overview": {
                "total_sessions": total,
                "successful": success,
                "failed": self.performance["total_failed"],
                "frozen": self.performance["total_frozen"],
                "success_rate": f"{success_rate:.1f}%"
            },
            "today": {
                "sessions": self.global_rate["current_day"],
                "remaining_capacity": self.global_rate["sessions_per_day"] - self.global_rate["current_day"]
            },
            "rate_limits": {
                "per_minute": f"{self.global_rate['current_minute']}/{self.global_rate['sessions_per_minute']}",
                "per_hour": f"{self.global_rate['current_hour']}/{self.global_rate['sessions_per_hour']}",
                "per_day": f"{self.global_rate['current_day']}/{self.global_rate['sessions_per_day']}"
            },
            "proxies": proxy_stats,
            "apis": api_stats,
            "queue": queue_stats,
            "top_countries": country_performance[:10],
            "timing": self.get_optimal_timing()
        }
        
    def configure_for_volume(self, target_daily: int = 600):
        """Configure optimizer for target daily volume"""
        # Calculate rates
        sessions_per_hour = target_daily / 18  # Assume 18 active hours
        sessions_per_minute = sessions_per_hour / 60
        
        self.global_rate["sessions_per_day"] = target_daily
        self.global_rate["sessions_per_hour"] = int(sessions_per_hour * 1.2)  # Buffer
        self.global_rate["sessions_per_minute"] = max(2, int(sessions_per_minute * 1.5))
        
        print(f"📊 Configured for {target_daily} sessions/day")
        print(f"   Rate: {self.global_rate['sessions_per_minute']}/min, {self.global_rate['sessions_per_hour']}/hour")
        
    def get_client_config(self, session_config: SessionConfig) -> Dict:
        """Get Pyrogram client configuration for a session"""
        config = {
            "device_model": session_config.device_info["device_model"],
            "system_version": session_config.device_info["system_version"],
            "app_version": session_config.device_info["app_version"],
            "lang_code": session_config.device_info.get("lang_code", "en")
        }
        
        # Add proxy if available
        if session_config.proxy:
            config["proxy"] = session_config.proxy.pyrogram_dict
            
        # Use rotated API if available
        if session_config.api:
            config["api_id"] = session_config.api.api_id
            config["api_hash"] = session_config.api.api_hash
            
        return config


# Global optimizer instance
_optimizer: Optional[HighVolumeOptimizer] = None


def get_optimizer() -> HighVolumeOptimizer:
    """Get or create global optimizer"""
    global _optimizer
    if _optimizer is None:
        _optimizer = HighVolumeOptimizer()
    return _optimizer


def configure_high_volume(
    target_daily: int = 600,
    proxy_file: str = None,
    proxy_list: List[str] = None,
    api_list: List[Tuple[int, str]] = None
):
    """One-line setup for high volume operation"""
    optimizer = get_optimizer()
    
    # Configure target
    optimizer.configure_for_volume(target_daily)
    
    # Load proxies
    if proxy_file and os.path.exists(proxy_file):
        optimizer.proxy_manager.load_proxies_from_file(proxy_file)
    if proxy_list:
        optimizer.proxy_manager.add_proxies_from_list(proxy_list)
        
    # Load APIs
    if api_list:
        optimizer.api_manager.add_apis_from_list(api_list)
        
    print(f"\n🚀 High Volume Optimizer Ready!")
    print(f"   Target: {target_daily} sessions/day")
    print(f"   Proxies: {len(optimizer.proxy_manager.proxies)}")
    print(f"   APIs: {len(optimizer.api_manager.apis)}")
    
    return optimizer


print("🚀 High Volume Optimizer loaded")
print("   Max capacity: 600+ sessions/day")
print("   Features: Proxy rotation, API rotation, Smart queuing, Anti-detection")
