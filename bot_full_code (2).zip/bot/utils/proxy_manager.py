"""
Advanced Proxy & IP Rotation Manager
=====================================
For 500-600 sessions/day with maximum success rate
"""

import asyncio
import random
import time
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from collections import defaultdict
import aiohttp


@dataclass
class ProxyInfo:
    """Proxy server information"""
    host: str
    port: int
    protocol: str = "socks5"  # socks5, socks4, http
    username: Optional[str] = None
    password: Optional[str] = None
    country: str = "unknown"
    last_used: Optional[datetime] = None
    success_count: int = 0
    fail_count: int = 0
    is_active: bool = True
    cooldown_until: Optional[datetime] = None
    
    @property
    def url(self) -> str:
        """Get proxy URL string"""
        if self.username and self.password:
            return f"{self.protocol}://{self.username}:{self.password}@{self.host}:{self.port}"
        return f"{self.protocol}://{self.host}:{self.port}"
    
    @property
    def pyrogram_dict(self) -> dict:
        """Get proxy dict for Pyrogram"""
        proxy = {
            "scheme": self.protocol,
            "hostname": self.host,
            "port": self.port
        }
        if self.username:
            proxy["username"] = self.username
        if self.password:
            proxy["password"] = self.password
        return proxy
    
    @property
    def success_rate(self) -> float:
        """Calculate success rate"""
        total = self.success_count + self.fail_count
        if total == 0:
            return 1.0
        return self.success_count / total
    
    def is_available(self) -> bool:
        """Check if proxy is available for use"""
        if not self.is_active:
            return False
        if self.cooldown_until and datetime.now() < self.cooldown_until:
            return False
        return True


class ProxyRotationManager:
    """
    Intelligent Proxy Rotation System
    ==================================
    - Round-robin rotation with smart selection
    - Automatic health checking
    - Country-based proxy matching
    - Cooldown management
    - Success/fail tracking
    """
    
    def __init__(self):
        self.proxies: List[ProxyInfo] = []
        self.current_index = 0
        self.proxy_by_country: Dict[str, List[ProxyInfo]] = defaultdict(list)
        self.session_proxy_map: Dict[str, ProxyInfo] = {}  # session_id -> proxy
        self.min_cooldown_seconds = 30
        self.max_proxies_per_hour = 100  # Per proxy limit
        self.proxy_usage_count: Dict[str, int] = defaultdict(int)
        self.last_hour_reset = datetime.now()
        
    def add_proxy(self, host: str, port: int, protocol: str = "socks5",
                  username: str = None, password: str = None, country: str = "unknown"):
        """Add a new proxy to the rotation pool"""
        proxy = ProxyInfo(
            host=host,
            port=port,
            protocol=protocol,
            username=username,
            password=password,
            country=country.upper()
        )
        self.proxies.append(proxy)
        self.proxy_by_country[country.upper()].append(proxy)
        print(f"✅ Proxy added: {host}:{port} ({country})")
        
    def add_proxies_from_list(self, proxy_list: List[str], protocol: str = "socks5"):
        """
        Add proxies from list format:
        - host:port
        - host:port:username:password
        - protocol://host:port
        - protocol://username:password@host:port
        """
        for proxy_str in proxy_list:
            try:
                proxy_str = proxy_str.strip()
                if not proxy_str:
                    continue
                    
                # Parse protocol://username:password@host:port format
                if "://" in proxy_str:
                    protocol_part, rest = proxy_str.split("://", 1)
                    protocol = protocol_part
                    
                    if "@" in rest:
                        auth, hostport = rest.rsplit("@", 1)
                        username, password = auth.split(":", 1)
                    else:
                        hostport = rest
                        username, password = None, None
                    
                    if ":" in hostport:
                        host, port = hostport.rsplit(":", 1)
                        port = int(port)
                    else:
                        continue
                else:
                    # Parse host:port:username:password format
                    parts = proxy_str.split(":")
                    if len(parts) >= 2:
                        host = parts[0]
                        port = int(parts[1])
                        username = parts[2] if len(parts) > 2 else None
                        password = parts[3] if len(parts) > 3 else None
                    else:
                        continue
                
                self.add_proxy(host, port, protocol, username, password)
                
            except Exception as e:
                print(f"⚠️ Failed to parse proxy: {proxy_str} - {e}")
                
    def load_proxies_from_file(self, filepath: str):
        """Load proxies from file (one per line)"""
        try:
            with open(filepath, 'r') as f:
                proxies = f.readlines()
            self.add_proxies_from_list(proxies)
            print(f"📂 Loaded {len(self.proxies)} proxies from {filepath}")
        except FileNotFoundError:
            print(f"⚠️ Proxy file not found: {filepath}")
        except Exception as e:
            print(f"❌ Error loading proxies: {e}")
            
    def _reset_hourly_counts(self):
        """Reset hourly usage counts"""
        now = datetime.now()
        if (now - self.last_hour_reset).total_seconds() >= 3600:
            self.proxy_usage_count.clear()
            self.last_hour_reset = now
            print("🔄 Hourly proxy usage counts reset")
            
    def get_best_proxy(self, country_code: str = None, exclude_proxies: List[str] = None) -> Optional[ProxyInfo]:
        """
        Get the best available proxy using smart selection
        
        Priority:
        1. Country-matched proxies
        2. Highest success rate
        3. Least recently used
        4. Under hourly limit
        """
        self._reset_hourly_counts()
        
        if not self.proxies:
            return None
            
        exclude_hosts = set(exclude_proxies or [])
        
        # Filter available proxies
        available = [
            p for p in self.proxies 
            if p.is_available() 
            and p.host not in exclude_hosts
            and self.proxy_usage_count[p.host] < self.max_proxies_per_hour
        ]
        
        if not available:
            # Reset cooldowns if no proxies available
            print("⚠️ No proxies available, resetting cooldowns...")
            for p in self.proxies:
                p.cooldown_until = None
            available = [p for p in self.proxies if p.is_active]
            
        if not available:
            return None
            
        # Prefer country-matched proxies
        if country_code:
            country_proxies = [p for p in available if p.country == country_code.upper()]
            if country_proxies:
                available = country_proxies
                
        # Sort by success rate (desc), then by last_used (asc/None first)
        def sort_key(p):
            last_used_ts = p.last_used.timestamp() if p.last_used else 0
            return (-p.success_rate, last_used_ts)
            
        available.sort(key=sort_key)
        
        # Select from top performers with some randomization
        top_count = min(5, len(available))
        selected = random.choice(available[:top_count])
        
        # Update usage
        selected.last_used = datetime.now()
        self.proxy_usage_count[selected.host] += 1
        
        return selected
        
    def get_next_proxy(self) -> Optional[ProxyInfo]:
        """Get next proxy in round-robin rotation"""
        if not self.proxies:
            return None
            
        available = [p for p in self.proxies if p.is_available()]
        if not available:
            return None
            
        self.current_index = (self.current_index + 1) % len(available)
        proxy = available[self.current_index]
        proxy.last_used = datetime.now()
        return proxy
        
    def report_success(self, proxy: ProxyInfo):
        """Report successful use of proxy"""
        proxy.success_count += 1
        proxy.cooldown_until = datetime.now() + timedelta(seconds=self.min_cooldown_seconds)
        print(f"✅ Proxy success: {proxy.host} (rate: {proxy.success_rate:.1%})")
        
    def report_failure(self, proxy: ProxyInfo, permanent: bool = False):
        """Report failed use of proxy"""
        proxy.fail_count += 1
        
        if permanent or proxy.success_rate < 0.3:
            proxy.is_active = False
            print(f"❌ Proxy disabled: {proxy.host} (rate: {proxy.success_rate:.1%})")
        else:
            # Longer cooldown on failure
            cooldown = self.min_cooldown_seconds * (1 + proxy.fail_count)
            proxy.cooldown_until = datetime.now() + timedelta(seconds=min(cooldown, 300))
            print(f"⚠️ Proxy cooldown: {proxy.host} for {cooldown}s")
            
    def assign_proxy_to_session(self, session_id: str, country_code: str = None) -> Optional[ProxyInfo]:
        """Assign a proxy to a session and track it"""
        proxy = self.get_best_proxy(country_code)
        if proxy:
            self.session_proxy_map[session_id] = proxy
        return proxy
        
    def get_session_proxy(self, session_id: str) -> Optional[ProxyInfo]:
        """Get the proxy assigned to a session"""
        return self.session_proxy_map.get(session_id)
        
    def release_session_proxy(self, session_id: str, success: bool = True):
        """Release proxy from session and report result"""
        proxy = self.session_proxy_map.pop(session_id, None)
        if proxy:
            if success:
                self.report_success(proxy)
            else:
                self.report_failure(proxy)
                
    async def check_proxy_health(self, proxy: ProxyInfo, timeout: int = 10) -> bool:
        """Check if proxy is working"""
        try:
            connector = aiohttp.TCPConnector(ssl=False)
            async with aiohttp.ClientSession(connector=connector) as session:
                async with session.get(
                    "https://api.telegram.org",
                    proxy=proxy.url,
                    timeout=aiohttp.ClientTimeout(total=timeout)
                ) as response:
                    return response.status == 200
        except Exception:
            return False
            
    async def check_all_proxies(self):
        """Check health of all proxies"""
        print(f"🔍 Checking {len(self.proxies)} proxies...")
        
        tasks = [self.check_proxy_health(p) for p in self.proxies]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        active_count = 0
        for proxy, is_healthy in zip(self.proxies, results):
            if isinstance(is_healthy, bool) and is_healthy:
                proxy.is_active = True
                active_count += 1
            else:
                proxy.is_active = False
                
        print(f"✅ Active proxies: {active_count}/{len(self.proxies)}")
        return active_count
        
    def get_stats(self) -> dict:
        """Get proxy pool statistics"""
        total = len(self.proxies)
        active = sum(1 for p in self.proxies if p.is_active)
        available = sum(1 for p in self.proxies if p.is_available())
        
        total_success = sum(p.success_count for p in self.proxies)
        total_fail = sum(p.fail_count for p in self.proxies)
        overall_rate = total_success / (total_success + total_fail) if (total_success + total_fail) > 0 else 0
        
        return {
            "total_proxies": total,
            "active_proxies": active,
            "available_now": available,
            "total_success": total_success,
            "total_fail": total_fail,
            "overall_success_rate": overall_rate,
            "countries": list(set(p.country for p in self.proxies if p.country != "unknown"))
        }


# Global proxy manager instance
_proxy_manager: Optional[ProxyRotationManager] = None


def get_proxy_manager() -> ProxyRotationManager:
    """Get or create global proxy manager"""
    global _proxy_manager
    if _proxy_manager is None:
        _proxy_manager = ProxyRotationManager()
    return _proxy_manager


def init_proxy_manager(proxy_file: str = None, proxy_list: List[str] = None) -> ProxyRotationManager:
    """Initialize proxy manager with proxies"""
    manager = get_proxy_manager()
    
    if proxy_file:
        manager.load_proxies_from_file(proxy_file)
    if proxy_list:
        manager.add_proxies_from_list(proxy_list)
        
    return manager


# Pre-configured free proxy sources (for testing only - use paid proxies for production)
SAMPLE_PROXY_PROVIDERS = [
    "https://www.proxy-list.download/api/v1/get?type=socks5",
    "https://api.proxyscrape.com/v2/?request=getproxies&protocol=socks5",
]


async def fetch_free_proxies() -> List[str]:
    """Fetch free proxies from public sources (NOT RECOMMENDED FOR PRODUCTION)"""
    proxies = []
    
    async with aiohttp.ClientSession() as session:
        for url in SAMPLE_PROXY_PROVIDERS:
            try:
                async with session.get(url, timeout=10) as response:
                    if response.status == 200:
                        text = await response.text()
                        proxies.extend(text.strip().split('\n'))
            except Exception as e:
                print(f"⚠️ Failed to fetch from {url}: {e}")
                
    return list(set(proxies))  # Remove duplicates


print("🔄 Proxy Rotation Manager loaded")
print("   Features: Smart selection, Country matching, Health check, Auto-cooldown")
