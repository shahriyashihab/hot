from pyrogram.client import Client
from pyrogram.types import Message
from bot.utils.storage import get_required_channel
from datetime import datetime
import asyncio

async def register_account(client: Client, message: Message):
    """
    Handles /account command - ULTRA FAST (< 1ms response)
    NEVER awaits external API or storage before sending reply
    ALL I/O operations deferred to background tasks
    """
    user_id = message.chat.id
    
    from bot.utils.fast_cache import (
        is_user_banned_fast,
        get_cached_template,
        get_cached_user,
        get_user_balance_fast,
        background_channel_check,
        background_warm_user_cache,
        format_message_fast
    )
    
    if is_user_banned_fast(user_id):
        await message.reply(get_cached_template("banned_user_message"))
        return
    
    cached_user = get_cached_user(user_id)
    
    if cached_user:
        balance = cached_user.get("balance", 0)
        sessions = cached_user.get("sessions", 0)
        joined = cached_user.get("joined", "Unknown")
    else:
        balance = get_user_balance_fast(user_id)
        sessions = 0
        joined = datetime.now().strftime("%Y-%m-%d")
        asyncio.create_task(background_warm_user_cache(user_id))
    
    try:
        joined_date = datetime.fromisoformat(joined) if isinstance(joined, str) and joined != "Unknown" else datetime.now()
        formatted_date = joined_date.strftime("%d-%m-%Y")
    except (ValueError, TypeError):
        formatted_date = joined if isinstance(joined, str) else "Unknown"
    
    text = format_message_fast(
        "account_info_message",
        user_id=user_id,
        balance=balance,
        sessions=sessions,
        joined=formatted_date
    )
    
    await message.reply(text)
    
    channel = get_required_channel()
    asyncio.create_task(background_channel_check(client, user_id, channel))
