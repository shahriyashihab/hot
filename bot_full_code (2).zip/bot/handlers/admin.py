# bot/handlers/admin.py
from pyrogram.client import Client
from pyrogram import filters
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery
from bot.utils.storage import (
    get_user_info,
    update_user_info,
    get_all_users,
    ban_user,
    unban_user,
    set_country_rate,
    set_country_rates,
    set_country_rate_by_type,
    get_country_rates,
    set_session_timeout,
    set_country_timeout,
    add_balance_for_user,
    get_user_stats,
    zero_all_balances,
    toggle_withdraw,
    get_total_users,
    get_all_users_list,
    get_pending_withdraw_requests,
    get_withdraw_logs,
    approve_withdraw_request,
    approve_withdraw_by_id,
    reject_withdraw_request,
    reject_withdraw_by_id,
    disable_all_countries,
    toggle_country_status,
    get_required_channel,
    set_required_channel,
    get_min_withdraw_amounts,
    set_min_withdraw_for_method,
    get_session_tracker_list,
    reset_session_tracker,
    get_all_message_templates,
    set_message_template,
    reset_message_template,
    DEFAULT_MESSAGE_TEMPLATES,
    get_all_balances_report,
    toggle_verification_pause,
    is_verification_paused,
    is_spam_check_enabled,
    toggle_spam_check,
    get_exportable_sessions,
    get_pending_exportable_sessions,
    get_session_export_counts,
    delete_exported_sessions,
    get_all_pending_sessions,
    cleanup_old_stuck_sessions,
    view_admin_logs,
    _storage,
    save_storage,
)
from bot.config import ADMIN_ID, SESSION_2FA_PASSWORD, EXTRA_APIS
import os
import json

# ---------------- Admin State Storage ----------------
import threading
from dataclasses import dataclass, field
from typing import Dict, Optional, Any, List

# ============================================================
# MULTI-ADMIN SYSTEM - Custom Filter for All Admins
# ============================================================

def is_admin(user_id: int) -> bool:
    """
    Check if a user is an admin.
    Returns True if user is in admin list or is the primary ADMIN_ID.
    """
    if user_id == ADMIN_ID:
        return True
    admins = _storage.get("admins", [])
    return user_id in admins

def get_all_admins() -> List[int]:
    """Get list of all admin IDs including primary admin."""
    admins = list(_storage.get("admins", []))
    if ADMIN_ID not in admins:
        admins.insert(0, ADMIN_ID)
    return admins

def admin_filter_func(_, __, update) -> bool:
    """
    Custom filter function to check if user is an admin.
    Works with both Message and CallbackQuery.
    """
    if hasattr(update, 'from_user') and update.from_user:
        return is_admin(update.from_user.id)
    return False

# Create custom admin filter that works for all admins
admin_filter = filters.create(admin_filter_func, name="AdminFilter")

@dataclass
class AdminStateManager:
    """Thread-safe admin state manager."""
    _states: Dict[int, Dict[str, Any]] = field(default_factory=dict)
    _monitor_enabled: bool = True
    _lock: threading.RLock = field(default_factory=threading.RLock)
    
    def get_state(self, user_id: int) -> Optional[Dict[str, str]]:
        """Get state for a specific admin user."""
        with self._lock:
            return self._states.get(user_id)
    
    def set_state(self, user_id: int, state: Dict[str, str]) -> None:
        """Set state for a specific admin user."""
        with self._lock:
            self._states[user_id] = state
    
    def clear_state(self, user_id: int) -> None:
        """Clear state for a specific admin user."""
        with self._lock:
            self._states.pop(user_id, None)
    
    def get_monitor_status(self) -> bool:
        """Get current monitor status."""
        with self._lock:
            return self._monitor_enabled
    
    def set_monitor_status(self, enabled: bool) -> None:
        """Set monitor status."""
        with self._lock:
            self._monitor_enabled = enabled

_admin_manager = AdminStateManager()
admin_state = _admin_manager._states

def get_monitor_status() -> bool:
    """Get current monitor status."""
    return _admin_manager.get_monitor_status()

def set_monitor_status(enabled: bool) -> None:
    """Set monitor status."""
    _admin_manager.set_monitor_status(enabled)

session_monitor_enabled = True

def get_admin_panel_buttons():
    """Generate main admin panel with 9 category buttons"""
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🧮 User Management", callback_data="menu_user")],
        [InlineKeyboardButton("🌍 Country & Pricing Controls", callback_data="menu_country")],
        [InlineKeyboardButton("💸 Withdraw & Finance", callback_data="menu_withdraw")],
        [InlineKeyboardButton("📁 Session Management", callback_data="menu_session")],
        [InlineKeyboardButton("🚀 System Controls", callback_data="menu_system")],
        [InlineKeyboardButton("📨 Messaging & Channel Tools", callback_data="menu_messaging")],
        [InlineKeyboardButton("📊 Statistics & Monitoring", callback_data="menu_stats"), InlineKeyboardButton("🔐 View 2FA Pass", callback_data="show_2fa_secret")],
        [InlineKeyboardButton("🛠️ Advanced Tools", callback_data="menu_advanced_tools")],
        [InlineKeyboardButton("⚙️ Settings & Configuration", callback_data="menu_settings_config")]
    ])

def get_user_management_buttons():
    """User Management sub-menu buttons"""
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🚫 Ban User", callback_data="ban"),
         InlineKeyboardButton("✅ Unban User", callback_data="unban")],
        [InlineKeyboardButton("💲 Adjust User Balance", callback_data="adjustbalance")],
        [InlineKeyboardButton("📊 User Stats", callback_data="userstats")],
        [InlineKeyboardButton("🧹 Zero All Users", callback_data="zerobalance")],
        [InlineKeyboardButton("👥 Total User Count", callback_data="totalusers")],
        [InlineKeyboardButton("🔙 Back to Main Menu", callback_data="back_admin")]
    ])

def get_country_pricing_buttons():
    """Country & Pricing Controls sub-menu buttons"""
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🌍 Set Country Price", callback_data="setrate")],
        [InlineKeyboardButton("⏳ Set Session Timeout", callback_data="settimeout")],
        [InlineKeyboardButton("🔴 Toggle Country", callback_data="togglecountry")],
        [InlineKeyboardButton("⛔ Disable All Countries", callback_data="disablecountries")],
        [InlineKeyboardButton("🔙 Back to Main Menu", callback_data="back_admin")]
    ])

def get_withdraw_finance_buttons():
    """Withdraw & Finance sub-menu buttons"""
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("💸 Withdraw ON/OFF", callback_data="togglewithdraw")],
        [InlineKeyboardButton("👤 User Specific Control", callback_data="user_withdraw_control")],
        [InlineKeyboardButton("💵 Min Withdraw Setting", callback_data="minwithdraw")],
        [InlineKeyboardButton("🪙 All Balances", callback_data="allbalances")],
        [InlineKeyboardButton("📨 Pending Withdraw", callback_data="pendingwithdraw")],
        [InlineKeyboardButton("🧾 Withdraw Logs", callback_data="withdrawlogs")],
        [InlineKeyboardButton("🔙 Back to Main Menu", callback_data="back_admin")]
    ])

def get_system_controls_buttons():
    """System Controls sub-menu buttons"""
    monitor_status = "🟢 Monitor ON" if session_monitor_enabled else "🔴 Monitor OFF"
    verification_status = "🔴 Verification OFF" if is_verification_paused() else "🟢 Verification ON"
    spam_check_status = "🟢 Spam Check ON" if is_spam_check_enabled() else "🔴 Spam Check OFF"
    
    return InlineKeyboardMarkup([
        [InlineKeyboardButton(f"⚡ {monitor_status}", callback_data="togglemonitor")],
        [InlineKeyboardButton(f"⏸️ {verification_status}", callback_data="toggleverification")],
        [InlineKeyboardButton(f"🔍 {spam_check_status}", callback_data="togglespamcheck")],
        [InlineKeyboardButton("🚀 High Volume Stats", callback_data="highvolumestats")],
        [InlineKeyboardButton("⚙️ Volume Config", callback_data="volumeconfig")],
        [InlineKeyboardButton("🔙 Back to Main Menu", callback_data="back_admin")]
    ])

def get_messaging_buttons():
    """Messaging & Channel Tools sub-menu buttons"""
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📢 Broadcast Message", callback_data="broadcast")],
        [InlineKeyboardButton("✉️ Send to User", callback_data="sendtouser")],
        [InlineKeyboardButton("📺 Set Channel", callback_data="setchannel")],
        [InlineKeyboardButton("📝 Message Settings", callback_data="messagesettings")],
        [InlineKeyboardButton("🔙 Back to Main Menu", callback_data="back_admin")]
    ])

def get_statistics_buttons():
    """Statistics & Monitoring sub-menu buttons"""
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📈 Today's Sessions", callback_data="sessiontracker")],
        [InlineKeyboardButton("🔙 Back to Main Menu", callback_data="back_admin")]
    ])

def get_advanced_tools_buttons():
    """
    🛠️ Advanced Tools - Data ও Session সম্পর্কিত উন্নত টুলস
    
    এই মেনুতে আছে:
    - View All Countries & Rates: সব দেশের rate একসাথে দেখা
    - Search User: User ID/Username দিয়ে খোঁজা
    - View Pending Sessions: Pending sessions দেখা ও manage করা
    - Cleanup Old Sessions: পুরানো stuck sessions পরিষ্কার করা
    - Backup/Export Data: সব data backup নেওয়া
    """
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📋 View All Countries & Rates", callback_data="view_all_countries")],
        [InlineKeyboardButton("🔍 Search User", callback_data="search_user")],
        [InlineKeyboardButton("⏳ View Pending Sessions", callback_data="view_pending_sessions")],
        [InlineKeyboardButton("🧹 Cleanup Old Sessions", callback_data="cleanup_old_sessions")],
        [InlineKeyboardButton("💾 Backup/Export Data", callback_data="backup_export_data")],
        [InlineKeyboardButton("🔙 Back to Main Menu", callback_data="back_admin")]
    ])

def get_settings_config_buttons():
    """
    ⚙️ Settings & Configuration - Bot ও Admin সেটিংস
    
    এই মেনুতে আছে:
    - Set 2FA Password: Session 2FA password সেট করা
    - API Health Check: সব API গুলো কাজ করছে কিনা দেখা
    - Country-wise Stats: দেশ অনুযায়ী বিস্তারিত stats
    - Admin Activity Log: Admin কি কি করেছে দেখা
    - Daily Report Toggle: দৈনিক auto report ON/OFF
    - Add New Admin: নতুন admin যোগ করা
    - Remove Admin: Admin সরিয়ে দেওয়া
    """
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🔑 Set 2FA Password", callback_data="set_2fa_password")],
        [InlineKeyboardButton("🏥 API Health Check", callback_data="api_health_check")],
        [InlineKeyboardButton("🌍 Country-wise Stats", callback_data="country_wise_stats")],
        [InlineKeyboardButton("📝 Admin Activity Log", callback_data="admin_activity_log")],
        [InlineKeyboardButton("📊 Daily Report Toggle", callback_data="daily_report_toggle")],
        [InlineKeyboardButton("👑 Add New Admin", callback_data="add_new_admin")],
        [InlineKeyboardButton("❌ Remove Admin", callback_data="remove_admin")],
        [InlineKeyboardButton("🔙 Back to Main Menu", callback_data="back_admin")]
    ])

def get_session_management_buttons():
    """Session Management sub-menu buttons with export counts"""
    counts = get_session_export_counts()
    active_count = counts.get("active", 0)
    pending_count = counts.get("pending", 0)
    
    return InlineKeyboardMarkup([
        [InlineKeyboardButton(f"📦 Export Active Sessions ({active_count})", callback_data="export_active_sessions")],
        [InlineKeyboardButton(f"⏳ Export Pending Sessions ({pending_count})", callback_data="export_pending_sessions")],
        [InlineKeyboardButton(f"📋 Export All Sessions ({active_count + pending_count})", callback_data="export_all_sessions")],
        [InlineKeyboardButton("🔄 Refresh Counts", callback_data="menu_session")],
        [InlineKeyboardButton("🔙 Back to Main Menu", callback_data="back_admin")]
    ])

# Template names for display
TEMPLATE_DISPLAY_NAMES = {
    "account_received_message": "📲 Account Received Message",
    "success_message": "✅ Success Message",
    "multi_device_message": "⚠️ Multi Device Message",
    "support_message": "🆘 Support Message",
    "account_info_message": "🎰 Account Info Message",
    "verification_failed_message": "🚫 Verification Failed Message",
    "welcome_message": "🎉 Welcome Message",
    "invalid_otp_message": "❌ Invalid OTP Message",
    "processing_message": "🔄 Processing Message",
    "banned_user_message": "🚫 Banned User Message",
    "withdraw_success_message": "✅ Withdraw Success Message",
    "no_balance_message": "❌ No Balance Message",
    "twofa_already_active_message": "❌ 2FA Already Active Message",
    
    "enter_phone_message": "📱 Enter Phone Message",
    "enter_otp_message": "🔢 Enter OTP Message",
    "otp_sent_message": "📤 OTP Sent Message",
    "waiting_verification_message": "⏳ Waiting Verification Message",
    "twofa_setup_message": "🔐 2FA Setup Message",
    "spam_check_message": "🔍 Spam Check Message",
    "withdraw_disabled_message": "❌ Withdraw Disabled Message",
    "withdraw_method_message": "💳 Withdraw Method Message",
    "enter_wallet_message": "📬 Enter Wallet Message",
    "invalid_wallet_message": "❌ Invalid Wallet Message",
    "session_timeout_message": "⏰ Session Timeout Message",
    "country_not_available_message": "🌍 Country Not Available Message",
    "join_channel_message": "📢 Join Channel Message",
    "min_withdraw_message": "⚠️ Min Withdraw Message",
    "enter_2fa_password_message": "🔑 Enter 2FA Password Message"
}

# Placeholder info for each template
TEMPLATE_PLACEHOLDERS = {
    "account_received_message": "{phone}, {flag}, {timeout}",
    "success_message": "{phone}, {price}, {status}",
    "multi_device_message": "{phone}",
    "support_message": "No placeholders",
    "account_info_message": "{user_id}, {balance}, {sessions}, {joined}",
    "verification_failed_message": "{phone}, {country_code}, {flag}",
    "welcome_message": "No placeholders",
    "invalid_otp_message": "No placeholders",
    "processing_message": "No placeholders",
    "banned_user_message": "No placeholders",
    "withdraw_success_message": "{amount}, {method}",
    "no_balance_message": "No placeholders",
    "twofa_already_active_message": "No placeholders",
    
    "enter_phone_message": "No placeholders",
    "enter_otp_message": "{timeout}",
    "otp_sent_message": "{phone}, {country_code}, {flag}, {timeout}",
    "waiting_verification_message": "{phone}, {country_code}, {flag}, {timeout}",
    "twofa_setup_message": "{phone}",
    "spam_check_message": "{phone}",
    "withdraw_disabled_message": "No placeholders",
    "withdraw_method_message": "{balance}",
    "enter_wallet_message": "{method}",
    "invalid_wallet_message": "{error}, {method}",
    "session_timeout_message": "{phone}, {country_code}, {flag}, {timeout}",
    "country_not_available_message": "{country_code}, {flag}",
    "join_channel_message": "{channel}",
    "min_withdraw_message": "{balance}, {min_amount}, {needed}",
    "enter_2fa_password_message": "{phone}"
}

# For backward compatibility
ADMIN_PANEL_BUTTONS = get_admin_panel_buttons()

# ---------------- Register Handlers ----------------
def register_admin_handlers(app: Client):
    # ---------------- /admin Command ----------------
    @app.on_message(filters.command("admin") & admin_filter)
    async def open_admin_panel(client: Client, message: Message):
        await message.reply_text("👑 Admin Panel", reply_markup=get_admin_panel_buttons())

    # ---------------- Category Menu Callbacks ----------------
    @app.on_callback_query(admin_filter & filters.regex(r"^menu_user$"))
    async def menu_user_callback(client: Client, query: CallbackQuery):
        await query.answer()
        await query.message.reply(
            "🧮 **User Management**\n\n"
            "ইউজার সম্পর্কিত সব সেটিংস এখানে:",
            reply_markup=get_user_management_buttons()
        )

    @app.on_callback_query(admin_filter & filters.regex(r"^menu_country$"))
    async def menu_country_callback(client: Client, query: CallbackQuery):
        await query.answer()
        await query.message.reply(
            "🌍 **Country & Pricing Controls**\n\n"
            "দেশ, প্রাইস এবং টাইমআউট সেটিংস:",
            reply_markup=get_country_pricing_buttons()
        )

    @app.on_callback_query(admin_filter & filters.regex(r"^menu_withdraw$"))
    async def menu_withdraw_callback(client: Client, query: CallbackQuery):
        await query.answer()
        await query.message.reply(
            "💸 **Withdraw & Finance**\n\n"
            "উইথড্র এবং ফাইনান্স সেটিংস:",
            reply_markup=get_withdraw_finance_buttons()
        )

    @app.on_callback_query(admin_filter & filters.regex(r"^menu_system$"))
    async def menu_system_callback(client: Client, query: CallbackQuery):
        await query.answer()
        await query.message.reply(
            "🚀 **System Controls**\n\n"
            "বটের মেইন কন্ট্রোল সিস্টেম:",
            reply_markup=get_system_controls_buttons()
        )

    @app.on_callback_query(admin_filter & filters.regex(r"^menu_messaging$"))
    async def menu_messaging_callback(client: Client, query: CallbackQuery):
        await query.answer()
        await query.message.reply(
            "📨 **Messaging & Channel Tools**\n\n"
            "বার্তা পাঠানো এবং চ্যানেল সেটিংস:",
            reply_markup=get_messaging_buttons()
        )

    @app.on_callback_query(admin_filter & filters.regex(r"^menu_stats$"))
    async def menu_stats_callback(client: Client, query: CallbackQuery):
        await query.answer()
        await query.message.reply(
            "📊 **Statistics & Monitoring**\n\n"
            "সকল ডাটা রিপোর্ট:",
            reply_markup=get_statistics_buttons()
        )

    @app.on_callback_query(admin_filter & filters.regex(r"^menu_session$"))
    async def menu_session_callback(client: Client, query: CallbackQuery):
        await query.answer()
        counts = get_session_export_counts()
        await query.message.reply(
            "📁 **Session Management**\n\n"
            "সেশন এক্সপোর্ট ও ম্যানেজমেন্ট:\n\n"
            f"✅ Active Sessions: **{counts.get('active', 0)}**\n"
            f"⏳ Pending Sessions: **{counts.get('pending', 0)}**\n\n"
            "⚠️ **নোট:** ডাউনলোড করার পর সেশনগুলো বটের স্টোরেজ থেকে ডিলিট হয়ে যাবে।\n"
            "চ্যানেলে সেশন রিপোর্ট থাকবে।",
            reply_markup=get_session_management_buttons()
        )

    # ---------------- Advanced Tools Menu ----------------
    @app.on_callback_query(admin_filter & filters.regex(r"^menu_advanced_tools$"))
    async def menu_advanced_tools_callback(client: Client, query: CallbackQuery):
        await query.answer()
        await query.message.reply(
            "🛠️ **Advanced Tools**\n\n"
            "উন্নত টুলস ও ডাটা ম্যানেজমেন্ট:\n\n"
            "📋 **View All Countries** - সব দেশের rate দেখুন\n"
            "🔍 **Search User** - User খুঁজুন\n"
            "⏳ **Pending Sessions** - Pending sessions দেখুন\n"
            "🧹 **Cleanup** - পুরানো sessions পরিষ্কার\n"
            "💾 **Backup** - Data backup নিন",
            reply_markup=get_advanced_tools_buttons()
        )

    # ---------------- Settings & Configuration Menu ----------------
    @app.on_callback_query(admin_filter & filters.regex(r"^menu_settings_config$"))
    async def menu_settings_config_callback(client: Client, query: CallbackQuery):
        await query.answer()
        await query.message.reply(
            "⚙️ **Settings & Configuration**\n\n"
            "বট ও Admin সেটিংস:\n\n"
            "🔑 **2FA Password** - Session password সেট\n"
            "🏥 **API Health** - API status চেক\n"
            "🌍 **Country Stats** - দেশ অনুযায়ী stats\n"
            "📝 **Activity Log** - Admin logs\n"
            "📊 **Daily Report** - Auto report toggle\n"
            "👑 **Add Admin** - নতুন admin যোগ",
            reply_markup=get_settings_config_buttons()
        )

    # ============================================================
    # 🛠️ ADVANCED TOOLS - FULLY IMPLEMENTED CALLBACKS
    # ============================================================
    
    @app.on_callback_query(admin_filter & filters.regex(r"^view_all_countries$"))
    async def view_all_countries_callback(client: Client, query: CallbackQuery):
        """📋 View All Countries & Rates"""
        await query.answer()
        try:
            countries = _storage.get("countries", {})
            if not countries:
                await query.message.reply(
                    "📋 **All Countries & Rates**\n\n"
                    "❌ কোনো দেশ কনফিগার করা হয়নি।\n\n"
                    "💡 দেশ যোগ করতে:\n"
                    "Country & Pricing Controls → Set Country Price",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("🔙 Back to Advanced Tools", callback_data="menu_advanced_tools")]
                    ])
                )
                return
            
            from bot.utils.country_data import get_flag
            
            lines = []
            for code, data in sorted(countries.items()):
                flag = get_flag(code)
                spam_free = data.get("spam_free_rate", data.get("rate", 0))
                spam = data.get("spam_rate", 0)
                limit = data.get("limit_rate", 0)
                timeout = data.get("timeout", 300)
                is_open = data.get("open", False)
                status = "🟢 Open" if is_open else "🔴 Closed"
                
                lines.append(
                    f"{flag} **{code}** {status}\n"
                    f"   ✅ Spam Free: ${spam_free} | ⚠️ Spam: ${spam} | 🔒 Limit: ${limit}\n"
                    f"   ⏰ Timeout: {timeout}s"
                )
            
            total_countries = len(countries)
            open_count = sum(1 for d in countries.values() if d.get("open", False))
            
            header = (
                f"📋 **All Countries & Rates**\n"
                f"━━━━━━━━━━━━━━━━━━━━━\n"
                f"🌍 Total Countries: **{total_countries}**\n"
                f"🟢 Open: **{open_count}** | 🔴 Closed: **{total_countries - open_count}**\n"
                f"━━━━━━━━━━━━━━━━━━━━━\n\n"
            )
            
            full_msg = header + "\n\n".join(lines[:20])
            if len(lines) > 20:
                full_msg += f"\n\n⚠️ আরো {len(lines) - 20}টি দেশ আছে..."
            
            buttons = [[InlineKeyboardButton("🔙 Back to Advanced Tools", callback_data="menu_advanced_tools")]]
            
            if len(full_msg) > 4000:
                await query.message.reply(header)
                for i in range(0, len(lines), 10):
                    chunk = "\n\n".join(lines[i:i+10])
                    await query.message.reply(chunk)
                await query.message.reply("✅ সব দেশের তথ্য দেখানো হয়েছে।", reply_markup=InlineKeyboardMarkup(buttons))
            else:
                await query.message.reply(full_msg, reply_markup=InlineKeyboardMarkup(buttons))
        except Exception as e:
            await query.message.reply(f"❌ Error: {str(e)}")

    @app.on_callback_query(admin_filter & filters.regex(r"^search_user$"))
    async def search_user_callback(client: Client, query: CallbackQuery):
        """🔍 Search User"""
        await query.answer()
        uid = query.from_user.id
        admin_state[uid] = {"action": "search_user"}
        await query.message.reply(
            "🔍 **Search User**\n\n"
            "User ID লিখুন যে user কে খুঁজতে চান:\n\n"
            "উদাহরণ: `123456789`\n\n"
            "❌ Cancel করতে /admin লিখুন",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🔙 Back to Advanced Tools", callback_data="menu_advanced_tools")]
            ])
        )

    @app.on_callback_query(admin_filter & filters.regex(r"^view_pending_sessions$"))
    async def view_pending_sessions_callback(client: Client, query: CallbackQuery):
        """⏳ View Pending Sessions"""
        await query.answer()
        try:
            pending = get_all_pending_sessions()
            if not pending:
                await query.message.reply(
                    "⏳ **Pending Sessions**\n\n"
                    "✅ কোনো pending session নেই।",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("🔙 Back to Advanced Tools", callback_data="menu_advanced_tools")]
                    ])
                )
                return
            
            from bot.utils.country_data import get_flag
            
            lines = []
            status_counts = {"pending": 0, "approved": 0, "rejected": 0, "timeout": 0}
            
            for session_id, data in list(pending.items())[:30]:
                phone = data.get("phone", "N/A")
                country_code = data.get("country_code", "N/A")
                status = data.get("status", "pending")
                submitted = data.get("submitted_at", data.get("created_at", "N/A"))
                user_id = data.get("user_id", "N/A")
                flag = get_flag(country_code) if country_code != "N/A" else "🌍"
                
                status_counts[status] = status_counts.get(status, 0) + 1
                
                status_icon = {"pending": "⏳", "approved": "✅", "rejected": "❌", "timeout": "⏰"}.get(status, "❓")
                
                if submitted != "N/A":
                    try:
                        submitted = submitted[:16].replace("T", " ")
                    except:
                        pass
                
                lines.append(
                    f"{status_icon} **{phone}** {flag}\n"
                    f"   👤 User: `{user_id}` | 🌍 {country_code}\n"
                    f"   📅 {submitted}"
                )
            
            header = (
                f"⏳ **Pending Sessions**\n"
                f"━━━━━━━━━━━━━━━━━━━━━\n"
                f"📊 Total: **{len(pending)}**\n"
                f"⏳ Pending: {status_counts.get('pending', 0)} | ✅ Approved: {status_counts.get('approved', 0)}\n"
                f"❌ Rejected: {status_counts.get('rejected', 0)} | ⏰ Timeout: {status_counts.get('timeout', 0)}\n"
                f"━━━━━━━━━━━━━━━━━━━━━\n\n"
            )
            
            full_msg = header + "\n\n".join(lines[:15])
            if len(pending) > 15:
                full_msg += f"\n\n⚠️ আরো {len(pending) - 15}টি session আছে..."
            
            buttons = [
                [InlineKeyboardButton("🧹 Cleanup Old Sessions", callback_data="cleanup_old_sessions")],
                [InlineKeyboardButton("🔙 Back to Advanced Tools", callback_data="menu_advanced_tools")]
            ]
            
            if len(full_msg) > 4000:
                await query.message.reply(header)
                for chunk in lines[:15]:
                    await query.message.reply(chunk)
                await query.message.reply("✅ সব sessions দেখানো হয়েছে।", reply_markup=InlineKeyboardMarkup(buttons))
            else:
                await query.message.reply(full_msg, reply_markup=InlineKeyboardMarkup(buttons))
        except Exception as e:
            await query.message.reply(f"❌ Error: {str(e)}")

    @app.on_callback_query(admin_filter & filters.regex(r"^cleanup_old_sessions$"))
    async def cleanup_old_sessions_callback(client: Client, query: CallbackQuery):
        """🧹 Cleanup Old Sessions - Confirmation"""
        await query.answer()
        pending = get_all_pending_sessions()
        total_pending = len(pending)
        
        await query.message.reply(
            f"🧹 **Cleanup Old Sessions**\n\n"
            f"⚠️ এই অপশন ২৪ ঘণ্টার বেশি পুরানো stuck sessions ডিলিট করবে।\n\n"
            f"📊 বর্তমান Pending Sessions: **{total_pending}**\n\n"
            f"আপনি কি নিশ্চিত?",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("✅ Yes, Cleanup", callback_data="confirm_cleanup_sessions")],
                [InlineKeyboardButton("❌ Cancel", callback_data="menu_advanced_tools")]
            ])
        )

    @app.on_callback_query(admin_filter & filters.regex(r"^confirm_cleanup_sessions$"))
    async def confirm_cleanup_sessions_callback(client: Client, query: CallbackQuery):
        """🧹 Cleanup Old Sessions - Execute"""
        await query.answer()
        try:
            before_count = len(get_all_pending_sessions())
            cleaned = cleanup_old_stuck_sessions(max_age_hours=24)
            after_count = len(get_all_pending_sessions())
            
            await query.message.reply(
                f"🧹 **Cleanup Complete!**\n\n"
                f"📊 **Result:**\n"
                f"━━━━━━━━━━━━━━━━━━━━━\n"
                f"📦 Before: {before_count} sessions\n"
                f"🗑️ Cleaned: {cleaned} sessions\n"
                f"📦 After: {after_count} sessions\n"
                f"━━━━━━━━━━━━━━━━━━━━━\n\n"
                f"✅ ২৪ ঘণ্টার বেশি পুরানো stuck sessions ডিলিট হয়েছে!",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("🔙 Back to Advanced Tools", callback_data="menu_advanced_tools")]
                ])
            )
        except Exception as e:
            await query.message.reply(f"❌ Cleanup Error: {str(e)}")

    @app.on_callback_query(admin_filter & filters.regex(r"^backup_export_data$"))
    async def backup_export_data_callback(client: Client, query: CallbackQuery):
        """💾 Backup/Export Data - Sends actual file with non-blocking IO"""
        await query.answer("⏳ Backup তৈরি হচ্ছে...")
        
        import asyncio
        from datetime import datetime
        
        storage_file = "data/storage.json"
        
        try:
            if not os.path.exists(storage_file):
                await query.message.reply(
                    "❌ **Backup Error**\n\n"
                    "storage.json ফাইল পাওয়া যায়নি!\n"
                    "Bot এ কোনো data নেই।",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("🔙 Back to Advanced Tools", callback_data="menu_advanced_tools")]
                    ])
                )
                return
            
            def _read_and_prepare_backup():
                """Non-blocking file operations in separate thread"""
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                backup_filename = f"backup_storage_{timestamp}.json"
                backup_path = f"/tmp/{backup_filename}"
                
                with open(storage_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                
                stats = {
                    "users": len(data.get("users", {})),
                    "countries": len(data.get("countries", {})),
                    "pending_sessions": len(data.get("pending_sessions", {})),
                    "withdrawals": len(data.get("withdrawals", [])),
                    "admin_logs": len(data.get("admin_logs", []))
                }
                
                with open(backup_path, 'w', encoding='utf-8') as f:
                    json.dump(data, f, ensure_ascii=False, indent=2)
                
                file_size = os.path.getsize(backup_path)
                
                return backup_path, backup_filename, stats, file_size, timestamp
            
            backup_path, backup_filename, stats, file_size, timestamp = await asyncio.to_thread(_read_and_prepare_backup)
            
            file_size_kb = file_size / 1024
            file_size_str = f"{file_size_kb:.1f} KB" if file_size_kb < 1024 else f"{file_size_kb/1024:.2f} MB"
            
            caption = (
                f"💾 **Storage Backup**\n"
                f"━━━━━━━━━━━━━━━━━━━━━\n"
                f"📅 Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
                f"📦 File Size: {file_size_str}\n\n"
                f"📊 **Stats:**\n"
                f"👥 Users: {stats['users']}\n"
                f"🌍 Countries: {stats['countries']}\n"
                f"⏳ Pending Sessions: {stats['pending_sessions']}\n"
                f"💸 Withdrawals: {stats['withdrawals']}\n"
                f"📝 Admin Logs: {stats['admin_logs']}\n"
                f"━━━━━━━━━━━━━━━━━━━━━\n\n"
                f"✅ Backup file successfully created!"
            )
            
            await client.send_document(
                chat_id=query.message.chat.id,
                document=backup_path,
                caption=caption,
                file_name=backup_filename
            )
            
            try:
                os.remove(backup_path)
            except:
                pass
            
        except FileNotFoundError:
            await query.message.reply(
                "❌ **File Not Found**\n\n"
                "storage.json ফাইল খুঁজে পাওয়া যায়নি।\n"
                "Bot এর কোনো data নেই অথবা path সমস্যা।",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("🔙 Back to Advanced Tools", callback_data="menu_advanced_tools")]
                ])
            )
        except json.JSONDecodeError as e:
            await query.message.reply(
                f"❌ **JSON Parse Error**\n\n"
                f"storage.json ফাইল corrupt হয়ে গেছে।\n"
                f"Error: {str(e)}",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("🔙 Back to Advanced Tools", callback_data="menu_advanced_tools")]
                ])
            )
        except Exception as e:
            await query.message.reply(
                f"❌ **Backup Error**\n\n"
                f"Error: {str(e)}",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("🔙 Back to Advanced Tools", callback_data="menu_advanced_tools")]
                ])
            )

    # ============================================================
    # ⚙️ SETTINGS & CONFIG - FULLY IMPLEMENTED CALLBACKS
    # ============================================================
    
    @app.on_callback_query(admin_filter & filters.regex(r"^set_2fa_password$"))
    async def set_2fa_password_callback(client: Client, query: CallbackQuery):
        """🔑 Set 2FA Password"""
        await query.answer()
        current_password = SESSION_2FA_PASSWORD
        masked_password = current_password[:4] + "*" * (len(current_password) - 4) if len(current_password) > 4 else "***"
        
        await query.message.reply(
            f"🔑 **2FA Password Settings**\n"
            f"━━━━━━━━━━━━━━━━━━━━━\n\n"
            f"📌 **Current Password:** `{masked_password}`\n\n"
            f"⚠️ এই password সেশন তৈরির সময় 2FA সেটআপে ব্যবহৃত হয়।\n\n"
            f"🔧 **Password পরিবর্তন করতে:**\n"
            f"নিচের বাটনে ক্লিক করুন অথবা Replit Secrets এ `SESSION_2FA_PASSWORD` আপডেট করুন।\n\n"
            f"💡 **Tip:** Strong password ব্যবহার করুন (16+ characters recommended)",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("✏️ Set New Password", callback_data="set_2fa_password_input")],
                [InlineKeyboardButton("🔙 Back to Settings", callback_data="menu_settings_config")]
            ])
        )
    
    @app.on_callback_query(admin_filter & filters.regex(r"^set_2fa_password_input$"))
    async def set_2fa_password_input_callback(client: Client, query: CallbackQuery):
        """🔑 Set 2FA Password - Input Mode"""
        await query.answer()
        uid = query.from_user.id
        _admin_manager.set_state(uid, {"action": "set_2fa_password"})
        await query.message.reply(
            "🔑 **Set New 2FA Password**\n\n"
            "নতুন password লিখুন:\n\n"
            "⚠️ **Requirements:**\n"
            "• কমপক্ষে 8 characters\n"
            "• Strong password recommended\n\n"
            "❌ Cancel করতে /admin লিখুন"
        )

    @app.on_callback_query(admin_filter & filters.regex(r"^api_health_check$"))
    async def api_health_check_callback(client: Client, query: CallbackQuery):
        """🏥 API Health Check - With actual connectivity testing"""
        await query.answer("⏳ API চেক করা হচ্ছে...")
        
        import asyncio
        from bot.config import API_ID, API_HASH
        
        try:
            api_count = len(EXTRA_APIS)
            lines = []
            healthy_count = 0
            
            from pyrogram.client import Client as PyrogramClient
            
            primary_api_id = API_ID
            primary_api_hash = API_HASH
            
            def validate_api_format(api_id, api_hash):
                """Validate API credentials format"""
                try:
                    if not api_id or not api_hash:
                        return False, "Empty credentials"
                    if not str(api_id).isdigit():
                        return False, "Invalid API_ID format"
                    if len(str(api_hash)) < 20:
                        return False, "API_HASH too short"
                    return True, "Valid format"
                except:
                    return False, "Validation error"
            
            primary_valid, primary_msg = validate_api_format(primary_api_id, primary_api_hash)
            if primary_valid:
                lines.append(f"✅ **Primary API:** Valid (ID: {str(primary_api_id)[:6]}...)")
                healthy_count += 1
            else:
                lines.append(f"⚠️ **Primary API:** {primary_msg}")
            
            for i in range(1, 6):
                api_id_env = os.getenv(f"EXTRA_API_{i}_ID")
                api_hash_env = os.getenv(f"EXTRA_API_{i}_HASH")
                
                if api_id_env and api_hash_env:
                    is_valid, msg = validate_api_format(api_id_env, api_hash_env)
                    if is_valid:
                        lines.append(f"✅ **Extra API {i}:** Valid (ID: {api_id_env[:6]}...)")
                        healthy_count += 1
                    else:
                        lines.append(f"⚠️ **Extra API {i}:** {msg}")
                else:
                    lines.append(f"❌ **Extra API {i}:** Not configured")
            
            if healthy_count >= 3:
                overall_status = "🟢 Excellent"
                status_desc = "সব API সঠিকভাবে কনফিগার করা আছে"
            elif healthy_count >= 1:
                overall_status = "🟡 Okay"
                status_desc = "কিছু API missing, আরো যোগ করার কথা বিবেচনা করুন"
            else:
                overall_status = "🔴 Critical"
                status_desc = "কোনো valid API নেই!"
            
            throughput = healthy_count * 25
            
            await query.message.reply(
                f"🏥 **API Health Check**\n"
                f"━━━━━━━━━━━━━━━━━━━━━\n\n"
                f"📊 **Overall Status:** {overall_status}\n"
                f"📝 {status_desc}\n\n"
                f"🔢 **Configured APIs:** {healthy_count}/{6}\n"
                f"⚡ **Est. Throughput:** ~{throughput} sessions/hour\n\n"
                f"**API Details:**\n" + "\n".join(lines) + "\n\n"
                f"💡 **Tips:**\n"
                f"• প্রতিটি API ~25 sessions/hour handle করতে পারে\n"
                f"• Replit Secrets এ EXTRA_API_X_ID ও EXTRA_API_X_HASH সেট করুন\n"
                f"• my.telegram.org থেকে API credentials নিন",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("🔄 Refresh", callback_data="api_health_check")],
                    [InlineKeyboardButton("🔙 Back to Settings", callback_data="menu_settings_config")]
                ])
            )
        except Exception as e:
            await query.message.reply(
                f"❌ **API Check Error**\n\nError: {str(e)}",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("🔙 Back to Settings", callback_data="menu_settings_config")]
                ])
            )

    @app.on_callback_query(admin_filter & filters.regex(r"^country_wise_stats$"))
    async def country_wise_stats_callback(client: Client, query: CallbackQuery):
        """🌍 Country-wise Stats - Page 1"""
        await _show_country_stats_page(client, query, page=1)
    
    @app.on_callback_query(admin_filter & filters.regex(r"^country_stats_page_(\d+)$"))
    async def country_stats_page_callback(client: Client, query: CallbackQuery):
        """🌍 Country-wise Stats - Paginated"""
        import re
        data_str = str(query.data) if query.data else ""
        match = re.match(r"^country_stats_page_(\d+)$", data_str)
        page = int(match.group(1)) if match else 1
        await _show_country_stats_page(client, query, page=page)
    
    async def _show_country_stats_page(client: Client, query: CallbackQuery, page: int = 1):
        """Helper function to show country stats with pagination"""
        await query.answer()
        
        ITEMS_PER_PAGE = 10
        
        try:
            from bot.utils.country_data import get_flag
            
            session_tracker = _storage.get("session_tracker", {})
            if session_tracker is None:
                session_tracker = {}
            
            country_stats = {}
            
            for user_id, sessions in session_tracker.items():
                if not isinstance(sessions, list):
                    continue
                    
                for session in sessions:
                    if not isinstance(session, dict):
                        continue
                    
                    cc = session.get("country_code", "other") or "other"
                    
                    try:
                        amount = float(session.get("amount", 0) or 0)
                    except (ValueError, TypeError):
                        amount = 0.0
                    
                    if cc not in country_stats:
                        country_stats[cc] = {"count": 0, "earnings": 0.0}
                    country_stats[cc]["count"] += 1
                    country_stats[cc]["earnings"] += amount
            
            if not country_stats:
                await query.message.reply(
                    "🌍 **Country-wise Stats**\n\n"
                    "❌ কোনো session data নেই।\n"
                    "Users verify করলে এখানে stats দেখা যাবে।",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("🔙 Back to Settings", callback_data="menu_settings_config")]
                    ])
                )
                return
            
            sorted_stats = sorted(country_stats.items(), key=lambda x: x[1].get("count", 0), reverse=True)
            
            total_sessions = sum(s.get("count", 0) for s in country_stats.values())
            total_earnings = sum(s.get("earnings", 0) for s in country_stats.values())
            total_countries = len(country_stats)
            
            total_pages = (total_countries + ITEMS_PER_PAGE - 1) // ITEMS_PER_PAGE
            page = max(1, min(page, total_pages))
            
            start_idx = (page - 1) * ITEMS_PER_PAGE
            end_idx = start_idx + ITEMS_PER_PAGE
            page_stats = sorted_stats[start_idx:end_idx]
            
            lines = []
            for idx, (cc, stats) in enumerate(page_stats, start=start_idx + 1):
                try:
                    flag = get_flag(cc) if cc and cc != "other" else "🌍"
                except:
                    flag = "🌍"
                count = stats.get("count", 0)
                earnings = stats.get("earnings", 0.0)
                lines.append(f"{idx}. {flag} **{cc}**: {count} sessions | ${earnings:.2f}")
            
            pagination_buttons = []
            if page > 1:
                pagination_buttons.append(InlineKeyboardButton("⬅️ Previous", callback_data=f"country_stats_page_{page - 1}"))
            if page < total_pages:
                pagination_buttons.append(InlineKeyboardButton("Next ➡️", callback_data=f"country_stats_page_{page + 1}"))
            
            buttons = []
            if pagination_buttons:
                buttons.append(pagination_buttons)
            buttons.append([InlineKeyboardButton("🔙 Back to Settings", callback_data="menu_settings_config")])
            
            await query.message.reply(
                f"🌍 **Country-wise Stats**\n"
                f"━━━━━━━━━━━━━━━━━━━━━\n"
                f"📊 Total Sessions: **{total_sessions}**\n"
                f"💰 Total Earnings: **${total_earnings:.2f}**\n"
                f"🌍 Countries: **{total_countries}**\n"
                f"━━━━━━━━━━━━━━━━━━━━━\n\n"
                f"**Countries (Page {page}/{total_pages}):**\n" + "\n".join(lines),
                reply_markup=InlineKeyboardMarkup(buttons)
            )
        except Exception as e:
            await query.message.reply(
                f"❌ **Stats Error**\n\nError: {str(e)}",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("🔙 Back to Settings", callback_data="menu_settings_config")]
                ])
            )

    @app.on_callback_query(admin_filter & filters.regex(r"^admin_activity_log$"))
    async def admin_activity_log_callback(client: Client, query: CallbackQuery):
        """📝 Admin Activity Log"""
        await query.answer()
        try:
            logs = view_admin_logs()
            
            if logs == "No admin logs." or not logs:
                await query.message.reply(
                    "📝 **Admin Activity Log**\n\n"
                    "❌ কোনো admin log নেই।",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("🔙 Back to Settings", callback_data="menu_settings_config")]
                    ])
                )
                return
            
            await query.message.reply(
                f"📝 **Admin Activity Log**\n"
                f"━━━━━━━━━━━━━━━━━━━━━\n"
                f"📊 Last 20 actions:\n"
                f"━━━━━━━━━━━━━━━━━━━━━\n\n"
                f"{logs}",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("🔙 Back to Settings", callback_data="menu_settings_config")]
                ])
            )
        except Exception as e:
            await query.message.reply(f"❌ Log Error: {str(e)}")

    @app.on_callback_query(admin_filter & filters.regex(r"^daily_report_toggle$"))
    async def daily_report_toggle_callback(client: Client, query: CallbackQuery):
        """📊 Daily Report Toggle"""
        await query.answer()
        try:
            current_status = _storage.get("daily_report_enabled", False)
            new_status = not current_status
            _storage["daily_report_enabled"] = new_status
            save_storage()
            
            status_text = "🟢 ON" if new_status else "🔴 OFF"
            status_msg = "চালু করা হয়েছে" if new_status else "বন্ধ করা হয়েছে"
            
            await query.message.reply(
                f"📊 **Daily Report Toggle**\n"
                f"━━━━━━━━━━━━━━━━━━━━━\n\n"
                f"📌 **Status:** {status_text}\n\n"
                f"✅ Daily Report {status_msg}!\n\n"
                f"💡 যখন ON থাকবে, প্রতিদিন সকাল ৯টায় auto report পাঠানো হবে।",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton(f"🔄 Toggle ({'OFF' if new_status else 'ON'})", callback_data="daily_report_toggle")],
                    [InlineKeyboardButton("🔙 Back to Settings", callback_data="menu_settings_config")]
                ])
            )
        except Exception as e:
            await query.message.reply(f"❌ Toggle Error: {str(e)}")

    @app.on_callback_query(admin_filter & filters.regex(r"^add_new_admin$"))
    async def add_new_admin_callback(client: Client, query: CallbackQuery):
        """👑 Add New Admin"""
        await query.answer()
        try:
            admins = _storage.get("admins", [ADMIN_ID])
            if ADMIN_ID not in admins:
                admins.append(ADMIN_ID)
                _storage["admins"] = admins
                save_storage()
            
            admin_lines = [f"👤 `{admin_id}`" for admin_id in admins]
            
            await query.message.reply(
                f"👑 **Admin Management**\n"
                f"━━━━━━━━━━━━━━━━━━━━━\n\n"
                f"📊 **Current Admins:** {len(admins)}\n\n"
                f"**Admin List:**\n" + "\n".join(admin_lines) + "\n\n"
                f"➕ **নতুন Admin যোগ করতে:**\n"
                f"User ID লিখুন (শুধু সংখ্যা)\n\n"
                f"❌ Cancel করতে /admin লিখুন",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("➕ Add Admin", callback_data="add_admin_input")],
                    [InlineKeyboardButton("🔙 Back to Settings", callback_data="menu_settings_config")]
                ])
            )
        except Exception as e:
            await query.message.reply(f"❌ Admin Error: {str(e)}")

    @app.on_callback_query(admin_filter & filters.regex(r"^add_admin_input$"))
    async def add_admin_input_callback(client: Client, query: CallbackQuery):
        """👑 Add Admin - Input Mode"""
        await query.answer()
        uid = query.from_user.id
        admin_state[uid] = {"action": "add_new_admin"}
        await query.message.reply(
            "👑 **Add New Admin**\n\n"
            "নতুন Admin এর User ID লিখুন:\n\n"
            "উদাহরণ: `123456789`\n\n"
            "❌ Cancel করতে /admin লিখুন"
        )

    # ---------------- Remove Admin Callbacks ----------------
    @app.on_callback_query(admin_filter & filters.regex(r"^remove_admin$"))
    async def remove_admin_callback(client: Client, query: CallbackQuery):
        """❌ Remove Admin - Show admin list with remove buttons"""
        await query.answer()
        try:
            admins = _storage.get("admins", [ADMIN_ID])
            if ADMIN_ID not in admins:
                admins.append(ADMIN_ID)
                _storage["admins"] = admins
                save_storage()
            
            if len(admins) <= 1:
                await query.message.reply(
                    "❌ **Remove Admin**\n"
                    "━━━━━━━━━━━━━━━━━━━━━\n\n"
                    "⚠️ শুধুমাত্র প্রধান Admin আছেন!\n"
                    "সরানোর জন্য অন্য কোনো Admin নেই।",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("🔙 Back to Settings", callback_data="menu_settings_config")]
                    ])
                )
                return
            
            buttons = []
            for admin_id in admins:
                if admin_id == ADMIN_ID:
                    buttons.append([InlineKeyboardButton(f"👑 {admin_id} (Primary - Protected)", callback_data="protected_admin")])
                else:
                    buttons.append([InlineKeyboardButton(f"❌ Remove {admin_id}", callback_data=f"confirm_remove_admin_{admin_id}")])
            
            buttons.append([InlineKeyboardButton("🔙 Back to Settings", callback_data="menu_settings_config")])
            
            await query.message.reply(
                f"❌ **Remove Admin**\n"
                f"━━━━━━━━━━━━━━━━━━━━━\n\n"
                f"📊 **Total Admins:** {len(admins)}\n\n"
                f"⚠️ যাকে সরাতে চান তার বাটনে ক্লিক করুন:\n\n"
                f"💡 Primary Admin সুরক্ষিত - সরানো যাবে না।",
                reply_markup=InlineKeyboardMarkup(buttons)
            )
        except Exception as e:
            await query.message.reply(f"❌ Error: {str(e)}")

    @app.on_callback_query(admin_filter & filters.regex(r"^protected_admin$"))
    async def protected_admin_callback(client: Client, query: CallbackQuery):
        """Primary Admin protection notice"""
        await query.answer("⚠️ Primary Admin সরানো যাবে না!", show_alert=True)

    @app.on_callback_query(admin_filter & filters.regex(r"^confirm_remove_admin_(\d+)$"))
    async def confirm_remove_admin_callback(client: Client, query: CallbackQuery):
        """❌ Confirm Remove Admin"""
        await query.answer()
        try:
            match = query.matches[0] if query.matches else None
            if not match:
                await query.message.reply("❌ Invalid request")
                return
            
            admin_to_remove = int(match.group(1))
            
            if admin_to_remove == ADMIN_ID:
                await query.message.reply(
                    "⚠️ **নিষেধ!**\n\n"
                    "Primary Admin সরানো যাবে না!",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("🔙 Back to Settings", callback_data="menu_settings_config")]
                    ])
                )
                return
            
            admins = _storage.get("admins", [ADMIN_ID])
            
            if admin_to_remove not in admins:
                await query.message.reply(
                    f"⚠️ User `{admin_to_remove}` Admin তালিকায় নেই!",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("🔙 Back to Settings", callback_data="menu_settings_config")]
                    ])
                )
                return
            
            admins.remove(admin_to_remove)
            _storage["admins"] = admins
            save_storage()
            
            admin_lines = [f"👤 `{aid}`" + (" 👑" if aid == ADMIN_ID else "") for aid in admins]
            
            await query.message.reply(
                f"✅ **Admin সরানো হয়েছে!**\n"
                f"━━━━━━━━━━━━━━━━━━━━━\n\n"
                f"❌ Removed: `{admin_to_remove}`\n\n"
                f"📊 **Remaining Admins:** {len(admins)}\n\n"
                f"**Admin List:**\n" + "\n".join(admin_lines),
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("❌ Remove Another", callback_data="remove_admin")],
                    [InlineKeyboardButton("🔙 Back to Settings", callback_data="menu_settings_config")]
                ])
            )
        except Exception as e:
            await query.message.reply(f"❌ Error: {str(e)}")

    # ---------------- Session Export Callbacks ----------------
    @app.on_callback_query(admin_filter & filters.regex(r"^export_active_sessions$"))
    async def export_active_sessions_callback(client: Client, query: CallbackQuery):
        await query.answer("⏳ Active সেশন এক্সপোর্ট হচ্ছে...")
        await _export_sessions(client, query, "active")

    @app.on_callback_query(admin_filter & filters.regex(r"^export_pending_sessions$"))
    async def export_pending_sessions_callback(client: Client, query: CallbackQuery):
        await query.answer("⏳ Pending সেশন এক্সপোর্ট হচ্ছে...")
        await _export_sessions(client, query, "pending")

    @app.on_callback_query(admin_filter & filters.regex(r"^export_all_sessions$"))
    async def export_all_sessions_callback(client: Client, query: CallbackQuery):
        await query.answer("⏳ সব সেশন এক্সপোর্ট হচ্ছে...")
        await _export_sessions(client, query, "all")

    async def _export_sessions(client: Client, query: CallbackQuery, export_type: str):
        """Internal function to export sessions as ZIP and delete from storage.
        
        Optimized for high-volume traffic (5000-6000 sessions/day):
        - Uses asyncio.to_thread for non-blocking ZIP creation
        - Deletes sessions only AFTER successful upload
        - Proper cleanup on failure with finally block
        - Handles Telegram 50MB limit gracefully
        """
        import zipfile
        import os
        import asyncio
        from datetime import datetime
        
        if export_type == "active":
            sessions = get_exportable_sessions()
            type_name = "Active"
        elif export_type == "pending":
            sessions = get_pending_exportable_sessions()
            type_name = "Pending"
        else:
            active_sessions = get_exportable_sessions()
            pending_sessions = get_pending_exportable_sessions()
            sessions = {**active_sessions, **pending_sessions}
            type_name = "All"
        
        if not sessions:
            await query.message.reply(
                f"❌ কোনো {type_name} সেশন নেই এক্সপোর্ট করার জন্য!",
                reply_markup=get_session_management_buttons()
            )
            return
        
        progress_msg = await query.message.reply(
            f"📦 **{type_name} Sessions Export**\n\n"
            f"⏳ {len(sessions)}টি সেশন ZIP করা হচ্ছে...\n"
            f"অপেক্ষা করুন..."
        )
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        zip_filename = f"sessions_{type_name.lower()}_{timestamp}.zip"
        zip_path = f"/tmp/{zip_filename}"
        upload_success = False
        session_ids_exported = []
        files_added = 0
        
        def _create_zip_blocking():
            """Blocking ZIP creation - runs in separate thread."""
            nonlocal files_added
            local_files_added = 0
            local_session_ids = []
            
            try:
                with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                    for session_id, session_data in sessions.items():
                        local_session_ids.append(session_id)
                        telethon_file = session_data.get("telethon_file", "")
                        
                        if telethon_file and os.path.exists(telethon_file):
                            original_filename = os.path.basename(telethon_file)
                            zipf.write(telethon_file, original_filename)
                            local_files_added += 1
                
                return local_session_ids, local_files_added
            except Exception as e:
                print(f"ZIP creation error: {e}")
                raise
        
        try:
            session_ids_exported, files_added = await asyncio.to_thread(_create_zip_blocking)
            
            if os.path.exists(zip_path):
                zip_size_mb = os.path.getsize(zip_path) / (1024 * 1024)
                if zip_size_mb > 49:
                    await progress_msg.edit_text(
                        f"⚠️ **ZIP ফাইল অনেক বড় ({zip_size_mb:.1f} MB)!**\n\n"
                        f"Telegram এ সর্বোচ্চ 50 MB পাঠানো যায়।\n"
                        f"অনুগ্রহ করে কম সেশন নিয়ে চেষ্টা করুন।"
                    )
                    return
            
            await progress_msg.edit_text(
                f"📦 **{type_name} Sessions Export**\n\n"
                f"⏳ ZIP তৈরি হয়েছে ({files_added} files)\n"
                f"📤 এখন আপলোড হচ্ছে..."
            )
            
            await client.send_document(
                chat_id=query.from_user.id,
                document=zip_path,
                caption=(
                    f"📦 **{type_name} Sessions Export Complete!**\n\n"
                    f"✅ সেশন সংখ্যা: **{len(session_ids_exported)}**\n"
                    f"📁 ফাইল সংখ্যা: **{files_added}**\n\n"
                    f"⚠️ সেশনগুলো স্টোরেজ থেকে ডিলিট হচ্ছে..."
                ),
                file_name=zip_filename
            )
            upload_success = True
            
            deleted_count = delete_exported_sessions(session_ids_exported)
            
            def _cleanup_session_files():
                """Blocking file cleanup - runs in separate thread."""
                for session_id in session_ids_exported:
                    session_data = sessions.get(session_id, {})
                    session_file = session_data.get("session_file", "")
                    telethon_file = session_data.get("telethon_file", "")
                    
                    for file_path in [session_file, telethon_file]:
                        if file_path and os.path.exists(file_path):
                            try:
                                os.remove(file_path)
                            except Exception:
                                pass
            
            await asyncio.to_thread(_cleanup_session_files)
            
            try:
                await progress_msg.delete()
            except Exception:
                pass
            
            await query.message.reply(
                f"✅ **Export সম্পন্ন!**\n\n"
                f"📦 {len(session_ids_exported)}টি {type_name} সেশন এক্সপোর্ট ও ডিলিট হয়েছে।\n"
                f"🗑️ স্টোরেজ থেকে ডিলিট: **{deleted_count}**\n\n"
                f"নতুন সেশন আসলে আবার এক্সপোর্ট করতে পারবেন।",
                reply_markup=get_session_management_buttons()
            )
            
        except Exception as e:
            error_msg = str(e)
            print(f"Session export error: {e}")
            
            if not upload_success:
                try:
                    await progress_msg.edit_text(
                        f"❌ **Export Error!**\n\n"
                        f"Error: {error_msg}\n\n"
                        f"সেশনগুলো ডিলিট করা হয়নি, আবার চেষ্টা করুন।"
                    )
                except Exception:
                    pass
        
        finally:
            if os.path.exists(zip_path):
                try:
                    os.remove(zip_path)
                except Exception:
                    pass

    # ---------------- Approve/Reject Withdraw Callbacks ----------------
    @app.on_callback_query(admin_filter & filters.regex(r"^wapprove_(.+)_(.+)$"))
    async def approve_withdraw_callback(client: Client, query: CallbackQuery):
        """Approve a pending withdraw request by user_id and timestamp"""
        await query.answer("⏳ প্রসেসিং...")
        try:
            from bot.utils.storage import approve_withdraw_by_id
            from bot.utils.fast_cache import invalidate_user_cache
            
            match = query.matches[0] if query.matches else None
            if not match:
                await query.message.reply("❌ Invalid request")
                return
            
            user_id = match.group(1)
            safe_ts = match.group(2)
            timestamp = safe_ts.replace('C', ':').replace('D', '.')
            
            result = approve_withdraw_by_id(user_id, timestamp)
            
            if result.get("success"):
                amount = result.get("amount", 0)
                method = result.get("method", "N/A")
                wallet = result.get("wallet_address", "N/A")
                
                try:
                    invalidate_user_cache(int(user_id))
                except (ValueError, TypeError):
                    pass
                
                await query.message.reply(
                    f"✅ **Withdraw Approved!**\n"
                    f"━━━━━━━━━━━━━━━━━━━━━\n\n"
                    f"👤 User ID: `{user_id}`\n"
                    f"💵 Amount: **${amount:.2f}**\n"
                    f"💳 Method: {method}\n"
                    f"📍 Wallet: `{wallet}`\n\n"
                    f"✅ এখন পেমেন্ট করুন!",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("📥 View Pending", callback_data="pendingwithdraw")],
                        [InlineKeyboardButton("🔙 Back to Withdraw & Finance", callback_data="menu_withdraw")]
                    ])
                )
            else:
                await query.message.reply(f"❌ Error: {result.get('error', 'Unknown error')}")
        except Exception as e:
            await query.message.reply(f"❌ Approve Error: {str(e)}")

    @app.on_callback_query(admin_filter & filters.regex(r"^wreject_(.+)_(.+)$"))
    async def reject_withdraw_callback(client: Client, query: CallbackQuery):
        """Reject a pending withdraw request and refund balance"""
        await query.answer("⏳ প্রসেসিং...")
        try:
            from bot.utils.storage import reject_withdraw_by_id
            from bot.utils.fast_cache import invalidate_user_cache
            
            match = query.matches[0] if query.matches else None
            if not match:
                await query.message.reply("❌ Invalid request")
                return
            
            user_id = match.group(1)
            safe_ts = match.group(2)
            timestamp = safe_ts.replace('C', ':').replace('D', '.')
            
            result = reject_withdraw_by_id(user_id, timestamp)
            
            if result.get("success"):
                amount = result.get("amount", 0)
                
                try:
                    invalidate_user_cache(int(user_id))
                except (ValueError, TypeError):
                    pass
                
                await query.message.reply(
                    f"❌ **Withdraw Rejected!**\n"
                    f"━━━━━━━━━━━━━━━━━━━━━\n\n"
                    f"👤 User ID: `{user_id}`\n"
                    f"💵 Amount: **${amount:.2f}**\n\n"
                    f"💰 **Balance Refunded!**\n"
                    f"User এর একাউন্টে ${amount:.2f} ফেরত দেওয়া হয়েছে।",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("📥 View Pending", callback_data="pendingwithdraw")],
                        [InlineKeyboardButton("🔙 Back to Withdraw & Finance", callback_data="menu_withdraw")]
                    ])
                )
            else:
                await query.message.reply(f"❌ Error: {result.get('error', 'Unknown error')}")
        except Exception as e:
            await query.message.reply(f"❌ Reject Error: {str(e)}")

    # ---------------- Toggle Monitor Callback ----------------
    @app.on_callback_query(admin_filter & filters.regex(r"^togglemonitor$"))
    async def toggle_monitor_callback(client: Client, query: CallbackQuery):
        global session_monitor_enabled
        session_monitor_enabled = not session_monitor_enabled
        status = "🟢 ON" if session_monitor_enabled else "🔴 OFF"
        print(f"⚡ Session Monitor toggled: {status}")
        await query.answer(f"Session Monitor: {status}", show_alert=True)
        await query.message.edit_reply_markup(reply_markup=get_system_controls_buttons())

    # ---------------- Toggle Verification Callback ----------------
    @app.on_callback_query(admin_filter & filters.regex(r"^toggleverification$"))
    async def toggle_verification_callback(client: Client, query: CallbackQuery):
        is_paused = toggle_verification_pause()
        if is_paused:
            status = "🔴 OFF - ইউজাররা নম্বর দিতে পারবে না"
            print(f"⏸️ Verification PAUSED by admin")
        else:
            status = "🟢 ON - ইউজাররা নম্বর দিতে পারবে"
            print(f"▶️ Verification RESUMED by admin")
        await query.answer(f"Verification: {status}", show_alert=True)
        await query.message.edit_reply_markup(reply_markup=get_system_controls_buttons())

    # ---------------- Toggle Spam Check Callback ----------------
    @app.on_callback_query(admin_filter & filters.regex(r"^togglespamcheck$"))
    async def toggle_spam_check_callback(client: Client, query: CallbackQuery):
        is_enabled = toggle_spam_check()
        if is_enabled:
            status = "🟢 ON - Spam চেক করা হবে, স্ট্যাটাস অনুযায়ী রেট"
            print(f"🔍 Spam Check ENABLED by admin")
        else:
            status = "🔴 OFF - Spam চেক বন্ধ, সবাই সম্পূর্ণ রেট পাবে"
            print(f"🔕 Spam Check DISABLED by admin - All accounts get spam_free rate")
        await query.answer(f"Spam Check: {status}", show_alert=True)
        await query.message.edit_reply_markup(reply_markup=get_system_controls_buttons())

    # ---------------- Quick Ban/Unban from Search User ----------------
    @app.on_callback_query(admin_filter & filters.regex(r"^quick_ban_(\d+)$"))
    async def quick_ban_callback(client: Client, query: CallbackQuery):
        """Quick ban user from search results"""
        await query.answer()
        data_str = str(query.data) if query.data else ""
        try:
            user_id_to_ban = int(data_str.replace("quick_ban_", ""))
            ban_user(user_id_to_ban)
            from bot.utils.fast_cache import mark_user_banned
            mark_user_banned(user_id_to_ban)
            print(f"✅ User {user_id_to_ban} banned via quick action")
            
            await query.message.reply(
                f"🚫 **User Banned Successfully!**\n\n"
                f"👤 User ID: `{user_id_to_ban}`\n"
                f"📌 Status: 🔴 Banned\n\n"
                f"এই user আর bot ব্যবহার করতে পারবে না।",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("✅ Unban This User", callback_data=f"quick_unban_{user_id_to_ban}")],
                    [InlineKeyboardButton("🔙 Back to Advanced Tools", callback_data="menu_advanced_tools")]
                ])
            )
        except Exception as e:
            await query.message.reply(f"❌ Ban Error: {str(e)}")

    @app.on_callback_query(admin_filter & filters.regex(r"^quick_unban_(\d+)$"))
    async def quick_unban_callback(client: Client, query: CallbackQuery):
        """Quick unban user from search results"""
        await query.answer()
        data_str = str(query.data) if query.data else ""
        try:
            user_id_to_unban = int(data_str.replace("quick_unban_", ""))
            unban_user(user_id_to_unban)
            from bot.utils.fast_cache import mark_user_unbanned
            mark_user_unbanned(user_id_to_unban)
            print(f"✅ User {user_id_to_unban} unbanned via quick action")
            
            await query.message.reply(
                f"✅ **User Unbanned Successfully!**\n\n"
                f"👤 User ID: `{user_id_to_unban}`\n"
                f"📌 Status: 🟢 Active\n\n"
                f"এই user এখন আবার bot ব্যবহার করতে পারবে।",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("🚫 Ban This User", callback_data=f"quick_ban_{user_id_to_unban}")],
                    [InlineKeyboardButton("🔙 Back to Advanced Tools", callback_data="menu_advanced_tools")]
                ])
            )
        except Exception as e:
            await query.message.reply(f"❌ Unban Error: {str(e)}")

    # ---------------- Min Withdraw Settings Callbacks ----------------
    @app.on_callback_query(admin_filter & filters.regex(r"^setmin_(usdt|trx|cardname|binance)$"))
    async def set_min_withdraw_callback(client: Client, query: CallbackQuery):
        uid = query.from_user.id
        data_str = str(query.data) if query.data else ""
        method = data_str.replace("setmin_", "")
        method_names = {"usdt": "USDT (BEP20)", "trx": "TRX", "cardname": "CARD NAME", "binance": "Binance"}
        method_name = method_names.get(method, method.upper())
        
        await query.answer()
        await query.message.reply(
            f"💵 **{method_name}** এর জন্য সর্বনিম্ন উইথড্র এমাউন্ট লিখুন:\n\n"
            f"উদাহরণ: 10 (মানে $10 সর্বনিম্ন)"
        )
        admin_state[uid] = {"action": "setmin", "method": method}

    @app.on_callback_query(admin_filter & filters.regex(r"^back_admin$"))
    async def back_to_admin_callback(client: Client, query: CallbackQuery):
        await query.answer()
        await query.message.reply("👑 Admin Panel", reply_markup=get_admin_panel_buttons())

    # ---------------- Set Country Rate Type Callbacks ----------------
    @app.on_callback_query(admin_filter & filters.regex(r"^setrate_(spamfree|spam|limit)$"))
    async def set_rate_type_callback(client: Client, query: CallbackQuery):
        uid = query.from_user.id
        data_str = str(query.data) if query.data else "setrate_spamfree"
        rate_type = data_str.split("_")[1] if "_" in data_str else "spamfree"
        
        rate_type_names = {
            "spamfree": ("Spam Free", "spam_free_rate", "✅"),
            "spam": ("Spam", "spam_rate", "⚠️"),
            "limit": ("Limit", "limit_rate", "🔒")
        }
        
        name, storage_key, emoji = rate_type_names.get(rate_type, ("Unknown", "rate", "📋"))
        
        await query.answer()
        await query.message.reply(
            f"{emoji} **{name} Rate সেট করুন**\n\n"
            f"Country code এবং rate লিখুন:\n\n"
            f"উদাহরণ: `+880 30`\n"
            f"(মানে +880 এর জন্য {name} Rate = $30)"
        )
        admin_state[uid] = {"action": "setrate_type", "rate_type": storage_key}

    @app.on_callback_query(admin_filter & filters.regex(r"^setrate_all$"))
    async def set_all_rates_callback(client: Client, query: CallbackQuery):
        uid = query.from_user.id
        
        await query.answer()
        await query.message.reply(
            "📋 **All Rates একসাথে সেট করুন**\n\n"
            "Country code এবং তিনটি rate লিখুন:\n\n"
            "Format: `+880 30 15 10`\n\n"
            "এখানে:\n"
            "• 30 = Spam Free Rate (ভালো একাউন্ট)\n"
            "• 15 = Spam Rate (স্প্যাম একাউন্ট)\n"
            "• 10 = Limit Rate (লিমিট একাউন্ট)\n\n"
            "অর্থাৎ: `+CountryCode SpamFreeRate SpamRate LimitRate`"
        )
        admin_state[uid] = {"action": "setrate_all"}

    # ---------------- Session Tracker Callbacks ----------------
    @app.on_callback_query(admin_filter & filters.regex(r"^view_session_list$"))
    async def view_session_list_callback(client: Client, query: CallbackQuery):
        await query.answer()
        list_data, total_users, total_sessions = get_session_tracker_list()
        
        if not list_data:
            await query.message.reply(
                "📋 **Session List**\n\n"
                "❌ কোনো ভেরিফাইড সেশন নেই!\n\n"
                "নতুন সেশন ভেরিফাইড হলে এখানে দেখাবে।"
            )
            return
        
        header = (
            f"📋 **Verified Sessions List**\n"
            f"━━━━━━━━━━━━━━━━━━━━━\n"
            f"👥 Total Users: **{total_users}**\n"
            f"✅ Total Sessions: **{total_sessions}**\n"
            f"━━━━━━━━━━━━━━━━━━━━━\n\n"
        )
        
        full_message = header + list_data
        
        if len(full_message) > 4000:
            for i in range(0, len(full_message), 4000):
                await query.message.reply(full_message[i:i+4000])
        else:
            await query.message.reply(full_message)

    @app.on_callback_query(admin_filter & filters.regex(r"^reset_session_tracker$"))
    async def reset_session_tracker_callback(client: Client, query: CallbackQuery):
        await query.answer()
        buttons = [
            [InlineKeyboardButton("✅ Yes, Reset All", callback_data="confirm_reset_tracker")],
            [InlineKeyboardButton("❌ Cancel", callback_data="sessiontracker")]
        ]
        await query.message.reply(
            "⚠️ **Warning!**\n\n"
            "আপনি কি নিশ্চিত সব সেশন ট্র্যাকার রিসেট করতে চান?\n\n"
            "এটা শুধু এই লিস্ট মুছে দেবে, ইউজারদের একাউন্টে কোনো প্রভাব পড়বে না।",
            reply_markup=InlineKeyboardMarkup(buttons)
        )

    @app.on_callback_query(admin_filter & filters.regex(r"^confirm_reset_tracker$"))
    async def confirm_reset_tracker_callback(client: Client, query: CallbackQuery):
        await query.answer()
        reset_session_tracker()
        await query.message.reply(
            "✅ **Session Tracker Reset Complete!**\n\n"
            "সব সেশন ট্র্যাকিং ডাটা মুছে দেওয়া হয়েছে।\n"
            "নতুন ভেরিফাইড সেশন থেকে আবার গণনা শুরু হবে।"
        )

    # ---------------- Message Settings Callbacks ----------------
    @app.on_callback_query(admin_filter & filters.regex(r"^messagesettings$"))
    async def message_settings_callback(client: Client, query: CallbackQuery):
        await query.answer()
        templates = get_all_message_templates()
        
        buttons = []
        for key, data in templates.items():
            display_name = TEMPLATE_DISPLAY_NAMES.get(key, key)
            status = "✏️" if data["is_custom"] else "📋"
            buttons.append([InlineKeyboardButton(f"{status} {display_name}", callback_data=f"edit_tpl_{key}")])
        
        buttons.append([InlineKeyboardButton("🔙 Back to Messaging", callback_data="menu_messaging")])
        
        await query.message.reply(
            "📝 **Message Settings**\n\n"
            "বটের বিভিন্ন মেসেজ এখান থেকে পরিবর্তন করুন:\n\n"
            "📋 = Default Message\n"
            "✏️ = Custom Message\n\n"
            "যেকোনো মেসেজ এডিট করতে নিচের বাটনে ক্লিক করুন:",
            reply_markup=InlineKeyboardMarkup(buttons)
        )

    @app.on_callback_query(admin_filter & filters.regex(r"^edit_tpl_(.+)$"))
    async def edit_template_callback(client: Client, query: CallbackQuery):
        uid = query.from_user.id
        data_str = str(query.data) if query.data else ""
        template_key = data_str.replace("edit_tpl_", "")
        
        await query.answer()
        
        templates = get_all_message_templates()
        template_data = templates.get(template_key)
        
        if not template_data:
            await query.message.reply("❌ Template not found!")
            return
        
        display_name = TEMPLATE_DISPLAY_NAMES.get(template_key, template_key)
        placeholders = TEMPLATE_PLACEHOLDERS.get(template_key, "None")
        current = template_data["current"]
        is_custom = template_data["is_custom"]
        
        status_text = "✏️ Custom" if is_custom else "📋 Default"
        
        buttons = [
            [InlineKeyboardButton("✏️ Edit This Message", callback_data=f"start_edit_{template_key}")],
            [InlineKeyboardButton("🔄 Reset to Default", callback_data=f"reset_tpl_{template_key}")],
            [InlineKeyboardButton("🔙 Back to Messages", callback_data="messagesettings")]
        ]
        
        await query.message.reply(
            f"📝 **{display_name}**\n\n"
            f"**Status:** {status_text}\n"
            f"**Placeholders:** `{placeholders}`\n\n"
            f"**Current Message:**\n"
            f"```\n{current[:500]}{'...' if len(current) > 500 else ''}\n```\n\n"
            f"⚠️ **Note:** Placeholders (like {'{phone}'}) will be replaced with actual values.",
            reply_markup=InlineKeyboardMarkup(buttons)
        )

    @app.on_callback_query(admin_filter & filters.regex(r"^start_edit_(.+)$"))
    async def start_edit_template_callback(client: Client, query: CallbackQuery):
        uid = query.from_user.id
        data_str = str(query.data) if query.data else ""
        template_key = data_str.replace("start_edit_", "")
        
        await query.answer()
        
        display_name = TEMPLATE_DISPLAY_NAMES.get(template_key, template_key)
        placeholders = TEMPLATE_PLACEHOLDERS.get(template_key, "None")
        
        await query.message.reply(
            f"✏️ **Edit: {display_name}**\n\n"
            f"নতুন মেসেজ লিখুন:\n\n"
            f"**Available Placeholders:** `{placeholders}`\n\n"
            f"⚠️ **Important:**\n"
            f"• Placeholders exactly এভাবে লিখবেন: {'{phone}'}, {'{price}'} etc.\n"
            f"• Cancel করতে /admin লিখুন"
        )
        admin_state[uid] = {"action": "edit_template", "template_key": template_key}

    @app.on_callback_query(admin_filter & filters.regex(r"^reset_tpl_(.+)$"))
    async def reset_template_callback(client: Client, query: CallbackQuery):
        data_str = str(query.data) if query.data else ""
        template_key = data_str.replace("reset_tpl_", "")
        
        await query.answer()
        
        display_name = TEMPLATE_DISPLAY_NAMES.get(template_key, template_key)
        
        buttons = [
            [InlineKeyboardButton("✅ Yes, Reset", callback_data=f"confirm_reset_{template_key}")],
            [InlineKeyboardButton("❌ Cancel", callback_data=f"edit_tpl_{template_key}")]
        ]
        
        await query.message.reply(
            f"⚠️ **Reset Confirmation**\n\n"
            f"আপনি কি নিশ্চিত **{display_name}** ডিফল্টে রিসেট করতে চান?",
            reply_markup=InlineKeyboardMarkup(buttons)
        )

    @app.on_callback_query(admin_filter & filters.regex(r"^confirm_reset_(.+)$"))
    async def confirm_reset_template_callback(client: Client, query: CallbackQuery):
        data_str = str(query.data) if query.data else ""
        template_key = data_str.replace("confirm_reset_", "")
        
        if template_key.startswith("tracker"):
            return
        
        await query.answer()
        
        reset_message_template(template_key)
        display_name = TEMPLATE_DISPLAY_NAMES.get(template_key, template_key)
        
        try:
            from bot.utils.fast_cache import refresh_all_templates
            refresh_all_templates()
            print(f"✅ Template '{template_key}' reset and cache refreshed")
        except Exception as cache_error:
            print(f"⚠️ Cache refresh error: {cache_error}")
        
        await query.message.reply(
            f"✅ **{display_name}** successfully reset to default!"
        )

    # ---------------- High Volume Stats Handler ----------------
    @app.on_callback_query(admin_filter & filters.regex(r"^highvolumestats$"))
    async def high_volume_stats_callback(client: Client, query: CallbackQuery):
        await query.answer()
        
        try:
            result = get_session_tracker_list()
            list_data, total_users, total_sessions = result if isinstance(result, tuple) else (result, 0, 0)
            
            if not list_data or total_sessions == 0:
                msg = """🚀 **আজকের Performance Report**

এখনো কোনো sessions নেই আজ।

ব্যবহারকারীরা verification শুরু করলে:
✅ সফল sessions - এখানে দেখাবে
❌ ব্যর্থ attempts - এখানে দেখাবে
❄️ Freeze হওয়া একাউন্ট - এখানে দেখাবে

এখন আপনার বট idle অবস্থায় আছে, users যুক্ত হলে data দেখা যাবে।

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
💡 **কি হবে এখানে:**
যখন users verify করবে, তখন এখানে দেখাবে:
• প্রতি ঘণ্টায় কত sessions
• Success rate কত %
• কোন দেশ থেকে বেশি
"""
                await query.message.reply(msg)
            else:
                msg = f"""🚀 **আজকের Performance Report**

👥 Total Users: **{total_users}**
✅ Total Verified Sessions: **{total_sessions}**

{list_data if list_data else "কোনো বিস্তারিত ডাটা নেই।"}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
💡 **এটা মানে কি:**
✅ Successful = কত সেশন ভালোভাবে তৈরি হয়েছে
❌ Failed = কত attempt ব্যর্থ হয়েছে
❄️ Frozen = কত একাউন্ট freeze হয়েছে
📊 Success Rate = সবার মধ্যে কত % সফল হয়েছে
"""
                await query.message.reply(msg)
        except Exception as e:
            msg = f"""🚀 **আজকের Performance**

এখনো কোনো data নেই। Users যুক্ত হলে এখানে দেখা যাবে।

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"""
            await query.message.reply(msg)

    @app.on_callback_query(admin_filter & filters.regex(r"^volumeconfig$"))
    async def volume_config_callback(client: Client, query: CallbackQuery):
        await query.answer()
        
        msg = """⚙️ **Volume Config - কিভাবে 600 sessions/day করবেন**

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📊 **এখন কত করতে পারো:**
🟡 Basic (কোনো setup ছাড়া): 100-150/day
🟢 Proxies সহ: 300-400/day
🟢 Proxies + Extra APIs: 500-600/day

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

✅ **যা করতে হবে:**

**#1 - Proxies যোগ করুন (Optional)**
একটি ফাইল তৈরি করুন: `proxies.txt`

এতে লিখুন:
```
124.56.78.9:8080
200.10.20.30:3128:user:pass
191.25.35.45:9090
```

**#2 - Extra API IDs যোগ করুন (Optional)**
my.telegram.org এ গিয়ে নতুন API ID বানান
config.py এ এভাবে যোগ করুন:
```
EXTRA_APIS = [
    (API_ID_2, "API_HASH_2"),
    (API_ID_3, "API_HASH_3"),
]
```

**#3 - সেটআপ চালু করুন**
main.py এর শুরুতে এটা যোগ করুন:
```python
from bot.utils.high_volume_optimizer import configure_high_volume
configure_high_volume(target_daily=600, proxy_file="proxies.txt")
```

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

💡 **সহজভাবে:**
- Proxies = বিভিন্ন IP থেকে request করা
- Extra APIs = একই সাথে বেশি request পাঠানো
- দুটোই থাকলে = সবচেয়ে দ্রুত কাজ করবে ⚡

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"""
        
        buttons = [
            [InlineKeyboardButton("📊 আজকের Stats দেখুন", callback_data="highvolumestats")],
            [InlineKeyboardButton("🔙 Back to System Controls", callback_data="menu_system")]
        ]
        
        await query.message.reply(msg, reply_markup=InlineKeyboardMarkup(buttons))

    # ---------------- Callback Queries ----------------
    @app.on_callback_query(admin_filter & filters.regex(r"^(setrate|settimeout|ban|unban|adjustbalance|userstats|totalusers|zerobalance|pendingwithdraw|withdrawlogs|togglewithdraw|togglecountry|disablecountries|broadcast|sendtouser|setchannel|minwithdraw|sessiontracker|allbalances|user_withdraw_control|uwc_.*|show_2fa_secret)$"))
    async def admin_callbacks(client: Client, query: CallbackQuery):
        uid = query.from_user.id
        data = str(query.data)
        
        print(f"🔍 Admin callback received: {data} from user {uid}")
        
        await query.answer()

        # ---------------- Actions requiring input ----------------
        if data == "setrate":
            buttons = [
                [InlineKeyboardButton("✅ Spam Free Rate (ভালো একাউন্ট)", callback_data="setrate_spamfree")],
                [InlineKeyboardButton("⚠️ Spam Rate (স্প্যাম একাউন্ট)", callback_data="setrate_spam")],
                [InlineKeyboardButton("🔒 Limit Rate (লিমিট একাউন্ট)", callback_data="setrate_limit")],
                [InlineKeyboardButton("📋 All Rates একসাথে সেট করুন", callback_data="setrate_all")],
                [InlineKeyboardButton("🔙 Back to Country & Pricing", callback_data="menu_country")]
            ]
            await query.message.reply(
                "🌐 **Set Country Price**\n\n"
                "কোন ধরনের একাউন্টের জন্য রেট সেট করতে চান?\n\n"
                "✅ **Spam Free** = ভালো/ক্লিন একাউন্ট (সর্বোচ্চ রেট)\n"
                "⚠️ **Spam** = স্প্যাম একাউন্ট (কম রেট)\n"
                "🔒 **Limit** = লিমিট একাউন্ট (ভিন্ন রেট)\n\n"
                "অথবা All Rates এ ক্লিক করে একসাথে ৩টি রেট সেট করুন।",
                reply_markup=InlineKeyboardMarkup(buttons)
            )

        elif data == "settimeout":
            await query.message.reply("⏳ দেশের কোড এবং সেকেন্ড দিন (যেমন: +880 60 মানে ৬০ সেকেন্ড)")
            admin_state[uid] = {"action": "settimeout"}

        elif data == "ban":
            await query.message.reply("🚫 Send user ID to ban")
            admin_state[uid] = {"action": "ban"}

        elif data == "unban":
            await query.message.reply("✔️ Send user ID to unban")
            admin_state[uid] = {"action": "unban"}

        elif data == "adjustbalance":
            await query.message.reply("💰 Send User ID and amount (e.g., 123456 +10 or 123456 -5)")
            admin_state[uid] = {"action": "adjustbalance"}

        elif data == "userstats":
            await query.message.reply("📊 Send user ID to view stats")
            admin_state[uid] = {"action": "userstats"}

        elif data == "totalusers":
            total, active = get_total_users()
            users_list = get_all_users_list()
            
            header = (
                "╔══════════════════════════════╗\n"
                "       📈 টোটাল ইউজার রিপোর্ট\n"
                "╠══════════════════════════════╣\n"
                f"  👥 মোট ইউজার: **{total}** জন\n"
                f"  ✅ একটিভ (২৪ ঘণ্টা): **{active}** জন\n"
                "╚══════════════════════════════╝\n"
            )
            
            if users_list:
                user_details = "\n📋 **ইউজার লিস্ট:**\n"
                user_details += "━━━━━━━━━━━━━━━━━━━━━\n"
                for idx, user in enumerate(users_list[:50], 1):
                    user_id = user.get('user_id', 'N/A')
                    balance = user.get('balance', 0)
                    sessions = user.get('sessions', 0)
                    banned = "🚫 Banned" if user.get('banned') else "✅ Active"
                    user_details += (
                        f"{idx}. 👤 **ID:** `{user_id}`\n"
                        f"   💰 Balance: ${balance:.2f}\n"
                        f"   ✅ Sessions: {sessions}\n"
                        f"   📌 Status: {banned}\n"
                        "━━━━━━━━━━━━━━━━━━━━━\n"
                    )
                if len(users_list) > 50:
                    user_details += f"\n⚠️ আরো {len(users_list) - 50} জন ইউজার আছে...\n"
            else:
                user_details = "\n❌ কোনো ইউজার নেই!"
            
            response = header + user_details
            
            if len(response) > 4000:
                for i in range(0, len(response), 4000):
                    await query.message.reply(response[i:i+4000])
            else:
                await query.message.reply(response)

        elif data == "zerobalance":
            zero_all_balances()
            await query.message.reply("🧹 All user balances have been reset to 0")

        elif data == "pendingwithdraw":
            pending = get_pending_withdraw_requests()
            
            header = (
                "╔══════════════════════════════╗\n"
                "    📥 পেন্ডিং উইথড্র রিকোয়েস্ট\n"
                "╠══════════════════════════════╣\n"
                f"  📊 মোট পেন্ডিং: **{len(pending)}** টি\n"
                "╚══════════════════════════════╝\n"
            )
            
            if pending:
                details = "\n📋 **রিকোয়েস্ট লিস্ট:**\n"
                details += "━━━━━━━━━━━━━━━━━━━━━\n"
                for idx, req in enumerate(pending, 1):
                    user_id = req.get('user_id', 'N/A')
                    amount = req.get('amount', 0)
                    method = req.get('method', 'N/A')
                    wallet_address = req.get('wallet_address', 'N/A')
                    timestamp = req.get('timestamp', 'N/A')
                    details += (
                        f"🔹 **রিকোয়েস্ট #{idx}**\n"
                        f"   👤 User ID: `{user_id}`\n"
                        f"   💵 Amount: **${amount:.2f}**\n"
                        f"   📱 Method: {method}\n"
                        f"   📍 Wallet: `{wallet_address}`\n"
                        f"   📅 Time: {timestamp}\n"
                        "━━━━━━━━━━━━━━━━━━━━━\n"
                    )
                
                buttons = []
                for idx, req in enumerate(pending[:10], 1):
                    user_id = req.get('user_id', 'N/A')
                    amount = req.get('amount', 0)
                    timestamp = req.get('timestamp', '')
                    safe_ts = timestamp.replace(':', 'C').replace('.', 'D')[:19] if timestamp else ''
                    buttons.append([
                        InlineKeyboardButton(f"✅ Approve #{idx}", callback_data=f"wapprove_{user_id}_{safe_ts}"),
                        InlineKeyboardButton(f"❌ Reject #{idx}", callback_data=f"wreject_{user_id}_{safe_ts}")
                    ])
                buttons.append([InlineKeyboardButton("🔙 Back to Withdraw & Finance", callback_data="menu_withdraw")])
                
                response = header + details
                if len(response) > 4000:
                    for i in range(0, len(response), 4000):
                        await query.message.reply(response[i:i+4000])
                    await query.message.reply("**অ্যাকশন বাটন:**", reply_markup=InlineKeyboardMarkup(buttons))
                else:
                    await query.message.reply(response, reply_markup=InlineKeyboardMarkup(buttons))
            else:
                details = "\n✅ কোনো পেন্ডিং রিকোয়েস্ট নেই!"
                response = header + details
                await query.message.reply(response, reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("🔙 Back to Withdraw & Finance", callback_data="menu_withdraw")]
                ]))

        elif data == "withdrawlogs":
            logs = get_withdraw_logs()
            
            header = (
                "╔══════════════════════════════╗\n"
                "       🧾 উইথড্র লগস\n"
                "╠══════════════════════════════╣\n"
                f"  📊 মোট লগ: **{len(logs)}** টি\n"
                "╚══════════════════════════════╝\n"
            )
            
            if logs:
                details = "\n📋 **সাম্প্রতিক উইথড্র:**\n"
                details += "━━━━━━━━━━━━━━━━━━━━━\n"
                for idx, log in enumerate(reversed(logs[-20:]), 1):
                    user_id = log.get('user_id', 'N/A')
                    amount = log.get('amount', 0)
                    method = log.get('method', 'N/A')
                    status = log.get('status', 'N/A')
                    timestamp = log.get('timestamp', 'N/A')
                    wallet_address = log.get('wallet_address', 'N/A')
                    
                    status_icon = "✅" if status == "approved" else "⏳" if status == "pending" else "❌"
                    
                    details += (
                        f"🔸 **লগ #{idx}**\n"
                        f"   👤 User ID: `{user_id}`\n"
                        f"   💵 Amount: **${amount:.2f}**\n"
                        f"   📱 Method: {method}\n"
                        f"   📍 Wallet: `{wallet_address}`\n"
                        f"   📌 Status: {status_icon} {status}\n"
                        f"   📅 Time: {timestamp}\n"
                        "━━━━━━━━━━━━━━━━━━━━━\n"
                    )
                if len(logs) > 20:
                    details += f"\n⚠️ শুধু সাম্প্রতিক ২০টি দেখানো হচ্ছে...\n"
            else:
                details = "\n❌ কোনো উইথড্র লগ নেই!"
            
            response = header + details
            
            if len(response) > 4000:
                for i in range(0, len(response), 4000):
                    await query.message.reply(response[i:i+4000])
            else:
                await query.message.reply(response, reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("🔙 Back to Withdraw & Finance", callback_data="menu_withdraw")]
                ]))

        elif data == "togglewithdraw":
            try:
                print(f"🔄 Toggling withdraw status...")
                status = toggle_withdraw()
                
                from bot.utils.fast_cache import force_refresh_withdraw_status
                force_refresh_withdraw_status(status)
                
                state = "ENABLED ✅" if status else "DISABLED ❌"
                print(f"✅ Withdraw toggled successfully. New status: {status}")
                await query.message.reply(f"💸 Withdraw is now {state}")
            except Exception as e:
                print(f"❌ Error toggling withdraw: {e}")
                import traceback
                traceback.print_exc()
                await query.message.reply(f"❌ Error: {str(e)}")

        elif data == "togglecountry":
            await query.message.reply("🔴 Send country code to toggle ON/OFF (e.g. +880)")
            admin_state[uid] = {"action": "togglecountry"}

        elif data == "disablecountries":
            disable_all_countries()
            await query.message.reply("🛑 All countries disabled! Verification temporarily paused.")

        elif data == "broadcast":
            await query.message.reply("📢 Send message to broadcast")
            admin_state[uid] = {"action": "broadcast"}

        elif data == "sendtouser":
            await query.message.reply(
                "📩 **Send Message to Specific User**\n\n"
                "প্রথমে User ID লিখুন:\n\n"
                "উদাহরণ: `123456789`"
            )
            admin_state[uid] = {"action": "sendtouser_step1"}

        elif data == "setchannel":
            current = get_required_channel()
            await query.message.reply(f"📺 Current channel: {current}\n\nSend new channel username (e.g. @newschannel457)")
            admin_state[uid] = {"action": "setchannel"}

        elif data == "minwithdraw":
            amounts = get_min_withdraw_amounts()
            buttons = [
                [InlineKeyboardButton(f"USDT (BEP20) - Min: ${amounts.get('usdt', 0)}", callback_data="setmin_usdt")],
                [InlineKeyboardButton(f"TRX - Min: ${amounts.get('trx', 0)}", callback_data="setmin_trx")],
                [InlineKeyboardButton(f"CARD NAME - Min: ${amounts.get('cardname', 0)}", callback_data="setmin_cardname")],
                [InlineKeyboardButton(f"Binance - Min: ${amounts.get('binance', 0)}", callback_data="setmin_binance")],
                [InlineKeyboardButton("🔙 Back to Withdraw & Finance", callback_data="menu_withdraw")]
            ]
            await query.message.reply(
                "💵 **Min Withdraw Settings**\n\n"
                "প্রতিটি উইথড্র মাধ্যমের জন্য সর্বনিম্ন এমাউন্ট সেট করুন:\n\n"
                "বাটনে ক্লিক করে এমাউন্ট সেট করুন:",
                reply_markup=InlineKeyboardMarkup(buttons)
            )

        elif data == "sessiontracker":
            list_data, total_users, total_sessions = get_session_tracker_list()
            buttons = [
                [InlineKeyboardButton("📋 View Session List", callback_data="view_session_list")],
                [InlineKeyboardButton("🔄 Reset All Sessions", callback_data="reset_session_tracker")],
                [InlineKeyboardButton("🔙 Back to Statistics", callback_data="menu_stats")]
            ]
            await query.message.reply(
                f"📊 **Today's Session Stats**\n\n"
                f"👥 Total Users: **{total_users}**\n"
                f"✅ Total Verified Sessions: **{total_sessions}**\n\n"
                f"নিচের বাটন থেকে অপশন সিলেক্ট করুন:",
                reply_markup=InlineKeyboardMarkup(buttons)
            )

        elif data == "user_withdraw_control":
            await query.message.reply(
                "👤 **User Specific Withdraw Control**\n\n"
                "ইউজারের ID লিখুন যার লিমিট সেট করতে চান:"
            )
            admin_state[uid] = {"action": "user_withdraw_step1"}

        elif data.startswith("uwc_"):
            parts = data.split("_")
            target_uid = int(parts[1])
            cmd = parts[2]
            
            if cmd == "toggle":
                from bot.utils.storage import get_user_withdraw_config, set_user_withdraw_config
                current = get_user_withdraw_config(target_uid).get("disabled", False)
                set_user_withdraw_config(target_uid, disabled=not current)
                await query.answer(f"Withdraw {'Disabled' if not current else 'Enabled'} for {target_uid}", show_alert=True)
                
                # Refresh Menu
                config = get_user_withdraw_config(target_uid)
                status_text = "🔴 OFF" if config.get("disabled") else "🟢 ON"
                min_amt = config.get("min", "Default")
                max_amt = config.get("max", "Unlimited")
                buttons = [
                    [InlineKeyboardButton(f"Status: {status_text}", callback_data=f"uwc_{target_uid}_toggle")],
                    [InlineKeyboardButton(f"Min: ${min_amt}", callback_data=f"uwc_{target_uid}_min")],
                    [InlineKeyboardButton(f"Max: ${max_amt}", callback_data=f"uwc_{target_uid}_max")],
                    [InlineKeyboardButton("🔙 Back", callback_data="menu_withdraw")]
                ]
                await query.message.edit_text(
                    f"👤 **Settings for User:** `{target_uid}`\n\n"
                    f"নিচের বাটন থেকে কনফিগার করুন:",
                    reply_markup=InlineKeyboardMarkup(buttons)
                )
            elif cmd == "min":
                await query.message.reply(f"Enter MINIMUM withdraw for `{target_uid}`:")
                admin_state[uid] = {"action": "user_withdraw_min", "target_uid": target_uid}
            elif cmd == "max":
                await query.message.reply(f"Enter MAXIMUM withdraw for `{target_uid}`:")
                admin_state[uid] = {"action": "user_withdraw_max", "target_uid": target_uid}

        elif data == "allbalances":
            report, total_users, users_with_balance, total_balance = get_all_balances_report()
            
            header = (
                f"💵 **All User Balances Report**\n"
                f"━━━━━━━━━━━━━━━━━━━━━\n"
                f"👥 Total Users: **{total_users}**\n"
                f"💰 Users with Balance: **{users_with_balance}**\n"
                f"💵 Total Unreleased Balance: **${total_balance}**\n"
                f"━━━━━━━━━━━━━━━━━━━━━\n\n"
            )
            
            if not report:
                await query.message.reply(
                    header + "❌ কোনো ইউজারের ব্যালেন্স নেই।"
                )
            else:
                full_message = header + report
                
                if len(full_message) > 4000:
                    await query.message.reply(header)
                    for i in range(0, len(report), 4000):
                        await query.message.reply(report[i:i+4000])
                else:
                    await query.message.reply(full_message)

        elif data == "show_2fa_secret":
            from bot.config import SESSION_2FA_PASSWORD
            await query.message.reply(
                f"🔐 **Current 2FA Password (Randomly Generated):**\n\n"
                f"`{SESSION_2FA_PASSWORD}`\n\n"
                f"এটি ব্যবহার করে আপনি ঐ অ্যাকাউন্টগুলোতে লগইন করতে পারবেন।"
            )

        else:
            await query.answer("Feature not implemented yet", show_alert=True)

    # ---------------- Message Handler for Admin Inputs ----------------
    @app.on_message(admin_filter & filters.text & ~filters.command(["admin", "start", "account", "withdraw", "cap", "support"]))
    async def handle_admin_actions(client: Client, message: Message):
        user_id = message.from_user.id
        if user_id not in admin_state:
            return

        action = admin_state[user_id]["action"]
        text = message.text.strip()

        try:
            if action == "setrate":
                parts = text.split()
                country = parts[0].strip()
                price = float(parts[1])
                set_country_rate(country, price)
                await message.reply(f"✅ Rate set: {country} = {price} USD")
            
            elif action == "setrate_type":
                parts = text.split()
                if len(parts) < 2:
                    await message.reply("❌ Format: +CountryCode Rate (e.g., +880 30)")
                    return
                country = parts[0].strip()
                rate = float(parts[1])
                rate_type = admin_state[user_id].get("rate_type", "spam_free_rate")
                
                rate_type_names = {
                    "spam_free_rate": "Spam Free",
                    "spam_rate": "Spam",
                    "limit_rate": "Limit"
                }
                type_name = rate_type_names.get(rate_type, "Unknown")
                
                set_country_rate_by_type(country, rate_type, rate)
                
                rates = get_country_rates(country)
                await message.reply(
                    f"✅ **{type_name} Rate সেট করা হয়েছে!**\n\n"
                    f"🌍 Country: {country}\n"
                    f"💵 {type_name} Rate: ${rate}\n\n"
                    f"📊 **সব Rates:**\n"
                    f"✅ Spam Free: ${rates['spam_free_rate']}\n"
                    f"⚠️ Spam: ${rates['spam_rate']}\n"
                    f"🔒 Limit: ${rates['limit_rate']}"
                )
            
            elif action == "setrate_all":
                parts = text.split()
                if len(parts) < 4:
                    await message.reply(
                        "❌ Format: +CountryCode SpamFreeRate SpamRate LimitRate\n\n"
                        "উদাহরণ: `+880 30 15 10`"
                    )
                    return
                country = parts[0].strip()
                spam_free_rate = float(parts[1])
                spam_rate = float(parts[2])
                limit_rate = float(parts[3])
                
                set_country_rates(country, spam_free_rate, spam_rate, limit_rate)
                
                await message.reply(
                    f"✅ **সব Rates সেট করা হয়েছে!**\n\n"
                    f"🌍 Country: {country}\n\n"
                    f"✅ Spam Free Rate: ${spam_free_rate}\n"
                    f"⚠️ Spam Rate: ${spam_rate}\n"
                    f"🔒 Limit Rate: ${limit_rate}\n\n"
                    f"এখন এই কান্ট্রির অ্যাকাউন্ট ভেরিফাই হলে:\n"
                    f"• ভালো অ্যাকাউন্ট = ${spam_free_rate}\n"
                    f"• স্প্যাম অ্যাকাউন্ট = ${spam_rate}\n"
                    f"• লিমিট অ্যাকাউন্ট = ${limit_rate}"
                )

            elif action == "settimeout":
                parts = text.split()
                if len(parts) < 2:
                    await message.reply("❌ ফরম্যাট: country_code seconds (যেমন: +880 60)")
                    return
                country = parts[0].strip()
                try:
                    timeout_seconds = int(parts[1])
                except ValueError:
                    await message.reply("❌ সেকেন্ড অবশ্যই একটি সংখ্যা হতে হবে!")
                    return
                if timeout_seconds <= 0:
                    await message.reply("❌ সেকেন্ড অবশ্যই ০ এর বেশি হতে হবে!")
                    return
                if timeout_seconds > 3600:
                    await message.reply("⚠️ সতর্কতা: ১ ঘণ্টার বেশি সময় সেট করা হচ্ছে!")
                success, msg = set_country_timeout(country, timeout_seconds)
                await message.reply(f"{msg}\n\n✅ এই দেশের ভেরিফিকেশন {timeout_seconds} সেকেন্ড পর হবে")


            elif action == "ban":
                print(f"🔍 Attempting to ban user: {text}")
                user_id_to_ban = int(text)
                ban_user(user_id_to_ban)
                from bot.utils.fast_cache import mark_user_banned
                mark_user_banned(user_id_to_ban)
                print(f"✅ User {text} banned successfully (storage + cache)")
                await message.reply(f"🚫 User {text} banned")

            elif action == "unban":
                print(f"🔍 Attempting to unban user: {text}")
                user_id_to_unban = int(text)
                unban_user(user_id_to_unban)
                from bot.utils.fast_cache import mark_user_unbanned
                mark_user_unbanned(user_id_to_unban)
                print(f"✅ User {text} unbanned successfully (storage + cache)")
                await message.reply(f"✔️ User {text} unbanned")

            elif action == "adjustbalance":
                parts = text.split()
                if len(parts) < 2:
                    await message.reply(
                        "❌ **ভুল ফরম্যাট!**\n\n"
                        "সঠিক ফরম্যাট: `UserID Amount`\n\n"
                        "উদাহরণ:\n"
                        "• `123456789 +10` (১০ ডলার যোগ)\n"
                        "• `123456789 -5` (৫ ডলার বাদ)\n"
                        "• `123456789 25` (২৫ ডলার যোগ)"
                    )
                    return
                try:
                    uid = int(parts[0])
                except ValueError:
                    await message.reply("❌ User ID শুধু সংখ্যা হতে হবে!")
                    return
                try:
                    amount_str = parts[1].replace("+", "").strip()
                    amount = float(amount_str)
                except ValueError:
                    await message.reply("❌ Amount সঠিক সংখ্যা হতে হবে (যেমন: 10, -5, +25)")
                    return
                
                old_info = get_user_info(uid)
                old_balance = old_info.get('balance', 0)
                add_balance_for_user(uid, amount)
                new_info = get_user_info(uid)
                new_balance = new_info.get('balance', 0)
                
                action_text = "যোগ করা হয়েছে" if amount >= 0 else "কমানো হয়েছে"
                await message.reply(
                    f"✅ **Balance Updated Successfully!**\n\n"
                    f"👤 User ID: `{uid}`\n"
                    f"💵 Old Balance: ${old_balance:.2f}\n"
                    f"{'➕' if amount >= 0 else '➖'} Amount: ${abs(amount):.2f} {action_text}\n"
                    f"💰 New Balance: **${new_balance:.2f}**"
                )

            elif action == "userstats":
                uid = int(text)
                stats = get_user_stats(uid)
                await message.reply(f"📊 User Stats:\n{stats}")

            elif action == "togglecountry":
                country = text.strip()
                if not country.startswith('+'):
                    await message.reply("❌ Country code must start with + (e.g. +880)")
                    return
                country_code, new_status = toggle_country_status(country)
                status_text = "🟢 OPEN" if new_status else "🔴 CLOSED"
                await message.reply(f"✅ Country {country_code} is now {status_text}")

            elif action == "setchannel":
                new_channel = text.strip()
                if not new_channel.startswith("@"):
                    await message.reply("❌ Channel must start with @ (e.g. @newchannel123)")
                    return
                old_channel = get_required_channel()
                set_required_channel(new_channel)
                total_users = len(get_all_users_list())
                await message.reply(
                    f"✅ Channel updated successfully!\n\n"
                    f"🔴 Old channel: {old_channel}\n"
                    f"🟢 New channel: {new_channel}\n\n"
                    f"👥 All {total_users} users must now join {new_channel} to use the bot."
                )

            elif action == "broadcast":
                from pyrogram.errors import FloodWait
                import asyncio
                users = get_all_users()
                total = len(users)
                sent, failed = 0, 0
                
                if total == 0:
                    await message.reply("❌ কোনো ইউজার নেই!")
                else:
                    progress_msg = await message.reply(
                        f"📢 **Broadcast শুরু হচ্ছে...**\n\n"
                        f"👥 Total Users: {total}\n"
                        f"⏳ Progress: 0%"
                    )
                    
                    for i, user_id_str in enumerate(users):
                        try:
                            await client.send_message(int(user_id_str), text)
                            sent += 1
                        except FloodWait as e:
                            wait_time = int(getattr(e, 'value', 30) or 30)
                            await asyncio.sleep(min(wait_time, 30))
                            try:
                                await client.send_message(int(user_id_str), text)
                                sent += 1
                            except Exception:
                                failed += 1
                        except Exception:
                            failed += 1
                        
                        if (i + 1) % 20 == 0 or i + 1 == total:
                            percent = int((i + 1) / total * 100)
                            try:
                                await progress_msg.edit_text(
                                    f"📢 **Broadcast চলছে...**\n\n"
                                    f"👥 Total: {total}\n"
                                    f"✅ Sent: {sent}\n"
                                    f"❌ Failed: {failed}\n"
                                    f"⏳ Progress: {percent}%"
                                )
                            except Exception:
                                pass  # Edit may fail if too fast
                        
                        await asyncio.sleep(0.05)
                    
                    try:
                        await progress_msg.edit_text(
                            f"📢 **Broadcast Complete!** ✅\n\n"
                            f"👥 Total Users: {total}\n"
                            f"✅ Sent: {sent}\n"
                            f"❌ Failed: {failed}\n"
                            f"📊 Success Rate: {int(sent/total*100) if total > 0 else 0}%"
                        )
                    except Exception:
                        await message.reply(
                            f"📢 **Broadcast Complete!** ✅\n\n"
                            f"✅ Sent: {sent}\n"
                            f"❌ Failed: {failed}"
                        )

            elif action == "sendtouser_step1":
                try:
                    target_user_id = int(text)
                    admin_state[user_id] = {"action": "sendtouser_step2", "target_user_id": target_user_id}
                    await message.reply(
                        f"✅ User ID: `{target_user_id}` সেট করা হয়েছে!\n\n"
                        f"এখন মেসেজ লিখুন যা পাঠাতে চান:\n\n"
                        f"⚠️ Cancel করতে /admin লিখুন"
                    )
                    return
                except ValueError:
                    await message.reply("❌ সঠিক User ID লিখুন (শুধু সংখ্যা)")
                    return

            elif action == "sendtouser_step2":
                target_user_id = admin_state[user_id].get("target_user_id")
                if not target_user_id:
                    await message.reply("❌ Error: Target user not found. Try again with /admin")
                else:
                    try:
                        await client.send_message(target_user_id, text)
                        await message.reply(
                            f"✅ **মেসেজ সফলভাবে পাঠানো হয়েছে!**\n\n"
                            f"👤 User ID: `{target_user_id}`\n"
                            f"📝 Message:\n```\n{text[:200]}{'...' if len(text) > 200 else ''}\n```"
                        )
                    except Exception as e:
                        await message.reply(f"❌ মেসেজ পাঠাতে ব্যর্থ হয়েছে!\n\nError: {str(e)}")

            elif action == "setmin":
                method = admin_state[user_id].get("method", "")
                method_names = {"usdt": "USDT (BEP20)", "trx": "TRX", "cardname": "CARD NAME", "binance": "Binance"}
                method_name = method_names.get(method, method.upper())
                
                try:
                    amount = float(text)
                    if amount < 0:
                        await message.reply("❌ এমাউন্ট 0 বা তার বেশি হতে হবে!")
                    else:
                        set_min_withdraw_for_method(method, amount)
                        await message.reply(
                            f"✅ সফলভাবে সেট করা হয়েছে!\n\n"
                            f"💵 **{method_name}** এর সর্বনিম্ন উইথড্র: **${amount}**"
                        )
                except ValueError:
                    await message.reply("❌ সঠিক সংখ্যা লিখুন (যেমন: 10 বা 15.5)")

            elif action == "edit_template":
                template_key = admin_state[user_id].get("template_key", "")
                display_name = TEMPLATE_DISPLAY_NAMES.get(template_key, template_key)
                
                set_message_template(template_key, text)
                
                try:
                    from bot.utils.fast_cache import update_template_cache
                    update_template_cache(template_key, text)
                    print(f"✅ Template '{template_key}' saved and cache updated")
                except Exception as cache_error:
                    print(f"⚠️ Cache update error: {cache_error}")
                
                await message.reply(
                    f"✅ **{display_name}** সফলভাবে আপডেট হয়েছে!\n\n"
                    f"**New Message:**\n"
                    f"```\n{text[:500]}{'...' if len(text) > 500 else ''}\n```"
                )

            elif action == "user_withdraw_step1":
                try:
                    target_uid = int(text)
                    from bot.utils.storage import get_user_withdraw_config
                    config = get_user_withdraw_config(target_uid)
                    
                    status = "🔴 OFF" if config.get("disabled") else "🟢 ON"
                    min_amt = config.get("min", "Default")
                    max_amt = config.get("max", "Unlimited")
                    
                    buttons = [
                        [InlineKeyboardButton(f"Status: {status}", callback_data=f"uwc_{target_uid}_toggle")],
                        [InlineKeyboardButton(f"Min: ${min_amt}", callback_data=f"uwc_{target_uid}_min")],
                        [InlineKeyboardButton(f"Max: ${max_amt}", callback_data=f"uwc_{target_uid}_max")],
                        [InlineKeyboardButton("🔙 Back", callback_data="menu_withdraw")]
                    ]
                    await message.reply(
                        f"👤 **Settings for User:** `{target_uid}`\n\n"
                        f"নিচের বাটন থেকে কনফিগার করুন:",
                        reply_markup=InlineKeyboardMarkup(buttons)
                    )
                except ValueError:
                    await message.reply("❌ Invalid User ID!")

            elif action == "user_withdraw_min":
                target_uid = admin_state[user_id].get("target_uid")
                try:
                    amt = float(text)
                    from bot.utils.storage import set_user_withdraw_config
                    set_user_withdraw_config(target_uid, min_amt=amt)
                    await message.reply(f"✅ Min withdraw set to ${amt} for `{target_uid}`")
                except:
                    await message.reply("❌ Invalid Amount!")

            elif action == "user_withdraw_max":
                target_uid = admin_state[user_id].get("target_uid")
                try:
                    amt = float(text)
                    from bot.utils.storage import set_user_withdraw_config
                    set_user_withdraw_config(target_uid, max_amt=amt)
                    await message.reply(f"✅ Max withdraw set to ${amt} for `{target_uid}`")
                except:
                    await message.reply("❌ Invalid Amount!")

            elif action == "set_2fa_password":
                new_password = text.strip()
                if len(new_password) < 8:
                    await message.reply(
                        "❌ **Password খুব ছোট!**\n\n"
                        "Password কমপক্ষে 8 characters হতে হবে।\n"
                        "আবার চেষ্টা করুন অথবা /admin দিয়ে cancel করুন।"
                    )
                    return
                
                _storage["temp_2fa_password"] = new_password
                save_storage()
                
                await message.reply(
                    f"✅ **2FA Password আপডেট হয়েছে!**\n"
                    f"━━━━━━━━━━━━━━━━━━━━━\n\n"
                    f"🔑 **New Password:** `{new_password[:4]}{'*' * (len(new_password) - 4)}`\n\n"
                    f"⚠️ **গুরুত্বপূর্ণ:**\n"
                    f"এই password শুধু temporary storage এ সেভ হয়েছে।\n\n"
                    f"🔧 **Permanent করতে:**\n"
                    f"Replit Secrets এ যান এবং `SESSION_2FA_PASSWORD` কে নতুন password দিয়ে আপডেট করুন:\n\n"
                    f"`{new_password}`\n\n"
                    f"💡 Bot restart করলে নতুন password কাজ করবে।",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("🔙 Back to Settings", callback_data="menu_settings_config")]
                    ])
                )
                _admin_manager.clear_state(user_id)

            elif action == "search_user":
                try:
                    search_uid = int(text.strip())
                    user_info = get_user_info(search_uid)
                    
                    from bot.utils.country_data import get_flag
                    
                    balance = user_info.get("balance", 0)
                    sessions = user_info.get("sessions", 0)
                    banned = user_info.get("banned", False)
                    joined = user_info.get("joined", "N/A")
                    country_sessions = user_info.get("country_sessions", {})
                    
                    banned_status = "🚫 Banned" if banned else "✅ Active"
                    
                    country_lines = []
                    for cc, count in sorted(country_sessions.items(), key=lambda x: x[1], reverse=True):
                        flag = get_flag(cc) if cc != "other" else "🌍"
                        country_lines.append(f"   {flag} {cc}: {count}টি")
                    country_text = "\n".join(country_lines) if country_lines else "   কোনো session নেই"
                    
                    buttons = [
                        [
                            InlineKeyboardButton("🚫 Ban", callback_data=f"quick_ban_{search_uid}"),
                            InlineKeyboardButton("✅ Unban", callback_data=f"quick_unban_{search_uid}")
                        ],
                        [InlineKeyboardButton("🔙 Back to Advanced Tools", callback_data="menu_advanced_tools")]
                    ]
                    
                    await message.reply(
                        f"🔍 **User Found!**\n"
                        f"━━━━━━━━━━━━━━━━━━━━━\n\n"
                        f"👤 **User ID:** `{search_uid}`\n"
                        f"💰 **Balance:** ${balance:.2f}\n"
                        f"✅ **Sessions:** {sessions}\n"
                        f"📌 **Status:** {banned_status}\n"
                        f"📅 **Joined:** {joined[:10] if len(joined) > 10 else joined}\n\n"
                        f"🌍 **Country Sessions:**\n{country_text}",
                        reply_markup=InlineKeyboardMarkup(buttons)
                    )
                    _admin_manager.clear_state(user_id)
                except ValueError:
                    await message.reply("❌ সঠিক User ID লিখুন (শুধু সংখ্যা)")
                    _admin_manager.clear_state(user_id)
                    return

            elif action == "add_new_admin":
                try:
                    new_admin_id = int(text.strip())
                    
                    admins = _storage.get("admins", [ADMIN_ID])
                    if ADMIN_ID not in admins:
                        admins.append(ADMIN_ID)
                    
                    if new_admin_id in admins:
                        await message.reply(f"⚠️ User `{new_admin_id}` ইতিমধ্যে Admin আছে!")
                        _admin_manager.clear_state(user_id)
                        return
                    
                    admins.append(new_admin_id)
                    _storage["admins"] = admins
                    save_storage()
                    
                    admin_lines = [f"👤 `{admin_id}`" for admin_id in admins]
                    
                    await message.reply(
                        f"✅ **নতুন Admin যোগ হয়েছে!**\n"
                        f"━━━━━━━━━━━━━━━━━━━━━\n\n"
                        f"👑 New Admin: `{new_admin_id}`\n\n"
                        f"📊 **Total Admins:** {len(admins)}\n\n"
                        f"**Admin List:**\n" + "\n".join(admin_lines),
                        reply_markup=InlineKeyboardMarkup([
                            [InlineKeyboardButton("🔙 Back to Settings", callback_data="menu_settings_config")]
                        ])
                    )
                    _admin_manager.clear_state(user_id)
                except ValueError:
                    await message.reply("❌ সঠিক User ID লিখুন (শুধু সংখ্যা)")
                    _admin_manager.clear_state(user_id)
                    return

        except Exception as e:
            await message.reply(f"❌ Error: {str(e)}")
            _admin_manager.clear_state(user_id)

        _admin_manager.clear_state(user_id)
