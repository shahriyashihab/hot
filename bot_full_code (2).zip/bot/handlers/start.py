from pyrogram.client import Client
from pyrogram.types import Message
from bot.utils.storage import get_required_channel
import asyncio

async def register_start(client: Client, message: Message):
    """
    Handles the /start command - ULTRA FAST (< 1ms response)
    Pattern: ALWAYS respond instantly, validate in background
    NEVER awaits external API or storage before sending reply
    ALL I/O operations deferred to background tasks
    """
    user_id = message.chat.id
    
    from bot.utils.fast_cache import (
        is_user_banned_fast, 
        get_cached_template,
        background_channel_check,
        background_save_user,
        background_warm_user_cache
    )
    from bot.handlers.withdraw import withdraw_sessions
    
    if user_id in withdraw_sessions:
        withdraw_sessions.pop(user_id, None)
    
    if is_user_banned_fast(user_id):
        await message.reply(get_cached_template("banned_user_message"))
        return
    
    welcome_text = get_cached_template("welcome_message")
    await message.reply(welcome_text)
    
    username = message.from_user.username or ""
    first_name = message.from_user.first_name or ""
    asyncio.create_task(background_save_user(user_id, username=username, first_name=first_name, channel_joined=True))
    asyncio.create_task(background_warm_user_cache(user_id))
    
    channel = get_required_channel()
    asyncio.create_task(background_channel_check(client, user_id, channel))
