from pyrogram.client import Client
from pyrogram import filters
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery
from bot.utils.storage import mark_withdraw_request, get_min_withdraw_for_method, get_required_channel
from bot.config import CHANNEL_WITHDRAW_REPORT, ADMIN_ID
import asyncio
import re
from typing import Tuple

withdraw_sessions = {}


def validate_wallet_address(address: str, method: str) -> Tuple[bool, str]:
    """
    Validate wallet address based on withdrawal method.
    
    Args:
        address: The wallet address to validate
        method: The withdrawal method (USDT, TRX, BINANCE, CARDNAME)
    
    Returns:
        Tuple of (is_valid, error_message or sanitized_address)
    """
    address = address.strip()
    
    if not address:
        return False, "Wallet address cannot be empty"
    
    if len(address) < 5:
        return False, "Wallet address is too short"
    
    if len(address) > 200:
        return False, "Wallet address is too long (max 200 characters)"
    
    dangerous_chars = ['<', '>', '"', "'", '\\', '\n', '\r', '\t', ';', '`', '$', '|', '&']
    for char in dangerous_chars:
        address = address.replace(char, '')
    
    method_upper = method.upper()
    
    if method_upper == "USDT":
        if address.startswith("0x") and len(address) == 42:
            if re.match(r'^0x[a-fA-F0-9]{40}$', address):
                return True, address
            return False, "Invalid BEP20 address format. Should be 0x followed by 40 hex characters."
        
        if address.startswith("T") and len(address) == 34:
            if re.match(r'^T[a-zA-Z0-9]{33}$', address):
                return True, address
            return False, "Invalid TRC20 address format."
        
        return False, "Invalid USDT address. Use BEP20 (0x...) or TRC20 (T...) format."
    
    elif method_upper == "TRX":
        if address.startswith("T") and len(address) == 34:
            if re.match(r'^T[a-zA-Z0-9]{33}$', address):
                return True, address
        return False, "Invalid TRX address. Should start with 'T' and be 34 characters."
    
    elif method_upper == "BINANCE":
        if re.match(r'^[a-zA-Z0-9@._-]{5,100}$', address):
            return True, address
        return False, "Invalid Binance ID. Use alphanumeric characters only."
    
    elif method_upper == "CARDNAME":
        name_pattern = r'^[a-zA-Z\s\.\-]{3,100}$'
        if re.match(name_pattern, address):
            return True, address
        return False, "Invalid card name. Use letters, spaces, dots, or hyphens only."
    
    return True, address

async def register_withdraw(client: Client, message: Message):
    """
    Handles /withdraw command - WITH CHANNEL GUARD
    Shows user balance and withdrawal options
    """
    user_id = message.chat.id
    
    from bot.utils.fast_cache import (
        is_user_banned_fast,
        get_cached_template,
        get_user_balance_fast,
        is_withdraw_enabled_fast,
        background_refresh_withdraw_status,
        sync_user_from_storage,
        format_message_fast
    )
    
    sync_user_from_storage(user_id)
    
    if is_user_banned_fast(user_id):
        await message.reply(get_cached_template("banned_user_message"))
        return
    
    # --- GLOBAL WITHDRAW CHECK ---
    if not is_withdraw_enabled_fast():
        await message.reply(get_cached_template("withdraw_disabled_message"))
        asyncio.create_task(background_refresh_withdraw_status())
        return
    
    balance = get_user_balance_fast(user_id)
    
    # --- USER SPECIFIC OVERRIDE ---
    from bot.utils.storage import get_user_withdraw_config
    user_config = get_user_withdraw_config(user_id)
    
    if user_config.get("disabled"):
        await message.reply("❌ আপনার জন্য উইথড্র সাময়িকভাবে বন্ধ আছে।")
        return
    
    if balance <= 0:
        await message.reply(get_cached_template("no_balance_message"))
        return
    
    text = format_message_fast("withdraw_method_message", balance=balance)
    buttons = [
        [InlineKeyboardButton("USDT (BEP20)", callback_data="withdraw_usdt")],
        [InlineKeyboardButton("TRX", callback_data="withdraw_trx")],
        [InlineKeyboardButton("CARD NAME", callback_data="withdraw_cardname")],
        [InlineKeyboardButton("Binance", callback_data="withdraw_binance")]
    ]
    await message.reply(text, reply_markup=InlineKeyboardMarkup(buttons))
    
    withdraw_sessions[user_id] = {"balance": balance, "step": "waiting_method"}


def register_withdraw_handlers(app: Client):
    """Register all withdraw-related handlers - WITH CHANNEL GUARD"""
    
    @app.on_callback_query(filters.regex(r"^withdraw_"))
    async def handle_withdraw_selection(client: Client, query: CallbackQuery):
        """Withdraw selection - Universal guard already enforces channel membership with force_check=True"""
        user_id = query.from_user.id
        
        if user_id not in withdraw_sessions:
            await query.answer("❌ Please use /withdraw to start a request.", show_alert=True)
            return

        data_str = str(query.data) if query.data else "withdraw_unknown"
        parts = data_str.split("_")
        method = parts[1].upper() if len(parts) > 1 else "UNKNOWN"
        
        from bot.utils.fast_cache import get_user_balance_fast
        current_balance = get_user_balance_fast(user_id)
        
        withdraw_sessions[user_id]["balance"] = current_balance
        
        # --- WITHDRAWAL LIMIT LOGIC ---
        # 1. Start with Global Min for this method
        min_amount = get_min_withdraw_for_method(method.lower())
        
        from bot.utils.storage import get_user_withdraw_config
        user_config = get_user_withdraw_config(user_id)
        
        # 2. Apply User Specific MIN override if exists
        custom_min = user_config.get("min")
        if custom_min is not None:
            min_amount = custom_min
            
        # 3. Apply User Specific MAX restriction if exists
        custom_max = user_config.get("max")
        if custom_max is not None and current_balance > custom_max:
            await query.answer(f"❌ Your max withdraw limit is ${custom_max}", show_alert=True)
            return

        # 4. Final Balance vs Min check
        if current_balance < min_amount:
            await query.answer(f"⚠️ Insufficient Balance❌\n\nMinimum withdraw amount: ${min_amount}\nYour balance: ${current_balance}", show_alert=True)
            return
        
        if current_balance <= 0:
            await query.answer("❌ আপনার ব্যালেন্স নেই!", show_alert=True)
            return
        
        withdraw_sessions[user_id]["method"] = method
        withdraw_sessions[user_id]["step"] = "waiting_wallet"

        from bot.utils.fast_cache import format_message_fast as fmt_msg
        await query.message.edit_text(fmt_msg("enter_wallet_message", method=method))
        await query.answer()

    @app.on_message(filters.private & filters.text & ~filters.command(["start", "account", "withdraw", "cap", "admin", "support"]))
    async def handle_wallet_input(client: Client, message: Message):
        """Wallet input - Universal guard already enforces channel membership with force_check=True"""
        user_id = message.chat.id
        if user_id not in withdraw_sessions or withdraw_sessions[user_id].get("step") != "waiting_wallet":
            return

        wallet_address = message.text.strip()
        
        if user_id not in withdraw_sessions:
            return
        
        data = withdraw_sessions[user_id]
        method = data.get("method", "UNKNOWN")
        
        is_valid, result = validate_wallet_address(wallet_address, method)
        
        if not is_valid:
            from bot.utils.fast_cache import format_message_fast as fmt_msg
            await message.reply(fmt_msg("invalid_wallet_message", error=result, method=method))
            return
        
        wallet_address = result
        
        data = withdraw_sessions.pop(user_id)
        balance = data["balance"]
        method = data["method"]

        from bot.utils.fast_cache import format_message_fast
        await message.reply(format_message_fast("withdraw_success_message", amount=balance, method=method))
        
        asyncio.create_task(
            process_withdraw_background(client, user_id, balance, method, wallet_address)
        )


async def process_withdraw_background(client: Client, user_id: int, balance: float, method: str, wallet_address: str):
    """Process withdraw in background - FULLY non-blocking via to_thread"""
    try:
        from datetime import datetime
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        print(f"💸 Processing withdraw: user={user_id}, amount=${balance}, method={method}")
        await asyncio.to_thread(mark_withdraw_request, user_id, method, balance, wallet_address)
        print(f"✅ Withdraw request recorded in storage for user {user_id}")
        
        try:
            from bot.utils import database as db
            await db.log_withdrawal(user_id, method, balance, wallet_address, "pending")
            print(f"✅ Withdraw logged to PostgreSQL database")
        except Exception as db_err:
            print(f"⚠️ DB logging skipped: {db_err}")
        
        withdraw_message = (
            f"💸 **New Withdraw Request**\n\n"
            f"👤 User ID: `{user_id}`\n"
            f"💰 Amount: **${balance}**\n"
            f"💳 Method: **{method}**\n"
            f"📬 Wallet: `{wallet_address}`\n"
            f"⏰ Time: {current_time}"
        )
        
        if CHANNEL_WITHDRAW_REPORT:
            try:
                print(f"📤 Sending withdraw report to channel: {CHANNEL_WITHDRAW_REPORT}")
                await client.send_message(
                    chat_id=CHANNEL_WITHDRAW_REPORT,
                    text=withdraw_message
                )
                print(f"✅ Withdraw report sent to channel successfully!")
            except Exception as channel_error:
                print(f"❌ Failed to send withdraw report to channel: {channel_error}")
                print(f"   Channel: {CHANNEL_WITHDRAW_REPORT}")
                import traceback
                traceback.print_exc()
        else:
            print(f"⚠️ CHANNEL_WITHDRAW_REPORT not configured, skipping channel report")
            
        from bot.utils.fast_cache import sync_user_from_storage_async
        await sync_user_from_storage_async(user_id)
        print(f"✅ User cache synced after withdraw")
        
    except Exception as e:
        print(f"❌ Error processing withdraw: {e}")
        import traceback
        traceback.print_exc()
