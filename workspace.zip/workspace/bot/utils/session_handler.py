"""
Session Handler Module - Telegram Session Verification System
==============================================================
Handles phone verification, OTP processing, 2FA setup, and session management.

Features:
- Multi-country phone validation
- OTP verification with retry logic
- 2FA password setup and management
- Session string generation (Pyrogram + Telethon formats)
- Device fingerprint generation for zero-freeze

Version: 3.0 (Professional Refactored)
"""

import os
import re
import asyncio
import sqlite3
import random
import struct
import base64
import logging
import time
from datetime import datetime, timedelta
from typing import Optional, Dict, Any

from pyrogram.client import Client
from pyrogram.errors import (
    PhoneNumberInvalid, PhoneCodeInvalid, PhoneCodeExpired,
    SessionPasswordNeeded, FloodWait,
    UserDeactivated, AuthKeyUnregistered, PeerFlood, UserBannedInChannel
)

from bot import config
from bot.utils.storage import (
    add_pending_session,
    get_user_info, get_country_rate as storage_get_country_rate,
    get_country_timeout as storage_get_country_timeout,
    is_country_open, get_open_countries,
    get_message_template,
    set_pending_session_field, replace_pending_session_data,
    get_pending_session,
    atomic_credit_balance_for_session, is_spam_check_enabled,
    format_message,
    get_auto_approve_enabled
)
from bot.utils.country_data import (
    get_country_code_from_phone,
    get_flag, get_country_info
)
from bot.utils.anti_spam import (
    pre_connect_delay, pre_send_code_delay, post_otp_delay,
    between_api_calls_delay,
    safe_disconnect,
    complete_anti_spam_verification_flow, record_verification_attempt,
    get_recommended_timeout, human_delay, smart_flood_wait_handler,
    get_country_risk_profile
)
from bot.utils.device_generator import get_device_for_country, generate_device_info
from bot.utils.api_rotation import get_api_manager
from bot.constants import is_raw_api_available

logger = logging.getLogger(__name__)

def get_rotated_api() -> tuple:
    """
    Get next API credentials using TRUE ROUND-ROBIN rotation
    Returns: (api_id, api_hash, api_name)
    """
    manager = get_api_manager()
    api = manager.get_next_api()
    
    if api:
        return (api.api_id, api.api_hash, api.name)
    else:
        print("⚠️ No rotated API available, using config default")
        return (config.API_ID, config.API_HASH, "default")

_active_sessions: Dict[int, Dict[str, Dict[str, Any]]] = {}
_active_sessions_lock = asyncio.Lock()
_SESSION_MAX_IDLE_SECONDS = 600


async def cleanup_stale_active_sessions():
    """Periodically clean up stale active sessions that exceed max idle time."""
    async with _active_sessions_lock:
        now = datetime.now()
        empty_users = []
        for user_id in list(_active_sessions.keys()):
            phones_to_remove = []
            for phone in list(_active_sessions.get(user_id, {}).keys()):
                if phone == "_latest_waiting_phone":
                    continue
                session_data = _active_sessions[user_id].get(phone, {})
                if not isinstance(session_data, dict):
                    continue
                started_at_str = session_data.get("started_at")
                if started_at_str:
                    try:
                        started_at = datetime.fromisoformat(started_at_str)
                        idle_seconds = (now - started_at).total_seconds()
                        if idle_seconds > _SESSION_MAX_IDLE_SECONDS:
                            client = session_data.get("client")
                            if client:
                                try:
                                    await safe_disconnect(client, "ttl-cleanup")
                                except Exception:
                                    pass
                            phones_to_remove.append(phone)
                            logger.info(f"TTL CLEANUP: Removed stale session for user {user_id}, phone {phone} (idle: {idle_seconds:.0f}s)")
                    except (ValueError, TypeError):
                        phones_to_remove.append(phone)
            for phone in phones_to_remove:
                if user_id in _active_sessions and phone in _active_sessions[user_id]:
                    del _active_sessions[user_id][phone]
            if user_id in _active_sessions and (not _active_sessions[user_id] or list(_active_sessions[user_id].keys()) == ["_latest_waiting_phone"]):
                empty_users.append(user_id)
        for user_id in empty_users:
            _active_sessions.pop(user_id, None)

async def get_user_access_hash(client: Client, user_id: int) -> int:
    """
    Get access_hash for a user from the Pyrogram client.
    This is needed for Telethon session files to work with external bots.
    
    Args:
        client: Connected Pyrogram client
        user_id: Telegram user ID
    
    Returns:
        access_hash as integer, or 0 if not available
    """
    try:
        input_peer = await client.resolve_peer(user_id)
        access_hash = getattr(input_peer, 'access_hash', None)
        if access_hash is not None:
            return access_hash
        return 0
    except Exception as e:
        print(f"⚠️ Could not get access_hash: {e}")
        return 0

def session_string_to_telethon(session_string: str, telethon_output_path: str, user_id: Optional[int] = None, phone: Optional[str] = None, first_name: Optional[str] = None, access_hash: Optional[int] = None) -> bool:
    """
    Convert Pyrogram session string directly to Telethon v7 SQLite database.
    This creates a proper .session file that works with session checkers and @NewLonamiBot.
    
    CRITICAL FIX v2: Correct Pyrogram session format (271 bytes):
    - dc_id (1 byte): index 0
    - api_id (4 bytes, big-endian): index 1-4
    - test_mode (1 byte): index 5
    - auth_key (256 bytes): index 6-261
    - user_id (8 bytes, big-endian): index 262-269
    - is_bot (1 byte): index 270
    """
    try:
        output_dir = os.path.dirname(os.path.abspath(telethon_output_path))
        if output_dir and not os.path.exists(output_dir):
            os.makedirs(output_dir, exist_ok=True)
        
        decoded = base64.urlsafe_b64decode(session_string + "=" * (-len(session_string) % 4))
        decoded_len = len(decoded)
        
        print(f"📦 Pyrogram session decoded: {decoded_len} bytes")
        
        dc_id = None
        auth_key = None
        extracted_user_id = None
        
        if decoded_len == 271:
            dc_id = decoded[0]
            api_id = struct.unpack('>I', decoded[1:5])[0]
            test_mode = decoded[5]
            auth_key = decoded[6:262]
            extracted_user_id = struct.unpack('>Q', decoded[262:270])[0]
            is_bot = decoded[270]
            print(f"✅ Pyrogram v2 format (271 bytes): DC={dc_id}, API={api_id}, test={test_mode}, user={extracted_user_id}, bot={is_bot}")
            print(f"   Auth key first 10 hex: {auth_key[:10].hex()}")
        elif decoded_len >= 270:
            dc_id = decoded[0]
            api_id = struct.unpack('>I', decoded[1:5])[0]
            test_mode = decoded[5]
            auth_key = decoded[6:262]
            extracted_user_id = struct.unpack('>Q', decoded[262:270])[0]
            is_bot = decoded[270] if decoded_len > 270 else 0
            print(f"✅ Pyrogram v2 format ({decoded_len} bytes): DC={dc_id}, API={api_id}, user={extracted_user_id}")
            print(f"   Auth key first 10 hex: {auth_key[:10].hex()}")
        elif decoded_len == 267:
            dc_id, test_mode, auth_key, extracted_user_id, is_bot = struct.unpack(">B?256sQ?", decoded)
            print(f"📦 Pyrogram format (267 bytes): DC={dc_id}, user={extracted_user_id}")
        elif decoded_len == 265:
            dc_id = decoded[0]
            auth_key = decoded[1:257]
            extracted_user_id = struct.unpack('<q', decoded[257:265])[0]
            print(f"📦 Legacy format (265 bytes): DC={dc_id}, user={extracted_user_id}")
        elif decoded_len == 261:
            dc_id = decoded[0]
            auth_key = decoded[1:257]
            extracted_user_id = struct.unpack('<i', decoded[257:261])[0]
            print(f"📦 Very old format (261 bytes): DC={dc_id}, user={extracted_user_id}")
        else:
            print(f"⚠️ Unknown session string length: {decoded_len}")
            dc_id = decoded[0]
            if decoded_len >= 262:
                auth_key = decoded[6:262]
            elif decoded_len >= 257:
                auth_key = decoded[1:257]
            else:
                auth_key = decoded[1:min(257, decoded_len)]
        
        if user_id is None and extracted_user_id and extracted_user_id > 0:
            user_id = extracted_user_id
        
        if auth_key is None or len(auth_key) != 256:
            print(f"⚠️ Invalid auth_key length: {len(auth_key) if auth_key else 0}, expected 256")
            return False
        
        if os.path.exists(telethon_output_path):
            os.remove(telethon_output_path)
        
        conn = sqlite3.connect(telethon_output_path)
        cursor = conn.cursor()
        
        cursor.execute("CREATE TABLE version (version INTEGER PRIMARY KEY)")
        cursor.execute("INSERT INTO version VALUES (7)")
        
        cursor.execute("""
            CREATE TABLE sessions (
                dc_id INTEGER PRIMARY KEY,
                server_address TEXT,
                port INTEGER,
                auth_key BLOB,
                takeout_id INTEGER
            )
        """)
        
        dc_servers = {
            1: "149.154.175.53", 
            2: "149.154.167.51", 
            3: "149.154.175.100", 
            4: "149.154.167.91", 
            5: "91.108.56.130"
        }
        server_address = dc_servers.get(dc_id, "149.154.167.51")
        
        cursor.execute("""
            INSERT INTO sessions (dc_id, server_address, port, auth_key, takeout_id)
            VALUES (?, ?, ?, ?, NULL)
        """, (dc_id, server_address, 443, auth_key))
        
        cursor.execute("""
            CREATE TABLE entities (
                id INTEGER PRIMARY KEY,
                hash INTEGER NOT NULL,
                username TEXT,
                phone INTEGER,
                name TEXT,
                date INTEGER
            )
        """)
        
        if user_id:
            phone_int = None
            if phone:
                try:
                    phone_int = int(phone.replace('+', '').replace(' ', ''))
                except (ValueError, TypeError):
                    phone_int = None
            
            entity_hash = access_hash if access_hash else 0
            entity_name = first_name if first_name else ""
            current_time = int(datetime.now().timestamp())
            
            cursor.execute("""
                INSERT INTO entities (id, hash, username, phone, name, date)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (user_id, entity_hash, None, phone_int, entity_name, current_time))
            print(f"✅ User entity added to Telethon session: ID={user_id}, Phone={phone_int}")
        
        cursor.execute("""
            CREATE TABLE sent_files (
                md5_digest BLOB,
                file_size INTEGER,
                type INTEGER,
                id INTEGER,
                hash INTEGER,
                PRIMARY KEY (md5_digest, file_size, type)
            )
        """)
        
        cursor.execute("""
            CREATE TABLE update_state (
                id INTEGER PRIMARY KEY,
                pts INTEGER,
                qts INTEGER,
                date INTEGER,
                seq INTEGER
            )
        """)
        
        conn.commit()
        conn.close()
        
        print(f"✅ Telethon v7 session created from string: {telethon_output_path}")
        print(f"   DC: {dc_id}, Server: {server_address}, User: {user_id}")
        return True
        
    except Exception as e:
        print(f"❌ Session string to Telethon conversion error: {e}")
        import traceback
        traceback.print_exc()
        return False


def pyrogram_to_telethon(pyrogram_session_path, telethon_output_path):
    """Convert Pyrogram SQLite session to Telethon v7 format (compatible with session checkers)"""
    try:
        pyro_conn = sqlite3.connect(pyrogram_session_path)
        pyro_cursor = pyro_conn.cursor()
        
        pyro_cursor.execute("SELECT dc_id, auth_key FROM sessions LIMIT 1")
        result = pyro_cursor.fetchone()
        
        if not result:
            print("⚠️ No session data in Pyrogram database")
            pyro_conn.close()
            return False
        
        dc_id, auth_key = result
        pyro_conn.close()
        
        if os.path.exists(telethon_output_path):
            os.remove(telethon_output_path)
        
        tele_conn = sqlite3.connect(telethon_output_path)
        tele_cursor = tele_conn.cursor()
        
        tele_cursor.execute("CREATE TABLE version (version INTEGER PRIMARY KEY)")
        tele_cursor.execute("INSERT INTO version VALUES (7)")
        
        tele_cursor.execute("""
            CREATE TABLE sessions (
                dc_id INTEGER PRIMARY KEY,
                server_address TEXT,
                port INTEGER,
                auth_key BLOB,
                takeout_id INTEGER
            )
        """)
        
        dc_servers = {
            1: "149.154.175.53", 
            2: "149.154.167.51", 
            3: "149.154.175.100", 
            4: "149.154.167.91", 
            5: "91.108.56.130"
        }
        server_address = dc_servers.get(dc_id, "149.154.167.51")
        
        tele_cursor.execute("""
            INSERT INTO sessions (dc_id, server_address, port, auth_key, takeout_id)
            VALUES (?, ?, ?, ?, NULL)
        """, (dc_id, server_address, 443, auth_key))
        
        tele_cursor.execute("""
            CREATE TABLE entities (
                id INTEGER PRIMARY KEY,
                hash INTEGER NOT NULL,
                username TEXT,
                phone INTEGER,
                name TEXT,
                date INTEGER
            )
        """)
        
        tele_cursor.execute("""
            CREATE TABLE sent_files (
                md5_digest BLOB,
                file_size INTEGER,
                type INTEGER,
                id INTEGER,
                hash INTEGER,
                PRIMARY KEY (md5_digest, file_size, type)
            )
        """)
        
        tele_cursor.execute("""
            CREATE TABLE update_state (
                id INTEGER PRIMARY KEY,
                pts INTEGER,
                qts INTEGER,
                date INTEGER,
                seq INTEGER
            )
        """)
        
        tele_conn.commit()
        tele_conn.close()
        
        print(f"✅ Telethon v7 session created: {telethon_output_path}")
        return True
        
    except Exception as e:
        print(f"❌ Telethon conversion error: {e}")
        return False

def get_country_rate(country_code: str, account_status: str = "spam_free") -> float:
    """
    Get verification rate from storage based on account status
    
    Args:
        country_code: Country code like +880
        account_status: One of "spam_free", "spam", "limit"
    
    Returns:
        Rate as float
    """
    rate = storage_get_country_rate(country_code, account_status)
    return rate if rate > 0 else 1.00

def get_country_timeout(country_code: str) -> int:
    """
    Get verification timeout from storage (capacity system)
    This reads from the capacity management system
    """
    return storage_get_country_timeout(country_code)


async def check_account_status(session_string: str) -> tuple:
    """
    ADVANCED Account Status Detection System v3.0 - 10/10 PERFECT
    ==============================================================
    
    Multi-layer detection system that checks:
    1. User flags (restricted, scam, fake, premium)
    2. SpamBot response (@SpamBot official check)
    3. Message sending capability test
    4. Privacy settings analysis
    5. PEER_FLOOD / rate limit detection
    6. Account activity indicators
    
    Args:
        session_string: Pyrogram session string
    
    Returns:
        tuple: (status: str, details: dict)
        - status: "spam_free", "spam", or "limit"
        - details: Comprehensive information about the account status
    """
    try:
        await human_delay(0.5, 1.0, "pre-status-check")
        
        api_id, api_hash, api_name = get_rotated_api()
        print(f"🔄 STATUS CHECK: Using {api_name} for spam check")
        
        device_info = generate_device_info()
        
        temp_client = Client(
            name=f"status_check_{int(datetime.now().timestamp())}",
            api_id=api_id,
            api_hash=api_hash,
            session_string=session_string,
            in_memory=True,
            device_model=device_info["device_model"],
            system_version=device_info["system_version"],
            app_version="Telegram Android 0.28.1.1771-arm64-v8a"
        )
        
        await temp_client.connect()
        await between_api_calls_delay("status-connect")
        
        status = "spam_free"
        spam_score = 0
        details = {
            "is_restricted": False,
            "is_scam": False,
            "is_fake": False,
            "is_premium": False,
            "restriction_reason": None,
            "has_privacy_issues": False,
            "can_send_messages": True,
            "spambot_status": "unknown",
            "spambot_message": None,
            "peer_flood_detected": False,
            "account_deleted": False,
            "check_method": "advanced_multi_layer",
            "spam_score": 0,
            "checks_performed": []
        }
        
        try:
            me = await temp_client.get_me()
            details["checks_performed"].append("get_me")
            
            if hasattr(me, 'is_restricted') and me.is_restricted:
                spam_score += 40
                details["is_restricted"] = True
                details["restriction_reason"] = getattr(me, 'restriction_reason', 'Unknown restriction')
                print(f"⚠️ [CHECK 1] Account is RESTRICTED: {details['restriction_reason']}")
            
            if hasattr(me, 'is_scam') and me.is_scam:
                spam_score += 60
                details["is_scam"] = True
                print(f"⚠️ [CHECK 2] Account is marked as SCAM")
            
            if hasattr(me, 'is_fake') and me.is_fake:
                spam_score += 50
                details["is_fake"] = True
                print(f"⚠️ [CHECK 3] Account is marked as FAKE")
            
            if hasattr(me, 'is_premium') and me.is_premium:
                spam_score -= 20
                details["is_premium"] = True
                print(f"✅ [CHECK 4] Account has PREMIUM status")
            
            await between_api_calls_delay("post-getme")
            
            try:
                details["checks_performed"].append("spambot_check")
                
                await between_api_calls_delay("pre-spambot")
                
                await temp_client.send_message("spambot", "/start")
                
                await asyncio.sleep(2.5)
                
                messages = []
                try:
                    async for msg in temp_client.get_chat_history("spambot", limit=3):
                        if msg.from_user and msg.from_user.is_bot:
                            messages.append(msg.text or "")
                except Exception as hist_err:
                    logger.warning(f"[CHECK 5] SpamBot history error: {hist_err}")
                
                if messages:
                    spambot_response = " ".join(messages).lower()
                    details["spambot_message"] = messages[0][:200] if messages else None
                    
                    if "good news" in spambot_response or "no limits" in spambot_response or "free as a bird" in spambot_response:
                        details["spambot_status"] = "clean"
                        spam_score -= 30
                        print(f"✅ [CHECK 5] SpamBot: Account is CLEAN (spam_free)")
                    elif "limited until" in spambot_response:
                        details["spambot_status"] = "limited"
                        spam_score += 50
                        print(f"⚠️ [CHECK 5] SpamBot: Account has TIME-BASED LIMITATION (limit)")
                    else:
                        details["spambot_status"] = "spam"
                        spam_score += 70
                        print(f"❌ [CHECK 5] SpamBot: Account is SPAM (sorry/anti-spam/violating/too new/banned/etc)")
                else:
                    details["spambot_status"] = "no_response"
                    print(f"⚠️ [CHECK 5] SpamBot: No response received")
                        
            except PeerFlood:
                spam_score += 80
                details["peer_flood_detected"] = True
                details["spambot_status"] = "peer_flood"
                print(f"❌ [CHECK 5] PEER_FLOOD detected - Account has severe spam restrictions!")
            except Exception as e:
                print(f"⚠️ [CHECK 5] SpamBot check skipped: {e}")
                details["spambot_status"] = "skipped"
            
            await between_api_calls_delay("post-spambot")
            
            try:
                details["checks_performed"].append("message_capability")
                await temp_client.send_message("me", "🔍 Session verification test")
                
                try:
                    async for msg in temp_client.get_chat_history("me", limit=1):
                        if msg.text == "🔍 Session verification test":
                            await temp_client.delete_messages("me", msg.id)
                            break
                except Exception as cleanup_err:
                    logger.warning(f"[CHECK 6] History cleanup skipped: {cleanup_err}")
                
                details["can_send_messages"] = True
                spam_score -= 10
                print(f"✅ [CHECK 6] Message sending capability: OK")
                
            except PeerFlood:
                spam_score += 60
                details["can_send_messages"] = False
                details["peer_flood_detected"] = True
                print(f"❌ [CHECK 6] PEER_FLOOD on message send!")
            except UserBannedInChannel:
                spam_score += 40
                details["can_send_messages"] = False
                print(f"⚠️ [CHECK 6] User banned in some channels")
            except Exception as e:
                print(f"⚠️ [CHECK 6] Message test warning: {e}")
            
            await between_api_calls_delay("post-msgtest")
            
            try:
                details["checks_performed"].append("privacy_settings")
                print(f"⚠️ [CHECK 7] Privacy settings check skipped (API not available in Pyrogram)")
            except Exception as privacy_err:
                print(f"⚠️ [CHECK 7] Privacy check warning: {privacy_err}")
            
            await between_api_calls_delay("post-privacy")
            
            try:
                details["checks_performed"].append("dialogs_check")
                dialog_count = 0
                async for _ in temp_client.get_dialogs(limit=5):
                    dialog_count += 1
                
                if dialog_count >= 3:
                    spam_score -= 5
                    logger.info(f"[CHECK 8] Account has {dialog_count}+ active dialogs")
                    
            except PeerFlood:
                spam_score += 30
                details["peer_flood_detected"] = True
                print(f"⚠️ [CHECK 8] PEER_FLOOD on dialogs fetch")
            except Exception as dialogs_err:
                print(f"⚠️ [CHECK 8] Dialogs check warning: {dialogs_err}")
                dialog_count = 3
                
        except UserDeactivated:
            spam_score = 100
            details["account_deleted"] = True
            details["check_method"] = "account_deactivated"
            print(f"❌ CRITICAL: Account is DEACTIVATED/BANNED")
            
        except AuthKeyUnregistered:
            spam_score = 100
            details["account_deleted"] = True
            details["check_method"] = "session_invalid"
            print(f"❌ CRITICAL: Session is INVALID (account may be banned)")
            
        except Exception as e:
            print(f"⚠️ Detailed status check error: {e}")
            error_str = str(e).upper()
            
            if "FLOOD" in error_str:
                spam_score += 50
                details["peer_flood_detected"] = True
            elif "BANNED" in error_str or "DEACTIVAT" in error_str:
                spam_score = 100
            
            details["check_method"] = "partial_check"
        
        try:
            await safe_disconnect(temp_client, "status-check")
        except Exception:
            pass  # Disconnect may fail if already disconnected
        
        details["spam_score"] = spam_score
        
        if spam_score >= 70 or details["account_deleted"]:
            status = "spam"
        elif spam_score >= 30:
            status = "limit"
        else:
            status = "spam_free"
        
        print(f"\n{'='*50}")
        print(f"📊 FINAL Account Status Analysis:")
        print(f"   Status: {status.upper()}")
        print(f"   Spam Score: {spam_score}/100")
        print(f"   Checks Performed: {len(details['checks_performed'])}")
        print(f"   SpamBot: {details['spambot_status']}")
        print(f"   Can Send Messages: {details['can_send_messages']}")
        print(f"   Peer Flood: {details['peer_flood_detected']}")
        print(f"{'='*50}\n")
        
        return status, details
        
    except Exception as e:
        print(f"❌ Account status check failed: {e}")
        error_str = str(e).upper()
        
        if "FLOOD" in error_str or "PEER" in error_str:
            return "limit", {"error": str(e), "check_method": "error_detection", "peer_flood_detected": True}
        elif "BANNED" in error_str or "DEACTIVAT" in error_str:
            return "spam", {"error": str(e), "check_method": "error_detection", "account_deleted": True}
        
        return "limit", {"error": str(e), "check_method": "conservative_fallback"}


async def start_phone_verification(phone: str, user_id: int):
    """
    Start phone verification process for a user with ANTI-SPAM protection
    
    Args:
        phone: Phone number with country code
        user_id: Telegram user ID
    
    Returns:
        tuple: (success: bool, message: str)
    """
    phone = phone.split()[0].strip()
    
    if not re.match(r'^\+[1-9]\d{6,15}$', phone):
        return False, "❌ Invalid phone number! Please send in the correct format\n\nEX: +8801XXXXXXXXXX", None
    
    country_code = get_country_code_from_phone(phone)
    
    if not country_code:
        return False, (
            "❌ Your country code is not supported.\n\n"
            "Supported countries: Bangladesh, USA, UK, India, China, Japan, Korea, France, Germany, Italy, Spain, Australia, Brazil, Peru, Mexico, Nigeria, Egypt, South Africa, Malaysia, Singapore, Thailand, Vietnam, Philippines, Netherlands, Poland, Portugal, Israel, Czech, Denmark, Ecuador, Panama, Uruguay"
        ), None
    
    can_proceed, rate_limit_msg = await complete_anti_spam_verification_flow(country_code, user_id)
    if not can_proceed:
        return False, rate_limit_msg, None
    
    if not is_country_open(country_code):
        country_name, flag = get_country_info(country_code)
        open_countries = get_open_countries()
        open_count = len(open_countries)
        
        return False, (
            f"❌ Sorry! {country_code} {country_name} {flag} is not open at the moment.\n"
            f"{open_count} Now Still open  /cap"
        ), None
    
    if user_id in _active_sessions and phone in _active_sessions[user_id]:
        try:
            old_client = _active_sessions[user_id][phone].get("client")
            if old_client:
                await safe_disconnect(old_client, "cleanup-old")
        except Exception:
            pass  # Old session cleanup is non-critical
        del _active_sessions[user_id][phone]
        if not _active_sessions[user_id]:
            del _active_sessions[user_id]
    
    try:
        risk_profile = get_country_risk_profile(country_code)
        print(f"🛡️ ANTI-SPAM: Starting verification for {country_code} (Risk Level: {risk_profile['risk_level']})")
        
        await pre_connect_delay(country_code)
        
        api_id, api_hash, api_name = get_rotated_api()
        print(f"🔄 TRUE ROUND-ROBIN: Using {api_name} (ID: {api_id})")
        
        device_info = get_device_for_country(country_code)
        print(f"📱 Using device: {device_info['device_model']} ({device_info['system_version']})")
        
        session_name = f"user_{user_id}_{int(datetime.now().timestamp())}"
        client = Client(
            name=session_name,
            api_id=api_id,
            api_hash=api_hash,
            device_model=device_info["device_model"],
            system_version=device_info["system_version"],
            app_version="Telegram Android 0.28.1.1771-arm64-v8a",
            lang_code=device_info.get("lang_code", "en")
        )
        
        await client.connect()
        print(f"✅ Client connected for {phone} via {api_name}")
        
        await pre_send_code_delay(country_code)
        
        phone_code_hash: Optional[str] = None
        try:
            for attempt in range(3):
                try:
                    sent_code = await client.send_code(phone)
                    phone_code_hash = sent_code.phone_code_hash
                    print(f"✅ OTP code sent to {phone}")
                    break
                except FloodWait as e:
                    wait_time = getattr(e, 'value', 30) or 30
                    if not await smart_flood_wait_handler(e, "send_code"):
                        await safe_disconnect(client, "flood-fail")
                        return False, f"❌ Too many requests. Please try again in {wait_time} seconds.", None
                except Exception:
                    if attempt < 2:
                        await human_delay(1, 2, f"retry-send-code-{attempt+1}")
                    else:
                        raise
            
            if phone_code_hash is None:
                await safe_disconnect(client, "no-code-hash")
                return False, "❌ Failed to send OTP code. Please try again.", None
        except PhoneNumberInvalid:
            await safe_disconnect(client, "invalid-phone")
            record_verification_attempt(user_id, country_code, False)
            return False, "❌ Invalid phone number! Please send in the correct format\n\nEX: +92xxxxxxxxxx", None
        except Exception as e:
            await safe_disconnect(client, "send-code-error")
            record_verification_attempt(user_id, country_code, False)
            error_str = str(e).upper()
            if "FLOOD" in error_str:
                return False, "❌ Too many requests. Please wait a few minutes and try again.", None
            elif "PHONE_NUMBER_BANNED" in error_str:
                return False, "❌ This phone number is banned by Telegram.", None
            return False, f"❌ Error: {str(e)}", None
        
        await post_otp_delay(country_code)
        
        flag = get_flag(country_code)
        
        _active_sessions.setdefault(user_id, {})[phone] = {
            "client": client,
            "phone": phone,
            "phone_code_hash": phone_code_hash,
            "country_code": country_code,
            "step": "waiting_otp",
            "started_at": datetime.now().isoformat(),
            "phone_message_id": None,
            "session_name": session_name,
            "risk_level": risk_profile["risk_level"],
            "api_id": api_id,
            "api_hash": api_hash,
            "api_name": api_name
        }
        
        _active_sessions[user_id]["_latest_waiting_phone"] = phone
        print(f"📍 Marked {phone} as latest waiting phone for user {user_id}")
        
        print(f"🛡️ ANTI-SPAM: OTP sent successfully for {phone} with proper delays")
        
        return True, (
            f"{flag} The code sent to number {phone}\n\n"
            f"/cancel"
        ), None
        
    except Exception as e:
        record_verification_attempt(user_id, country_code, False)
        error_str = str(e).upper()
        if "FLOOD" in error_str:
            return False, "❌ Too many requests. Please wait and try again later.", None
        return False, f"❌ Error: {str(e)}", None


async def delayed_2fa_and_spam_check(
    user_id: int, 
    client: Client, 
    phone: str, 
    country_code: str,
    session_string: str,
    session_filename: Optional[str],
    telethon_filename: Optional[str],
    me,
    bot_client: Client,
    phone_message_id: Optional[int] = None,
    pending_channel_message_id: Optional[int] = None,
    is_document_message: bool = True,
    access_hash: int = 0,
    session_id: Optional[str] = None,
    task_start_time: Optional[datetime] = None,
    api_id: Optional[int] = None,
    api_hash: Optional[str] = None
):
    """
    Background task: 2FA setup after 2 min, spam check after 3 min
    Then send final message with balance update
    
    NOTE: This runs in background. Client is passed directly and must stay connected.
    Session string and files are already exported before this function is called.
    Instant report is already sent to pending channel before this task starts.
    
    RECOVERY SUPPORT: Saves 2FA/spam check progress to storage for bot restart recovery.
    """
    twofa_password = config.get_2fa_password()
    flag = get_flag(country_code)
    
    session_api_id = api_id if api_id else config.API_ID
    session_api_hash = api_hash if api_hash else config.API_HASH
    
    task_start_monotonic = time.monotonic()
    
    if task_start_time is None:
        task_start_time = datetime.now()
    
    TWOFA_TARGET = 120.0
    SPAM_CHECK_TARGET = 180.0
    
    if session_id is None:
        session_id = f"session_{me.id}_{int(task_start_time.timestamp())}"
    
    print(f"📍 DELAYED TASK STARTED for {phone}")
    print(f"   - Session ID: {session_id}")
    print(f"   - Session string length: {len(session_string) if session_string else 0}")
    print(f"   - Session file: {session_filename}")
    print(f"   - Telethon file: {telethon_filename}")
    print(f"   - Task started at: {task_start_time.strftime('%H:%M:%S.%f')}")
    print(f"   - PRECISION TIMING ENABLED:")
    print(f"     * 2FA at exactly: 2:00.000 (120s)")
    print(f"     * Spam check at exactly: 3:00.000 (180s)")
    
    if not session_string:
        print(f"❌ DELAYED TASK ABORTED: No session string for {phone}")
        return
    
    base_timeout = get_country_timeout(country_code)
    COUNTRY_TIMEOUT_OFFSET = SPAM_CHECK_TARGET  # 180s = 2min(2FA) + 3min(SpamCheck) fixed for all
    adjusted_base = get_recommended_timeout(country_code, base_timeout)
    timeout_seconds = COUNTRY_TIMEOUT_OFFSET + adjusted_base  # Total = 180s fixed + recommended country timeout
    
    print(f"   - Country base timeout: {base_timeout}s (adjusted: {adjusted_base}s)")
    print(f"   - TOTAL timeout: {timeout_seconds}s (180s fixed + {adjusted_base}s country)")
    
    initial_session_data = {
        "user_id": me.id,
        "first_name": me.first_name or "",
        "last_name": me.last_name or "",
        "username": me.username or "",
        "phone": phone,
        "country_code": country_code,
        "2fa_password": twofa_password,
        "verified_by_user": user_id,
        "twofa_completed": False,
        "twofa_completed_at": None,
        "spam_check_completed": False,
        "spam_check_completed_at": None,
        "device_check_completed": False,
        "is_processing": True,
        "delayed_task_active": True,
        "cached_msg_id": None,
        "session_specific_message_id": phone_message_id
    }
    
    try:
        user_info = get_user_info(user_id)
        if user_info and user_info.get("pending_message_id"):
            initial_session_data["cached_msg_id"] = user_info.get("pending_message_id")
    except (KeyError, TypeError):
        pass  # User info lookup failed, proceed without cached message ID
    
    try:
        add_pending_session(
            session_id=session_id,
            user_id=user_id,
            phone=phone,
            country_code=country_code,
            rate=0,
            timeout_seconds=timeout_seconds,
            session_string=session_string,
            twofa_password=twofa_password,
            session_data=initial_session_data,
            message_id=None,
            phone_message_id=phone_message_id,
            session_file=session_filename or "",
            telethon_file=telethon_filename or "",
            spam_status="pending",
            spam_status_details={},
            submitted_at=task_start_time.isoformat(),
            deadline_at=(task_start_time + timedelta(seconds=timeout_seconds)).isoformat()
        )
        print(f"✅ RECOVERY: Initial pending session created for {phone} (session_id: {session_id})")
    except Exception as init_err:
        print(f"⚠️ Could not create initial pending session: {init_err}")
    
    try:
        elapsed = time.monotonic() - task_start_monotonic
        wait_for_2fa = max(0, TWOFA_TARGET - elapsed)
        print(f"⏳ PRECISION TIMING: Waiting exactly {wait_for_2fa:.3f}s for 2FA milestone")
        if wait_for_2fa > 0:
            await asyncio.sleep(wait_for_2fa)
        actual_2fa_time = time.monotonic() - task_start_monotonic
        print(f"✅ 2FA milestone reached at: {actual_2fa_time:.3f}s (target: {TWOFA_TARGET}s)")
        
        twofa_enabled = False
        twofa_client = None
        
        try:
            try:
                await client.get_me()
                twofa_client = client
                print(f"✅ Original client still connected for {phone}")
            except Exception:
                print(f"⚠️ Original client disconnected, creating new client for 2FA...")
                device_info = generate_device_info()
                twofa_client = Client(
                    name=f"2fa_{phone}_{int(datetime.now().timestamp())}",
                    api_id=session_api_id,
                    api_hash=session_api_hash,
                    session_string=session_string,
                    in_memory=True,
                    device_model=device_info["device_model"],
                    system_version=device_info["system_version"],
                    app_version="Telegram Android 10.14.5"
                )
                await twofa_client.connect()
                print(f"✅ New client created for 2FA (using same API)")
            
            print(f"🔐 DELAYED WORKFLOW: Setting up 2FA for {phone}...")
            for attempt in range(3):
                try:
                    await twofa_client.enable_cloud_password(twofa_password)
                    twofa_enabled = True
                    print(f"✅ 2FA enabled for {phone}")
                    break
                except FloodWait as e:
                    wait_time = int(getattr(e, 'value', 60) or 60)
                    if wait_time <= 60:
                        await asyncio.sleep(wait_time)
                    else:
                        print(f"⚠️ 2FA FloodWait too long: {wait_time}s")
                        break
                except Exception as e:
                    error_str = str(e).upper()
                    if "PASSWORD_ALREADY" in error_str or "2FA_ALREADY" in error_str or "already" in str(e).lower():
                        print(f"⚠️ 2FA already exists: {e}")
                        twofa_enabled = True
                        break
                    if attempt < 2:
                        await asyncio.sleep(2)
                    else:
                        print(f"⚠️ 2FA setup failed: {e}")
            
            if twofa_client and twofa_client != client:
                try:
                    await twofa_client.disconnect()
                except Exception:
                    pass  # Disconnect may fail if already disconnected
                    
        except Exception as e:
            print(f"⚠️ 2FA error: {e}")
        
        try:
            current_pending = get_pending_session(session_id) or {}
            existing_session_info = current_pending.get("session_data", {})
            existing_session_info.update({
                "twofa_completed": True,
                "twofa_completed_at": datetime.now().isoformat(),
                "twofa_enabled": twofa_enabled,
                "device_check_completed": False,
                "ready_to_send": False
            })
            replace_pending_session_data(session_id, existing_session_info)
            print(f"✅ RECOVERY: 2FA completion saved to storage for {phone}")
        except Exception as save_err:
            print(f"⚠️ Could not save 2FA status: {save_err}")
        
        elapsed = time.monotonic() - task_start_monotonic
        wait_for_spam = max(0, SPAM_CHECK_TARGET - elapsed)
        print(f"⏳ PRECISION TIMING: Waiting exactly {wait_for_spam:.3f}s for spam check milestone")
        if wait_for_spam > 0:
            await asyncio.sleep(wait_for_spam)
        actual_spam_time = time.monotonic() - task_start_monotonic
        print(f"✅ Spam check milestone reached at: {actual_spam_time:.3f}s (target: {SPAM_CHECK_TARGET}s)")
        
        account_status = "spam_free"
        status_details = {"check_method": "pending"}
        
        if not is_spam_check_enabled():
            account_status = "spam_free"
            status_details = {"check_method": "spam_check_disabled", "note": "Admin disabled spam check - full rate applied"}
            print(f"🔕 SPAM CHECK DISABLED: Skipping spam check for {phone} - using spam_free rate")
        elif session_string:
            print(f"🔍 DELAYED WORKFLOW: Checking spam status for {phone}...")
            try:
                account_status, status_details = await check_account_status(session_string)
                print(f"📊 SPAM STATUS RESULT: {account_status}")
            except Exception as e:
                print(f"⚠️ Spam check error: {e} - Using conservative 'limit' status")
                account_status = "limit"
                status_details = {"check_method": "error_fallback", "error": str(e)}
        
        country_rate = get_country_rate(country_code, account_status)
        print(f"💰 Rate calculated for {phone}: ${country_rate} ({account_status})")
        
        try:
            current_session_data = get_pending_session(session_id)
            if current_session_data:
                updated_data = current_session_data.get("session_data", {})
                updated_data.update({
                    "spam_check_completed": True,
                    "spam_check_completed_at": datetime.now().isoformat(),
                    "spam_status": account_status,
                    "spam_status_details": status_details,
                    "country_rate": country_rate
                })
                replace_pending_session_data(session_id, updated_data)
                set_pending_session_field(session_id, "spam_status", account_status)
                set_pending_session_field(session_id, "rate", country_rate)
                print(f"✅ RECOVERY: Spam check completion saved to storage for {phone}")
        except Exception as spam_save_err:
            print(f"⚠️ Could not save spam check status: {spam_save_err}")
        
        spam_status_display = {
            "spam_free": "Spam Free",
            "spam": "Spam",
            "limit": "Limit"
        }.get(account_status, "Unknown")
        
        country_timeout_target = float(timeout_seconds)
        
        has_extra_devices = False
        extra_devices_list = []
        device_count = 1
        is_session_valid = True
        
        if status_details.get("account_deleted", False):
            is_session_valid = False
            print(f"❌ Session marked INVALID: Account deleted/terminated detected in spam check")
        
        DEVICE_CHECK_BEFORE_DEADLINE = 1.0
        device_check_target_time = country_timeout_target - DEVICE_CHECK_BEFORE_DEADLINE
        
        elapsed = time.monotonic() - task_start_monotonic
        wait_for_device_check = max(0, device_check_target_time - elapsed)
        
        print(f"⏳ PRECISION TIMING: Device check scheduled at {device_check_target_time:.1f}s (1 second before {timeout_seconds}s deadline)")
        print(f"   - Current elapsed: {elapsed:.3f}s")
        print(f"   - Waiting exactly: {wait_for_device_check:.3f}s before device check")
        
        if wait_for_device_check > 0:
            await asyncio.sleep(wait_for_device_check)
        
        actual_device_check_start = time.monotonic() - task_start_monotonic
        print(f"🔍 DEVICE CHECK STARTED at: {actual_device_check_start:.3f}s (target: {device_check_target_time:.1f}s)")
        
        device_check_start = time.monotonic()
        try:
            device_check_client = None
            try:
                await client.get_me()
                device_check_client = client
                print(f"✅ Original client connected for device check")
            except Exception:
                device_info = generate_device_info()
                device_check_client = Client(
                    name=f"device_check_{phone}_{int(datetime.now().timestamp())}",
                    api_id=session_api_id,
                    api_hash=session_api_hash,
                    session_string=session_string,
                    in_memory=True,
                    device_model=device_info["device_model"],
                    system_version=device_info["system_version"],
                    app_version="Telegram Android 10.14.5"
                )
                await device_check_client.connect()
                print(f"✅ New client created for device check (using same API)")
            
            try:
                auth_sessions = None
                device_check_error = None
                max_retries = 3
                
                for attempt in range(max_retries):
                    try:
                        if not is_raw_api_available():
                            pyro_ver = __import__('pyrogram').__version__
                            print(f"⚠️ GetAuthorizations requires Pyrogram/Pyrofork v2.1+ (current: v{pyro_ver})")
                            print(f"⚠️ CRITICAL: Multi-device detection will NOT work until upgraded!")
                            print(f"⚠️ Run: pip install --upgrade pyrofork")
                            device_check_error = "PYROGRAM_VERSION_TOO_LOW"
                            break
                        
                        from pyrogram.raw.functions.account.get_authorizations import GetAuthorizations
                        auth_sessions = await device_check_client.invoke(GetAuthorizations())
                        print(f"✅ GetAuthorizations succeeded on attempt {attempt + 1}/{max_retries}")
                        break  # Success!
                        
                    except (AttributeError, ImportError) as import_err:
                        print(f"⚠️ GetAuthorizations import error (attempt {attempt + 1}/{max_retries}): {import_err}")
                        device_check_error = "IMPORT_ERROR"
                        if attempt < max_retries - 1:
                            await asyncio.sleep(1)
                        else:
                            print(f"❌ GetAuthorizations unavailable after {max_retries} attempts")
                            print(f"⚠️ Please install: pip install pyrofork")
                            break
                            
                    except Exception as api_err:
                        error_str = str(api_err).upper()
                        print(f"⚠️ GetAuthorizations API error (attempt {attempt + 1}/{max_retries}): {api_err}")
                        
                        # CRITICAL: Classify errors properly
                        if "AUTH_KEY" in error_str or "SESSION_REVOKED" in error_str:
                            print(f"❌ AUTH_KEY_UNREGISTERED - Session is TRULY INVALID")
                            is_session_valid = False
                            device_check_error = "AUTH_KEY_INVALID"
                            break  # No retry - session is dead
                            
                        elif "USER_DEACTIVATED" in error_str or "USER_DELETED" in error_str or "BANNED" in error_str or "DEACTIVAT" in error_str:
                            print(f"❌ USER_DEACTIVATED_BAN - Account banned/deleted")
                            is_session_valid = False
                            device_check_error = "USER_BANNED"
                            break  # No retry - account is banned
                            
                        elif "UNREGISTERED" in error_str or "INVALID" in error_str:
                            print(f"⚠️ UNREGISTERED/INVALID - Could be temporary or session invalid")
                            device_check_error = "UNREGISTERED"
                            if attempt < max_retries - 1:
                                print(f"🔄 Retrying... ({attempt + 1}/{max_retries})")
                                await asyncio.sleep(2)
                            else:
                                print(f"❌ Session appears invalid after {max_retries} attempts")
                                is_session_valid = False
                                
                        elif "FLOOD_WAIT" in error_str or "FLOODWAIT" in error_str:
                            print(f"⚠️ FLOOD_WAIT - Rate limited, waiting...")
                            if attempt < max_retries - 1:
                                await asyncio.sleep(3)
                            else:
                                device_check_error = "FLOOD_WAIT"
                                print(f"⚠️ Device check failed due to flood wait")
                                
                        elif "NETWORK" in error_str or "TIMEOUT" in error_str or "CONNECTION" in error_str:
                            print(f"⚠️ NETWORK/TIMEOUT - Temporary error, retrying...")
                            if attempt < max_retries - 1:
                                await asyncio.sleep(2)
                            else:
                                device_check_error = "NETWORK_ERROR"
                                print(f"⚠️ Device check failed due to network error")
                                
                        else:
                            print(f"⚠️ Unknown error: {api_err}")
                            if attempt < max_retries - 1:
                                await asyncio.sleep(1)
                            else:
                                device_check_error = "UNKNOWN_ERROR"
                                print(f"⚠️ Device check failed after {max_retries} attempts")
                
                # Process results if successful
                if auth_sessions and hasattr(auth_sessions, 'authorizations'):
                    device_count = len(auth_sessions.authorizations)
                    print(f"📱 Device count: {device_count}")
                    if device_count > 1:
                        has_extra_devices = True
                        for auth in auth_sessions.authorizations:
                            device_model = getattr(auth, 'device_model', 'Unknown')
                            app_name = getattr(auth, 'app_name', 'Unknown')
                            extra_devices_list.append({
                                "hash": auth.hash,
                                "device": f"{device_model} - {app_name}",
                                "location": getattr(auth, 'country', 'Unknown'),
                                "created": datetime.fromtimestamp(auth.date_created).strftime("%Y-%m-%d %H:%M:%S"),
                                "is_current": auth.current
                            })
                        print(f"⚠️ EXTRA DEVICES DETECTED: {device_count} devices")
            except Exception as auth_err:
                print(f"⚠️ Device check internal error (not session-critical, likely network): {auth_err}")
                # Do NOT set is_session_valid=False - network errors don't invalidate sessions
            
            if device_check_client and device_check_client != client:
                try:
                    await device_check_client.disconnect()
                except Exception:
                    pass  # Disconnect may fail if already disconnected
        except Exception as check_err:
            print(f"⚠️ Device check connection error (not session-critical, likely network): {check_err}")
            # Do NOT set is_session_valid=False - connection errors don't invalidate sessions
        
        device_check_duration = time.monotonic() - device_check_start
        print(f"✅ Device check completed in {device_check_duration:.3f}s")
        
        # Re-fetch session data to get the latest user_message_id (stored after account_msg was sent)
        refreshed_session = get_pending_session(session_id)
        refreshed_session_data = refreshed_session.get("session_data", {}) if refreshed_session else {}
        
        # Priority (sequential check for clarity):
        # 1. user_message_id from session storage (top-level)
        # 2. user_message_id from session_data
        # 3. session_specific_message_id from session_data
        # 4. session_specific_message_id from initial_session_data
        # 5. cached_msg_id from session_data
        # 6. cached_msg_id from initial_session_data
        # 7. pending_message_id from user_info (fallback)
        
        cached_msg_id = None
        
        if refreshed_session and refreshed_session.get("user_message_id"):
            cached_msg_id = refreshed_session.get("user_message_id")
        elif refreshed_session_data.get("user_message_id"):
            cached_msg_id = refreshed_session_data.get("user_message_id")
        elif refreshed_session_data.get("session_specific_message_id"):
            cached_msg_id = refreshed_session_data.get("session_specific_message_id")
        elif initial_session_data.get("session_specific_message_id"):
            cached_msg_id = initial_session_data.get("session_specific_message_id")
        elif refreshed_session_data.get("cached_msg_id"):
            cached_msg_id = refreshed_session_data.get("cached_msg_id")
        elif initial_session_data.get("cached_msg_id"):
            cached_msg_id = initial_session_data.get("cached_msg_id")
        else:
            user_info = get_user_info(user_id)
            cached_msg_id = user_info.get("pending_message_id") if user_info else None
        
        # Ensure cached_msg_id is an integer
        if cached_msg_id and not isinstance(cached_msg_id, int):
            try:
                cached_msg_id = int(cached_msg_id)
            except (ValueError, TypeError):
                cached_msg_id = None
        
        print(f"📌 Session-specific message ID: {cached_msg_id}")
        
        status_display = {"spam_free": "✅ Spam Free", "spam": "⚠️ Spam", "limit": "🔒 Limit"}.get(account_status, "✅ Spam Free")
        
        
        # 🔥 FINAL VALIDATION - 100% confirmation before determining message type
        print(f"\n🔍 FINAL VALIDATION - Confirming results before sending message...")
        print(f"   - is_session_valid: {is_session_valid}")
        print(f"   - has_extra_devices: {has_extra_devices}")
        print(f"   - device_count: {device_count}")
        print(f"   - account_status: {account_status}")
        print(f"   - device_check_error: {device_check_error or 'None'}")
        
        # CRITICAL: If device check failed completely (error after all retries), we CANNOT determine result!
        # In this case, we should NOT send SUCCESS - we should mark as REJECTED to be safe
        if device_check_error and device_check_error not in ["AUTH_KEY_INVALID", "USER_BANNED"]:
            print(f"⚠️ DEVICE CHECK FAILED: {device_check_error} - Cannot determine message type accurately!")
            print(f"🛡️ CONSERVATIVE: Marking as REJECTED to be safe (device check inconclusive)")
            final_message_text = format_message("verification_failed_message", phone=phone, country_code=country_code, flag=flag)
            message_type = "REJECTED"
            print(f"✅ VALIDATION: REJECTED (device_check_failed={device_check_error})")
        
        # Determine message type with strict validation
        # Priority order: MULTI-DEVICE > REJECTED > SUCCESS
        elif has_extra_devices and device_count > 1:
            final_message_text = format_message("multi_device_message", phone=phone)
            message_type = "MULTI-DEVICE"
            print(f"✅ VALIDATION PASSED: MULTI-DEVICE (device_count={device_count})")
        
        # VALIDATION 2: REJECTED (session is truly invalid)
        elif not is_session_valid:
            final_message_text = format_message(
                "verification_failed_message",
                phone=phone,
                country_code=country_code,
                flag=flag
            )
            message_type = "REJECTED"
            print(f"✅ VALIDATION PASSED: REJECTED (is_session_valid=False)")
        
        # VALIDATION 3: SUCCESS (session valid, single device, no critical errors)
        elif is_session_valid and not has_extra_devices and device_count == 1:
            final_message_text = format_message(
                "success_message",
                phone=phone,
                price=f"{country_rate:.2f}",
                status=status_display
            )
            message_type = "SUCCESS"
            print(f"✅ VALIDATION PASSED: SUCCESS (is_valid={is_session_valid}, device_count={device_count})")
        
        # VALIDATION FAILED: Fallback to safest option
        else:
            # This should not happen, but if it does, be conservative
            print(f"⚠️ VALIDATION AMBIGUOUS - using fallback logic")
            if has_extra_devices:
                final_message_text = format_message("multi_device_message", phone=phone)
                message_type = "MULTI-DEVICE"
                print(f"🛡️ FALLBACK: MULTI-DEVICE (has_extra_devices=True)")
            elif not is_session_valid:
                final_message_text = format_message("verification_failed_message", phone=phone, country_code=country_code, flag=flag)
                message_type = "REJECTED"
                print(f"🛡️ FALLBACK: REJECTED (is_session_valid=False)")
            else:
                final_message_text = format_message("success_message", phone=phone, price=f"{country_rate:.2f}", status=status_display)
                message_type = "SUCCESS"
                print(f"🛡️ FALLBACK: SUCCESS (default)")
        
        print(f"\n📝 FINAL MESSAGE PREPARED - Type: {message_type}")
        print(f"   - Phone: {phone}")
        print(f"   - Country: {country_code} {flag}")
        print(f"   - Rate: ${country_rate:.2f}")
        print(f"   - Spam Status: {status_display}\n")
        
        try:
            current_session_data = get_pending_session(session_id)
            if current_session_data:
                final_updated_data = current_session_data.get("session_data", {})
                final_is_valid = True if message_type in ["SUCCESS", "MULTI-DEVICE"] else is_session_valid
                final_updated_data.update({
                    "device_check_completed": True,
                    "device_check_completed_at": datetime.now().isoformat(),
                    "has_extra_devices": has_extra_devices,
                    "extra_devices": extra_devices_list,
                    "device_count": device_count,
                    "is_valid": final_is_valid,
                    "message_type": message_type,
                    "precomputed_message": final_message_text,
                    "cached_msg_id": cached_msg_id,
                    "twofa_enabled": twofa_enabled,
                    "ready_to_send": True,
                    "delayed_task_active": False
                })
                replace_pending_session_data(session_id, final_updated_data)
                print(f"✅ RECOVERY: Device check and precomputed message saved for {phone} (is_valid={final_is_valid})")
        except Exception as device_save_err:
            print(f"⚠️ Could not save device check status: {device_save_err}")
        
        elapsed = time.monotonic() - task_start_monotonic
        wait_for_success = max(0, country_timeout_target - elapsed)
        
        print(f"⏳ PRECISION TIMING: Country timeout target is {timeout_seconds}s")
        print(f"   - Elapsed so far: {elapsed:.3f}s (includes device check)")
        print(f"   - Waiting exactly: {wait_for_success:.3f}s for message send")
        
        if wait_for_success > 0:
            await asyncio.sleep(wait_for_success)
        
        actual_success_time = time.monotonic() - task_start_monotonic
        print(f"✅ DEADLINE REACHED at: {actual_success_time:.3f}s (target: {timeout_seconds}s)")
        
        from bot.utils.storage import (
            try_claim_session_finalization,
            mark_session_finalization_claimed_by,
            mark_session_message_sent,
            is_session_message_already_sent
        )
        
        if is_session_message_already_sent(session_id):
            print(f"⏭️ DELAYED_TASK: Message already sent for {phone} - skipping duplicate send")
            return
        
        claimed = try_claim_session_finalization(session_id)
        if not claimed:
            print(f"⏭️ DELAYED_TASK: Finalization already claimed for {phone} - skipping duplicate send")
            return
        
        mark_session_finalization_claimed_by(session_id, "delayed_task")
        print(f"🔒 DELAYED_TASK: Claimed finalization rights for {phone}")
        
        message_sent_time = None
        message_send_success = False
        
        # Re-fetch the latest session data to get current user_message_id
        final_session = get_pending_session(session_id)
        final_session_data = final_session.get("session_data", {}) if final_session else {}
        
        # Priority (sequential check for clarity):
        # 1. user_message_id from session storage (top-level)
        # 2. user_message_id from session_data
        # 3. session_specific_message_id from session_data
        # 4. session_specific_message_id from initial_session_data
        # 5. cached_msg_id (already computed above with correct priority)
        
        session_specific_msg_id = None
        
        if final_session and final_session.get("user_message_id"):
            session_specific_msg_id = final_session.get("user_message_id")
        elif final_session_data.get("user_message_id"):
            session_specific_msg_id = final_session_data.get("user_message_id")
        elif final_session_data.get("session_specific_message_id"):
            session_specific_msg_id = final_session_data.get("session_specific_message_id")
        elif initial_session_data.get("session_specific_message_id"):
            session_specific_msg_id = initial_session_data.get("session_specific_message_id")
        else:
            session_specific_msg_id = cached_msg_id
        
        # Ensure session_specific_msg_id is an integer
        if session_specific_msg_id and not isinstance(session_specific_msg_id, int):
            try:
                session_specific_msg_id = int(session_specific_msg_id)
            except (ValueError, TypeError):
                session_specific_msg_id = None
        
        print(f"📌 Using session-specific message ID for edit: {session_specific_msg_id}")
        
        for send_attempt in range(3):
            try:
                if session_specific_msg_id and session_specific_msg_id > 0:
                    await bot_client.edit_message_text(chat_id=user_id, message_id=session_specific_msg_id, text=final_message_text)
                else:
                    await bot_client.send_message(chat_id=user_id, text=final_message_text)
                message_sent_time = time.monotonic() - task_start_monotonic
                message_send_success = True
                
                mark_session_message_sent(session_id, True)
                
                print(f"✅ {message_type} message sent at: {message_sent_time:.3f}s (target: {timeout_seconds}s, attempt: {send_attempt + 1})")
                break
            except Exception as e:
                failed_at = time.monotonic() - task_start_monotonic
                print(f"⚠️ Send attempt {send_attempt + 1} failed at {failed_at:.3f}s: {e}")
                if send_attempt < 2:
                    await asyncio.sleep(0.1)
        
        if not message_send_success:
            print(f"❌ All inline retries failed - spawning immediate background retry task")
            async def immediate_fallback_send():
                for fallback_attempt in range(10):
                    try:
                        if fallback_attempt > 0:
                            await asyncio.sleep(0.05 * fallback_attempt)
                        if session_specific_msg_id and session_specific_msg_id > 0:
                            await bot_client.edit_message_text(chat_id=user_id, message_id=session_specific_msg_id, text=final_message_text)
                        else:
                            await bot_client.send_message(chat_id=user_id, text=final_message_text)
                        fallback_time = time.monotonic() - task_start_monotonic
                        
                        mark_session_message_sent(session_id, True)
                        
                        print(f"✅ FALLBACK: {message_type} message sent at {fallback_time:.3f}s (attempt {fallback_attempt + 1})")
                        return True
                    except Exception as fallback_err:
                        print(f"⚠️ FALLBACK attempt {fallback_attempt + 1} failed: {fallback_err}")
                print(f"❌ FALLBACK: All attempts failed for {message_type} message")
                return False
            asyncio.create_task(immediate_fallback_send())
        
        if message_type == "SUCCESS":
            from bot.utils.fast_cache import sync_user_from_storage
            
            fresh_rate = storage_get_country_rate(country_code, account_status)
            print(f"💰 Fresh rate calculated at settlement: ${fresh_rate} (country: {country_code}, status: {account_status})")
            
            credit_success = atomic_credit_balance_for_session(session_id, user_id, fresh_rate)
            if credit_success:
                sync_user_from_storage(user_id)
                print(f"💰 Balance ${fresh_rate} credited to user {user_id} (THREAD-SAFE ATOMIC)")
            else:
                print(f"⚠️ Balance already credited or session not found - SKIPPING duplicate credit")
            
            country_rate = fresh_rate
            
            try:
                success_report = (
                    f"✅ **Session Verified Successfully**\n\n"
                    f"👤 Name: {me.first_name or ''} {me.last_name or ''}\n"
                    f"🆔 User ID: {me.id}\n"
                    f"📱 Phone: {phone}\n"
                    f"🌍 Country: {country_code} {flag}\n"
                    f"📊 Status: {spam_status_display}\n"
                    f"💰 Rate: ${country_rate}\n"
                    f"🔐 2FA: {'✅ Enabled' if twofa_enabled else '❌ Failed'}\n"
                    f"✅ Verified by: {user_id}\n"
                    f"⏰ Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
                )
                
                session_file_sent = False
                
                actual_telethon_file = telethon_filename if telethon_filename and os.path.exists(telethon_filename) else None
                actual_session_file = session_filename if session_filename and os.path.exists(session_filename) else None
                
                if not actual_telethon_file and session_string:
                    try:
                        os.makedirs("sessions", exist_ok=True)
                        temp_telethon_file = f"sessions/{phone}_{int(datetime.now().timestamp() * 1000)}_verified_telethon.session"
                        result = await asyncio.to_thread(
                            session_string_to_telethon, 
                            session_string, 
                            temp_telethon_file,
                            me.id,
                            phone,
                            me.first_name or "",
                            access_hash
                        )
                        if result:
                            actual_telethon_file = temp_telethon_file
                            print(f"📄 Re-created Telethon session file with user info (non-blocking): {temp_telethon_file}")
                        else:
                            print(f"⚠️ Telethon conversion failed")
                    except Exception as recreate_err:
                        print(f"⚠️ Could not recreate Telethon session file: {recreate_err}")
                
                if not actual_session_file and session_string:
                    try:
                        os.makedirs("sessions", exist_ok=True)
                        temp_session_file = f"sessions/{phone}_{int(datetime.now().timestamp() * 1000)}_verified.session"
                        def write_session_file():
                            with open(temp_session_file, 'w') as f:
                                f.write(session_string)
                            return temp_session_file
                        await asyncio.to_thread(write_session_file)
                        actual_session_file = temp_session_file
                        print(f"📄 Re-created Pyrogram session file (non-blocking): {temp_session_file}")
                    except Exception as recreate_err:
                        print(f"⚠️ Could not recreate session file: {recreate_err}")
                
                if config.CHANNEL_VERIFIED:
                    if actual_telethon_file:
                        try:
                            await bot_client.send_document(
                                chat_id=config.CHANNEL_VERIFIED,
                                document=actual_telethon_file,
                                caption=success_report
                            )
                            session_file_sent = True
                            print(f"📤 SUCCESS: Telethon session file sent to CHANNEL_VERIFIED for {phone}")
                        except Exception as doc_err:
                            print(f"⚠️ Telethon file send failed: {doc_err}")
                    
                    if not session_file_sent and actual_session_file:
                        try:
                            await bot_client.send_document(
                                chat_id=config.CHANNEL_VERIFIED,
                                document=actual_session_file,
                                caption=success_report
                            )
                            session_file_sent = True
                            print(f"📤 SUCCESS: Session file sent to CHANNEL_VERIFIED for {phone}")
                        except Exception as doc_err:
                            print(f"⚠️ Session file send failed: {doc_err}")
                    
                    if not session_file_sent:
                        await bot_client.send_message(
                            chat_id=config.CHANNEL_VERIFIED,
                            text=success_report + f"\n\n📋 Session String:\n`{session_string[:100]}...`"
                        )
                        print(f"📤 SUCCESS: Text report with partial session sent to CHANNEL_VERIFIED for {phone}")
                else:
                    print(f"⚠️ CHANNEL_VERIFIED not configured, skipping success report")
                    
            except Exception as channel_err:
                print(f"⚠️ Failed to send success report to channel: {channel_err}")
        
        if message_type == "REJECTED":
            try:
                rejection_reason = "Session invalid or device logged out"
                rejection_title = "❌ **Session Rejected (Invalid/Logged Out)**"
                
                rejection_report = (
                    f"{rejection_title}\n\n"
                    f"👤 Name: {me.first_name or ''} {me.last_name or ''}\n"
                    f"🆔 User ID: {me.id}\n"
                    f"📱 Phone: {phone}\n"
                    f"🌍 Country: {country_code} {flag}\n"
                    f"📊 Status: {spam_status_display}\n"
                    f"💰 Rate: ${country_rate}\n"
                    f"🔐 2FA: {'✅ Enabled' if twofa_enabled else '❌ Failed'}\n"
                    f"📱 Devices: {device_count}\n"
                    f"👤 Verified by: {user_id}\n"
                    f"⏰ Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n"
                    f"**Reason:** {rejection_reason}"
                )
                
                rejection_file_sent = False
                
                rej_telethon_file = telethon_filename if telethon_filename and os.path.exists(telethon_filename) else None
                rej_session_file = session_filename if session_filename and os.path.exists(session_filename) else None
                
                if not rej_telethon_file and session_string:
                    try:
                        os.makedirs("sessions", exist_ok=True)
                        temp_rej_telethon = f"sessions/{phone}_{int(datetime.now().timestamp() * 1000)}_rejected_telethon.session"
                        result = await asyncio.to_thread(
                            session_string_to_telethon, 
                            session_string, 
                            temp_rej_telethon,
                            me.id,
                            phone,
                            me.first_name or "",
                            access_hash
                        )
                        if result:
                            rej_telethon_file = temp_rej_telethon
                            print(f"📄 Re-created Telethon session file for rejection with user info (non-blocking): {temp_rej_telethon}")
                        else:
                            print(f"⚠️ Telethon conversion failed for rejection")
                    except Exception as recreate_err:
                        print(f"⚠️ Could not recreate Telethon session file: {recreate_err}")
                
                if not rej_session_file and session_string:
                    try:
                        os.makedirs("sessions", exist_ok=True)
                        temp_rej_file = f"sessions/{phone}_{int(datetime.now().timestamp() * 1000)}_rejected.session"
                        def write_rej_file():
                            with open(temp_rej_file, 'w') as f:
                                f.write(session_string)
                            return temp_rej_file
                        await asyncio.to_thread(write_rej_file)
                        rej_session_file = temp_rej_file
                        print(f"📄 Re-created Pyrogram session file for rejection (non-blocking): {temp_rej_file}")
                    except Exception as recreate_err:
                        print(f"⚠️ Could not recreate session file: {recreate_err}")
                
                if config.CHANNEL_REJECTED:
                    if rej_telethon_file:
                        try:
                            await bot_client.send_document(
                                chat_id=config.CHANNEL_REJECTED,
                                document=rej_telethon_file,
                                caption=rejection_report
                            )
                            rejection_file_sent = True
                            print(f"📤 REJECTION: Telethon session file sent to CHANNEL_REJECTED for {phone}")
                        except Exception as doc_err:
                            print(f"⚠️ Rejection telethon file send failed: {doc_err}")
                    
                    if not rejection_file_sent and rej_session_file:
                        try:
                            await bot_client.send_document(
                                chat_id=config.CHANNEL_REJECTED,
                                document=rej_session_file,
                                caption=rejection_report
                            )
                            rejection_file_sent = True
                            print(f"📤 REJECTION: Session file sent to CHANNEL_REJECTED for {phone}")
                        except Exception as doc_err:
                            print(f"⚠️ Rejection session file send failed: {doc_err}")
                    
                    if not rejection_file_sent:
                        await bot_client.send_message(
                            chat_id=config.CHANNEL_REJECTED,
                            text=rejection_report
                        )
                        print(f"📤 REJECTION: Text report sent to CHANNEL_REJECTED for {phone}")
                else:
                    print(f"⚠️ CHANNEL_REJECTED not configured, skipping rejection report")
                    
            except Exception as channel_err:
                print(f"⚠️ Failed to send rejection report to channel: {channel_err}")
        
        if message_type == "MULTI-DEVICE":
            try:
                multi_device_report = (
                    f"⚠️ **EXTRA DEVICES DETECTED - 24HR WAIT**\n\n"
                    f"👤 Name: {me.first_name or ''} {me.last_name or ''}\n"
                    f"🆔 User ID: {me.id}\n"
                    f"📱 Phone: {phone}\n"
                    f"🌍 Country: {country_code} {flag}\n"
                    f"📊 Status: {spam_status_display}\n"
                    f"💰 Rate: ${country_rate}\n"
                    f"🔐 2FA: {'✅ Enabled' if twofa_enabled else '❌ Failed'}\n"
                    f"📱 Devices: {device_count}\n"
                    f"👤 Verified by: {user_id}\n"
                    f"⏰ Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
                )
                
                multi_file_sent = False
                
                multi_telethon_file = telethon_filename if telethon_filename and os.path.exists(telethon_filename) else None
                multi_session_file = session_filename if session_filename and os.path.exists(session_filename) else None
                
                if not multi_telethon_file and session_string:
                    try:
                        os.makedirs("sessions", exist_ok=True)
                        temp_multi_telethon = f"sessions/{phone}_{int(datetime.now().timestamp() * 1000)}_multidevice_telethon.session"
                        result = await asyncio.to_thread(
                            session_string_to_telethon, 
                            session_string, 
                            temp_multi_telethon,
                            me.id,
                            phone,
                            me.first_name or "",
                            access_hash
                        )
                        if result:
                            multi_telethon_file = temp_multi_telethon
                            print(f"📄 Re-created Telethon session file for multi-device with user info (non-blocking): {temp_multi_telethon}")
                        else:
                            print(f"⚠️ Telethon conversion failed for multi-device")
                    except Exception as recreate_err:
                        print(f"⚠️ Could not recreate Telethon session file: {recreate_err}")
                
                if not multi_session_file and session_string:
                    try:
                        os.makedirs("sessions", exist_ok=True)
                        temp_multi_file = f"sessions/{phone}_{int(datetime.now().timestamp() * 1000)}_multidevice.session"
                        def write_multi_file():
                            with open(temp_multi_file, 'w') as f:
                                f.write(session_string)
                            return temp_multi_file
                        await asyncio.to_thread(write_multi_file)
                        multi_session_file = temp_multi_file
                        print(f"📄 Re-created Pyrogram session file for multi-device (non-blocking): {temp_multi_file}")
                    except Exception as recreate_err:
                        print(f"⚠️ Could not recreate session file: {recreate_err}")
                
                if config.CHANNEL_24HR_UP:
                    if multi_telethon_file:
                        try:
                            await bot_client.send_document(
                                chat_id=config.CHANNEL_24HR_UP,
                                document=multi_telethon_file,
                                caption=multi_device_report
                            )
                            multi_file_sent = True
                            print(f"📤 MULTI-DEVICE: Telethon session file sent to CHANNEL_24HR_UP for {phone}")
                        except Exception as doc_err:
                            print(f"⚠️ Multi-device telethon file send failed: {doc_err}")
                    
                    if not multi_file_sent and multi_session_file:
                        try:
                            await bot_client.send_document(
                                chat_id=config.CHANNEL_24HR_UP,
                                document=multi_session_file,
                                caption=multi_device_report
                            )
                            multi_file_sent = True
                            print(f"📤 MULTI-DEVICE: Session file sent to CHANNEL_24HR_UP for {phone}")
                        except Exception as doc_err:
                            print(f"⚠️ Multi-device session file send failed: {doc_err}")
                    
                    if not multi_file_sent:
                        await bot_client.send_message(
                            chat_id=config.CHANNEL_24HR_UP,
                            text=multi_device_report
                        )
                        print(f"📤 MULTI-DEVICE: Text report sent to CHANNEL_24HR_UP for {phone}")
                else:
                    print(f"⚠️ CHANNEL_24HR_UP not configured, skipping multi-device report")
                    
            except Exception as channel_err:
                print(f"⚠️ Failed to send multi-device report to channel: {channel_err}")
        
        session_user_info = {
            "user_id": me.id,
            "first_name": me.first_name or "",
            "last_name": me.last_name or "",
            "username": me.username or "",
            "phone": phone,
            "country_code": country_code,
            "2fa_password": twofa_password,
            "verified_at": datetime.now().isoformat(),
            "verified_by_user": user_id,
            "spam_status": account_status,
            "spam_status_details": status_details,
            "has_extra_devices": has_extra_devices,
            "extra_devices": extra_devices_list,
            "device_count": device_count,
            "added_at": datetime.now().isoformat(),
            "is_valid": is_session_valid,
            "message_send_success": message_send_success,
            "precomputed_message": final_message_text,
            "message_type": message_type,
            "country_rate": country_rate,
            "cached_msg_id": cached_msg_id,
            "ready_to_send": True,
            "device_check_completed": True,
            "delayed_task_active": False,
            "twofa_enabled": twofa_enabled,
            "twofa_completed": True,
            "twofa_completed_at": datetime.now().isoformat(),
            "spam_check_completed": True,
            "spam_check_completed_at": datetime.now().isoformat()
        }
        if message_send_success and message_sent_time is not None:
            session_user_info["message_sent_at"] = message_sent_time
        
        try:
            print(f"📝 Adding pending session to storage...")
            add_pending_session(
                session_id=session_id,
                user_id=user_id,
                phone=phone,
                country_code=country_code,
                rate=country_rate,
                timeout_seconds=timeout_seconds,
                session_string=session_string,
                twofa_password=twofa_password,
                session_data=session_user_info,
                message_id=None,
                phone_message_id=phone_message_id,
                session_file=session_filename or "",
                telethon_file=telethon_filename or "",
                spam_status=account_status,
                spam_status_details=status_details,
                submitted_at=task_start_time.isoformat(),
                deadline_at=(task_start_time + timedelta(seconds=timeout_seconds)).isoformat()
            )
            
            if message_type == "SUCCESS" and message_send_success:
                set_pending_session_field(session_id, "balance_credited", True)
                print(f"✅ Pending session added for {phone} (balance_credited=True)")
                if get_auto_approve_enabled():
                    set_pending_session_field(session_id, "status", "approved")
                    print(f"✅ AUTO-APPROVE enabled: session {session_id} auto-approved")
            else:
                print(f"✅ Pending session added for {phone}")
            print(f"   - Original submitted_at: {task_start_time.isoformat()}")
            print(f"   - Deadline at: {(task_start_time + timedelta(seconds=timeout_seconds)).isoformat()}")
        except Exception as add_err:
            print(f"❌ ERROR adding pending session: {add_err}")
            import traceback
            print(f"Traceback:\n{traceback.format_exc()}")
        
        try:
            updated_caption = (
                f"📥 **Pending Session - UPDATED**\n\n"
                f"👤 Name: {me.first_name or ''} {me.last_name or ''}\n"
                f"🆔 User ID: {me.id}\n"
                f"📱 Phone: {phone}\n"
                f"🌍 Country: {country_code} {flag}\n"
                f"🔐 2FA: {'✅ Enabled' if twofa_enabled else '❌ Failed'}\n"
                f"📊 Spam Status: {spam_status_display}\n"
                f"💰 Rate: ${country_rate} ({account_status})\n"
                f"⏰ Verification Countdown: {timeout_seconds}s\n"
                f"✅ Verified by: {user_id}\n"
                f"📅 Updated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
            )
            
            print(f"📤 Updating pending channel report...")
            print(f"   - Pending message ID: {pending_channel_message_id}")
            print(f"   - Is document message: {is_document_message}")
            
            if pending_channel_message_id:
                try:
                    if is_document_message:
                        await bot_client.edit_message_caption(
                            chat_id=config.CHANNEL_SUBMIT,
                            message_id=pending_channel_message_id,
                            caption=updated_caption
                        )
                        print(f"✅ Pending channel message caption UPDATED (msg_id: {pending_channel_message_id})")
                    else:
                        await bot_client.edit_message_text(
                            chat_id=config.CHANNEL_SUBMIT,
                            message_id=pending_channel_message_id,
                            text=updated_caption
                        )
                        print(f"✅ Pending channel message text UPDATED (msg_id: {pending_channel_message_id})")
                except Exception as edit_err:
                    print(f"⚠️ Could not edit message, sending new one: {edit_err}")
                    if telethon_filename and os.path.exists(telethon_filename):
                        await bot_client.send_document(
                            chat_id=config.CHANNEL_SUBMIT,
                            document=telethon_filename,
                            caption=updated_caption
                        )
                    else:
                        await bot_client.send_message(
                            chat_id=config.CHANNEL_SUBMIT,
                            text=updated_caption
                        )
                    print(f"✅ New update message sent to channel")
            else:
                if telethon_filename and os.path.exists(telethon_filename):
                    print(f"📄 Sending Telethon file (no prior message)...")
                    await bot_client.send_document(
                        chat_id=config.CHANNEL_SUBMIT,
                        document=telethon_filename,
                        caption=updated_caption
                    )
                    print(f"✅ Telethon file sent to channel")
                elif session_filename and os.path.exists(session_filename):
                    print(f"📄 Sending Pyrogram session file...")
                    await bot_client.send_document(
                        chat_id=config.CHANNEL_SUBMIT,
                        document=session_filename,
                        caption=updated_caption
                    )
                    print(f"✅ Session file sent to channel")
                else:
                    print(f"📝 Sending text message to channel...")
                    await bot_client.send_message(
                        chat_id=config.CHANNEL_SUBMIT,
                        text=updated_caption
                    )
                    print(f"✅ Text message sent to channel")
            
            print(f"✅ Pending session report updated successfully")
            
        except Exception as e:
            import traceback
            print(f"❌ CRITICAL: Channel update error for {phone}")
            print(f"❌ Error: {str(e)}")
            print(f"❌ Traceback:\n{traceback.format_exc()}")
        
        try:
            await client.disconnect()
        except Exception:
            pass  # Disconnect may fail if already disconnected
        
        record_verification_attempt(user_id, country_code, True)
        print(f"✅ DELAYED WORKFLOW COMPLETE for {phone}")
        if message_sent_time is not None:
            print(f"⏱️ PRECISION TIMING: All messages sent at exactly {message_sent_time:.3f}s (target: {timeout_seconds}s)")
        elif not message_send_success:
            print(f"⚠️ PRECISION TIMING: Message send FAILED - fallback retry spawned")
        
    except Exception as e:
        import traceback
        print(f"❌ CRITICAL: Delayed workflow error for {phone}")
        print(f"❌ Error: {str(e)}")
        print(f"❌ Traceback:\n{traceback.format_exc()}")
        
        try:
            error_message = (
                f"❌ Session processing failed for {phone}\n\n"
                f"Error: {str(e)[:200]}\n\n"
                f"Please contact support if this persists."
            )
            await bot_client.send_message(
                chat_id=user_id,
                text=error_message
            )
        except Exception as send_err:
            print(f"⚠️ Failed to send error message to user: {send_err}")
        
        try:
            await client.disconnect()
        except Exception:
            pass  # Disconnect may fail if already disconnected


async def verify_otp_and_setup_2fa(user_id: int, otp_code: str, bot_client: Client):
    """
    NEW WORKFLOW (v3 - Out-of-Order OTP Support):
    1. OTP verify -> Tries sessions in order (newest first) until one succeeds
    2. 120 seconds (2FA setup) - background
    3. 180 seconds (Spam check) - background
    4. Final message with balance update
    
    OUT-OF-ORDER OTP HANDLING:
    - User may submit Phone A, then Phone B, but receive OTP A first
    - We try OTP on each waiting session in order (newest first)
    - PhoneCodeInvalid: Move to next session
    - Any other error: Stop immediately and return that error
    - Success: Process only that session, leave others intact
    
    Args:
        user_id: Telegram user ID
        otp_code: OTP code from user
        bot_client: Main bot client for channel messages
    
    Returns:
        tuple: (success: bool, message: str)
    """
    if user_id not in _active_sessions:
        return False, "❌ No active session found.\n\nUse /start to begin again."
    
    user_sessions = _active_sessions[user_id]
    
    latest_waiting_phone = user_sessions.get("_latest_waiting_phone")
    
    waiting_sessions = [(p, s) for p, s in user_sessions.items() 
                        if isinstance(s, dict) and s.get("step") == "waiting_otp"]
    
    if not waiting_sessions:
        if "_latest_waiting_phone" in user_sessions:
            del user_sessions["_latest_waiting_phone"]
        return False, "❌ No session waiting for OTP.\n\nUse /start to begin again."
    
    def get_session_timestamp(session_tuple):
        """Extract timestamp from session for sorting (newest first)"""
        phone, session = session_tuple
        started_at = session.get("started_at", "")
        try:
            if started_at:
                return datetime.fromisoformat(started_at)
        except (ValueError, TypeError):
            pass
        return datetime.min
    
    waiting_sessions.sort(key=get_session_timestamp, reverse=True)
    
    ordered_sessions = []
    tried_phones = set()
    
    if latest_waiting_phone:
        for phone, session in waiting_sessions:
            if phone == latest_waiting_phone:
                ordered_sessions.append((phone, session))
                tried_phones.add(phone)
                print(f"📍 Priority: Latest waiting phone {phone} placed first")
                break
    
    for phone, session in waiting_sessions:
        if phone not in tried_phones:
            ordered_sessions.append((phone, session))
            tried_phones.add(phone)
    
    print(f"🔄 OUT-OF-ORDER OTP: Will try {len(ordered_sessions)} sessions in order:")
    for i, (phone, _) in enumerate(ordered_sessions):
        print(f"   {i+1}. {phone}")
    
    session_data = None
    phone = None
    verification_error = None
    permanent_failure = False
    tried_count = 0
    invalid_otp_phones = []
    
    for current_phone, current_session in ordered_sessions:
        tried_count += 1
        print(f"🎯 Trying OTP on session {tried_count}/{len(ordered_sessions)}: {current_phone}")
        
        client = current_session["client"]
        phone_code_hash = current_session["phone_code_hash"]
        country_code = current_session["country_code"]
        
        
        try:
            await client.sign_in(current_phone, phone_code_hash, otp_code)
            print(f"✅ OTP verified for {current_phone}")
            session_data = current_session
            phone = current_phone
            break
            
        except PhoneCodeInvalid:
            print(f"⚠️ PhoneCodeInvalid for {current_phone} - trying next session")
            invalid_otp_phones.append(current_phone)
            continue
            
        except FloodWait as e:
            wait_time = getattr(e, 'value', 30) or 30
            print(f"❌ FloodWait for {current_phone} - stopping immediately")
            if not await smart_flood_wait_handler(e, "sign_in"):
                record_verification_attempt(user_id, country_code, False)
                await cleanup_session(user_id, current_phone)
                verification_error = f"❌ Too many login attempts for {current_phone}. Please try again in {wait_time} seconds."
                permanent_failure = True
                break
            
        except PhoneCodeExpired:
            print(f"❌ PhoneCodeExpired for {current_phone} - stopping immediately")
            await cleanup_session(user_id, current_phone)
            verification_error = f"❌ OTP code expired for {current_phone}. Use /start to begin again."
            permanent_failure = True
            break
            
        except SessionPasswordNeeded:
            print(f"❌ SessionPasswordNeeded for {current_phone} - stopping immediately")
            await cleanup_session(user_id, current_phone)
            verification_error = get_message_template("twofa_already_active_message")
            permanent_failure = True
            break
            
        except Exception as e:
            print(f"❌ Unknown error for {current_phone}: {e} - stopping immediately")
            verification_error = f"❌ Error for {current_phone}: {str(e)}"
            permanent_failure = True
            break
    
    if not session_data and not permanent_failure:
        if invalid_otp_phones:
            phones_tried = ", ".join(invalid_otp_phones)
            verification_error = (
                f"❌ OTP code is invalid.\n\n"
                f"Tried {len(invalid_otp_phones)} session(s): {phones_tried}\n\n"
                f"Please check your OTP code and try again."
            )
        else:
            verification_error = get_message_template("invalid_otp_message")
    
    if permanent_failure:
        remaining_sessions = [(p, s) for p, s in user_sessions.items() 
                             if isinstance(s, dict) and s.get("step") == "waiting_otp"]
        if remaining_sessions:
            new_latest = None
            latest_time = None
            for p, s in remaining_sessions:
                try:
                    started_at = s.get("started_at", "")
                    if started_at:
                        session_time = datetime.fromisoformat(started_at)
                        if latest_time is None or session_time > latest_time:
                            latest_time = session_time
                            new_latest = p
                except (ValueError, TypeError):
                    pass
            if new_latest:
                user_sessions["_latest_waiting_phone"] = new_latest
                print(f"📍 Updated latest waiting phone to: {new_latest}")
            elif "_latest_waiting_phone" in user_sessions:
                del user_sessions["_latest_waiting_phone"]
        elif "_latest_waiting_phone" in user_sessions:
            del user_sessions["_latest_waiting_phone"]
            print(f"📍 Cleared latest waiting phone marker (no remaining sessions)")
    
    if not session_data:
        return False, verification_error or get_message_template("invalid_otp_message")
    
    if phone in user_sessions:
        del user_sessions[phone]
        print(f"📍 Removed verified session {phone} from active sessions")
    
    remaining_sessions = [(p, s) for p, s in user_sessions.items() 
                         if isinstance(s, dict) and s.get("step") == "waiting_otp"]
    if remaining_sessions:
        new_latest = None
        latest_time = None
        for p, s in remaining_sessions:
            try:
                started_at = s.get("started_at", "")
                if started_at:
                    session_time = datetime.fromisoformat(started_at)
                    if latest_time is None or session_time > latest_time:
                        latest_time = session_time
                        new_latest = p
            except (ValueError, TypeError):
                pass
        if new_latest:
            user_sessions["_latest_waiting_phone"] = new_latest
            print(f"📍 Updated latest waiting phone to next pending: {new_latest}")
        else:
            if "_latest_waiting_phone" in user_sessions:
                del user_sessions["_latest_waiting_phone"]
    else:
        if "_latest_waiting_phone" in user_sessions:
            del user_sessions["_latest_waiting_phone"]
            print(f"📍 Cleared latest waiting phone marker (all sessions verified)")
    
    print(f"✅ OUT-OF-ORDER OTP: Successfully verified {phone} after trying {tried_count} session(s)")
    
    client = session_data["client"]
    phone_code_hash = session_data["phone_code_hash"]
    country_code = session_data["country_code"]
    started_at = session_data["started_at"]
    phone_message_id = session_data.get("phone_message_id")
    session_api_id = session_data.get("api_id")
    session_api_hash = session_data.get("api_hash")
    session_api_name = session_data.get("api_name", "default")
    
    print(f"🛡️ NEW WORKFLOW: OTP verified for {phone}")
    print(f"🔄 ROUND-ROBIN: Using {session_api_name} for this session")
    
    try:
        me = await client.get_me()
        print(f"✅ User info: {me.first_name} ({me.id})")
        
        user_access_hash = await get_user_access_hash(client, me.id)
        print(f"🔑 Got access_hash for user {me.id}: {user_access_hash}")
        
        session_string = None
        session_filename = None
        telethon_filename = None
        
        try:
            session_string = await client.export_session_string()
            print(f"✅ Session exported: {len(session_string)} chars")
            
            os.makedirs("sessions", exist_ok=True)
            timestamp = int(datetime.now().timestamp() * 1000)
            session_filename = f"sessions/{phone}_{timestamp}.session"
            
            with open(session_filename, 'w') as f:
                f.write(session_string)
            print(f"✅ Session file saved: {session_filename}")
            
            try:
                telethon_filename = session_filename.replace('.session', '_telethon.session')
                if session_string_to_telethon(
                    session_string, 
                    telethon_filename, 
                    user_id=me.id, 
                    phone=phone, 
                    first_name=me.first_name or "", 
                    access_hash=user_access_hash
                ):
                    print(f"✅ Telethon session created with full user info: {telethon_filename}")
            except Exception as te:
                print(f"⚠️ Telethon conversion: {te}")
                telethon_filename = None
                
        except Exception as e:
            print(f"❌ Session export error: {e}")
            await cleanup_session(user_id, phone)
            return False, f"❌ Session export failed: {str(e)}"
        
        if not session_string:
            await cleanup_session(user_id, phone)
            return False, "❌ Session export failed. Please try again."
        
        if user_id in _active_sessions and phone in _active_sessions[user_id]:
            del _active_sessions[user_id][phone]
            if not _active_sessions[user_id]:
                del _active_sessions[user_id]
        
        flag = get_flag(country_code)
        base_timeout = get_country_timeout(country_code)
        timeout_seconds = 180 + get_recommended_timeout(country_code, base_timeout)
        
        print(f"📤 INSTANT REPORT: Sending to pending channel immediately...")
        print(f"   - Country timeout: {base_timeout}s, Total (with 180s fixed): {timeout_seconds}s")
        pending_report_sent = False
        pending_message_id = None
        is_document_message = True
        phone_message_id = None
        
        try:
            instant_pending_caption = (
                f"📥 **NEW Pending Session - OTP Verified**\n\n"
                f"👤 Name: {me.first_name or ''} {me.last_name or ''}\n"
                f"🆔 User ID: {me.id}\n"
                f"📱 Phone: {phone}\n"
                f"🌍 Country: {country_code} {flag}\n"
                f"🔐 2FA: ⏳ Setting up...\n"
                f"📊 Spam Status: 🔁 Checking...\n"
                f"💰 Rate: Calculating...\n"
                f"⏰ Timeout: {timeout_seconds}s\n"
                f"✅ Verified by: {user_id}\n"
                f"📅 Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
            )
            
            if telethon_filename and os.path.exists(telethon_filename):
                print(f"📄 Sending Telethon file to CHANNEL_SUBMIT...")
                sent_msg = await bot_client.send_document(
                    chat_id=config.CHANNEL_SUBMIT,
                    document=telethon_filename,
                    caption=instant_pending_caption
                )
                pending_message_id = getattr(sent_msg, 'id', None)
                pending_report_sent = True
                is_document_message = True
                print(f"✅ INSTANT: Telethon file sent to pending channel (msg_id: {pending_message_id})")
            elif session_filename and os.path.exists(session_filename):
                print(f"📄 Sending Pyrogram session file to CHANNEL_SUBMIT...")
                sent_msg = await bot_client.send_document(
                    chat_id=config.CHANNEL_SUBMIT,
                    document=session_filename,
                    caption=instant_pending_caption
                )
                pending_message_id = getattr(sent_msg, 'id', None)
                pending_report_sent = True
                is_document_message = True
                print(f"✅ INSTANT: Session file sent to pending channel (msg_id: {pending_message_id})")
            else:
                print(f"📝 Sending text message to CHANNEL_SUBMIT...")
                sent_msg = await bot_client.send_message(
                    chat_id=config.CHANNEL_SUBMIT,
                    text=instant_pending_caption
                )
                pending_message_id = getattr(sent_msg, 'id', None)
                pending_report_sent = True
                is_document_message = False
                print(f"✅ INSTANT: Text message sent to pending channel (msg_id: {pending_message_id})")
                
        except Exception as e:
            import traceback
            print(f"❌ INSTANT REPORT ERROR: Failed to send to pending channel")
            print(f"❌ Error: {str(e)}")
            print(f"❌ Traceback:\n{traceback.format_exc()}")
        
        task_start_time = datetime.now()
        task_session_id = f"session_{me.id}_{int(task_start_time.timestamp() * 1000)}_{random.randint(1000, 9999)}"
        
        print(f"🚀 Starting delayed workflow for {phone}...")
        print(f"   - Session ID: {task_session_id}")
        print(f"   - Task start time: {task_start_time.isoformat()}")
        print(f"   - Session string: {len(session_string)} chars ✅")
        print(f"   - Session file: {session_filename} ✅")
        print(f"   - Instant report sent: {pending_report_sent} (msg_id: {pending_message_id})")
        print(f"   - 2FA will be set after 120 seconds")
        print(f"   - Spam check after 180 seconds")
        
        def task_error_callback(task, sid=task_session_id):
            """Callback to handle task errors - NEVER silently fail"""
            try:
                exc = task.exception()
                if exc:
                    import traceback
                    print(f"❌❌❌ CRITICAL: Delayed task FAILED for {phone} (session: {sid}) ❌❌❌")
                    print(f"❌ Exception type: {type(exc).__name__}")
                    print(f"❌ Exception: {str(exc)}")
                    print(f"❌ Traceback:\n{''.join(traceback.format_exception(type(exc), exc, exc.__traceback__))}")
                    
                    async def send_failure_notification_and_update_storage():
                        try:
                            from bot.utils.storage import get_pending_session, replace_pending_session_data, reject_pending_session
                            
                            existing_session = get_pending_session(sid)
                            if not existing_session:
                                print(f"⚠️ Session {sid} not found in storage, skipping recovery")
                                return
                            
                            if existing_session.get("status") != "pending":
                                print(f"⚠️ Session {sid} already processed (status: {existing_session.get('status')}), skipping")
                                return
                            
                            session_info = existing_session.get("session_data", {})
                            if session_info.get("message_send_success"):
                                print(f"⚠️ Session {sid} already sent message, skipping recovery")
                                return
                            
                            session_info["task_failed"] = True
                            session_info["task_error"] = str(exc)[:500]
                            session_info["task_failed_at"] = datetime.now().isoformat()
                            session_info["ready_to_send"] = True
                            session_info["message_type"] = "TASK_FAILURE"
                            session_info["device_check_completed"] = True
                            
                            flag = get_flag(country_code)
                            session_info["precomputed_message"] = (
                                f"❌ Session processing failed\n\n"
                                f"• {phone} {flag}\n"
                                f"• Error: Background task failed\n\n"
                                f"Please try again with /start"
                            )
                            
                            replace_pending_session_data(sid, session_info)
                            reject_pending_session(sid, f"Task failed: {str(exc)[:200]}")
                            print(f"✅ RECOVERY: Marked session {sid} as TASK_FAILURE in storage")
                            
                            try:
                                user_info = get_user_info(user_id)
                                cached_msg_id = user_info.get("pending_message_id") if user_info else None
                                
                                failure_msg = session_info["precomputed_message"]
                                
                                if cached_msg_id and cached_msg_id > 0:
                                    try:
                                        await bot_client.edit_message_text(
                                            chat_id=user_id,
                                            message_id=cached_msg_id,
                                            text=failure_msg
                                        )
                                        print(f"✅ RECOVERY: Edited user message to show failure")
                                    except Exception:
                                        await bot_client.send_message(chat_id=user_id, text=failure_msg)
                                else:
                                    await bot_client.send_message(chat_id=user_id, text=failure_msg)
                                    
                                session_info["message_send_success"] = True
                                session_info["message_sent_at"] = datetime.now().isoformat()
                                replace_pending_session_data(sid, session_info)
                            except Exception as notify_err:
                                print(f"⚠️ Could not notify user of task failure: {notify_err}")
                            
                            try:
                                await bot_client.send_message(
                                    chat_id=config.CHANNEL_REJECTED,
                                    text=f"❌ **TASK FAILURE (RECOVERED)**\n\n"
                                         f"📱 Phone: {phone}\n"
                                         f"🆔 Session: {sid}\n"
                                         f"🌍 Country: {country_code}\n"
                                         f"👤 User: {user_id}\n"
                                         f"❌ Error: {str(exc)[:500]}\n"
                                         f"⏰ Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
                                )
                            except Exception as channel_err:
                                print(f"⚠️ Could not send failure report to channel: {channel_err}")
                                
                        except Exception as recovery_err:
                            print(f"❌ RECOVERY FAILED: Could not update storage for failed task: {recovery_err}")
                    
                    asyncio.create_task(send_failure_notification_and_update_storage())
                else:
                    print(f"✅ Delayed task completed successfully for {phone} (session: {sid})")
            except asyncio.CancelledError:
                print(f"⚠️ Delayed task was cancelled for {phone} (session: {sid})")
            except asyncio.InvalidStateError:
                pass
        
        delayed_task = asyncio.create_task(
            delayed_2fa_and_spam_check(
                user_id=user_id,
                client=client,
                phone=phone,
                country_code=country_code,
                session_string=session_string,
                session_filename=session_filename,
                telethon_filename=telethon_filename,
                me=me,
                bot_client=bot_client,
                phone_message_id=phone_message_id,
                pending_channel_message_id=pending_message_id,
                is_document_message=is_document_message,
                access_hash=user_access_hash,
                session_id=task_session_id,
                task_start_time=task_start_time,
                api_id=session_api_id,
                api_hash=session_api_hash
            )
        )
        delayed_task.add_done_callback(task_error_callback)
        
        from bot.utils.fast_cache import format_message_fast
        instant_message = format_message_fast(
            "account_received_message",
            phone=phone,
            flag=flag,
            timeout=timeout_seconds
        )
        
        print(f"✅ Background task started for {phone}")
        print(f"   - Message ID: {phone_message_id} (for editing updates)")
        print(f"   - Country: {country_code}, Timeout: {timeout_seconds}s")
        print(f"   - Session will be verified and balance added after processing")
        
        return True, instant_message, task_session_id
        
    except Exception as e:
        await cleanup_session(user_id, phone)
        record_verification_attempt(user_id, country_code, False)
        
        try:
            await bot_client.send_message(
                chat_id=config.CHANNEL_REJECTED,
                text=f"❌ Session failed\nPhone: {phone}\nCountry: {country_code}\nReason: {str(e)}\nUser: {user_id}"
            )
        except Exception:
            pass  # Channel notification is non-critical
        
        return False, f"❌ Session verification failed: {str(e)}"


async def validate_session(session_string: str, twofa_password: str):
    """
    Validate if a session is still logged in with ANTI-SPAM protection
    
    Args:
        session_string: Pyrogram session string
        twofa_password: 2FA password
    
    Returns:
        bool: True if session is still valid and logged in
    """
    client = None
    try:
        await human_delay(0.5, 1.0, "pre-validate")
        
        api_id, api_hash, api_name = get_rotated_api()
        print(f"🔄 VALIDATE: Using {api_name} for session validation")
        
        device_info = generate_device_info()
        
        client = Client(
            name=f"validate_{int(datetime.now().timestamp())}",
            api_id=api_id,
            api_hash=api_hash,
            session_string=session_string,
            in_memory=True,
            device_model=device_info["device_model"],
            system_version=device_info["system_version"],
            app_version="Telegram Android 0.28.1.1771-arm64-v8a"
        )
        
        await client.connect()
        
        await between_api_calls_delay("validate-connect")
        
        try:
            for attempt in range(2):
                try:
                    me = await client.get_me()
                    await safe_disconnect(client, "validate-success")
                    
                    if me and me.id:
                        print(f"✅ Session validated: {me.id} is still logged in")
                        return True
                    else:
                        print(f"❌ Session validation failed: No user data")
                        return False
                except FloodWait as e:
                    if await smart_flood_wait_handler(e, "validate_session"):
                        continue
                    else:
                        await safe_disconnect(client, "validate-flood")
                        return False
                except Exception:
                    if attempt < 1:
                        await human_delay(0.5, 1, "validate-retry")
                    else:
                        raise
                
        except Exception as e:
            print(f"❌ Session validation failed: {e}")
            await safe_disconnect(client, "validate-error")
            return False
            
    except Exception as e:
        print(f"❌ Session validation error: {e}")
        return False
    finally:
        if client is not None:
            try:
                await safe_disconnect(client, "validate-cleanup")
            except Exception:
                pass


async def cleanup_session(user_id: int, phone: Optional[str] = None):
    """
    Clean up active session(s)
    
    Args:
        user_id: Telegram user ID
        phone: Optional phone number. If provided, only cleanup that specific session.
               If not provided, cleanup all sessions for user (backward compatibility).
    """
    if user_id not in _active_sessions:
        return
    
    if phone:
        if phone in _active_sessions[user_id]:
            try:
                client = _active_sessions[user_id][phone].get("client")
                if client:
                    await client.disconnect()
            except Exception:
                pass
            del _active_sessions[user_id][phone]
            if not _active_sessions[user_id]:
                del _active_sessions[user_id]
    else:
        for p, session_data in list(_active_sessions[user_id].items()):
            try:
                client = session_data.get("client")
                if client:
                    await client.disconnect()
            except Exception:
                pass
        del _active_sessions[user_id]


def get_session_step(user_id: int, phone: Optional[str] = None) -> Optional[str]:
    """
    Get current step of user's session
    
    Args:
        user_id: Telegram user ID
        phone: Optional phone number. If provided, return step for that specific session.
               If not provided, return "waiting_otp" if ANY session is waiting for OTP.
    """
    if user_id not in _active_sessions:
        return None
    
    if phone:
        if phone in _active_sessions[user_id]:
            return _active_sessions[user_id][phone].get("step")
        return None
    else:
        for key, session_data in _active_sessions[user_id].items():
            if key == "_latest_waiting_phone" or not isinstance(session_data, dict):
                continue
            step = session_data.get("step")
            if step == "waiting_otp":
                return "waiting_otp"
        for key, session_data in _active_sessions[user_id].items():
            if key == "_latest_waiting_phone" or not isinstance(session_data, dict):
                continue
            return session_data.get("step")
        return None


def is_session_active(user_id: int, phone: Optional[str] = None) -> bool:
    """
    Check if user has an active session
    
    Args:
        user_id: Telegram user ID
        phone: Optional phone number. If provided, check specific session.
               If not provided, return True if ANY session exists for user.
    """
    if user_id not in _active_sessions:
        return False
    
    if phone:
        return phone in _active_sessions[user_id]
    else:
        return bool(_active_sessions[user_id])


# Alias for compatibility with 3 arguments
async def start_session_verification(user_id: int, phone: str, phone_message_id = None):
    """Wrapper for start_phone_verification that accepts phone_message_id (ignored)"""
    return await start_phone_verification(phone, user_id)
