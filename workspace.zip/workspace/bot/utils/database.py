"""
Database Module - SQLite Only
=============================
File-based SQLite via aiosqlite - no external server needed.

Features:
- Async SQLite via aiosqlite
- Full schema: users, sessions, pending_sessions, transaction_logs,
  admin_logs, failed_verifications, withdrawal_logs, session_analytics, bot_metrics
"""

import os
import logging
from datetime import datetime
from typing import Dict, Any, Optional, List, Union
import json

logger = logging.getLogger(__name__)

DB_PATH = os.environ.get("SQLITE_DB_PATH", "data/bot_data.db")

_sqlite_db: Any = None

_BACKEND = "sqlite"
_initialized = False


# ============================================================
# SQLite Schema
# ============================================================

SQLITE_SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    user_id INTEGER PRIMARY KEY,
    balance REAL DEFAULT 0,
    sessions INTEGER DEFAULT 0,
    banned INTEGER DEFAULT 0,
    joined TEXT DEFAULT (datetime('now')),
    success_count INTEGER DEFAULT 0,
    channel_joined INTEGER DEFAULT 0,
    data TEXT DEFAULT '{}',
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT UNIQUE NOT NULL,
    user_id INTEGER NOT NULL,
    phone TEXT,
    country_code TEXT,
    spam_status TEXT,
    session_string TEXT,
    data TEXT DEFAULT '{}',
    verified_at TEXT DEFAULT (datetime('now')),
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS pending_sessions (
    session_id TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL,
    phone TEXT,
    country_code TEXT,
    status TEXT DEFAULT 'pending',
    data TEXT DEFAULT '{}',
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS transaction_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    session_id TEXT,
    action TEXT,
    amount REAL,
    country_code TEXT,
    phone_number TEXT,
    spam_status TEXT,
    details TEXT DEFAULT '{}',
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS admin_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    admin_id INTEGER,
    action TEXT,
    target_user_id INTEGER,
    details TEXT DEFAULT '{}',
    message TEXT,
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS failed_verifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    phone_number TEXT,
    country_code TEXT,
    reason TEXT,
    error_type TEXT,
    details TEXT DEFAULT '{}',
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS withdrawal_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    method TEXT,
    amount REAL,
    wallet_address TEXT,
    status TEXT DEFAULT 'pending',
    processed_by INTEGER,
    processed_at TEXT,
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS session_analytics (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    date TEXT DEFAULT (date('now')),
    country_code TEXT,
    total_sessions INTEGER DEFAULT 0,
    successful_sessions INTEGER DEFAULT 0,
    failed_sessions INTEGER DEFAULT 0,
    total_earnings REAL DEFAULT 0,
    avg_spam_score REAL,
    updated_at TEXT DEFAULT (datetime('now')),
    UNIQUE(date, country_code)
);

CREATE TABLE IF NOT EXISTS bot_metrics (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    metric_name TEXT,
    metric_value REAL,
    metric_type TEXT,
    recorded_at TEXT DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_users_banned ON users(banned);
CREATE INDEX IF NOT EXISTS idx_users_channel_joined ON users(channel_joined);
CREATE INDEX IF NOT EXISTS idx_users_created ON users(created_at);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_sessions_country ON sessions(country_code);
CREATE INDEX IF NOT EXISTS idx_sessions_verified ON sessions(verified_at);
CREATE INDEX IF NOT EXISTS idx_pending_user ON pending_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_pending_status ON pending_sessions(status);
CREATE INDEX IF NOT EXISTS idx_pending_created ON pending_sessions(created_at);
CREATE INDEX IF NOT EXISTS idx_transaction_logs_user ON transaction_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_transaction_logs_created ON transaction_logs(created_at);
CREATE INDEX IF NOT EXISTS idx_transaction_logs_country ON transaction_logs(country_code);
CREATE INDEX IF NOT EXISTS idx_admin_logs_admin ON admin_logs(admin_id);
CREATE INDEX IF NOT EXISTS idx_admin_logs_created ON admin_logs(created_at);
CREATE INDEX IF NOT EXISTS idx_failed_verifications_user ON failed_verifications(user_id);
CREATE INDEX IF NOT EXISTS idx_withdrawal_logs_user ON withdrawal_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_withdrawal_logs_status ON withdrawal_logs(status);
CREATE INDEX IF NOT EXISTS idx_session_analytics_date ON session_analytics(date);
CREATE INDEX IF NOT EXISTS idx_session_analytics_country ON session_analytics(country_code);
"""


# ============================================================
# SQLite Helper Functions
# ============================================================

def _ensure_db_dir():
    os.makedirs(os.path.dirname(DB_PATH) or "data", exist_ok=True)


async def _sqlite_execute(sql: str, params: tuple = ()) -> Any:
    if not _sqlite_db:
        return None
    cursor = await _sqlite_db.execute(sql, params)
    await _sqlite_db.commit()
    return cursor


async def _sqlite_fetchone(sql: str, params: tuple = ()) -> Optional[Dict[str, Any]]:
    if not _sqlite_db:
        return None
    cursor = await _sqlite_db.execute(sql, params)
    row = await cursor.fetchone()
    if row is None:
        return None
    return _sqlite_row_to_dict(row, cursor)


async def _sqlite_fetchall(sql: str, params: tuple = ()) -> List[Dict[str, Any]]:
    if not _sqlite_db:
        return []
    cursor = await _sqlite_db.execute(sql, params)
    rows = await cursor.fetchall()
    return [_sqlite_row_to_dict(row, cursor) for row in rows]


def _sqlite_row_to_dict(row: tuple, cursor) -> Dict[str, Any]:
    cols = [desc[0] for desc in cursor.description]
    result = dict(zip(cols, row))
    for key, value in result.items():
        if isinstance(value, str):
            try:
                parsed = json.loads(value)
                if isinstance(parsed, (dict, list)):
                    result[key] = parsed
            except (json.JSONDecodeError, TypeError):
                pass
    return result


# ============================================================
# Initialize / Close
# ============================================================

async def init_database() -> bool:
    global _sqlite_db, _initialized, _BACKEND

    try:
        import aiosqlite
    except ImportError:
        logger.error("aiosqlite not installed - cannot initialize database")
        _BACKEND = None
        _initialized = False
        return False

    try:
        _ensure_db_dir()
        _sqlite_db = await aiosqlite.connect(DB_PATH)
        await _sqlite_db.execute("PRAGMA journal_mode=WAL")
        await _sqlite_db.execute("PRAGMA foreign_keys=ON")
        await _sqlite_db.executescript(SQLITE_SCHEMA)
        await _sqlite_db.commit()
        _BACKEND = "sqlite"
        _initialized = True
        logger.info(f"SQLite database initialized at {DB_PATH}")
        return True
    except Exception as e:
        logger.error(f"SQLite init failed: {e}")
        if _sqlite_db:
            try:
                await _sqlite_db.close()
            except Exception:
                pass
            _sqlite_db = None
        _BACKEND = None
        _initialized = False
        return False


async def close_database() -> None:
    global _sqlite_db, _initialized, _BACKEND
    if _sqlite_db:
        await _sqlite_db.close()
        _sqlite_db = None
        logger.info("SQLite connection closed")
    _initialized = False
    _BACKEND = None if not _initialized else "sqlite"


def is_database_ready() -> bool:
    return _initialized and _BACKEND is not None


def get_backend() -> Optional[str]:
    return _BACKEND


# ============================================================
# Transaction Logging
# ============================================================

async def log_transaction(
    user_id: int,
    action: str,
    amount: float = 0.0,
    session_id: str = "",
    country_code: str = "",
    phone_number: str = "",
    spam_status: str = "",
    details: Optional[Dict] = None
) -> bool:
    if not _initialized:
        return False

    try:
        await _sqlite_execute("""
            INSERT INTO transaction_logs
            (user_id, session_id, action, amount, country_code, phone_number, spam_status, details)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (user_id, session_id, action, amount, country_code, phone_number, spam_status,
              json.dumps(details or {})))
        return True
    except Exception as e:
        logger.error(f"Error logging transaction: {e}")
    return False


# ============================================================
# Admin Action Logging
# ============================================================

async def log_admin_action(
    admin_id: int,
    action: str,
    target_user_id: Optional[int] = None,
    message: str = "",
    details: Optional[Dict] = None
) -> bool:
    if not _initialized:
        return False

    try:
        await _sqlite_execute("""
            INSERT INTO admin_logs (admin_id, action, target_user_id, message, details)
            VALUES (?, ?, ?, ?, ?)
        """, (admin_id, action, target_user_id, message, json.dumps(details or {})))
        return True
    except Exception as e:
        logger.error(f"Error logging admin action: {e}")
    return False


# ============================================================
# Failed Verification Logging
# ============================================================

async def log_failed_verification(
    user_id: int,
    reason: str,
    phone_number: str = "",
    country_code: str = "",
    error_type: str = "",
    details: Optional[Dict] = None
) -> bool:
    if not _initialized:
        return False

    try:
        await _sqlite_execute("""
            INSERT INTO failed_verifications
            (user_id, phone_number, country_code, reason, error_type, details)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (user_id, phone_number, country_code, reason, error_type,
              json.dumps(details or {})))
        return True
    except Exception as e:
        logger.error(f"Error logging failed verification: {e}")
    return False


# ============================================================
# Withdrawal Logging
# ============================================================

async def log_withdrawal(
    user_id: int,
    method: str,
    amount: float,
    wallet_address: str,
    status: str = "pending"
) -> bool:
    if not _initialized:
        return False

    try:
        await _sqlite_execute("""
            INSERT INTO withdrawal_logs (user_id, method, amount, wallet_address, status)
            VALUES (?, ?, ?, ?, ?)
        """, (user_id, method, amount, wallet_address, status))
        return True
    except Exception as e:
        logger.error(f"Error logging withdrawal: {e}")
    return False


# ============================================================
# Session Analytics
# ============================================================

async def update_session_analytics(
    country_code: str,
    successful: bool,
    amount: float = 0.0,
    spam_score: float = 0.0
) -> bool:
    if not _initialized:
        return False

    try:
        await _sqlite_execute("""
            INSERT INTO session_analytics (date, country_code, total_sessions, successful_sessions,
                                           failed_sessions, total_earnings, avg_spam_score)
            VALUES (date('now'), ?, 1, ?, ?, ?, ?)
            ON CONFLICT (date, country_code) DO UPDATE SET
                total_sessions = session_analytics.total_sessions + 1,
                successful_sessions = session_analytics.successful_sessions + ?,
                failed_sessions = session_analytics.failed_sessions + ?,
                total_earnings = session_analytics.total_earnings + ?,
                avg_spam_score = (session_analytics.avg_spam_score + ?) / 2,
                updated_at = datetime('now')
        """, (country_code, 1 if successful else 0, 0 if successful else 1, amount, spam_score,
              1 if successful else 0, 0 if successful else 1, amount, spam_score))
        return True
    except Exception as e:
        logger.error(f"Error updating session analytics: {e}")
    return False


async def record_metric(metric_name: str, metric_value: float, metric_type: str = "gauge") -> bool:
    if not _initialized:
        return False

    try:
        await _sqlite_execute("""
            INSERT INTO bot_metrics (metric_name, metric_value, metric_type)
            VALUES (?, ?, ?)
        """, (metric_name, metric_value, metric_type))
        return True
    except Exception as e:
        logger.error(f"Error recording metric: {e}")
    return False


# ============================================================
# Query Functions - Transactions
# ============================================================

async def get_recent_transactions(limit: int = 50) -> List[Dict[str, Any]]:
    if not _initialized:
        return []

    try:
        return await _sqlite_fetchall("""
            SELECT * FROM transaction_logs
            ORDER BY created_at DESC
            LIMIT ?
        """, (limit,))
    except Exception as e:
        logger.error(f"Error getting transactions: {e}")
    return []


async def get_recent_admin_logs(limit: int = 50) -> List[Dict[str, Any]]:
    if not _initialized:
        return []

    try:
        return await _sqlite_fetchall("""
            SELECT * FROM admin_logs
            ORDER BY created_at DESC
            LIMIT ?
        """, (limit,))
    except Exception as e:
        logger.error(f"Error getting admin logs: {e}")
    return []


async def get_failed_verifications(limit: int = 50) -> List[Dict[str, Any]]:
    if not _initialized:
        return []

    try:
        return await _sqlite_fetchall("""
            SELECT * FROM failed_verifications
            ORDER BY created_at DESC
            LIMIT ?
        """, (limit,))
    except Exception as e:
        logger.error(f"Error getting failed verifications: {e}")
    return []


async def get_pending_withdrawals() -> List[Dict[str, Any]]:
    if not _initialized:
        return []

    try:
        return await _sqlite_fetchall("""
            SELECT * FROM withdrawal_logs
            WHERE status = 'pending'
            ORDER BY created_at DESC
        """)
    except Exception as e:
        logger.error(f"Error getting pending withdrawals: {e}")
    return []


# ============================================================
# Query Functions - Statistics
# ============================================================

async def get_daily_stats(days: int = 7) -> List[Dict[str, Any]]:
    if not _initialized:
        return []

    try:
        return await _sqlite_fetchall("""
            SELECT
                date,
                SUM(total_sessions) as total_sessions,
                SUM(successful_sessions) as successful_sessions,
                SUM(failed_sessions) as failed_sessions,
                SUM(total_earnings) as total_earnings
            FROM session_analytics
            WHERE date >= date('now', ?)
            GROUP BY date
            ORDER BY date DESC
        """, (f"-{days} days",))
    except Exception as e:
        logger.error(f"Error getting daily stats: {e}")
    return []


async def get_country_stats() -> List[Dict[str, Any]]:
    if not _initialized:
        return []

    try:
        return await _sqlite_fetchall("""
            SELECT
                country_code,
                SUM(total_sessions) as total_sessions,
                SUM(successful_sessions) as successful_sessions,
                SUM(total_earnings) as total_earnings,
                AVG(avg_spam_score) as avg_spam_score
            FROM session_analytics
            GROUP BY country_code
            ORDER BY total_earnings DESC
        """)
    except Exception as e:
        logger.error(f"Error getting country stats: {e}")
    return []


async def get_time_range_stats(days: int = 30) -> List[Dict[str, Any]]:
    if not _initialized:
        return []

    try:
        return await _sqlite_fetchall("""
            SELECT
                date,
                SUM(total_sessions) as total_sessions,
                SUM(successful_sessions) as successful_sessions,
                SUM(failed_sessions) as failed_sessions,
                SUM(total_earnings) as total_earnings,
                AVG(avg_spam_score) as avg_spam_score
            FROM session_analytics
            WHERE date >= date('now', ?)
            GROUP BY date
            ORDER BY date DESC
        """, (f"-{days} days",))
    except Exception as e:
        logger.error(f"Error getting time range stats: {e}")
    return []


# ============================================================
# Query Functions - Users
# ============================================================

async def upsert_user(user_id: int, data: Dict[str, Any]) -> bool:
    if not _initialized:
        return False

    try:
        await _sqlite_execute("""
            INSERT INTO users (user_id, balance, sessions, banned, joined, success_count, channel_joined, data)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT (user_id) DO UPDATE SET
                balance = excluded.balance,
                sessions = excluded.sessions,
                banned = excluded.banned,
                success_count = excluded.success_count,
                channel_joined = excluded.channel_joined,
                data = excluded.data,
                updated_at = datetime('now')
        """, (
            user_id,
            data.get("balance", 0),
            data.get("sessions", 0),
            1 if data.get("banned", False) else 0,
            data.get("joined", datetime.now().isoformat()),
            data.get("success_count", 0),
            1 if data.get("channel_joined", False) else 0,
            json.dumps(data)
        ))
        return True
    except Exception as e:
        logger.error(f"Error upserting user: {e}")
    return False


async def get_user_by_id(user_id: int) -> Optional[Dict[str, Any]]:
    if not _initialized:
        return None

    try:
        return await _sqlite_fetchone("SELECT * FROM users WHERE user_id = ?", (user_id,))
    except Exception as e:
        logger.error(f"Error getting user: {e}")
    return None


async def batch_upsert_users(users: List[Dict[str, Any]]) -> int:
    if not _initialized or not users:
        return 0

    upserted = 0
    try:
        for user in users:
            try:
                await _sqlite_execute("""
                    INSERT INTO users (user_id, balance, sessions, banned, success_count, channel_joined, data)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                    ON CONFLICT (user_id) DO UPDATE SET
                        balance = excluded.balance,
                        sessions = excluded.sessions,
                        banned = excluded.banned,
                        success_count = excluded.success_count,
                        channel_joined = excluded.channel_joined,
                        data = excluded.data,
                        updated_at = datetime('now')
                """, (
                    user.get("user_id"),
                    user.get("balance", 0),
                    user.get("sessions", 0),
                    1 if user.get("banned", False) else 0,
                    user.get("success_count", 0),
                    1 if user.get("channel_joined", False) else 0,
                    json.dumps(user)
                ))
                upserted += 1
            except Exception as e:
                logger.debug(f"Error upserting user {user.get('user_id')}: {e}")
    except Exception as e:
        logger.error(f"Error in batch upsert: {e}")
    return upserted


# ============================================================
# Query Functions - Sessions
# ============================================================

async def upsert_session(session_id: str, data: Dict[str, Any]) -> bool:
    if not _initialized:
        return False

    try:
        await _sqlite_execute("""
            INSERT INTO sessions (session_id, user_id, phone, country_code, spam_status, session_string, data)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT (session_id) DO UPDATE SET
                spam_status = excluded.spam_status,
                session_string = excluded.session_string,
                data = excluded.data
        """, (
            session_id,
            data.get("user_id"),
            data.get("phone", ""),
            data.get("country_code", ""),
            data.get("spam_status", ""),
            data.get("session_string", ""),
            json.dumps(data)
        ))
        return True
    except Exception as e:
        logger.error(f"Error upserting session: {e}")
    return False


async def upsert_pending_session(session_id: str, data: Dict[str, Any]) -> bool:
    if not _initialized:
        return False

    try:
        await _sqlite_execute("""
            INSERT INTO pending_sessions (session_id, user_id, phone, country_code, status, data)
            VALUES (?, ?, ?, ?, ?, ?)
            ON CONFLICT (session_id) DO UPDATE SET
                status = excluded.status,
                data = excluded.data,
                updated_at = datetime('now')
        """, (
            session_id,
            data.get("user_id"),
            data.get("phone", ""),
            data.get("country_code", ""),
            data.get("status", "pending"),
            json.dumps(data)
        ))
        return True
    except Exception as e:
        logger.error(f"Error upserting pending session: {e}")
    return False


async def get_pending_session_by_id(session_id: str) -> Optional[Dict[str, Any]]:
    if not _initialized:
        return None

    try:
        return await _sqlite_fetchone("SELECT * FROM pending_sessions WHERE session_id = ?", (session_id,))
    except Exception as e:
        logger.error(f"Error getting pending session: {e}")
    return None


async def delete_pending_session(session_id: str) -> bool:
    if not _initialized:
        return False

    try:
        await _sqlite_execute("DELETE FROM pending_sessions WHERE session_id = ?", (session_id,))
        return True
    except Exception as e:
        logger.error(f"Error deleting pending session: {e}")
    return False


async def cleanup_old_pending_sessions(hours: int = 24) -> int:
    if not _initialized:
        return 0

    try:
        cursor = await _sqlite_execute("""
            DELETE FROM pending_sessions
            WHERE created_at < datetime('now', ?)
        """, (f"-{hours} hours",))
        count = cursor.rowcount if cursor else 0
        if count > 0:
            logger.info(f"Cleaned up {count} old pending sessions (SQLite)")
        return count
    except Exception as e:
        logger.error(f"Error cleaning up pending sessions: {e}")
    return 0


# ============================================================
# Query Functions - Search & Details
# ============================================================

async def search_users_by_phone(phone_pattern: str, limit: int = 50) -> List[Dict[str, Any]]:
    if not _initialized:
        return []

    try:
        return await _sqlite_fetchall("""
            SELECT DISTINCT
                s.user_id,
                s.phone,
                s.country_code,
                s.session_id,
                'verified' as source
            FROM sessions s
            WHERE s.phone LIKE ?
            UNION
            SELECT DISTINCT
                ps.user_id,
                ps.phone,
                ps.country_code,
                ps.session_id,
                'pending' as source
            FROM pending_sessions ps
            WHERE ps.phone LIKE ?
            LIMIT ?
        """, (f"%{phone_pattern}%", f"%{phone_pattern}%", limit))
    except Exception as e:
        logger.error(f"Error searching users by phone: {e}")
    return []


async def get_session_detail(session_id: str) -> Optional[Dict[str, Any]]:
    if not _initialized:
        return None

    try:
        row = await _sqlite_fetchone("""
            SELECT s.*,
                (SELECT COUNT(*) FROM failed_verifications fv WHERE fv.phone_number = s.phone) as error_count
            FROM sessions s
            WHERE s.session_id = ?
        """, (session_id,))

        if row:
            errors = await _sqlite_fetchall("""
                SELECT * FROM failed_verifications
                WHERE phone_number = ?
                ORDER BY created_at DESC LIMIT 10
            """, (row.get("phone", ""),))
            row["errors"] = errors or []
            txns = await _sqlite_fetchall("""
                SELECT * FROM transaction_logs
                WHERE session_id = ?
                ORDER BY created_at DESC LIMIT 5
            """, (session_id,))
            row["transactions"] = txns or []
            return row

        pending_row = await _sqlite_fetchone("""
            SELECT ps.*,
                (SELECT COUNT(*) FROM failed_verifications fv WHERE fv.phone_number = ps.phone) as error_count
            FROM pending_sessions ps
            WHERE ps.session_id = ?
        """, (session_id,))

        if pending_row:
            pending_row["session_type"] = "pending"
            errors = await _sqlite_fetchall("""
                SELECT * FROM failed_verifications
                WHERE phone_number = ?
                ORDER BY created_at DESC LIMIT 10
            """, (pending_row.get("phone", ""),))
            pending_row["errors"] = errors or []
            return pending_row

    except Exception as e:
        logger.error(f"Error getting session detail: {e}")
    return None


# ============================================================
# Metrics & Health
# ============================================================

async def log_bot_metric(metric_name: str, metric_value: float, metric_type: str = "gauge") -> bool:
    return await record_metric(metric_name, metric_value, metric_type)


async def get_latest_metrics(limit: int = 30) -> List[Dict[str, Any]]:
    if not _initialized:
        return []

    try:
        return await _sqlite_fetchall("""
            SELECT metric_name, metric_value, metric_type, recorded_at
            FROM bot_metrics
            ORDER BY recorded_at DESC
            LIMIT ?
        """, (limit,))
    except Exception as e:
        logger.error(f"Error getting metrics: {e}")
    return []


async def get_hourly_transaction_stats(hours: int = 24) -> List[Dict[str, Any]]:
    if not _initialized:
        return []

    try:
        return await _sqlite_fetchall("""
            SELECT
                strftime('%%Y-%%m-%%d %%H:00:00', created_at) as hour,
                COUNT(*) as total_transactions,
                SUM(CASE WHEN action = 'session_verified' THEN 1 ELSE 0 END) as verified_sessions,
                COALESCE(SUM(amount), 0) as total_amount
            FROM transaction_logs
            WHERE created_at >= datetime('now', ?)
            GROUP BY strftime('%%Y-%%m-%%d %%H', created_at)
            ORDER BY hour DESC
        """, (f"-{hours} hours",))
    except Exception as e:
        logger.error(f"Error getting hourly stats: {e}")
    return []


async def get_user_sessions_count(user_id: int) -> int:
    if not _initialized:
        return 0

    try:
        v_row = await _sqlite_fetchone("SELECT COUNT(*) as cnt FROM sessions WHERE user_id = ?", (user_id,))
        p_row = await _sqlite_fetchone("SELECT COUNT(*) as cnt FROM pending_sessions WHERE user_id = ?", (user_id,))
        v = v_row["cnt"] if v_row else 0
        p = p_row["cnt"] if p_row else 0
        return v + p
    except Exception as e:
        logger.error(f"Error getting user sessions count: {e}")
    return 0


async def get_db_health_stats() -> Dict[str, Any]:
    result = {
        "connected": _initialized,
        "backend": _BACKEND or "none",
        "tables": {},
        "total_size": "N/A",
    }

    if not _initialized:
        return result

    try:
        import os as _os
        file_size = _os.path.getsize(DB_PATH) if _os.path.exists(DB_PATH) else 0
        if file_size > 1024 * 1024:
            result["total_size"] = f"{file_size / (1024*1024):.1f} MB"
        elif file_size > 1024:
            result["total_size"] = f"{file_size / 1024:.1f} KB"
        else:
            result["total_size"] = f"{file_size} bytes"

        tables = ["users", "sessions", "pending_sessions", "transaction_logs",
                  "admin_logs", "failed_verifications", "withdrawal_logs",
                  "session_analytics", "bot_metrics"]
        for table in tables:
            row = await _sqlite_fetchone(f"SELECT COUNT(*) as cnt FROM {table}")
            result["tables"][f"public.{table}"] = {
                "total_size": "N/A",
                "data_size": "N/A",
                "estimated_rows": row["cnt"] if row else 0,
            }
        result["db_file"] = DB_PATH
    except Exception as e:
        logger.error(f"DB health check error: {e}")
        result["error"] = str(e)

    return result


# ============================================================
# Module Load Info
# ============================================================

print(f"Database Module Loaded")
print(f"   Backend: SQLite only")
print(f"   SQLite DB path: {DB_PATH}")
