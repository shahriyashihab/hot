"""
TRUE ROUND-ROBIN API Rotation System v2.0
==========================================
Every verification uses the NEXT API in sequence:
API 1 → API 2 → API 3 → API 4 → API 5 → API 1 → ...

This ensures:
- Even load distribution across ALL APIs
- Minimum freeze rate (each API gets rest time)
- Maximum daily capacity
"""

import threading
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from datetime import datetime, timedelta


@dataclass
class APICredentials:
    """Telegram API credentials with usage tracking"""
    api_id: int
    api_hash: str
    name: str = "default"
    daily_limit: int = 200
    hourly_limit: int = 30
    is_active: bool = True
    
    sessions_today: int = 0
    sessions_this_hour: int = 0
    last_used: Optional[datetime] = None
    last_hour_reset: Optional[datetime] = None
    last_day_reset: Optional[datetime] = None
    
    success_count: int = 0
    fail_count: int = 0
    flood_count: int = 0
    cooldown_until: Optional[datetime] = None
    
    @property
    def success_rate(self) -> float:
        total = self.success_count + self.fail_count
        return self.success_count / total if total > 0 else 1.0
    
    def is_available(self) -> bool:
        """Check if API can be used now"""
        if not self.is_active:
            return False
        if self.cooldown_until and datetime.now() < self.cooldown_until:
            return False
        
        self._reset_counters()
        
        if self.sessions_today >= self.daily_limit:
            return False
        if self.sessions_this_hour >= self.hourly_limit:
            return False
            
        return True
    
    def _reset_counters(self):
        """Reset hourly/daily counters if needed"""
        now = datetime.now()
        
        if self.last_hour_reset is None or (now - self.last_hour_reset).total_seconds() >= 3600:
            self.sessions_this_hour = 0
            self.last_hour_reset = now
            
        if self.last_day_reset is None or self.last_day_reset.date() != now.date():
            self.sessions_today = 0
            self.last_day_reset = now
            
    def record_usage(self, success: bool = True, flood: bool = False):
        """Record API usage"""
        self._reset_counters()
        
        self.sessions_today += 1
        self.sessions_this_hour += 1
        self.last_used = datetime.now()
        
        if success:
            self.success_count += 1
        else:
            self.fail_count += 1
            
        if flood:
            self.flood_count += 1
            cooldown_minutes = min(30, 5 * self.flood_count)
            self.cooldown_until = datetime.now() + timedelta(minutes=cooldown_minutes)
            print(f"⚠️ API {self.name} flood cooldown: {cooldown_minutes} minutes")


class TrueRoundRobinManager:
    """
    TRUE ROUND-ROBIN API Rotation
    ==============================
    GUARANTEED sequence: API 1 → API 2 → API 3 → API 4 → API 5 → API 1 → ...
    
    Benefits:
    - Each API gets equal load
    - Each API gets 4x rest time between uses (with 5 APIs)
    - Minimum freeze rate
    - Maximum throughput
    """
    
    def __init__(self):
        self.apis: List[APICredentials] = []
        self._lock = threading.Lock()
        self._current_index = 0
        self._total_rotations = 0
        self.session_api_map: Dict[str, APICredentials] = {}
        
    def add_api(self, api_id: int, api_hash: str, name: str = None,
                daily_limit: int = 200, hourly_limit: int = 30):
        """Add API credentials to rotation pool"""
        if name is None:
            name = f"api_{len(self.apis) + 1}"
            
        api = APICredentials(
            api_id=api_id,
            api_hash=api_hash,
            name=name,
            daily_limit=daily_limit,
            hourly_limit=hourly_limit
        )
        self.apis.append(api)
        print(f"✅ API added to rotation: {name} (ID: {api_id})")
        
    def add_apis_from_list(self, api_list: List[Tuple[int, str]]):
        """Add multiple APIs from list"""
        for i, (api_id, api_hash) in enumerate(api_list):
            self.add_api(api_id, api_hash, f"api_{i + 1}")
    
    def get_next_api(self) -> Optional[APICredentials]:
        """
        TRUE ROUND-ROBIN: Get the NEXT API in sequence
        Always rotates: 1 → 2 → 3 → 4 → 5 → 1 → 2 → ...
        Skips only if API is in cooldown or at limit
        """
        if not self.apis:
            return None
        
        with self._lock:
            attempts = 0
            total_apis = len(self.apis)
            
            while attempts < total_apis:
                api = self.apis[self._current_index]
                
                self._current_index = (self._current_index + 1) % total_apis
                self._total_rotations += 1
                
                if api.is_available():
                    print(f"🔄 ROUND-ROBIN: Using {api.name} (rotation #{self._total_rotations})")
                    return api
                else:
                    reason = "cooldown" if api.cooldown_until else "limit reached"
                    print(f"⏭️ Skipping {api.name} ({reason}), trying next...")
                
                attempts += 1
            
            print("⚠️ All APIs unavailable!")
            return None
    
    def assign_api_to_session(self, session_id: str) -> Optional[APICredentials]:
        """Assign next API in rotation to a session"""
        api = self.get_next_api()
        if api:
            self.session_api_map[session_id] = api
        return api
        
    def get_session_api(self, session_id: str) -> Optional[APICredentials]:
        """Get API assigned to a session"""
        return self.session_api_map.get(session_id)
        
    def release_session_api(self, session_id: str, success: bool = True, flood: bool = False):
        """Release API from session and record result"""
        api = self.session_api_map.pop(session_id, None)
        if api:
            api.record_usage(success, flood)
            
    def get_current_api_info(self) -> dict:
        """Get info about current rotation state"""
        if not self.apis:
            return {"status": "no_apis"}
        
        current_api = self.apis[self._current_index]
        return {
            "current_index": self._current_index,
            "current_api": current_api.name,
            "current_api_id": current_api.api_id,
            "total_rotations": self._total_rotations,
            "next_api": self.apis[(self._current_index + 1) % len(self.apis)].name
        }
            
    def get_stats(self) -> dict:
        """Get API pool statistics"""
        total = len(self.apis)
        available = sum(1 for a in self.apis if a.is_available())
        
        total_today = sum(a.sessions_today for a in self.apis)
        total_success = sum(a.success_count for a in self.apis)
        total_fail = sum(a.fail_count for a in self.apis)
        
        return {
            "rotation_mode": "TRUE_ROUND_ROBIN",
            "total_apis": total,
            "available_now": available,
            "current_index": self._current_index,
            "total_rotations": self._total_rotations,
            "sessions_today": total_today,
            "total_success": total_success,
            "total_fail": total_fail,
            "overall_success_rate": total_success / (total_success + total_fail) if (total_success + total_fail) > 0 else 0,
            "remaining_capacity": sum(a.daily_limit - a.sessions_today for a in self.apis if a.is_available())
        }
        
    def get_detailed_stats(self) -> List[dict]:
        """Get detailed stats for each API"""
        stats = []
        for i, api in enumerate(self.apis):
            is_current = (i == self._current_index)
            stats.append({
                "name": api.name,
                "api_id": api.api_id,
                "is_current": is_current,
                "is_available": api.is_available(),
                "sessions_today": api.sessions_today,
                "sessions_this_hour": api.sessions_this_hour,
                "daily_limit": api.daily_limit,
                "hourly_limit": api.hourly_limit,
                "success_rate": f"{api.success_rate:.1%}",
                "flood_count": api.flood_count,
                "in_cooldown": api.cooldown_until is not None and datetime.now() < api.cooldown_until,
                "last_used": api.last_used.strftime("%H:%M:%S") if api.last_used else "Never"
            })
        return stats
    
    def get_rotation_visual(self) -> str:
        """Get visual representation of current rotation"""
        if not self.apis:
            return "No APIs configured"
        
        visual = "🔄 API Rotation Status:\n"
        for i, api in enumerate(self.apis):
            marker = "▶️" if i == self._current_index else "  "
            status = "✅" if api.is_available() else "❌"
            visual += f"{marker} {status} {api.name} (today: {api.sessions_today}/{api.daily_limit})\n"
        
        visual += f"\n📊 Total rotations: {self._total_rotations}"
        return visual


APIRotationManager = TrueRoundRobinManager

_api_manager: Optional[TrueRoundRobinManager] = None


def get_api_manager() -> TrueRoundRobinManager:
    """Get or create global API manager"""
    global _api_manager
    if _api_manager is None:
        _api_manager = TrueRoundRobinManager()
        _auto_load_extra_apis(_api_manager)
    return _api_manager


def _auto_load_extra_apis(manager: TrueRoundRobinManager):
    """Automatically load extra APIs from config"""
    try:
        from bot.config import EXTRA_APIS
        if EXTRA_APIS:
            for i, (api_id, api_hash) in enumerate(EXTRA_APIS):
                manager.add_api(
                    api_id=api_id,
                    api_hash=api_hash,
                    name=f"API_{i+1}",
                    daily_limit=200,
                    hourly_limit=30
                )
            print(f"✅ Loaded {len(EXTRA_APIS)} APIs for TRUE ROUND-ROBIN rotation")
    except ImportError:
        pass
    except Exception as e:
        print(f"⚠️ Error loading extra APIs: {e}")


def init_api_manager(api_list: List[Tuple[int, str]] = None) -> TrueRoundRobinManager:
    """Initialize API manager with credentials"""
    manager = get_api_manager()
    
    if api_list:
        manager.add_apis_from_list(api_list)
        
    return manager


print("🔄 TRUE ROUND-ROBIN API Rotation System v2.0 loaded")
print("   Sequence: API 1 → API 2 → API 3 → API 4 → API 5 → API 1 → ...")
print("   Benefits: Even load, Maximum rest time, Minimum freeze rate")
