"""
Storage Module - JSON-based persistent storage with thread-safe operations.
===========================================================================
Provides user management, session handling, and transaction logging.

Features:
- Thread-safe file operations with RLock (reentrant)
- Debounced saves for performance
- Automatic migration of storage schema
- Balance credit atomicity
- Optional encryption for sensitive data
- Data retention policy support
"""

import json
import os
import logging
import threading
import base64
import hashlib
import atexit
from datetime import datetime, timedelta
from typing import Dict, Any, Optional, List, Union
from functools import wraps

from bot import config

logger = logging.getLogger(__name__)

STORAGE_FILE = "data/storage.json"
RETENTION_DAYS = 30

_storage: Dict[str, Any] = {
    "users": {},
    "countries": {},
    "withdrawals": [],
    "admin_logs": [],
    "failed_verifications": [],
    "transaction_logs": [],
    "pending_sessions": {},
    "maintenance": False,
    "required_channel": ""
}

_save_pending = False
_storage_lock = threading.RLock()
_save_lock = threading.Lock()
_balance_credit_lock = threading.Lock()
_session_finalization_lock = threading.Lock()
_save_timer: Optional[threading.Timer] = None


def thread_safe(func):
    """Decorator to make storage operations thread-safe."""
    @wraps(func)
    def wrapper(*args, **kwargs):
        with _storage_lock:
            return func(*args, **kwargs)
    return wrapper


_fernet_instance = None


def _get_fernet() -> Optional[Any]:
    """Get Fernet instance for encryption if key is available."""
    global _fernet_instance
    if _fernet_instance is not None:
        return _fernet_instance
    
    key = os.getenv("STORAGE_ENCRYPTION_KEY")
    if not key:
        return None
    
    try:
        from cryptography.fernet import Fernet
        derived_key = base64.urlsafe_b64encode(hashlib.sha256(key.encode()).digest())
        _fernet_instance = Fernet(derived_key)
        return _fernet_instance
    except ImportError:
        logger.warning("cryptography not installed - encryption disabled")
        return None
    except Exception as e:
        logger.error(f"Fernet init error: {e}")
        return None


def _encrypt_value(value: str) -> str:
    """Encrypt sensitive values using Fernet (AES-128-CBC with HMAC)."""
    fernet = _get_fernet()
    if not fernet:
        return value
    try:
        encrypted = fernet.encrypt(value.encode())
        return encrypted.decode()
    except Exception as e:
        logger.error(f"Encryption error: {e}")
        return value


def _decrypt_value(value: str) -> str:
    """Decrypt sensitive values using Fernet."""
    fernet = _get_fernet()
    if not fernet:
        return value
    try:
        decrypted = fernet.decrypt(value.encode())
        return decrypted.decode()
    except Exception as e:
        logger.error(f"Decryption error: {e}")
        return value


def _clean_storage_for_save(data, _seen=None, _depth=0):
    """Recursively clean storage data to remove non-serializable objects.
    
    Features:
    - Circular reference detection via _seen set
    - Maximum depth limit (50) to prevent stack overflow
    - Safe handling for high-concurrency (200-300 users)
    """
    MAX_DEPTH = 50
    
    if _depth > MAX_DEPTH:
        return "[MAX_DEPTH_EXCEEDED]"
    
    if _seen is None:
        _seen = set()
    
    obj_id = id(data)
    if obj_id in _seen:
        return "[CIRCULAR_REF]"
    
    if isinstance(data, dict):
        _seen.add(obj_id)
        cleaned = {}
        for key, value in data.items():
            try:
                cleaned[str(key)] = _clean_storage_for_save(value, _seen, _depth + 1)
            except (TypeError, ValueError, RecursionError):
                cleaned[str(key)] = "[UNSERIALIZABLE]"
        _seen.discard(obj_id)
        return cleaned
    elif isinstance(data, (list, tuple)):
        _seen.add(obj_id)
        cleaned = []
        for item in data:
            try:
                cleaned.append(_clean_storage_for_save(item, _seen, _depth + 1))
            except (TypeError, ValueError, RecursionError):
                cleaned.append("[UNSERIALIZABLE]")
        _seen.discard(obj_id)
        return cleaned
    elif isinstance(data, (str, int, float, bool, type(None))):
        return data
    elif isinstance(data, datetime):
        return data.isoformat()
    else:
        try:
            return str(data)
        except Exception:
            return "[UNSERIALIZABLE]"


def _do_save() -> bool:
    """Actually perform the save operation with atomic write.
    
    Features:
    - Atomic write with temp file
    - RecursionError protection
    - High-concurrency safe (200-300 users)
    
    Returns: True if save succeeded, False otherwise
    """
    global _save_pending
    with _storage_lock:
        success = False
        try:
            os.makedirs(os.path.dirname(STORAGE_FILE), exist_ok=True)
            temp_file = STORAGE_FILE + ".tmp"

            try:
                _2fa_password = _storage.pop("_2fa_password_persistent", None)
                clean_data = _clean_storage_for_save(_storage)
            except RecursionError:
                logger.warning("RecursionError during clean - using fallback save")
                clean_data = json.loads(json.dumps(_storage, default=str))
                _2fa_password = None
            finally:
                if _2fa_password is not None:
                    _storage["_2fa_password_persistent"] = _2fa_password

            with open(temp_file, 'w', encoding='utf-8') as f:
                json.dump(clean_data, f, ensure_ascii=False, indent=2, default=str)
            os.replace(temp_file, STORAGE_FILE)
            success = True
        except RecursionError as e:
            logger.error(f"Storage save RecursionError: {e}")
        except OSError as e:
            logger.error(f"Storage save error (OS): {e}")
        except Exception as e:
            logger.error(f"Storage save error: {e}")
        finally:
            _save_pending = False
        return success


def load_storage() -> None:
    """Load storage from file with automatic schema migration."""
    global _storage
    with _storage_lock:
        if os.path.exists(STORAGE_FILE):
            try:
                with open(STORAGE_FILE, 'r', encoding='utf-8') as f:
                    loaded_data = json.load(f)
                    if loaded_data:
                        _storage = loaded_data
                        
                        if "pending_sessions" not in _storage:
                            _storage["pending_sessions"] = {}
                            logger.info("Migrated storage: added pending_sessions key")
                        
                        if "maintenance" not in _storage:
                            _storage["maintenance"] = False
                        
                        if "required_channel" not in _storage:
                            _storage["required_channel"] = ""

                        save_storage()
            except json.JSONDecodeError as e:
                logger.warning(f"Error loading storage.json: {e}. Using default storage.")
            except Exception as e:
                logger.warning(f"Unexpected error loading storage: {e}. Using default storage.")


def save_storage(immediate: bool = False) -> None:
    """Save storage to file - debounced for speed (saves after 0.5s delay).
    
    On shutdown, call save_storage_now() or use immediate=True to force an
    instant write. An atexit handler is registered for best-effort flush.
    """
    global _save_pending, _save_timer
    
    if immediate:
        _do_save()
        return
    
    with _save_lock:
        if _save_pending:
            return
        _save_pending = True
        
        if _save_timer:
            _save_timer.cancel()
        
        _save_timer = threading.Timer(0.5, _do_save)
        _save_timer.daemon = True
        _save_timer.start()


def save_storage_now() -> None:
    """Force immediate save - use for critical operations."""
    _do_save()


def _flush_pending_save():
    """Flush any pending save on shutdown."""
    global _save_pending, _save_timer
    if _save_pending:
        if _save_timer:
            _save_timer.cancel()
            _save_timer = None
        _do_save()


atexit.register(_flush_pending_save)


load_storage()


def cleanup_old_data(days: int = RETENTION_DAYS) -> int:
    """
    Clean up data older than specified days.
    Returns number of items cleaned.
    """
    cleaned = 0
    cutoff = datetime.now() - timedelta(days=days)
    
    with _storage_lock:
        old_count = len(_storage.get("transaction_logs", []))
        _storage["transaction_logs"] = [
            log for log in _storage.get("transaction_logs", [])
            if _parse_date(log.get("timestamp")) > cutoff
        ]
        cleaned += old_count - len(_storage["transaction_logs"])
        
        old_count = len(_storage.get("failed_verifications", []))
        _storage["failed_verifications"] = [
            v for v in _storage.get("failed_verifications", [])
            if _parse_date(v.get("timestamp")) > cutoff
        ]
        cleaned += old_count - len(_storage["failed_verifications"])
        
        old_count = len(_storage.get("admin_logs", []))
        _storage["admin_logs"] = [
            log for log in _storage.get("admin_logs", [])
            if _parse_date(log.get("timestamp")) > cutoff
        ]
        cleaned += old_count - len(_storage["admin_logs"])
        
        if cleaned > 0:
            save_storage()
            logger.info(f"Cleaned up {cleaned} old data entries (>{days} days)")
    
    return cleaned


def _parse_date(date_str: Optional[str]) -> datetime:
    """Parse ISO date string, return epoch if invalid."""
    if not date_str:
        return datetime.min
    try:
        return datetime.fromisoformat(date_str)
    except (ValueError, TypeError):
        return datetime.min


@thread_safe
def get_user_info(user_id, create_if_missing: bool = True) -> Dict[str, Any]:
    """Get user information with thread-safe access.
    
    Args:
        user_id: The user ID to look up
        create_if_missing: If True, create a default user record if not found.
                          If False, return empty dict for unknown users.
    """
    user_id = str(user_id)
    if user_id not in _storage["users"]:
        if create_if_missing:
            _storage["users"][user_id] = {
                "balance": 0,
                "sessions": 0,
                "banned": False,
                "joined": datetime.now().isoformat(),
                "success_count": 0,
                "channel_joined": False
            }
            save_storage()
        else:
            return {}
    return _storage["users"].get(user_id, {})


@thread_safe
def update_user_info(user_id, **kwargs) -> None:
    """Update user information with thread-safe access."""
    user_id = str(user_id)
    if user_id not in _storage["users"]:
        get_user_info(user_id)
    _storage["users"][user_id].update(kwargs)
    save_storage()


@thread_safe
def get_all_users() -> List[str]:
    """Get list of all user IDs."""
    return list(_storage["users"].keys())


@thread_safe
def ban_user(user_id) -> None:
    """Ban a user."""
    update_user_info(user_id, banned=True)


@thread_safe
def unban_user(user_id) -> None:
    """Unban a user."""
    update_user_info(user_id, banned=False)


@thread_safe
def is_user_banned(user_id) -> bool:
    """Check if user is banned."""
    user = get_user_info(user_id)
    return user.get("banned", False)


@thread_safe
def delete_user(user_id) -> None:
    """Delete a user."""
    user_id = str(user_id)
    if user_id in _storage["users"]:
        del _storage["users"][user_id]
        save_storage()


@thread_safe
def add_balance_for_user(user_id, amount: float) -> None:
    """Add or subtract balance from user."""
    user = get_user_info(user_id)
    current = user.get("balance", 0)
    update_user_info(user_id, balance=current + amount)
    
    try:
        from bot.utils.fast_cache import invalidate_user_cache
        invalidate_user_cache(int(user_id))
    except (ImportError, ValueError, TypeError):
        pass


def atomic_credit_balance_for_session(session_id: str, user_id: Union[int, str], amount: float) -> bool:
    """
    Atomically credit balance for a session.
    
    Args:
        session_id: The session identifier
        user_id: The user to credit balance to
        amount: The amount to credit
        
    Returns:
        True if balance was credited, False if already credited or session not found
    """
    with _balance_credit_lock:
        with _storage_lock:
            pending = _storage.get("pending_sessions", {}).get(session_id)
            if not pending:
                logger.warning(f"ATOMIC CREDIT: Session {session_id} not found")
                return False
            
            if pending.get("balance_credited", False):
                logger.debug(f"ATOMIC CREDIT: Balance already credited for session {session_id}")
                return False
            
            current_status = pending.get("status", "pending")
            if current_status in ("expired", "rejected"):
                logger.warning(f"ATOMIC CREDIT: Session {session_id} already {current_status} - refusing credit")
                return False
            
            pending["balance_credited"] = True
            pending["status"] = "approved"
            
            user_id = str(user_id)
            if user_id not in _storage["users"]:
                get_user_info(user_id)
            
            current_balance = _storage["users"][user_id].get("balance", 0)
            _storage["users"][user_id]["balance"] = current_balance + amount
            
            current_sessions = _storage["users"][user_id].get("sessions", 0)
            _storage["users"][user_id]["sessions"] = current_sessions + 1
            
            country_code = pending.get("country_code")
            if not country_code:
                from bot.utils.country_data import get_country_code_from_phone
                session_info = pending.get("session_data", {})
                phone = session_info.get("phone", "") or pending.get("phone", "")
                if phone:
                    clean_phone = phone.replace("*", "").replace("-", "").replace(" ", "")
                    country_code = get_country_code_from_phone(clean_phone)
            
            if "country_sessions" not in _storage["users"][user_id]:
                _storage["users"][user_id]["country_sessions"] = {}
            country_sessions = _storage["users"][user_id]["country_sessions"]
            final_country = country_code if country_code else "other"
            country_sessions[final_country] = country_sessions.get(final_country, 0) + 1
            
            if "session_tracker" not in _storage:
                _storage["session_tracker"] = {}
            if user_id not in _storage["session_tracker"]:
                _storage["session_tracker"][user_id] = []
            
            phone = pending.get("phone", "")
            spam_status = pending.get("spam_status", "unknown")
            session_info = pending.get("session_data", {})
            
            _storage["session_tracker"][user_id].append({
                "session_id": session_id,
                "phone": phone,
                "country_code": final_country,
                "amount": amount,
                "spam_status": spam_status,
                "verified_at": datetime.now().isoformat(),
                "is_fake": session_info.get("spam_status_details", {}).get("is_fake", False),
                "is_scam": session_info.get("spam_status_details", {}).get("is_scam", False),
                "is_premium": session_info.get("spam_status_details", {}).get("is_premium", False)
            })

            save_success = _do_save()
            if not save_success:
                logger.warning(f"ATOMIC CREDIT: Save failed for session {session_id} - balance credited in memory only")

            logger.info(f"ATOMIC CREDIT: ${amount} credited to user {user_id} for session {session_id} (country: {country_code}, saved: {save_success})")
            logger.info(f"SESSION TRACKER: Added session {session_id} for user {user_id}")
            return True


def try_claim_session_finalization(session_id: str) -> bool:
    """
    Atomically try to claim the right to finalize a session (send final message).
    
    This prevents duplicate message sending from delayed_task and monitor.
    Uses threading lock for thread-safety.
    
    Args:
        session_id: The session identifier to claim
        
    Returns:
        True if this caller got the claim, False if already claimed
    """
    with _session_finalization_lock:
        with _storage_lock:
            pending = _storage.get("pending_sessions", {}).get(session_id)
            if not pending:
                logger.warning(f"FINALIZATION: Session {session_id} not found")
                return False
            
            session_data = pending.get("session_data", {})
            
            if session_data.get("finalization_claimed", False):
                claimed_by = session_data.get("finalization_claimed_by", "unknown")
                logger.debug(f"FINALIZATION: Session {session_id} already claimed by {claimed_by}")
                return False
            
            if session_data.get("message_send_success", False):
                logger.debug(f"FINALIZATION: Session {session_id} message already sent")
                return False
            
            session_data["finalization_claimed"] = True
            session_data["finalization_claimed_at"] = datetime.now().isoformat()
            pending["session_data"] = session_data
            
            _do_save()
            
            logger.info(f"FINALIZATION: Session {session_id} claimed successfully")
            return True


def mark_session_finalization_claimed_by(session_id: str, claimed_by: str) -> None:
    """Mark who claimed the finalization (for debugging)."""
    with _session_finalization_lock:
        with _storage_lock:
            pending = _storage.get("pending_sessions", {}).get(session_id)
            if pending:
                session_data = pending.get("session_data", {})
                session_data["finalization_claimed_by"] = claimed_by
                pending["session_data"] = session_data
                _do_save()


def mark_session_message_sent(session_id: str, success: bool = True) -> bool:
    """
    Atomically mark that the session's final message was sent.
    This prevents any other code path from trying to send again.
    
    Args:
        session_id: The session identifier
        success: Whether the message was sent successfully
        
    Returns:
        True if marked successfully, False if session not found
    """
    with _session_finalization_lock:
        with _storage_lock:
            pending = _storage.get("pending_sessions", {}).get(session_id)
            if not pending:
                return False
            
            session_data = pending.get("session_data", {})
            session_data["message_send_success"] = success
            session_data["message_sent_at"] = datetime.now().isoformat()
            pending["session_data"] = session_data
            
            _do_save()
            
            logger.debug(f"FINALIZATION: Session {session_id} message_send_success={success}")
            return True


@thread_safe
def is_session_message_already_sent(session_id: str) -> bool:
    """Check if session's final message was already sent."""
    pending = _storage.get("pending_sessions", {}).get(session_id)
    if not pending:
        return True
    session_data = pending.get("session_data", {})
    return session_data.get("message_send_success", False)


@thread_safe
def is_session_finalization_claimed(session_id: str) -> bool:
    """Check if session finalization is already claimed by someone."""
    pending = _storage.get("pending_sessions", {}).get(session_id)
    if not pending:
        return True
    session_data = pending.get("session_data", {})
    return session_data.get("finalization_claimed", False)


@thread_safe
def get_open_countries() -> List[str]:
    """Get list of open countries."""
    return [code for code, data in _storage["countries"].items() if data.get("open", True)]


def get_country_fallback_chain(country_code: str) -> List[str]:
    """
    Get fallback chain for a country code.
    Creates a progressive fallback from most specific to least specific.
    """
    if not country_code or not country_code.startswith('+'):
        return [country_code] if country_code else []
    
    fallback_chain = [country_code]
    
    if country_code.startswith('+1') and len(country_code) > 2:
        fallback_chain.append('+1')
    elif country_code.startswith('+7') and len(country_code) > 2:
        fallback_chain.append('+7')
    elif country_code.startswith('+262') and len(country_code) > 4:
        fallback_chain.append('+262')
    elif country_code.startswith('+590') and len(country_code) > 4:
        fallback_chain.append('+590')
    elif country_code.startswith('+599') and len(country_code) > 4:
        fallback_chain.append('+599')
    elif country_code.startswith('+44') and len(country_code) > 3:
        fallback_chain.append('+44')
    elif country_code.startswith('+672') and len(country_code) > 4:
        fallback_chain.append('+672')
        fallback_chain.append('+61')
    elif country_code.startswith('+61') and len(country_code) > 3:
        fallback_chain.append('+61')
    elif country_code.startswith('+358') and len(country_code) > 4:
        fallback_chain.append('+358')
    elif len(country_code) > 3:
        for i in range(len(country_code) - 1, 2, -1):
            shorter = country_code[:i]
            if shorter not in fallback_chain:
                fallback_chain.append(shorter)
    
    return fallback_chain


@thread_safe
def find_country_data_with_fallback(country_code: str):
    """
    Find country data using fallback chain.
    
    Args:
        country_code: Country code like +1829
    
    Returns:
        tuple: (matched_code, country_data) or (None, None) if not found
    """
    fallback_chain = get_country_fallback_chain(country_code)
    
    for code in fallback_chain:
        if code in _storage["countries"]:
            return code, _storage["countries"][code]
    
    return None, None


@thread_safe
def is_country_open(country_code: str) -> bool:
    """Check if a country is open."""
    matched_code, country_data = find_country_data_with_fallback(country_code)
    if country_data:
        return country_data.get("open", False)
    return False


def validate_rate(rate) -> float:
    """Validate and sanitize rate value."""
    try:
        rate = float(rate)
        if rate < 0:
            return 0.0
        if rate > 10000:
            return 10000.0
        return round(rate, 2)
    except (TypeError, ValueError):
        return 0.0


def validate_rates_hierarchy(spam_free_rate, spam_rate, limit_rate):
    """Validate rate hierarchy (spam_free >= spam >= limit)."""
    spam_free_rate = validate_rate(spam_free_rate)
    spam_rate = validate_rate(spam_rate)
    limit_rate = validate_rate(limit_rate)
    
    if spam_rate > spam_free_rate:
        spam_rate = spam_free_rate
    if limit_rate > spam_rate:
        limit_rate = spam_rate
        
    return spam_free_rate, spam_rate, limit_rate


@thread_safe
def get_country_rate(country_code: str, account_status: str = "spam_free") -> float:
    """Get rate for a country based on account status."""
    matched_code, country_data = find_country_data_with_fallback(country_code)
    
    if not country_data:
        country_data = {}
    
    if account_status == "spam":
        rate = country_data.get("spam_rate", country_data.get("rate", 0.0))
    elif account_status == "limit":
        rate = country_data.get("limit_rate", country_data.get("rate", 0.0))
    else:
        rate = country_data.get("spam_free_rate", country_data.get("rate", 0.0))
    
    return validate_rate(rate)


@thread_safe
def get_country_rates(country_code: str) -> Dict[str, float]:
    """Get all rates for a country (spam_free, spam, limit)."""
    matched_code, country_data = find_country_data_with_fallback(country_code)
    
    if not country_data:
        country_data = {}
    
    default_rate = country_data.get("rate", 0.0)
    return {
        "spam_free_rate": country_data.get("spam_free_rate", default_rate),
        "spam_rate": country_data.get("spam_rate", default_rate),
        "limit_rate": country_data.get("limit_rate", default_rate)
    }


@thread_safe
def get_country_timeout(country_code: str) -> int:
    """Get timeout for a country in seconds."""
    matched_code, country_data = find_country_data_with_fallback(country_code)
    if country_data:
        return country_data.get("timeout", 300)
    return 300


@thread_safe
def set_country_rate(country_code: str, rate: float) -> None:
    """Set default rate for a country."""
    if country_code not in _storage["countries"]:
        _storage["countries"][country_code] = {
            "rate": rate, 
            "spam_free_rate": rate,
            "spam_rate": rate,
            "limit_rate": rate,
            "timeout": 300, 
            "open": True
        }
    else:
        _storage["countries"][country_code]["rate"] = rate
        if "spam_free_rate" not in _storage["countries"][country_code]:
            _storage["countries"][country_code]["spam_free_rate"] = rate
        if "spam_rate" not in _storage["countries"][country_code]:
            _storage["countries"][country_code]["spam_rate"] = rate
        if "limit_rate" not in _storage["countries"][country_code]:
            _storage["countries"][country_code]["limit_rate"] = rate
        _storage["countries"][country_code]["open"] = True
    save_storage()


@thread_safe
def set_country_rates(country_code: str, spam_free_rate: float, spam_rate: float, limit_rate: float) -> Dict[str, Any]:
    """Set all 3 rates for a country."""
    spam_free_rate, spam_rate, limit_rate = validate_rates_hierarchy(
        spam_free_rate, spam_rate, limit_rate
    )
    
    if country_code not in _storage["countries"]:
        _storage["countries"][country_code] = {
            "rate": spam_free_rate,
            "spam_free_rate": spam_free_rate,
            "spam_rate": spam_rate,
            "limit_rate": limit_rate,
            "timeout": 300, 
            "open": True
        }
    else:
        _storage["countries"][country_code]["rate"] = spam_free_rate
        _storage["countries"][country_code]["spam_free_rate"] = spam_free_rate
        _storage["countries"][country_code]["spam_rate"] = spam_rate
        _storage["countries"][country_code]["limit_rate"] = limit_rate
        _storage["countries"][country_code]["open"] = True
    save_storage()
    
    return {
        "spam_free_rate": spam_free_rate,
        "spam_rate": spam_rate,
        "limit_rate": limit_rate,
        "validated": True
    }


@thread_safe
def set_country_rate_by_type(country_code: str, rate_type: str, rate: float) -> None:
    """Set specific rate type for a country."""
    if country_code not in _storage["countries"]:
        _storage["countries"][country_code] = {
            "rate": 0.0,
            "spam_free_rate": 0.0,
            "spam_rate": 0.0,
            "limit_rate": 0.0,
            "timeout": 300, 
            "open": True
        }
    
    _storage["countries"][country_code][rate_type] = rate
    if rate_type == "spam_free_rate":
        _storage["countries"][country_code]["rate"] = rate
    _storage["countries"][country_code]["open"] = True
    save_storage()


@thread_safe
def set_session_timeout(timeout_seconds: int) -> None:
    """Set session timeout globally."""
    for country in _storage["countries"]:
        _storage["countries"][country]["timeout"] = timeout_seconds
    save_storage()


@thread_safe
def set_country_timeout(country_code: str, timeout_seconds: int):
    """Set session timeout for a specific country."""
    if country_code in _storage["countries"]:
        _storage["countries"][country_code]["timeout"] = timeout_seconds
        save_storage()
        return True, f"⏳ Timeout for {country_code} set to {timeout_seconds} seconds"
    else:
        return False, f"❌ Country {country_code} not found. Set rate first!"


@thread_safe
def add_open_country(country_code: str) -> None:
    """Add a country to open list."""
    if country_code not in _storage["countries"]:
        _storage["countries"][country_code] = {"rate": 0.0, "timeout": 300, "open": True}
    else:
        _storage["countries"][country_code]["open"] = True
    save_storage()


@thread_safe
def close_country(country_code: str) -> None:
    """Close a country."""
    if country_code in _storage["countries"]:
        _storage["countries"][country_code]["open"] = False
        save_storage()


@thread_safe
def toggle_country_status(country_code: str):
    """Toggle country open/close status."""
    if country_code in _storage["countries"]:
        current = _storage["countries"][country_code].get("open", False)
        _storage["countries"][country_code]["open"] = not current
        save_storage()
        return country_code, not current
    return country_code, False


@thread_safe
def try_deduct_balance_for_withdraw(user_id, amount: float) -> bool:
    """
    Atomically check balance and deduct for withdrawal.
    Prevents double-spend by doing check-and-deduct in one locked operation.
    
    Returns:
        True if balance was sufficient and deducted, False otherwise
    """
    user_id = str(user_id)
    if user_id not in _storage["users"]:
        return False
    
    current_balance = _storage["users"][user_id].get("balance", 0)
    if current_balance < amount or amount <= 0:
        return False
    
    _storage["users"][user_id]["balance"] = current_balance - amount
    _do_save()
    
    try:
        from bot.utils.fast_cache import invalidate_user_cache
        invalidate_user_cache(int(user_id))
    except (ImportError, ValueError, TypeError):
        pass
    
    return True


@thread_safe
def record_withdraw_request_only(user_id, method: str, amount: float, wallet_address: str) -> None:
    """Record withdrawal request without deducting balance (balance already deducted atomically)."""
    _storage["withdrawals"].append({
        "user_id": str(user_id),
        "method": method,
        "amount": amount,
        "wallet_address": wallet_address,
        "timestamp": datetime.now().isoformat(),
        "status": "pending"
    })
    save_storage()


@thread_safe
def force_logout_users() -> None:
    """Force logout all users."""
    _storage["admin_logs"].append({
        "action": "force_logout_all",
        "timestamp": datetime.now().isoformat()
    })
    save_storage()


@thread_safe
def get_failed_verifications() -> str:
    """Get list of failed verifications."""
    return "\n".join([f"User {v['user_id']} - {v['reason']}" for v in _storage["failed_verifications"][-10:]]) or "No failed verifications"


@thread_safe
def get_transaction_logs() -> str:
    """Get transaction logs."""
    return "\n".join([f"{t.get('timestamp', 'N/A')}: User {t.get('user_id', 'N/A')} - {t.get('action', 'N/A')}" for t in _storage["transaction_logs"][-20:]]) or "No transactions"


@thread_safe
def log_transaction(user_id, action: str, amount: float = 0, **kwargs) -> None:
    """Log a transaction."""
    _storage["transaction_logs"].append({
        "user_id": str(user_id),
        "action": action,
        "amount": amount,
        "timestamp": datetime.now().isoformat(),
        **kwargs
    })
    save_storage()


@thread_safe
def log_failed_verification(user_id, reason: str, **kwargs) -> None:
    """Log a failed verification."""
    _storage["failed_verifications"].append({
        "user_id": str(user_id),
        "reason": reason,
        "timestamp": datetime.now().isoformat(),
        **kwargs
    })
    save_storage()


@thread_safe
def get_required_channel() -> str:
    """Get required channel from storage."""
    return _storage.get("required_channel", "")


@thread_safe
def set_required_channel(channel: str) -> None:
    """Set required channel in storage."""
    _storage["required_channel"] = channel
    save_storage()


@thread_safe
def reset_user_channel_joined(user_id=None) -> int:
    """Reset channel_joined flag for one or all users. Returns count of affected users."""
    count = 0
    if user_id is not None:
        user_id = str(user_id)
        if user_id in _storage.get("users", {}):
            _storage["users"][user_id]["channel_joined"] = False
            count = 1
    else:
        for uid in _storage.get("users", {}):
            if _storage["users"][uid].get("channel_joined", False):
                _storage["users"][uid]["channel_joined"] = False
                count += 1
    if count > 0:
        save_storage()
    return count


@thread_safe
def is_withdraw_enabled() -> bool:
    """Check if withdrawal is enabled."""
    return not _storage.get("withdraw_disabled", False)


@thread_safe
def toggle_withdraw() -> bool:
    """Toggle withdraw enabled/disabled."""
    current = _storage.get("withdraw_disabled", False)
    _storage["withdraw_disabled"] = not current
    save_storage()
    return not _storage["withdraw_disabled"]


@thread_safe
def is_verification_paused() -> bool:
    """Check if verification is paused."""
    return _storage.get("verification_paused", False)


@thread_safe
def toggle_verification_pause() -> bool:
    """Toggle verification pause status."""
    current = _storage.get("verification_paused", False)
    _storage["verification_paused"] = not current
    save_storage()
    return _storage["verification_paused"]


@thread_safe
def is_spam_check_enabled() -> bool:
    """Check if spam check is enabled. Default is True (enabled)."""
    return _storage.get("spam_check_enabled", True)


@thread_safe
def toggle_spam_check() -> bool:
    """Toggle spam check enabled/disabled. Returns new state."""
    current = _storage.get("spam_check_enabled", True)
    _storage["spam_check_enabled"] = not current
    save_storage()
    return _storage["spam_check_enabled"]


@thread_safe
def _get_user_pending_session_stats(user_id: str) -> Dict[str, int]:
    """Get pending session statistics for a specific user."""
    i = str(user_id)
    pending_sessions = _storage.get("pending_sessions", {})

    stats = {
        "waiting_24hr": 0,
        "unverified": 0,
        "rejected": 0
    }

    for session_data in list(pending_sessions.values()):
        if str(session_data.get("user_id", "")) != i:
            continue

        if session_data.get("balance_credited", False):
            continue

        status = session_data.get("status", "pending")
        session_info = session_data.get("session_data", {})
        message_type = session_info.get("message_type", "")

        if status in ("rejected", "timeout", "expired"):
            stats["rejected"] += 1
        elif message_type in ("MULTI-DEVICE", "24HR"):
            stats["waiting_24hr"] += 1
        elif status == "pending":
            stats["unverified"] += 1

    return stats


@thread_safe
def get_user_stats(user_id=None) -> Union[Dict[str, Any], str]:
    """Get user statistics. If user_id provided, get stats for that user."""
    if user_id is not None:
        user_id = str(user_id)
        user = _storage.get("users", {}).get(user_id)
        if not user:
            return f"User {user_id} not found."
        
        from bot.utils.country_data import get_flag
        
        pending_stats = _get_user_pending_session_stats(user_id)
        
        sessions_count = user.get('sessions', 0)
        country_sessions = user.get('country_sessions', {})
        
        country_lines = []
        for cc, count in sorted(country_sessions.items(), key=lambda x: x[1], reverse=True):
            if cc == "other":
                country_lines.append(f"🌍 Other: {count}")
            else:
                flag = get_flag(cc)
                country_lines.append(f"{flag} {cc}: {count}")
        country_text = "\n".join(country_lines) if country_lines else "No successful sessions"
        
        return (
            f"📊 **User Stats:**\n"
            f"👤 User ID: `{user_id}`\n"
            f"💰 Balance: **${user.get('balance', 0):.2f}**\n"
            f"━━━━━━━━━━━━━━━━━━━\n"
            f"📈 **Session Summary:**\n"
            f"✅ Total Successful: {sessions_count}\n"
            f"⏳ 24 Hours: {pending_stats['waiting_24hr']}\n"
            f"⚠️ Unverified: {pending_stats['unverified']}\n"
            f"❌ Rejected: {pending_stats['rejected']}\n"
            f"━━━━━━━━━━━━━━━━━━━\n"
            f"🌍 **Successful Sessions by Country:**\n"
            f"{country_text}\n"
            f"━━━━━━━━━━━━━━━━━━━\n"
            f"🚫 Banned: {'Yes' if user.get('banned') else 'No'}\n"
            f"📅 Joined: {user.get('joined', 'N/A')}"
        )
    
    users = _storage.get("users", {})
    total = len(users)
    banned = sum(1 for u in users.values() if u.get("banned", False))
    active = total - banned
    total_balance = sum(u.get("balance", 0) for u in users.values())
    total_sessions = sum(u.get("sessions", 0) for u in users.values())
    
    return {
        "total": total,
        "active": active,
        "banned": banned,
        "total_balance": total_balance,
        "total_sessions": total_sessions
    }


@thread_safe
def zero_all_balances() -> int:
    """Zero all user balances and reset session tracker.
    Returns count of affected users."""
    count = 0
    affected_users = []
    for user_id in _storage["users"]:
        if _storage["users"][user_id].get("balance", 0) > 0:
            _storage["users"][user_id]["balance"] = 0
            _storage["users"][user_id]["sessions"] = 0
            affected_users.append(user_id)
            count += 1
    _storage["session_tracker"] = {}
    save_storage()
    
    try:
        from bot.utils.fast_cache import invalidate_user_cache
        for uid in affected_users:
            try:
                invalidate_user_cache(int(uid))
            except (ValueError, TypeError):
                pass
    except ImportError:
        pass
    
    return count


@thread_safe
def get_total_users():
    """Get total user count and active count (returns tuple for backward compatibility)."""
    users = _storage.get("users", {})
    total = len(users)
    cutoff = datetime.now() - timedelta(hours=24)
    active = sum(1 for u in users.values() 
                 if _parse_date(u.get("joined")) > cutoff or u.get("sessions", 0) > 0)
    return total, active


@thread_safe
def get_all_users_list(limit: int = 50, offset: int = 0) -> List[Dict[str, Any]]:
    """Get paginated list of users with their info.
    
    Args:
        limit: Maximum number of users to return (default 50)
        offset: Number of users to skip (default 0)
    """
    users = _storage.get("users", {})
    items = list(users.items())
    sliced = items[offset:offset + limit]
    return [{"user_id": uid, **data} for uid, data in sliced]

@thread_safe
def set_user_withdraw_config(user_id, min_amt=None, max_amt=None, disabled=None):
    """Set custom withdraw configuration for a specific user."""
    user_id = str(user_id)
    if user_id not in _storage.get("users", {}):
        return False
    
    if "withdraw_config" not in _storage["users"][user_id]:
        _storage["users"][user_id]["withdraw_config"] = {}
    
    if min_amt is not None:
        _storage["users"][user_id]["withdraw_config"]["min"] = float(min_amt)
    if max_amt is not None:
        _storage["users"][user_id]["withdraw_config"]["max"] = float(max_amt)
    if disabled is not None:
        _storage["users"][user_id]["withdraw_config"]["disabled"] = bool(disabled)
        
    save_storage()
    try:
        from bot.utils.fast_cache import invalidate_user_cache
        invalidate_user_cache(int(user_id))
    except:
        pass
    return True

@thread_safe
def get_user_withdraw_config(user_id) -> Dict[str, Any]:
    """Get custom withdraw configuration for a specific user."""
    user_id = str(user_id)
    user = _storage.get("users", {}).get(user_id, {})
    return user.get("withdraw_config", {})


@thread_safe
def get_pending_withdraw_requests() -> List[Dict[str, Any]]:
    """Get pending withdraw requests."""
    return [w for w in _storage.get("withdrawals", []) if w.get("status") == "pending"]


@thread_safe
def approve_withdraw_request(index: int) -> Dict[str, Any]:
    """Approve a pending withdraw request by index.
    
    Args:
        index: Index of the pending request in the pending list
        
    Returns:
        Dict with request details or error info
    """
    pending = [w for w in _storage.get("withdrawals", []) if w.get("status") == "pending"]
    if index < 0 or index >= len(pending):
        return {"success": False, "error": "Invalid request index"}
    
    target_request = pending[index]
    
    for w in _storage.get("withdrawals", []):
        if (w.get("user_id") == target_request.get("user_id") and 
            w.get("timestamp") == target_request.get("timestamp") and 
            w.get("status") == "pending"):
            w["status"] = "approved"
            w["approved_at"] = datetime.now().isoformat()
            save_storage()
            return {
                "success": True, 
                "user_id": w.get("user_id"),
                "amount": w.get("amount"),
                "method": w.get("method"),
                "wallet_address": w.get("wallet_address"),
                "timestamp": w.get("timestamp", "")
            }
    
    return {"success": False, "error": "Request not found"}


@thread_safe
def reject_withdraw_request(index: int) -> Dict[str, Any]:
    """Reject a pending withdraw request and refund balance.
    
    Args:
        index: Index of the pending request in the pending list
        
    Returns:
        Dict with request details or error info
    """
    pending = [w for w in _storage.get("withdrawals", []) if w.get("status") == "pending"]
    if index < 0 or index >= len(pending):
        return {"success": False, "error": "Invalid request index"}
    
    target_request = pending[index]
    user_id = target_request.get("user_id")
    amount = target_request.get("amount", 0)
    
    for w in _storage.get("withdrawals", []):
        if (w.get("user_id") == user_id and 
            w.get("timestamp") == target_request.get("timestamp") and 
            w.get("status") == "pending"):
            w["status"] = "rejected"
            w["rejected_at"] = datetime.now().isoformat()
            
            if user_id in _storage.get("users", {}):
                current_balance = _storage["users"][user_id].get("balance", 0)
                _storage["users"][user_id]["balance"] = current_balance + amount
            
            save_storage()
            
            try:
                from bot.utils.fast_cache import invalidate_user_cache
                invalidate_user_cache(int(user_id))
            except (ImportError, ValueError, TypeError):
                pass
            
            return {
                "success": True, 
                "user_id": user_id,
                "amount": amount,
                "method": w.get("method"),
                "wallet_address": w.get("wallet_address", ""),
                "timestamp": w.get("timestamp", ""),
                "refunded": True
            }
    
    return {"success": False, "error": "Request not found"}


@thread_safe
def get_withdraw_logs() -> List[Dict[str, Any]]:
    """Get all withdraw logs."""
    return _storage.get("withdrawals", [])[-50:]


@thread_safe
def disable_all_countries() -> int:
    """Disable all countries. Returns count of affected countries."""
    count = 0
    for code in _storage["countries"]:
        if _storage["countries"][code].get("open", False):
            _storage["countries"][code]["open"] = False
            count += 1
    save_storage()
    return count


@thread_safe
def get_min_withdraw_amounts() -> Dict[str, float]:
    """Get minimum withdraw amounts for each method."""
    return _storage.get("min_withdraw", {
        "usdt": 10.0,
        "trx": 10.0,
        "cardname": 10.0,
        "binance": 10.0
    })


@thread_safe
def get_min_withdraw_for_method(method: str) -> float:
    """Get minimum withdraw for a specific method."""
    mins = get_min_withdraw_amounts()
    return mins.get(method.lower(), 10.0)


@thread_safe
def set_min_withdraw_for_method(method: str, amount: float) -> None:
    """Set minimum withdraw for a specific method."""
    if "min_withdraw" not in _storage:
        _storage["min_withdraw"] = {
            "usdt": 10.0,
            "trx": 10.0,
            "cardname": 10.0,
            "binance": 10.0
        }
    _storage["min_withdraw"][method.lower()] = amount
    save_storage()


@thread_safe
def get_session_tracker_list():
    """Get session tracker list with detailed info."""
    tracker = _storage.get("session_tracker", {})
    if not tracker:
        return "", 0, 0
    
    from bot.utils.country_data import get_flag
    
    lines = []
    total_sessions = 0
    total_earnings = 0.0
    country_stats = {}
    
    for user_id, sessions in tracker.items():
        user_session_count = len(sessions)
        total_sessions += user_session_count
        user_earnings = sum(s.get("amount", 0) for s in sessions)
        total_earnings += user_earnings
        
        for s in sessions:
            cc = s.get("country_code", "other")
            country_stats[cc] = country_stats.get(cc, 0) + 1
        
        lines.append(f"👤 User {user_id}: {user_session_count} sessions (${user_earnings:.2f})")
    
    country_lines = []
    for cc, count in sorted(country_stats.items(), key=lambda x: x[1], reverse=True)[:10]:
        flag = get_flag(cc) if cc != "other" else "🌍"
        country_lines.append(f"   {flag} {cc}: {count}")
    
    summary = f"💰 Total Earnings: ${total_earnings:.2f}\n"
    if country_lines:
        summary += "🌍 Top Countries:\n" + "\n".join(country_lines) + "\n\n"
    
    return summary + "\n".join(lines), len(tracker), total_sessions


@thread_safe
def reset_session_tracker() -> None:
    """Reset session tracker."""
    _storage["session_tracker"] = {}
    save_storage()


@thread_safe
def cleanup_old_stuck_sessions(max_age_hours: Optional[int] = None) -> int:
    """Clean up old stuck/pending sessions older than max_age_hours.
    
    Improved logic:
    - Check multiple timestamp fields (submitted_at, created_at, deadline_at)
    - Remove sessions older than max_age_hours regardless of status
    - Sessions with balance_credited=True are completed and can be cleaned
    - Sessions without any valid timestamp are considered for removal
    
    When max_age_hours is None the configured session_expiry_hours is used.
    """
    from datetime import timedelta
    
    if max_age_hours is None:
        max_age_hours = get_session_expiry_hours()
    
    pending = _storage.get("pending_sessions", {})
    if not pending:
        return 0
    
    cutoff = datetime.now() - timedelta(hours=max_age_hours)
    to_remove = []
    
    for session_id, session_data in list(pending.items()):
        # Multi-device sessions are managed by the 24h auto-logout/verify/credit
        # and expiry flow (monitor + finalize_expired_sessions). Never delete them
        # silently here, otherwise they vanish without verification or notification.
        inner_data = session_data.get("session_data", {})
        if inner_data.get("has_extra_devices"):
            continue
        
        submitted_str = session_data.get("submitted_at") or session_data.get("created_at") or session_data.get("deadline_at")
        
        should_remove = False
        
        if submitted_str:
            try:
                submitted_at = datetime.fromisoformat(submitted_str.replace("Z", "+00:00"))
                if submitted_at < cutoff:
                    should_remove = True
            except (ValueError, TypeError):
                should_remove = True
        else:
            should_remove = True
        
        if should_remove:
            to_remove.append(session_id)
            logger.info(f"CLEANUP: Marking session {session_id} for removal (age check passed)")
    
    for session_id in to_remove:
        try:
            del _storage["pending_sessions"][session_id]
        except KeyError:
            pass
    
    if to_remove:
        save_storage()
        logger.info(f"CLEANUP: Removed {len(to_remove)} old sessions (>{max_age_hours}h)")
    
    return len(to_remove)


@thread_safe
def get_auto_approve_enabled() -> bool:
    """Whether successful sessions are automatically approved (no manual approval needed)."""
    return bool(_storage.get("auto_approve_enabled", False))


@thread_safe
def set_auto_approve_enabled(enabled: bool) -> None:
    """Persist the auto-approve setting."""
    _storage["auto_approve_enabled"] = bool(enabled)
    save_storage()


@thread_safe
def get_session_expiry_hours() -> int:
    """Hours after which an old stuck/pending session is cleaned up. Default 24."""
    try:
        return int(_storage.get("session_expiry_hours", 24))
    except (TypeError, ValueError):
        return 24


@thread_safe
def set_session_expiry_hours(hours: int) -> None:
    """Persist the session expiry (cleanup) threshold in hours."""
    try:
        _storage["session_expiry_hours"] = max(1, int(hours))
    except (TypeError, ValueError):
        _storage["session_expiry_hours"] = 24
    save_storage()


@thread_safe
def get_stuck_session_expiry_hours() -> int:
    """Hours after which a stuck session that still has its session string is finalized. Default 72."""
    try:
        return int(_storage.get("stuck_session_expiry_hours", 72))
    except (TypeError, ValueError):
        return 72


@thread_safe
def set_stuck_session_expiry_hours(hours: int) -> None:
    """Persist the stuck-session finalize threshold in hours."""
    try:
        _storage["stuck_session_expiry_hours"] = max(1, int(hours))
    except (TypeError, ValueError):
        _storage["stuck_session_expiry_hours"] = 72
    save_storage()


DEFAULT_MESSAGE_TEMPLATES = {
    "account_received_message": (
        "\u2705 *Account Received*\n\n"
        "\U0001f4f1 `{phone}`   {flag}\n"
        "\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\n"
        "\U0001f4b0 Price        \u2192  *Calculating...*\n"
        "\U0001f4ca Status       \u2192  \U0001f504 Processing\n"
        "\u23f0 ETA          \u2192  ~{timeout} seconds\n"
        "\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\n\n"
        "\U0001f514 You will be notified when verified."
    ),
    "success_message": (
        "\u2705 *Verification Successful*\n\n"
        "\U0001f4f1 Phone: `{phone}`\n"
        "\U0001f4b0 Balance Added: *${price}*\n"
        "\U0001f4ca Status: *{status}*\n\n"
        "Your account has been credited successfully."
    ),
    "multi_device_message": (
        "\u26a0\ufe0f *Multiple Devices Detected*\n\n"
        "\U0001f4f1 Phone: `{phone}`\n\n"
        "Multiple devices are logged into this account.\n"
        "The session may be invalid.\n\n"
        "Use /start to try a different number."
    ),
    "support_message": (
        "\U0001f4de *Support*\n\n"
        "Contact the admin for assistance.\n"
        "Please describe your issue clearly."
    ),
    "account_info_message": (
        "\U0001f3b0 *Your Account*\n\n"
        "\U0001f464 User ID: `{user_id}`\n"
        "\U0001f4b0 Balance: *${balance}*\n"
        "\u2705 Sessions: *{sessions}*\n"
        "\U0001f4c5 Joined: *{joined}*\n\n"
        "Commands:\n"
        "/start - Submit a number\n"
        "/withdraw - Withdraw funds\n"
        "/cap - View open countries"
    ),
    "verification_failed_message": (
        "\u274c *Verification Failed*\n\n"
        "\U0001f4f1 Phone: `{phone}`\n"
        "\U0001f30d Country: {flag} {country_code}\n\n"
        "Device is not logged in. Session has expired.\n\n"
        "Type /start to try again."
    ),
    "welcome_message": (
        "\U0001f44b *Welcome!*\n\n"
        "Send your phone number to begin verification.\n\n"
        "Example: `+8801XXXXXXXXXX`\n\n"
        "Commands:\n"
        "/account - View your account\n"
        "/withdraw - Withdraw balance\n"
        "/cap - Available countries\n"
        "/cancel - Stop verification"
    ),
    "invalid_otp_message": (
        "\u274c *Invalid OTP Code*\n\n"
        "The code you entered is incorrect.\n"
        "Please enter the OTP sent to your Telegram app."
    ),
    "processing_message": (
        "\u23f3 *Processing...*\n\n"
        "Please wait while we process your request.\n"
        "This may take a few moments."
    ),
    "banned_user_message": (
        "\U0001f6ab *Access Denied*\n\n"
        "You have been banned from using this bot.\n"
        "Contact support if you believe this is a mistake."
    ),
    "withdraw_success_message": (
        "\u2705 *Withdraw Request Submitted*\n\n"
        "\U0001f4b0 Amount: *${amount}*\n"
        "\U0001f4b3 Method: *{method}*\n\n"
        "Your request will be processed shortly.\n"
        "Check /account for updated balance."
    ),
    "no_balance_message": (
        "\u274c *Insufficient Balance*\n\n"
        "You do not have any balance to withdraw.\n\n"
        "Submit numbers via /start to earn balance."
    ),
    "twofa_already_active_message": (
        "\u26a0\ufe0f *2FA Already Enabled*\n\n"
        "This account already has Two-Factor Authentication.\n\n"
        "Use /start to try a different number."
    ),

    "enter_phone_message": (
        "\U0001f4f1 *Enter Your Phone Number*\n\n"
        "Send your phone number with country code.\n\n"
        "Example: `+8801XXXXXXXXXX`\n\n"
        "\u26a0\ufe0f Include the correct country code.\n"
        "Type /cancel to stop."
    ),
    "enter_otp_message": (
        "\U0001f522 *Enter OTP Code*\n\n"
        "Enter the code sent to your Telegram app.\n\n"
        "\u23f0 Timeout: *{timeout} seconds*\n\n"
        "Type /cancel to stop."
    ),
    "otp_sent_message": (
        "\U0001f4e4 *OTP Code Sent*\n\n"
        "\U0001f4f1 Phone: `{phone}`\n"
        "\U0001f30d Country: {flag} {country_code}\n\n"
        "\u23f0 Time Remaining: *{timeout} seconds*\n\n"
        "Enter the code or type /cancel"
    ),
    "waiting_verification_message": (
        "\u23f3 *Verification In Progress*\n\n"
        "\U0001f4f1 Phone: `{phone}`\n"
        "\U0001f30d Country: {flag} {country_code}\n\n"
        "\u23f0 Estimated Time: *{timeout} seconds*\n\n"
        "You will be notified when complete."
    ),
    "twofa_setup_message": (
        "\U0001f510 *Setting Up Security*\n\n"
        "\U0001f4f1 Phone: `{phone}`\n\n"
        "\u23f3 2FA is being configured.\n"
        "Please wait approximately 2 minutes."
    ),
    "spam_check_message": (
        "\U0001f50d *Checking Account Status*\n\n"
        "\U0001f4f1 Phone: `{phone}`\n\n"
        "\u23f3 Verifying account standing...\n"
        "This ensures fair pricing."
    ),
    "withdraw_disabled_message": (
        "\u274c *Withdrawals Unavailable*\n\n"
        "Withdrawals are temporarily disabled.\n"
        "Please check back later."
    ),
    "withdraw_method_message": (
        "\U0001f4b3 *Select Withdrawal Method*\n\n"
        "\U0001f4b0 Your Balance: *${balance}*\n\n"
        "Please choose your preferred method:"
    ),
    "enter_wallet_message": (
        "\U0001f4ec *Enter {method} Wallet Address*\n\n"
        "Send your {method} wallet address below.\n\n"
        "\u26a0\ufe0f *Important:*\n"
        "\u2022 Double-check the address before sending\n"
        "\u2022 Incorrect addresses cannot be refunded\n"
        "\u2022 Type /cancel to abort"
    ),
    "invalid_wallet_message": (
        "\u274c *Invalid Wallet Address*\n\n"
        "Error: `{error}`\n\n"
        "\U0001f4ec Please send a valid *{method}* address.\n\n"
        "Type /cancel to abort."
    ),
    "session_timeout_message": (
        "\u23f0 *Session Expired*\n\n"
        "\U0001f4f1 Phone: `{phone}`\n"
        "\U0001f30d Country: {flag} {country_code}\n\n"
        "No response received within *{timeout} seconds*.\n\n"
        "\U0001f504 Type /start to try again."
    ),
    "country_not_available_message": (
        "\u274c *Country Unavailable*\n\n"
        "\U0001f30d Country: {flag} {country_code}\n\n"
        "This country is currently closed.\n\n"
        "Type /cap to see available countries\n"
        "Or try a different number with /start"
    ),
    "join_channel_message": (
        "\U0001f4e2 *Channel Required*\n\n"
        "\U0001f517 Channel: {channel}\n\n"
        "You must join this channel to use the bot.\n\n"
        "\u2705 After joining, click the button below\n"
        "or type /start to begin."
    ),
    "min_withdraw_message": (
        "\u26a0\ufe0f *Insufficient Balance*\n\n"
        "\U0001f4b0 Your Balance: *${balance}*\n"
        "\U0001f4b5 Minimum Withdraw: *${min_amount}*\n\n"
        "\u274c You need *${needed}* more to withdraw.\n\n"
        "Submit more numbers via /start"
    ),
    "enter_2fa_password_message": (
        "\U0001f510 *2FA Password Required*\n\n"
        "\U0001f4f1 Phone: `{phone}`\n\n"
        "This account has Two-Factor Authentication.\n\n"
        "\U0001f511 Enter the 2FA password:\n\n"
        "Type /cancel to abort."
    )
}


@thread_safe
def get_message_template(template_name: str) -> str:
    """Get a message template."""
    custom = _storage.get("message_templates", {})
    if template_name in custom:
        return custom[template_name]
    return DEFAULT_MESSAGE_TEMPLATES.get(template_name, f"[{template_name}]")


@thread_safe
def set_message_template(template_name: str, template_text: str) -> None:
    """Set a custom message template."""
    if "message_templates" not in _storage:
        _storage["message_templates"] = {}
    _storage["message_templates"][template_name] = template_text
    save_storage()
    
    try:
        from bot.utils.fast_cache import preload_templates as _refresh
        _refresh()
    except (ImportError, Exception):
        pass


@thread_safe
def reset_message_template(template_name: str) -> None:
    """Reset a message template to default."""
    if "message_templates" in _storage and template_name in _storage["message_templates"]:
        del _storage["message_templates"][template_name]
        save_storage()
    
    try:
        from bot.utils.fast_cache import preload_templates as _refresh
        _refresh()
    except (ImportError, Exception):
        pass


@thread_safe
def get_all_message_templates() -> Dict[str, Dict[str, Any]]:
    """Get all message templates with their status."""
    custom = _storage.get("message_templates", {})
    result = {}
    
    for name, default_text in DEFAULT_MESSAGE_TEMPLATES.items():
        is_custom = name in custom
        current_text = custom.get(name, default_text)
        result[name] = {
            "current": current_text,
            "default": default_text,
            "is_custom": is_custom
        }
    
    return result


@thread_safe
def get_all_balances_report():
    """Get report of all user balances.
    
    Returns:
        tuple: (report_text, total_users, users_with_balance, total_balance)
    """
    users = _storage.get("users", {})
    lines = []
    total_balance = 0
    users_with_balance = 0
    total_users = len(users)
    
    for user_id, data in users.items():
        balance = data.get("balance", 0)
        if balance > 0:
            username = data.get("username", "")
            first_name = data.get("first_name", "Unknown")
            display_name = f"@{username}" if username else first_name
            lines.append(f"👤 {display_name} ({user_id}): ${balance:.2f}")
            total_balance += balance
            users_with_balance += 1
    
    report = "\n".join(lines[:50]) if lines else ""
    
    return report, total_users, users_with_balance, round(total_balance, 2)


def format_message(template_name: str, **kwargs) -> str:
    """Format a message template with variables (safe - no overlapping key corruption)."""
    import re
    template = get_message_template(template_name)
    try:
        for key, value in kwargs.items():
            template = re.sub(r'\{' + re.escape(key) + r'\}', str(value), template)
        return template
    except Exception:
        return template


@thread_safe
def add_pending_session(
    session_id: str, 
    user_id, 
    phone: str, 
    country_code: str, 
    session_data: Dict[str, Any],
    rate: float = 0.0,
    timeout_seconds: int = 300,
    session_string: str = "",
    twofa_password: str = "",
    message_id: Optional[int] = None,
    phone_message_id: Optional[int] = None,
    session_file: str = "",
    telethon_file: str = "",
    spam_status: str = "pending",
    spam_status_details: Optional[Dict[str, Any]] = None,
    submitted_at: str = "",
    deadline_at: str = ""
) -> None:
    """Add a pending session with extended parameters. Preserves critical state for existing sessions."""
    existing = _storage.get("pending_sessions", {}).get(session_id)
    preserved_status = existing.get("status") if existing and existing.get("status") in ("approved", "rejected") else "pending"
    preserved_balance_credited = existing.get("balance_credited", False) if existing else False
    
    _storage["pending_sessions"][session_id] = {
        "user_id": str(user_id),
        "phone": phone,
        "country_code": country_code,
        "session_data": session_data,
        "status": preserved_status,
        "created_at": existing.get("created_at") if existing else datetime.now().isoformat(),
        "rate": rate,
        "timeout_seconds": timeout_seconds,
        "session_string": session_string,
        "twofa_password": twofa_password,
        "message_id": message_id,
        "phone_message_id": phone_message_id,
        "session_file": session_file,
        "telethon_file": telethon_file,
        "spam_status": spam_status,
        "spam_status_details": spam_status_details or {},
        "submitted_at": existing.get("submitted_at") if existing and existing.get("submitted_at") else submitted_at,
        "deadline_at": existing.get("deadline_at") if existing and existing.get("deadline_at") else deadline_at,
        "balance_credited": preserved_balance_credited or existing.get("balance_credited", False) if existing else False
    }
    save_storage()


@thread_safe
def get_pending_session(session_id: str) -> Optional[Dict[str, Any]]:
    """Get a copy of a pending session (safe - no mutable reference leak)."""
    session = _storage.get("pending_sessions", {}).get(session_id)
    if session is None:
        return None
    try:
        return json.loads(json.dumps(session, default=str))
    except Exception:
        return dict(session)


@thread_safe
def get_all_pending_sessions() -> Dict[str, Dict[str, Any]]:
    """Get all pending sessions."""
    return _storage.get("pending_sessions", {}).copy()


@thread_safe
def approve_pending_session(session_id: str):
    """Approve a pending session. Returns tuple (success, message) for backward compatibility."""
    if session_id in _storage.get("pending_sessions", {}):
        _storage["pending_sessions"][session_id]["status"] = "approved"
        save_storage()
        return True, f"Session {session_id} approved successfully"
    return False, f"Session {session_id} not found"


@thread_safe
def reject_pending_session(session_id: str, reason: str = "") -> bool:
    """Reject a pending session."""
    if session_id in _storage.get("pending_sessions", {}):
        _storage["pending_sessions"][session_id]["status"] = "rejected"
        _storage["pending_sessions"][session_id]["rejection_reason"] = reason
        save_storage()
        return True
    return False


@thread_safe
def expire_pending_session(session_id: str, reason: str = "") -> bool:
    """Mark a pending session as expired (24h window missed while bot was offline)."""
    if session_id in _storage.get("pending_sessions", {}):
        _storage["pending_sessions"][session_id]["status"] = "expired"
        _storage["pending_sessions"][session_id]["expired_reason"] = reason
        if "session_data" not in _storage["pending_sessions"][session_id]:
            _storage["pending_sessions"][session_id]["session_data"] = {}
        _storage["pending_sessions"][session_id]["session_data"]["message_type"] = "EXPIRED"
        save_storage()
        return True
    return False


@thread_safe
def update_pending_session_field(session_id: str, field: str, value: Any) -> bool:
    """Update a field inside session_data of a pending session."""
    if session_id in _storage.get("pending_sessions", {}):
        if "session_data" not in _storage["pending_sessions"][session_id]:
            _storage["pending_sessions"][session_id]["session_data"] = {}
        _storage["pending_sessions"][session_id]["session_data"][field] = value
        save_storage()
        return True
    return False


@thread_safe
def set_pending_session_field(session_id: str, field: str, value: Any) -> bool:
    """Set a TOP-LEVEL field on a pending session (not inside session_data)."""
    if session_id in _storage.get("pending_sessions", {}):
        _storage["pending_sessions"][session_id][field] = value
        save_storage()
        return True
    return False


@thread_safe
def delete_pending_session(session_id: str) -> bool:
    """Delete a pending session by ID."""
    if session_id in _storage.get("pending_sessions", {}):
        del _storage["pending_sessions"][session_id]
        save_storage()
        logger.info(f"Deleted pending session {session_id}")
        return True
    return False


def replace_pending_session_data(session_id: str, new_data: dict) -> bool:
    """Replace the entire session_data dict (avoids nesting bug)."""
    if session_id in _storage.get("pending_sessions", {}):
        _storage["pending_sessions"][session_id]["session_data"] = new_data
        save_storage()
        return True
    return False


@thread_safe
def view_admin_logs() -> str:
    """View admin logs."""
    logs = _storage.get("admin_logs", [])[-20:]
    if not logs:
        return "No admin logs."
    return "\n".join([f"{l.get('timestamp', 'N/A')}: {l.get('action', 'N/A')}" for l in logs])


@thread_safe
def get_exportable_sessions() -> Dict[str, Dict[str, Any]]:
    """Get all sessions that are ready for export (verified/approved sessions).
    
    Returns:
        Dict of session_id -> session_data for approved/verified sessions
    """
    exportable = {}
    pending = _storage.get("pending_sessions", {})
    
    for session_id, session_data in pending.items():
        status = session_data.get("status", "pending")
        session_inner = session_data.get("session_data", {})
        
        if status == "approved" or session_inner.get("verified", False):
            exportable[session_id] = session_data
    
    return exportable


@thread_safe
def get_pending_exportable_sessions() -> Dict[str, Dict[str, Any]]:
    """Get all pending sessions (not yet verified).
    
    Returns:
        Dict of session_id -> session_data for pending sessions
    """
    pending_export = {}
    pending = _storage.get("pending_sessions", {})
    
    for session_id, session_data in pending.items():
        status = session_data.get("status", "pending")
        session_inner = session_data.get("session_data", {})
        
        if status == "pending" and not session_inner.get("verified", False):
            pending_export[session_id] = session_data
    
    return pending_export


@thread_safe
def get_session_export_counts() -> Dict[str, int]:
    """Get counts of exportable sessions.
    
    Returns:
        Dict with 'active' and 'pending' counts
    """
    pending = _storage.get("pending_sessions", {})
    active_count = 0
    pending_count = 0
    
    for session_id, session_data in pending.items():
        status = session_data.get("status", "pending")
        session_inner = session_data.get("session_data", {})
        
        if status == "approved" or session_inner.get("verified", False):
            active_count += 1
        elif status == "pending" and not session_inner.get("verified", False):
            pending_count += 1
    
    return {"active": active_count, "pending": pending_count}


def delete_exported_sessions(session_ids: List[str]) -> int:
    """Delete sessions from storage after export.
    
    Note: This only deletes from bot storage, NOT from private channel.
    
    Args:
        session_ids: List of session IDs to delete
        
    Returns:
        Number of sessions deleted
    """
    deleted = 0
    with _storage_lock:
        for session_id in session_ids:
            if session_id in _storage.get("pending_sessions", {}):
                del _storage["pending_sessions"][session_id]
                deleted += 1
        
        if deleted > 0:
            _do_save()
            logger.info(f"Deleted {deleted} exported sessions from storage")
    
    return deleted


logger.info("Storage module loaded with thread-safe operations and retention policy support")
