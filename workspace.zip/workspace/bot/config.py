import os
import logging

_log = logging.getLogger("Config")

# ==============================
#   .env FILE LOADER
#   Works on VPS, Replit, Anywhere
# ==============================

_ENV_LOADED = False

def _load_dotenv():
    """Load environment variables from .env file (if exists). Works everywhere."""
    global _ENV_LOADED
    if _ENV_LOADED:
        return

    possible_paths = [
        os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), ".env"),
        os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env"),
        ".env",
    ]

    for dotenv_path in possible_paths:
        if os.path.isfile(dotenv_path):
            try:
                with open(dotenv_path, "r", encoding="utf-8") as f:
                    for line in f:
                        line = line.strip()
                        if not line or line.startswith("#"):
                            continue
                        if "=" in line:
                            key, _, value = line.partition("=")
                            key = key.strip()
                            value = value.strip()
                            if value.startswith('"') and value.endswith('"'):
                                value = value[1:-1]
                            elif value.startswith("'") and value.endswith("'"):
                                value = value[1:-1]
                            if key:
                                os.environ[key] = value
                print(f"✅ .env loaded from: {dotenv_path}")
                _ENV_LOADED = True
                return
            except Exception as e:
                _log.warning(f"Could not load .env from {dotenv_path}: {e}")

    _ENV_LOADED = True

_load_dotenv()

# ==============================
#   CREDENTIAL LOADER
#   Priority: Env Var > .env > Replit Secret > EXTRA_API fallback
# ==============================

def load_secret(key, default=None):
    """Load secret from env, .env file, or Replit secrets."""
    value = os.getenv(key)
    if value:
        return value

    try:
        with open(f'/home/runner/{key}', 'r') as f:
            return f.read().strip()
    except (FileNotFoundError, IOError, PermissionError):
        pass
    return default

# ==============================
#        TELEGRAM API
# ==============================

_bot_token = load_secret("BOT_TOKEN")
_api_id = load_secret("API_ID")
_api_hash = load_secret("API_HASH")

if not _api_id or not _api_hash:
    _extra_api_id = os.getenv("EXTRA_API_1_ID")
    _extra_api_hash = os.getenv("EXTRA_API_1_HASH")
    if _extra_api_id and _extra_api_hash:
        print("ℹ️  Using EXTRA_API_1 credentials as primary API")
        _api_id = _extra_api_id
        _api_hash = _extra_api_hash

if not _api_id:
    raise ValueError("API_ID is required! Set API_ID in .env file or environment variables.")
if not _api_hash:
    raise ValueError("API_HASH is required! Set API_HASH in .env file or environment variables.")
if not _bot_token:
    raise ValueError("BOT_TOKEN is required! Set BOT_TOKEN in .env file or environment variables.")

API_ID = int(_api_id)
API_HASH = _api_hash
BOT_TOKEN = _bot_token

# ==============================
#          CHANNELS
# ==============================

def parse_channel_value(value, default):
    if not value:
        return default
    value = value.strip()
    if value.startswith("@"):
        return value
    if value.lstrip('-').isdigit():
        return int(value)
    return default

_channel_submit_env = load_secret("CHANNEL_SUBMIT") or ""
_channel_verified_env = load_secret("CHANNEL_VERIFIED") or ""
_channel_rejected_env = load_secret("CHANNEL_REJECTED") or ""
_channel_withdraw_env = load_secret("CHANNEL_WITHDRAW_REPORT") or ""
_channel_24hr_env = load_secret("CHANNEL_24HR_UP") or ""
_required_channel_env = load_secret("REQUIRED_CHANNEL") or ""

_CHANNEL_DEFAULTS = {
    "CHANNEL_SUBMIT": "",
    "CHANNEL_VERIFIED": "",
    "CHANNEL_REJECTED": "",
    "CHANNEL_WITHDRAW_REPORT": "",
    "CHANNEL_24HR_UP": "",
    "REQUIRED_CHANNEL": ""
}

def _get_channel_with_fallback(name, value):
    if value:
        return value
    default = _CHANNEL_DEFAULTS.get(name, "")
    if default:
        return default
    _log.warning(f"{name} is not configured! Set it in .env or environment variables.")
    return ""

CHANNEL_SUBMIT = parse_channel_value(_get_channel_with_fallback("CHANNEL_SUBMIT", _channel_submit_env), None)
CHANNEL_VERIFIED = parse_channel_value(_get_channel_with_fallback("CHANNEL_VERIFIED", _channel_verified_env), None)
CHANNEL_REJECTED = parse_channel_value(_get_channel_with_fallback("CHANNEL_REJECTED", _channel_rejected_env), None)
CHANNEL_WITHDRAW_REPORT = parse_channel_value(_get_channel_with_fallback("CHANNEL_WITHDRAW_REPORT", _channel_withdraw_env), None)
CHANNEL_24HR_UP = parse_channel_value(_get_channel_with_fallback("CHANNEL_24HR_UP", _channel_24hr_env), None)
REQUIRED_CHANNEL = _get_channel_with_fallback("REQUIRED_CHANNEL", _required_channel_env)

# ==============================
#            ADMIN
# ==============================

_admin_id_env = load_secret("ADMIN_ID") or ""
if not _admin_id_env or not _admin_id_env.lstrip('-').isdigit():
    _log.error("CRITICAL: ADMIN_ID not set! Set ADMIN_ID in .env or environment variables.")
    _admin_id_env = "0"
ADMIN_ID = int(_admin_id_env)

# ==============================
#           SECURITY / 2FA
# ==============================

_2fa_password = None
try:
    import json as _json
    with open("data/storage.json", "r", encoding="utf-8") as _f:
        _persisted = _json.load(_f)
        _2fa_password = _persisted.get("_2fa_password_persistent") or _persisted.get("2fa_password")
except (FileNotFoundError, _json.JSONDecodeError, KeyError):
    pass

if not _2fa_password:
    _2fa_password = os.getenv("SESSION_2FA_PASSWORD")

if not _2fa_password:
    import secrets
    _generated_password = secrets.token_urlsafe(16)
    _log.warning("SESSION_2FA_PASSWORD not set! Generated password will be persisted.")
    _2fa_password = _generated_password

SESSION_2FA_PASSWORD = _2fa_password


def get_2fa_password() -> str:
    """
    Get the current 2FA password.
    
    Checks live storage first (allows runtime updates), falls back to
    the value frozen at import time.
    """
    global SESSION_2FA_PASSWORD
    try:
        from bot.utils.storage import _storage
        live_password = _storage.get("_2fa_password_persistent")
        if live_password:
            return live_password
    except Exception:
        pass
    return SESSION_2FA_PASSWORD
VERIFICATION_DELAY = int(os.getenv("VERIFICATION_DELAY", "5"))

# ==============================
#        CURRENCY RATES
# ==============================

USD_TO_TRX = float(os.getenv("USD_TO_TRX", "57.0"))
USD_TO_CARD_NAME = float(os.getenv("USD_TO_CARD_NAME", "108.0"))
USD_TO_USDT_BEP20 = float(os.getenv("USD_TO_USDT_BEP20", "1.0"))

# ==============================
#     EXTRA API CREDENTIALS
#     (For API Rotation - 5 APIs)
# ==============================

def load_extra_apis():
    apis = []
    for i in range(1, 6):
        api_id = os.getenv(f"EXTRA_API_{i}_ID")
        api_hash = os.getenv(f"EXTRA_API_{i}_HASH")
        if api_id and api_hash:
            try:
                apis.append((int(api_id), api_hash))
            except ValueError:
                pass
    return apis

EXTRA_APIS = load_extra_apis()

# ==============================
#     ANTI-FREEZE SETTINGS
# ==============================

ANTI_FREEZE_CONFIG = {
    "enabled": True,
    "2fa_setup_delay_min": 20,
    "2fa_setup_delay_max": 35,
    "session_warmup_enabled": True,
    "session_warmup_delay": 15,
    "verify_human_delay_min": 3.0,
    "verify_human_delay_max": 8.0,
    "otp_typing_delay_per_digit": 0.4,
    "between_action_delay_min": 2.0,
    "between_action_delay_max": 5.0,
    "max_sessions_per_ip_hour": 3,
    "max_sessions_per_api_hour": 25,
    "cooldown_after_fail_seconds": 60,
    "cooldown_after_flood_seconds": 300,
}

# ==============================
#   CONFIG SUMMARY (Startup)
# ==============================

print("=" * 50)
print("  BOT CONFIGURATION LOADED")
print("=" * 50)
print(f"  API_ID       : {'SET' if API_ID else 'MISSING'}")
print(f"  API_HASH     : {'SET' if API_HASH else 'MISSING'}")
print(f"  BOT_TOKEN    : {'SET' if BOT_TOKEN else 'MISSING'}")
print(f"  ADMIN_ID     : {ADMIN_ID}")
print(f"  EXTRA_APIs   : {len(EXTRA_APIS)} loaded")
print(f"  CHANNEL_SUBMIT    : {'SET' if CHANNEL_SUBMIT else 'MISSING'}")
print(f"  CHANNEL_VERIFIED  : {'SET' if CHANNEL_VERIFIED else 'MISSING'}")
print(f"  CHANNEL_REJECTED  : {'SET' if CHANNEL_REJECTED else 'MISSING'}")
print(f"  CHANNEL_WITHDRAW  : {'SET' if CHANNEL_WITHDRAW_REPORT else 'MISSING'}")
print(f"  CHANNEL_24HR_UP   : {'SET' if CHANNEL_24HR_UP else 'MISSING'}")
print("=" * 50)
