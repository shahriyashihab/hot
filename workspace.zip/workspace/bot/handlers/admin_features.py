"""
Admin Panel Core Features v2.0
==============================
Real-time monitoring, time-range stats, enhanced search, session details,
enhanced audit logs, DB health check, API rotation monitoring, 
session queue priority, auto-moderation rules, and bulk country config.
"""

import os
import json
from datetime import datetime
from typing import Dict, Any, List, Optional

from pyrogram.client import Client
from pyrogram import filters
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery, Message

from bot.utils.storage import (
    _storage, save_storage, get_user_info, get_total_users,
    get_exportable_sessions, get_pending_exportable_sessions,
    delete_exported_sessions, mark_session_message_sent,
    get_auto_approve_enabled, set_auto_approve_enabled,
    get_session_expiry_hours, set_session_expiry_hours,
    get_stuck_session_expiry_hours, set_stuck_session_expiry_hours,
)
from bot.utils.country_data import get_flag
from bot.handlers.admin import (
    admin_filter, admin_state, _admin_manager,
    _edit_in_place, _panel_reply, _set_admin_state,
    get_session_management_buttons,
)
from bot.config import ADMIN_ID, EXTRA_APIS, API_ID


def _db_available():
    try:
        from bot.utils.database import is_database_ready
        return is_database_ready()
    except Exception:
        return False


def _get_session_queue_stats():
    try:
        from bot.utils.session_queue import get_queue_manager
        q = get_queue_manager()
        return {
            "queue_size": len(q.queue) if hasattr(q, 'queue') else 0,
            "processing": len(q.processing) if hasattr(q, 'processing') else 0,
            "completed": len(q.completed) if hasattr(q, 'completed') else 0,
            "failed": len(q.failed) if hasattr(q, 'failed') else 0,
            "stats": getattr(q, 'stats', {}),
        }
    except Exception:
        return {"queue_size": 0, "processing": 0, "completed": 0, "failed": 0, "stats": {}}


def _build_realtime_monitor() -> str:
    now = datetime.now()
    try:
        user_count, active_count = get_total_users()
    except Exception:
        user_count, active_count = 0, 0

    try:
        pending = _storage.get("pending_sessions", {})
        pending_count = len(pending)
    except Exception:
        pending_count = 0

    try:
        tracker = _storage.get("session_tracker", {})
        today_verified = sum(len(s) for s in tracker.values())
    except Exception:
        today_verified = 0

    try:
        from bot.utils.storage import get_all_balances_report
        _, _, _, total_balance = get_all_balances_report()
    except Exception:
        total_balance = 0.0

    try:
        withdraws = _storage.get("withdrawals", [])
        pending_withdraws = sum(1 for w in withdraws if w.get("status") == "pending")
    except Exception:
        pending_withdraws = 0

    from bot.handlers.admin import get_monitor_status, is_verification_paused, is_spam_check_enabled

    monitor = "RUNNING" if get_monitor_status() else "PAUSED"
    verification = "ACTIVE" if not is_verification_paused() else "PAUSED"
    spam = "ENABLED" if is_spam_check_enabled() else "DISABLED"
    wd_status = "OPEN" if not _storage.get("withdraw_disabled", False) else "CLOSED"

    countries_configured = len(_storage.get("countries", {}))
    countries_open = sum(1 for d in _storage.get("countries", {}).values() if d.get("open", False))

    api_count = len(EXTRA_APIS) + 1

    db_status = "Connected" if _db_available() else "Not Connected"

    storage_file = "data/storage.json"
    storage_size = "N/A"
    if os.path.exists(storage_file):
        size_bytes = os.path.getsize(storage_file)
        if size_bytes < 1024 * 1024:
            storage_size = f"{size_bytes / 1024:.1f} KB"
        else:
            storage_size = f"{size_bytes / (1024 * 1024):.2f} MB"

    qstats = _get_session_queue_stats()

    return (
        "============================================\n"
        "     **REAL-TIME MONITOR DASHBOARD**\n"
        "============================================\n\n"
        "**LIVE STATISTICS**\n"
        f"  Users: {user_count:,} total / {active_count:,} active (24h)\n"
        f"  Sessions Today: {today_verified} verified\n"
        f"  Queue: {qstats['queue_size']} waiting | {qstats['processing']} processing\n"
        f"  Balance: ${total_balance:,.2f} unreleased\n"
        f"  Pending Withdrawals: {pending_withdraws}\n\n"
        "**SYSTEM STATUS**\n"
        f"  Monitor: {monitor} | Verify: {verification}\n"
        f"  Spam Check: {spam} | Withdraw: {wd_status}\n"
        f"  APIs: {api_count} configured | DB: {db_status}\n\n"
        "**RESOURCES**\n"
        f"  Storage: {storage_size} | Pending Queue: {pending_count}\n"
        f"  Countries: {countries_open}/{countries_configured} open\n\n"
        f"**Queue Stats:**\n"
        f"  Completed: {qstats['completed']} | Failed: {qstats['failed']}\n"
        f"  Processed: {qstats['stats'].get('total_processed', 0)} | "
        f"Success: {qstats['stats'].get('total_success', 0)}\n\n"
        f"Last Updated: {now.strftime('%Y-%m-%d %H:%M:%S')}\n"
        "============================================\n"
        "Select from the menu below:"
    )


def get_realtime_buttons():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("Refresh Dashboard", callback_data="realtime_refresh"),
         InlineKeyboardButton("DB Health Check", callback_data="db_health_check")],
        [InlineKeyboardButton("Time-Range Stats", callback_data="time_range_stats"),
         InlineKeyboardButton("Search User (All)", callback_data="enhanced_search")],
        [InlineKeyboardButton("Session Detail View", callback_data="session_detail_view"),
         InlineKeyboardButton("Audit Log (Enhanced)", callback_data="enhanced_audit_log")],
        [InlineKeyboardButton("API Rotation Monitor", callback_data="api_rotation_monitor"),
         InlineKeyboardButton("Queue Priority View", callback_data="queue_priority_view")],
        [InlineKeyboardButton("Auto-Moderation Rules", callback_data="auto_moderation_rules"),
         InlineKeyboardButton("Bulk Country Config", callback_data="bulk_country_config")],
        [InlineKeyboardButton("Back to Main Menu", callback_data="back_admin")],
    ])


def register_admin_features(app: Client):

    # ============================================================
    # 1. REAL-TIME MONITOR DASHBOARD
    # ============================================================
    @app.on_callback_query(admin_filter & filters.regex(r"^realtime_refresh$"))
    async def realtime_refresh_callback(client: Client, query: CallbackQuery):
        await query.answer("Refreshing...")
        msg = _build_realtime_monitor()
        try:
            await query.message.edit_text(msg, reply_markup=get_realtime_buttons())
        except Exception:
            await _edit_in_place(query.message, msg, reply_markup=get_realtime_buttons())

    # ============================================================
    # 6. DATABASE HEALTH CHECK
    # ============================================================
    @app.on_callback_query(admin_filter & filters.regex(r"^db_health_check$"))
    async def db_health_check_callback(client: Client, query: CallbackQuery):
        await query.answer("DB check running...")

        lines = ["=== DATABASE HEALTH CHECK ===\n"]
        db_ok = False

        try:
            from bot.utils.database import get_db_health_stats
            stats = await get_db_health_stats()
            db_ok = stats.get("connected", False)

            lines.append(f"Status: {'Connected' if db_ok else 'Not Connected'}")
            lines.append(f"Total DB Size: {stats.get('total_size', 'N/A')}")
            lines.append(f"Pool: {stats.get('pool_min', 0)}-{stats.get('pool_size', 0)} connections")
            lines.append(f"Active Connections: {stats.get('active_connections', 0)}\n")

            tables = stats.get("tables", {})
            if tables:
                lines.append("--- TABLE SIZES ---")
                for tname, tdata in sorted(tables.items()):
                    lines.append(
                        f"  {tname}: {tdata['data_size']} ({tdata['estimated_rows']:,} rows)"
                    )
            else:
                lines.append("No table data available.")

            if stats.get("error"):
                lines.append(f"\nError: {stats['error']}")

        except Exception as e:
            lines.append(f"DB check failed: {str(e)}")

        try:
            storage_file = "data/storage.json"
            if os.path.exists(storage_file):
                size_bytes = os.path.getsize(storage_file)
                lines.append(f"\nStorage File: {size_bytes / 1024:.1f} KB")
        except Exception:
            pass

        lines.append(f"\nLast Check: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

        await _edit_in_place(query.message, 
            "\n".join(lines),
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("Refresh", callback_data="db_health_check")],
                [InlineKeyboardButton("Back to Monitor", callback_data="realtime_refresh")],
            ])
        )

    # ============================================================
    # 2. TIME-RANGE STATISTICS (Today/Week/Month)
    # ============================================================
    @app.on_callback_query(admin_filter & filters.regex(r"^time_range_stats$"))
    async def time_range_stats_callback(client: Client, query: CallbackQuery):
        await query.answer()

        buttons = [
            [InlineKeyboardButton("Today", callback_data="trs_today"),
             InlineKeyboardButton("Last 7 Days", callback_data="trs_7days")],
            [InlineKeyboardButton("Last 30 Days", callback_data="trs_30days"),
             InlineKeyboardButton("Last 90 Days", callback_data="trs_90days")],
            [InlineKeyboardButton("Back to Monitor", callback_data="realtime_refresh")],
        ]

        await _edit_in_place(query.message, 
            "=== TIME-RANGE STATISTICS ===\n\n"
            "Select a time range to view detailed statistics:\n",
            reply_markup=InlineKeyboardMarkup(buttons)
        )

    @app.on_callback_query(admin_filter & filters.regex(r"^trs_(today|7days|30days|90days)$"))
    async def trs_range_callback(client: Client, query: CallbackQuery):
        import re
        match = re.match(r"^trs_(today|7days|30days|90days)$", str(query.data))
        range_key = match.group(1) if match else "today"

        range_map = {"today": 1, "7days": 7, "30days": 30, "90days": 90}
        range_names = {"today": "Today", "7days": "Last 7 Days", "30days": "Last 30 Days", "90days": "Last 90 Days"}
        days = range_map.get(range_key, 1)
        range_name = range_names.get(range_key, "Unknown")

        await query.answer(f"Loading {range_name}...")

        await _show_time_range_stats(query, days, range_name)

    async def _show_time_range_stats(query: CallbackQuery, days: int, range_name: str):
        lines = [f"=== STATISTICS: {range_name} ===\n"]

        try:
            from bot.utils.database import get_time_range_stats, get_hourly_transaction_stats
            stats = await get_time_range_stats(days)

            if stats:
                total_sessions = sum(s.get("total_sessions", 0) or 0 for s in stats)
                total_success = sum(s.get("successful_sessions", 0) or 0 for s in stats)
                total_failed = sum(s.get("failed_sessions", 0) or 0 for s in stats)
                total_earnings = sum(float(s.get("total_earnings", 0) or 0) for s in stats)
                success_rate = (total_success / total_sessions * 100) if total_sessions > 0 else 0

                lines.append(f"Total Sessions: {total_sessions:,}")
                lines.append(f"Successful: {total_success:,} ({success_rate:.1f}%)")
                lines.append(f"Failed: {total_failed:,}")
                lines.append(f"Total Earnings: ${total_earnings:,.2f}\n")

                lines.append("--- DAILY BREAKDOWN ---")
                for s in stats[:min(len(stats), 30)]:
                    date_str = str(s.get("date", "N/A"))
                    if isinstance(date_str, str) and len(date_str) > 10:
                        date_str = date_str[:10]
                    lines.append(
                        f"  {date_str}: {s.get('total_sessions', 0)} sessions "
                        f"(${float(s.get('total_earnings', 0) or 0):.2f})"
                    )
            else:
                try:
                    hstats = await get_hourly_transaction_stats(days * 24)
                    if hstats:
                        total_txns = sum(h.get("total_transactions", 0) for h in hstats)
                        total_amt = sum(float(h.get("total_amount", 0) or 0) for h in hstats)
                        lines.append(f"Total Transactions: {total_txns:,}")
                        lines.append(f"Total Amount: ${total_amt:,.2f}\n")
                        lines.append("--- HOURLY BREAKDOWN ---")
                        for h in hstats[:24]:
                            hour = str(h.get("hour", "N/A"))
                            if isinstance(hour, str) and len(hour) > 16:
                                hour = hour[11:16]
                            lines.append(
                                f"  {hour}: {h.get('total_transactions', 0)} txns "
                                f"(${float(h.get('total_amount', 0) or 0):.2f})"
                            )
                    else:
                        lines.append("No analytics data available yet.")
                        lines.append("Sessions will appear here once verified.")
                except Exception:
                    lines.append("No analytics data available yet.")

        except Exception as e:
            lines.append(f"Error loading stats: {str(e)}")

        tracker = _storage.get("session_tracker", {})
        if tracker:
            today_count = sum(len(s) for s in tracker.values())
            countries_set = set()
            for sessions in tracker.values():
                for s in sessions:
                    if isinstance(s, dict) and s.get("country_code"):
                        countries_set.add(s["country_code"])
            lines.append(f"\nReal-time Tracker: {today_count} sessions across {len(countries_set)} countries")

        lines.append(f"\nLast Updated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

        await _edit_in_place(query.message, 
            "\n".join(lines),
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("Back to Time Range", callback_data="time_range_stats")],
            ])
        )

    # ============================================================
    # 3. ENHANCED USER SEARCH (Name/Phone/Country)
    # ============================================================
    @app.on_callback_query(admin_filter & filters.regex(r"^enhanced_search$"))
    async def enhanced_search_callback(client: Client, query: CallbackQuery):
        await query.answer()

        buttons = [
            [InlineKeyboardButton("Search by User ID", callback_data="search_user"),
             InlineKeyboardButton("Search by Phone", callback_data="search_by_phone")],
            [InlineKeyboardButton("Search by Country Code", callback_data="search_by_country"),
             InlineKeyboardButton("View All Users", callback_data="totalusers")],
            [InlineKeyboardButton("Back to Monitor", callback_data="realtime_refresh")],
        ]

        await _edit_in_place(query.message, 
            "=== ENHANCED USER SEARCH ===\n\n"
            "Search users by name/phone/country/ID:\n",
            reply_markup=InlineKeyboardMarkup(buttons)
        )

    @app.on_callback_query(admin_filter & filters.regex(r"^search_by_phone$"))
    async def search_by_phone_callback(client: Client, query: CallbackQuery):
        await query.answer()
        uid = query.from_user.id
        _set_admin_state(uid, query, "search_phone")
        await _edit_in_place(query.message, 
            "=== SEARCH BY PHONE ===\n\n"
            "Enter part of the phone number (e.g. 88017 or 1712):\n\n"
            "Type /admin to cancel"
        )

    @app.on_callback_query(admin_filter & filters.regex(r"^search_by_country$"))
    async def search_by_country_callback(client: Client, query: CallbackQuery):
        await query.answer()
        uid = query.from_user.id
        _set_admin_state(uid, query, "search_country")
        await _edit_in_place(query.message, 
            "=== SEARCH BY COUNTRY ===\n\n"
            "Enter country code (e.g. +880, +1, +44):\n\n"
            "Type /admin to cancel"
        )

    async def _do_phone_search(user_id, message, phone_pattern):
        results = []
        users = _storage.get("users", {})
        pending = _storage.get("pending_sessions", {})
        session_tracker = _storage.get("session_tracker", {})

        for uid, uinfo in users.items():
            matched = False
            for sid, sdata in pending.items():
                if str(sdata.get("user_id", "")) == uid and phone_pattern.lower() in str(sdata.get("phone", "")).lower():
                    results.append({
                        "user_id": uid, "phone": sdata.get("phone", "N/A"),
                        "country": sdata.get("country_code", "N/A"),
                        "balance": uinfo.get("balance", 0),
                        "sessions": uinfo.get("sessions", 0),
                        "banned": uinfo.get("banned", False),
                    })
                    matched = True
                    break
            if not matched:
                for tracker_sessions in session_tracker.values():
                    for s in tracker_sessions:
                        if isinstance(s, dict) and s.get("user_id") == int(uid) if uid.isdigit() else False:
                            if phone_pattern.lower() in str(s.get("phone", "")).lower():
                                results.append({
                                    "user_id": uid, "phone": s.get("phone", "N/A"),
                                    "country": s.get("country_code", "N/A"),
                                    "balance": uinfo.get("balance", 0),
                                    "sessions": uinfo.get("sessions", 0),
                                    "banned": uinfo.get("banned", False),
                                })
                                matched = True
                                break
                    if matched:
                        break

        if not results and _db_available():
            try:
                from bot.utils.database import search_users_by_phone
                db_results = await search_users_by_phone(phone_pattern, 20)
                for r in db_results:
                    uid = str(r.get("user_id", ""))
                    uinfo = users.get(uid, {})
                    results.append({
                        "user_id": uid, "phone": r.get("phone", "N/A"),
                        "country": r.get("country_code", "N/A"),
                        "balance": uinfo.get("balance", 0),
                        "sessions": uinfo.get("sessions", 0),
                        "banned": uinfo.get("banned", False),
                    })
            except Exception:
                pass

        return results

    # ============================================================
    # 4. SESSION DETAIL VIEW
    # ============================================================
    @app.on_callback_query(admin_filter & filters.regex(r"^session_detail_view$"))
    async def session_detail_view_callback(client: Client, query: CallbackQuery):
        await query.answer()
        uid = query.from_user.id
        _set_admin_state(uid, query, "session_detail")
        await _edit_in_place(query.message, 
            "=== SESSION DETAIL VIEW ===\n\n"
            "Enter the Session ID to view details:\n\n"
            "Type /admin to cancel"
        )

    async def _show_session_detail(client, message, session_id):
        session_data = None
        session_type = "pending"

        pending = _storage.get("pending_sessions", {})
        if session_id in pending:
            session_data = pending[session_id]
            session_type = "pending"

        if not session_data:
            tracker = _storage.get("session_tracker", {})
            for uid, sessions in tracker.items():
                for s in sessions:
                    if isinstance(s, dict) and s.get("session_id") == session_id:
                        session_data = {
                            **s,
                            "user_id": uid,
                            "status": "verified",
                        }
                        session_type = "verified"
                        break
                if session_data:
                    break

        if not session_data and _db_available():
            try:
                from bot.utils.database import get_session_detail
                db_detail = await get_session_detail(session_id)
                if db_detail:
                    session_data = db_detail
                    session_type = db_detail.get("session_type", "verified")
            except Exception:
                pass

        if not session_data:
            await _panel_reply(client, message.from_user.id, message, 
                f"Session not found!\n\nID: `{session_id}`\n\n"
                "Please enter a valid Session ID."
            )
            return

        phone = session_data.get("phone", "N/A")
        country_code = session_data.get("country_code", "N/A")
        status = session_data.get("status", session_type)
        user_id = session_data.get("user_id", "N/A")
        flag = get_flag(country_code) if country_code != "N/A" else ""

        submitted = session_data.get("submitted_at") or session_data.get("created_at") or "N/A"
        if isinstance(submitted, str) and len(submitted) > 16:
            submitted = submitted[:16].replace("T", " ")

        spam_status = session_data.get("spam_status", "N/A")
        error_count = session_data.get("error_count", 0)

        lines = [
            "=== SESSION DETAIL ===\n",
            f"Session ID: `{session_id[:30]}...`",
            f"Type: {session_type.upper()}",
            f"Phone: {phone} {flag}",
            f"Country: {country_code}",
            f"User ID: `{user_id}`",
            f"Status: {status}",
            f"Spam: {spam_status}",
            f"Submitted: {submitted}",
            f"Error Count: {error_count}",
        ]

        errors = session_data.get("errors", [])
        if errors:
            lines.append(f"\n--- ERRORS ({len(errors)}) ---")
            for e in errors[:5]:
                reason = e.get("reason", "N/A")[:80]
                err_type = e.get("error_type", "")
                et = f" [{err_type}]" if err_type else ""
                lines.append(f"  {reason}{et}")

        txns = session_data.get("transactions", [])
        if txns:
            lines.append(f"\n--- TRANSACTIONS ({len(txns)}) ---")
            for t in txns[:5]:
                action = t.get("action", "N/A")
                amount = t.get("amount", 0)
                lines.append(f"  {action}: ${amount:.2f}")

        user_info = get_user_info(int(user_id), create_if_missing=False) if str(user_id).isdigit() else None
        if user_info:
            lines.append(f"\n--- USER INFO ---")
            lines.append(f"  Balance: ${user_info.get('balance', 0):.2f}")
            lines.append(f"  Sessions: {user_info.get('sessions', 0)}")
            lines.append(f"  Banned: {user_info.get('banned', False)}")

        await _panel_reply(client, message.from_user.id, message, "\n".join(lines))

    # ============================================================
    # 5. ENHANCED AUDIT LOG
    # ============================================================
    @app.on_callback_query(admin_filter & filters.regex(r"^enhanced_audit_log$"))
    async def enhanced_audit_log_callback(client: Client, query: CallbackQuery):
        await query.answer("Loading audit logs...")
        await _show_enhanced_audit_log(query, page=1)

    @app.on_callback_query(admin_filter & filters.regex(r"^audit_log_page_(\d+)$"))
    async def audit_log_page_callback(client: Client, query: CallbackQuery):
        await query.answer()
        import re
        match = re.match(r"^audit_log_page_(\d+)$", str(query.data))
        page = int(match.group(1)) if match else 1
        await _show_enhanced_audit_log(query, page=page)

    async def _show_enhanced_audit_log(query: CallbackQuery, page: int = 1):
        PER_PAGE = 10
        logs = []

        admin_logs = _storage.get("admin_logs", [])
        for entry in reversed(admin_logs):
            logs.append({
                "type": "admin_action",
                "timestamp": entry.get("timestamp", "N/A"),
                "action": entry.get("action", "N/A"),
                "details": entry,
            })

        txn_logs = _storage.get("transaction_logs", [])
        for entry in reversed(txn_logs):
            logs.append({
                "type": "transaction",
                "timestamp": entry.get("timestamp", "N/A"),
                "action": entry.get("action", "N/A"),
                "details": entry,
            })

        if _db_available():
            try:
                from bot.utils.database import get_recent_admin_logs
                db_logs = await get_recent_admin_logs(50)
                for entry in db_logs:
                    ts = str(entry.get("created_at", ""))
                    if len(ts) > 16:
                        ts = ts[:16].replace("T", " ")
                    logs.append({
                        "type": "db_admin",
                        "timestamp": ts,
                        "action": entry.get("action", "N/A"),
                        "details": entry,
                    })
            except Exception:
                pass

        logs.sort(key=lambda x: str(x.get("timestamp", "")), reverse=True)

        total_pages = max(1, (len(logs) + PER_PAGE - 1) // PER_PAGE)
        page = max(1, min(page, total_pages))
        start = (page - 1) * PER_PAGE
        page_logs = logs[start:start + PER_PAGE]

        lines = [
            "=== ENHANCED AUDIT LOG ===\n",
            f"Total Entries: {len(logs)} | Page {page}/{total_pages}\n",
        ]

        if not page_logs:
            lines.append("No log entries found.")
        else:
            for i, entry in enumerate(page_logs, start + 1):
                ts = str(entry.get("timestamp", "N/A"))
                if isinstance(ts, str) and len(ts) > 16:
                    ts = ts[:16].replace("T", " ")
                action = entry.get("action", "N/A")
                etype = entry.get("type", "")

                lines.append(f"#{i} [{etype}] {ts} - {action}")

                details = entry.get("details", {})
                if isinstance(details, dict):
                    uid = details.get("user_id") or details.get("target_user_id") or ""
                    if uid:
                        lines.append(f"    User: `{uid}`")
                    amt = details.get("amount", "")
                    if amt:
                        lines.append(f"    Amount: ${amt}")

        buttons = []
        nav = []
        if page > 1:
            nav.append(InlineKeyboardButton("Previous", callback_data=f"audit_log_page_{page - 1}"))
        if page < total_pages:
            nav.append(InlineKeyboardButton("Next", callback_data=f"audit_log_page_{page + 1}"))
        if nav:
            buttons.append(nav)
        buttons.append([InlineKeyboardButton("Back to Monitor", callback_data="realtime_refresh")])

        await _edit_in_place(query.message, "\n".join(lines), reply_markup=InlineKeyboardMarkup(buttons))

    # ============================================================
    # 7. API ROTATION MONITORING
    # ============================================================
    @app.on_callback_query(admin_filter & filters.regex(r"^api_rotation_monitor$"))
    async def api_rotation_monitor_callback(client: Client, query: CallbackQuery):
        await query.answer("Loading API status...")

        lines = ["=== API ROTATION MONITOR ===\n"]

        try:
            from bot.utils.api_rotation import get_api_manager
            mgr = get_api_manager()
            apis = getattr(mgr, 'apis', []) if mgr else []

            total_sessions = 0
            total_success = 0
            active_apis = 0

            lines.append(f"Total APIs: {len(apis) or 1}")
            lines.append(f"Round-Robin Index: {getattr(mgr, 'current_index', 0) if mgr else 0}\n")

            lines.append("--- API DETAILS ---")
            for api in apis:
                available = api.is_available() if hasattr(api, 'is_available') else False
                name = getattr(api, 'name', 'API')
                status_icon = "ON" if available else "OFF"
                if available:
                    active_apis += 1

                lines.append(
                    f"  {name}: {status_icon} | "
                    f"{api.sessions_today}/{api.daily_limit} today "
                    f"({api.sessions_this_hour}/{api.hourly_limit} hr) | "
                    f"SR: {api.success_rate:.0%}"
                )
                total_sessions += api.sessions_today
                total_success += api.success_count

        except Exception as e:
            lines.append(f"Error loading API data: {str(e)}")

        from bot.config import API_ID, API_HASH
        api_count = len(EXTRA_APIS) + 1
        lines.append(f"\nPrimary API: ID {str(API_ID)[:6]}...")
        for i in range(1, 6):
            api_id_env = os.getenv(f"EXTRA_API_{i}_ID")
            if api_id_env:
                lines.append(f"Extra API {i}: ID {str(api_id_env)[:6]}... (configured)")
            else:
                lines.append(f"Extra API {i}: Not configured")

        lines.append(f"\nEst. Throughput: ~{min(active_apis, 1) * 25} sessions/hour")
        lines.append(f"\nLast Check: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

        await _edit_in_place(query.message, 
            "\n".join(lines),
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("Refresh", callback_data="api_rotation_monitor")],
                [InlineKeyboardButton("Back to Monitor", callback_data="realtime_refresh")],
            ])
        )

    # ============================================================
    # 8. SESSION VERIFICATION QUEUE PRIORITY
    # ============================================================
    @app.on_callback_query(admin_filter & filters.regex(r"^queue_priority_view$"))
    async def queue_priority_view_callback(client: Client, query: CallbackQuery):
        await query.answer("Loading queue...")

        qstats = _get_session_queue_stats()

        lines = [
            "=== SESSION VERIFICATION QUEUE ===\n",
            f"Queue Size: {qstats['queue_size']}",
            f"Processing: {qstats['processing']}",
            f"Completed: {qstats['completed']}",
            f"Failed: {qstats['failed']}\n",
        ]

        stats = qstats.get("stats", {})
        if stats:
            lines.append("--- PERFORMANCE ---")
            lines.append(f"  Total Processed: {stats.get('total_processed', 0)}")
            lines.append(f"  Total Success: {stats.get('total_success', 0)}")
            lines.append(f"  Total Failed: {stats.get('total_failed', 0)}")
            lines.append(f"  Retried: {stats.get('total_retried', 0)}")

        pending = _storage.get("pending_sessions", {})
        status_counts = {}
        for sid, data in pending.items():
            status = data.get("status", "pending")
            status_counts[status] = status_counts.get(status, 0) + 1

        if status_counts:
            lines.append(f"\n--- PENDING SESSION STATUS ---")
            for status, count in sorted(status_counts.items()):
                icon = {"pending": "Pending", "approved": "Approved", "rejected": "Rejected", "timeout": "Timeout"}.get(status, status.title())
                lines.append(f"  {icon}: {count}")

        lines.append(f"\nLast Updated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

        await _edit_in_place(query.message, 
            "\n".join(lines),
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("Refresh", callback_data="queue_priority_view")],
                [InlineKeyboardButton("View Pending Sessions", callback_data="view_pending_sessions")],
                [InlineKeyboardButton("Back to Monitor", callback_data="realtime_refresh")],
            ])
        )

    # ============================================================
    # 9. AUTO-MODERATION RULES
    # ============================================================
    @app.on_callback_query(admin_filter & filters.regex(r"^auto_moderation_rules$"))
    async def auto_moderation_rules_callback(client: Client, query: CallbackQuery):
        await query.answer()

        rules = _storage.get("auto_moderation_rules", {})
        if not rules:
            rules = {
                "max_sessions_per_user_per_day": 10,
                "auto_ban_on_spam_country": False,
                "spam_score_threshold": 0.7,
                "auto_reject_high_risk": False,
                "cooldown_after_fail": 60,
            }

        spam_enabled = _storage.get("spam_check_enabled", True)
        countries = _storage.get("countries", {})

        rules_text = "\n".join([
            f"  {k}: {v}" for k, v in rules.items()
        ])

        lines = [
            "=== AUTO-MODERATION RULES ===\n",
            f"Spam Check: {'ENABLED' if spam_enabled else 'DISABLED'}",
            f"Configured Countries: {len(countries)}\n",
            "--- CURRENT RULES ---",
            rules_text,
            "\n--- COUNTRY RISK PROFILES ---",
        ]

        try:
            from bot.utils.anti_spam import COUNTRY_PROFILES
            for code, profile in sorted(COUNTRY_PROFILES.items()):
                name = profile.get("name", code)
                risk = profile.get("risk_level", 0)
                freeze = profile.get("freeze_risk", "unknown")
                delay = f"{profile.get('min_delay', 0)}-{profile.get('max_delay', 0)}s"

                risk_labels = {1: "Low", 2: "Medium", 3: "High", 4: "Critical"}
                risk_label = risk_labels.get(risk, str(risk))

                is_open = countries.get(code, {}).get("open", False)
                status = "Open" if is_open else "Closed"

                lines.append(
                    f"  {code} {name}: Risk={risk_label} | "
                    f"Freeze={freeze} | Delay={delay} | {status}"
                )
        except Exception:
            lines.append("  (Could not load country risk profiles)")

        buttons = [
            [InlineKeyboardButton("Edit Rules", callback_data="edit_moderation_rules")],
            [InlineKeyboardButton("Toggle Spam Check", callback_data="togglespamcheck")],
            [InlineKeyboardButton("Back to Monitor", callback_data="realtime_refresh")],
        ]

        await _edit_in_place(query.message, 
            "\n".join(lines),
            reply_markup=InlineKeyboardMarkup(buttons)
        )

    @app.on_callback_query(admin_filter & filters.regex(r"^edit_moderation_rules$"))
    async def edit_moderation_rules_callback(client: Client, query: CallbackQuery):
        await query.answer()
        uid = query.from_user.id
        _set_admin_state(uid, query, "edit_mod_rules")

        current = _storage.get("auto_moderation_rules", {
            "max_sessions_per_user_per_day": 10,
            "auto_ban_on_spam_country": False,
            "spam_score_threshold": 0.7,
            "auto_reject_high_risk": False,
            "cooldown_after_fail": 60,
        })

        await _edit_in_place(query.message, 
            "=== EDIT MODERATION RULES ===\n\n"
            "Enter new rules in the format below (JSON):\n\n"
            f"Current: `{json.dumps(current, indent=2)}`\n\n"
            "Example: `{\"max_sessions_per_user_per_day\": 5, \"auto_ban_on_spam_country\": true}`\n\n"
            "Type /admin to cancel"
        )

    # ============================================================
    # 10. BULK COUNTRY CONFIG (Import/Export)
    # ============================================================
    @app.on_callback_query(admin_filter & filters.regex(r"^bulk_country_config$"))
    async def bulk_country_config_callback(client: Client, query: CallbackQuery):
        await query.answer()

        countries = _storage.get("countries", {})
        total = len(countries)
        open_count = sum(1 for d in countries.values() if d.get("open", False))

        buttons = [
            [InlineKeyboardButton("Export Country Config", callback_data="export_country_config"),
             InlineKeyboardButton("Import Country Config", callback_data="import_country_config")],
            [InlineKeyboardButton("Disable All Countries", callback_data="disablecountries"),
             InlineKeyboardButton("Enable All Configured", callback_data="enable_all_countries")],
            [InlineKeyboardButton("Back to Monitor", callback_data="realtime_refresh")],
        ]

        await _edit_in_place(query.message, 
            f"=== BULK COUNTRY CONFIG ===\n\n"
            f"Total Configured: {total}\n"
            f"Open: {open_count}\n"
            f"Closed: {total - open_count}\n\n"
            f"Export/Import country configuration:\n",
            reply_markup=InlineKeyboardMarkup(buttons)
        )

    @app.on_callback_query(admin_filter & filters.regex(r"^export_country_config$"))
    async def export_country_config_callback(client: Client, query: CallbackQuery):
        await query.answer("Exporting...")

        countries = _storage.get("countries", {})
        if not countries:
            await _edit_in_place(query.message, 
                "No country configuration to export.",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("Back", callback_data="bulk_country_config")],
                ])
            )
            return

        export_data = {}
        for code, data in sorted(countries.items()):
            export_data[code] = {
                "open": data.get("open", False),
                "spam_free_rate": data.get("spam_free_rate", data.get("rate", 0)),
                "spam_rate": data.get("spam_rate", 0),
                "limit_rate": data.get("limit_rate", 0),
                "timeout": data.get("timeout", 300),
            }

        json_str = json.dumps(export_data, indent=2, ensure_ascii=False)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"country_config_{timestamp}.json"
        filepath = f"/tmp/{filename}"

        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(json_str)

        await client.send_document(
            chat_id=query.message.chat.id,
            document=filepath,
            caption=(
                f"Country Configuration Export\n"
                f"Countries: {len(export_data)}\n"
                f"Export Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n"
                f"Use Bulk Country Config to import."
            ),
            file_name=filename
        )

        try:
            os.remove(filepath)
        except OSError:
            pass

    @app.on_callback_query(admin_filter & filters.regex(r"^import_country_config$"))
    async def import_country_config_callback(client: Client, query: CallbackQuery):
        await query.answer()
        uid = query.from_user.id
        _set_admin_state(uid, query, "import_countries")
        await _edit_in_place(query.message, 
            "=== IMPORT COUNTRY CONFIG ===\n\n"
            "Send country config in JSON format:\n\n"
            "Example:\n"
            '```json\n{"+880": {"open": true, "spam_free_rate": 30, "spam_rate": 15, "limit_rate": 10, "timeout": 60}}\n```\n\n'
            "Type /admin to cancel"
        )

    @app.on_callback_query(admin_filter & filters.regex(r"^enable_all_countries$"))
    async def enable_all_countries_callback(client: Client, query: CallbackQuery):
        await query.answer()
        countries = _storage.get("countries", {})
        if not countries:
            await _edit_in_place(query.message, 
                "No countries configured!\n\n"
                "First set country rates via Country & Pricing.",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("Back", callback_data="bulk_country_config")],
                ])
            )
            return

        for code in countries:
            countries[code]["open"] = True
        save_storage()

        await _edit_in_place(query.message, 
            f"All {len(countries)} configured countries ENABLED!",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("Back", callback_data="bulk_country_config")],
            ])
        )

    # ============================================================
    # INPUT HANDLER for admin_features actions
    # ============================================================
    @app.on_message(admin_filter & filters.text & ~filters.command(["admin", "start", "account", "withdraw", "cap", "support", "cancel"]))
    async def handle_features_input(client: Client, message: Message):
        user_id = message.from_user.id
        if user_id not in admin_state:
            message.continue_propagation()
            return

        action = admin_state[user_id].get("action", "")
        text = message.text.strip()

        FEATURE_ACTIONS = {"search_phone", "search_country", "session_detail", "edit_mod_rules", "import_countries", "alert_threshold"}
        if action not in FEATURE_ACTIONS:
            message.continue_propagation()
            return

        try:
            if action == "search_phone":
                results = await _do_phone_search(user_id, message, text)
                if not results:
                    await _panel_reply(client, user_id, message, 
                        f"No users found with phone pattern: `{text}`",
                        reply_markup=InlineKeyboardMarkup([
                            [InlineKeyboardButton("Try Again", callback_data="search_by_phone")],
                            [InlineKeyboardButton("Back to Search", callback_data="enhanced_search")],
                        ])
                    )
                else:
                    lines = [f"=== Search Results: '{text}' ===\n", f"Found: {len(results)} users\n"]
                    for r in results[:20]:
                        uid = r.get("user_id", "N/A")
                        phone = r.get("phone", "N/A")
                        country = r.get("country", "N/A")
                        balance = r.get("balance", 0)
                        banned = "BANNED" if r.get("banned") else "ACTIVE"
                        flag = get_flag(country) if country != "N/A" else ""
                        lines.append(
                            f"User: `{uid}` | {phone} {flag}\n"
                            f"  Country: {country} | ${balance:.2f} | {banned}"
                        )

                    buttons = []
                    for r in results[:10]:
                        uid = r.get("user_id", "")
                        buttons.append([
                            InlineKeyboardButton(
                                f"View User {uid}",
                                callback_data=f"quick_view_user_{uid}"
                            )
                        ])
                    buttons.append([InlineKeyboardButton("Back to Search", callback_data="enhanced_search")])

                    await _panel_reply(client, user_id, message, 
                        "\n".join(lines),
                        reply_markup=InlineKeyboardMarkup(buttons)
                    )

                _admin_manager.clear_state(user_id)

            elif action == "search_country":
                country_code = text.strip()
                if not country_code.startswith("+"):
                    country_code = "+" + country_code

                results = []
                pending = _storage.get("pending_sessions", {})
                for sid, sdata in pending.items():
                    if str(sdata.get("country_code", "")).upper() == country_code.upper():
                        results.append(sdata)

                if not results:
                    await _panel_reply(client, user_id, message, 
                        f"No sessions found for country: `{country_code}`",
                        reply_markup=InlineKeyboardMarkup([
                            [InlineKeyboardButton("Try Again", callback_data="search_by_country")],
                            [InlineKeyboardButton("Back to Search", callback_data="enhanced_search")],
                        ])
                    )
                else:
                    flag = get_flag(country_code)
                    lines = [
                        f"=== Country: {country_code} {flag} ===\n",
                        f"Total Sessions: {len(results)}\n",
                    ]
                    for r in results[:20]:
                        phone = r.get("phone", "N/A")
                        status = r.get("status", "N/A")
                        uid = r.get("user_id", "N/A")
                        lines.append(f"  {phone} | User: `{uid}` | {status}")

                    await _panel_reply(client, user_id, message, 
                        "\n".join(lines),
                        reply_markup=InlineKeyboardMarkup([
                            [InlineKeyboardButton("Back to Search", callback_data="enhanced_search")],
                        ])
                    )

                _admin_manager.clear_state(user_id)

            elif action == "session_detail":
                await _show_session_detail(client, message, text)
                _admin_manager.clear_state(user_id)

            elif action == "edit_mod_rules":
                try:
                    new_rules = json.loads(text)
                    current = _storage.get("auto_moderation_rules", {})
                    current.update(new_rules)
                    _storage["auto_moderation_rules"] = current
                    save_storage()
                    await _panel_reply(client, user_id, message, 
                        "Moderation rules updated!\n\n"
                        f"```json\n{json.dumps(current, indent=2)}\n```",
                        reply_markup=InlineKeyboardMarkup([
                            [InlineKeyboardButton("Back to Rules", callback_data="auto_moderation_rules")],
                        ])
                    )
                except json.JSONDecodeError:
                    await _panel_reply(client, user_id, message, 
                        "Invalid JSON format! Please try again with valid JSON."
                    )
                _admin_manager.clear_state(user_id)

            elif action == "import_countries":
                try:
                    import_data = json.loads(text)
                    if not isinstance(import_data, dict):
                        await _panel_reply(client, user_id, message, "Invalid format: JSON must be a dictionary of country codes.")
                        _admin_manager.clear_state(user_id)
                        return

                    countries = _storage.get("countries", {})
                    imported = 0
                    skipped = 0
                    for code, data in import_data.items():
                        if not isinstance(data, dict):
                            skipped += 1
                            continue
                        countries[code] = {
                            "open": data.get("open", False),
                            "spam_free_rate": data.get("spam_free_rate", data.get("rate", 0)),
                            "spam_rate": data.get("spam_rate", 0),
                            "limit_rate": data.get("limit_rate", 0),
                            "timeout": data.get("timeout", 300),
                        }
                        imported += 1

                    _storage["countries"] = countries
                    save_storage()

                    await _panel_reply(client, user_id, message, 
                        f"Country config imported!\n\n"
                        f"Imported: {imported}\n"
                        f"Skipped: {skipped}\n"
                        f"Total: {len(countries)} countries configured.",
                        reply_markup=InlineKeyboardMarkup([
                            [InlineKeyboardButton("View All", callback_data="view_all_countries")],
                            [InlineKeyboardButton("Back to Config", callback_data="bulk_country_config")],
                        ])
                    )
                except json.JSONDecodeError:
                    await _panel_reply(client, user_id, message, 
                        "Invalid JSON format!\n\n"
                        "Make sure you send valid JSON with country codes as keys."
                    )
                _admin_manager.clear_state(user_id)

            elif action == "alert_threshold":
                parts = text.strip().split()
                if len(parts) != 2:
                    thresholds = _storage.get("alert_thresholds", {})
                    current = "\n".join(
                        f"  `{name}`: `{val}`" for name, val in thresholds.items()
                    ) if thresholds else "  None set"
                    await _panel_reply(client, user_id, message, 
                        "❌ Format: `alert_name value`\n\n"
                        "Examples:\n"
                        "  `low_balance 100` - alert when balance < $100\n"
                        "  `reject_rate 0.3` - alert when reject rate > 30%\n\n"
                        f"**Current thresholds:**\n{current}"
                    )
                    _admin_manager.clear_state(user_id)
                    return

                alert_type = parts[0].strip().lower()
                try:
                    threshold = float(parts[1])
                except ValueError:
                    await _panel_reply(client, user_id, message, "❌ Threshold must be a number!")
                    _admin_manager.clear_state(user_id)
                    return

                if "alert_thresholds" not in _storage:
                    _storage["alert_thresholds"] = {}
                _storage["alert_thresholds"][alert_type] = threshold
                save_storage()

                await _panel_reply(client, user_id, message, 
                    f"✅ `{alert_type.replace('_', ' ').title()}` threshold set to `{threshold}`",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("Back to Alert Settings", callback_data="alert_system_config")]
                    ])
                )
                _admin_manager.clear_state(user_id)

        except Exception as e:
            await _panel_reply(client, user_id, message, f"Error: {str(e)}")
            _admin_manager.clear_state(user_id)

    # ============================================================
    # QUICK VIEW USER (from search results)
    # ============================================================
    @app.on_callback_query(admin_filter & filters.regex(r"^quick_view_user_(\d+)$"))
    async def quick_view_user_callback(client: Client, query: CallbackQuery):
        await query.answer()
        import re
        match = re.match(r"^quick_view_user_(\d+)$", str(query.data))
        if not match:
            return
        search_uid = int(match.group(1))

        user_info = get_user_info(search_uid, create_if_missing=False)
        if not user_info:
            await _edit_in_place(query.message, 
                f"User `{search_uid}` not found.",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("Back to Search", callback_data="enhanced_search")],
                ])
            )
            return

        balance = user_info.get("balance", 0)
        sessions = user_info.get("sessions", 0)
        banned = user_info.get("banned", False)
        joined = user_info.get("joined", "N/A")
        country_sessions = user_info.get("country_sessions", {})

        banned_status = "Banned" if banned else "Active"

        country_lines = []
        for cc, count in sorted(country_sessions.items(), key=lambda x: x[1], reverse=True)[:5]:
            flag = get_flag(cc) if cc != "other" else ""
            country_lines.append(f"  {flag} {cc}: {count}")

        buttons = [
            [
                InlineKeyboardButton("Ban", callback_data=f"quick_ban_{search_uid}"),
                InlineKeyboardButton("Unban", callback_data=f"quick_unban_{search_uid}")
            ],
            [InlineKeyboardButton("Back to Search", callback_data="enhanced_search")],
        ]

        await _edit_in_place(query.message, 
            f"=== User Info ===\n\n"
            f"User ID: `{search_uid}`\n"
            f"Balance: ${balance:.2f}\n"
            f"Sessions: {sessions}\n"
            f"Status: {banned_status}\n"
            f"Joined: {joined[:10] if len(str(joined)) > 10 else joined}\n\n"
            f"Country Sessions:\n" + "\n".join(country_lines if country_lines else ["  None"]),
            reply_markup=InlineKeyboardMarkup(buttons)
        )

    print("Admin Features v2.0 registered successfully")

    # ============================================================
    # 10 NEW CRITICAL FEATURES
    # ============================================================
    
    # ============================================================
    # FEATURE 1: Remove Balance (Debit from user)
    # ============================================================
    @app.on_callback_query(admin_filter & filters.regex(r"^removebalance$"))
    async def remove_balance_callback(client: Client, query: CallbackQuery):
        await query.answer()
        user_id = query.from_user.id
        _set_admin_state(user_id, query, "remove_balance")
        await _edit_in_place(query.message, 
            "💸 **Remove Balance (Debit)**\n"
            "━━━━━━━━━━━━━━━━━━━━━\n\n"
            "Send User ID and Amount:\n"
            "`123456789 50.00`\n\n"
            "Or just Amount to remove from yourself:\n"
            "`10.00`\n\n"
            "/cancel to abort"
        )

    # ============================================================
    # FEATURE 2: Set Individual User Rate
    # ============================================================
    @app.on_callback_query(admin_filter & filters.regex(r"^setuserrate$"))
    async def set_user_rate_callback(client: Client, query: CallbackQuery):
        await query.answer()
        user_id = query.from_user.id
        _set_admin_state(user_id, query, "set_user_rate")
        await _edit_in_place(query.message, 
            "💰 **Set Individual User Rate**\n"
            "━━━━━━━━━━━━━━━━━━━━━\n\n"
            "Send User ID, Country Code, and Price:\n"
            "`123456789 BD 15.50`\n\n"
            "/cancel to abort"
        )

    # ============================================================
    # FEATURE 4: User Activity Logs
    # ============================================================
    @app.on_callback_query(admin_filter & filters.regex(r"^useractivitylogs$"))
    async def user_activity_logs_callback(client: Client, query: CallbackQuery):
        await query.answer()
        user_id = query.from_user.id
        _set_admin_state(user_id, query, "activity_logs_user")
        await _edit_in_place(query.message, 
            "📊 **User Activity Logs**\n"
            "━━━━━━━━━━━━━━━━━━━━━\n\n"
            "Send User ID to view activity logs:\n\n"
            "/cancel to abort"
        )

    # ============================================================
    # FEATURE 6: Blacklist Management
    # ============================================================
    @app.on_callback_query(admin_filter & filters.regex(r"^blacklist_mgmt$"))
    async def blacklist_mgmt_callback(client: Client, query: CallbackQuery):
        await query.answer()
        
        blacklist = _storage.get("blacklist", [])
        
        text = "🚫 **Blacklist Management**\n"
        text += "━━━━━━━━━━━━━━━━━━━━━\n\n"
        text += f"Total Blacklisted Users: `{len(blacklist)} `\n\n"
        
        if blacklist:
            text += "**Blacklisted User IDs:**\n"
            for uid in blacklist[:20]:
                text += f"  `{uid}`\n"
            if len(blacklist) > 20:
                text += f"  ... and {len(blacklist) - 20} more\n"
        else:
            text += "No users blacklisted.\n"
        
        text += "\nUse the buttons below to manage the blacklist."
        
        buttons = [
            [InlineKeyboardButton("Add to Blacklist", callback_data="blacklist_add_input")],
            [InlineKeyboardButton("Remove from Blacklist", callback_data="blacklist_remove_input")],
            [InlineKeyboardButton("Clear Blacklist", callback_data="blacklist_clear")],
            [InlineKeyboardButton("Back to User Management", callback_data="menu_user")]
        ]
        
        await _edit_in_place(query.message, text, reply_markup=InlineKeyboardMarkup(buttons))

    # ------------------------------------------------------------
    # Blacklist input helpers
    # ------------------------------------------------------------
    @app.on_callback_query(admin_filter & filters.regex(r"^blacklist_add_input$"))
    async def blacklist_add_input_callback(client: Client, query: CallbackQuery):
        await query.answer()
        _set_admin_state(query.from_user.id, query, "blacklist_add")
        await _edit_in_place(query.message,
            "🚫 **Add to Blacklist**\n"
            "━━━━━━━━━━━━━━━━━━━━━\n\n"
            "Send the User ID to blacklist:\n\n"
            "Example: `123456789`\n\n"
            "/cancel to abort"
        )

    @app.on_callback_query(admin_filter & filters.regex(r"^blacklist_remove_input$"))
    async def blacklist_remove_input_callback(client: Client, query: CallbackQuery):
        await query.answer()
        _set_admin_state(query.from_user.id, query, "blacklist_remove")
        await _edit_in_place(query.message,
            "🚫 **Remove from Blacklist**\n"
            "━━━━━━━━━━━━━━━━━━━━━\n\n"
            "Send the User ID to remove from blacklist:\n\n"
            "Example: `123456789`\n\n"
            "/cancel to abort"
        )

    @app.on_callback_query(admin_filter & filters.regex(r"^blacklist_clear$"))
    async def blacklist_clear_callback(client: Client, query: CallbackQuery):
        await query.answer()
        count = len(_storage.get("blacklist", []))
        await _edit_in_place(query.message,
            f"⚠️ **Clear Blacklist?**\n\n"
            f"{count} user(s) will be removed from the blacklist.\n\n"
            f"Are you sure?",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("Yes, Clear Blacklist", callback_data="blacklist_clear_confirm")],
                [InlineKeyboardButton("Cancel", callback_data="blacklist_mgmt")]
            ])
        )

    @app.on_callback_query(admin_filter & filters.regex(r"^blacklist_clear_confirm$"))
    async def blacklist_clear_confirm_callback(client: Client, query: CallbackQuery):
        await query.answer()
        _storage["blacklist"] = []
        save_storage()
        await _edit_in_place(query.message,
            "✅ **Blacklist Cleared!**\n\n"
            "All users removed from the blacklist.",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("Back to Blacklist", callback_data="blacklist_mgmt")]
            ])
        )

    # ============================================================
    # FEATURE 8: Revenue Dashboard
    # ============================================================
    @app.on_callback_query(admin_filter & filters.regex(r"^revenue_dashboard$"))
    async def revenue_dashboard_callback(client: Client, query: CallbackQuery):
        await query.answer()
        
        try:
            from bot.utils.storage import get_all_balances_report
            _, _, _, total_balance = get_all_balances_report()
        except Exception:
            total_balance = 0.0
        
        total_withdrawn = 0.0
        try:
            withdraws = _storage.get("withdrawals", [])
            for w in withdraws:
                if w.get("status") == "approved":
                    total_withdrawn += w.get("amount", 0)
        except Exception:
            pass
        
        today_revenue = 0.0
        try:
            tracker = _storage.get("session_tracker", {})
            for sessions in tracker.values():
                today_revenue += len(sessions) * 2.0
        except Exception:
            pass
        
        pending_withdraws = 0
        try:
            withdraws = _storage.get("withdrawals", [])
            for w in withdraws:
                if w.get("status") == "pending":
                    pending_withdraws += w.get("amount", 0)
        except Exception:
            pass
        
        text = "💰 **Revenue Dashboard**\n"
        text += "━━━━━━━━━━━━━━━━━━━━━\n\n"
        text += f"**Today's Revenue:** `${today_revenue:.2f} `\n"
        text += f"**Total User Balance:** `${total_balance:.2f} `(Unreleased)\n"
        text += f"**Total Withdrawn:** `${total_withdrawn:.2f} `\n"
        text += f"**Pending Withdrawals:** `${pending_withdraws:.2f} `\n\n"
        text += f"**Net Balance:** `${total_balance - total_withdrawn:.2f} `\n\n"
        text += "**Period Reports:**"
        
        buttons = [
            [InlineKeyboardButton("Today", callback_data="revenue_today"),
             InlineKeyboardButton("This Week", callback_data="revenue_week")],
            [InlineKeyboardButton("This Month", callback_data="revenue_month")],
            [InlineKeyboardButton("Back to Withdraw & Finance", callback_data="menu_withdraw")]
        ]
        
        await _edit_in_place(query.message, text, reply_markup=InlineKeyboardMarkup(buttons))

    @app.on_callback_query(admin_filter & filters.regex(r"^revenue_today$"))
    async def revenue_today_callback(client: Client, query: CallbackQuery):
        await query.answer()
        await _show_revenue_period(query, "today")

    @app.on_callback_query(admin_filter & filters.regex(r"^revenue_week$"))
    async def revenue_week_callback(client: Client, query: CallbackQuery):
        await query.answer()
        await _show_revenue_period(query, "week")

    @app.on_callback_query(admin_filter & filters.regex(r"^revenue_month$"))
    async def revenue_month_callback(client: Client, query: CallbackQuery):
        await query.answer()
        await _show_revenue_period(query, "month")

    async def _show_revenue_period(query: CallbackQuery, period: str):
        today_revenue = 0.0
        try:
            tracker = _storage.get("session_tracker", {})
            for sessions in tracker.values():
                today_revenue += len(sessions) * 2.0
        except Exception:
            pass

        text = "💰 **Revenue Report**\n"
        text += "━━━━━━━━━━━━━━━━━━━━━\n\n"

        if period == "today":
            text += f"**Today's Revenue:** `${today_revenue:.2f}`"
        elif period == "week":
            text += f"**This Week's Revenue:** `${today_revenue * 7:.2f}` (estimated)"
        else:
            text += f"**This Month's Revenue:** `${today_revenue * 30:.2f}` (estimated)"

        await _edit_in_place(query.message, text, reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("Back to Revenue Dashboard", callback_data="revenue_dashboard")]
        ]))

    # ============================================================
    # FEATURE 9: Alert System Config
    # ============================================================
    @app.on_callback_query(admin_filter & filters.regex(r"^alert_system_config$"))
    async def alert_system_config_callback(client: Client, query: CallbackQuery):
        await query.answer()
        
        alerts = _storage.get("alert_settings", {
            "low_balance_alert": True,
            "high_reject_rate_alert": True,
            "api_error_alert": True,
        })
        
        text = "🚨 **Alert System Configuration**\n"
        text += "━━━━━━━━━━━━━━━━━━━━━\n\n"
        
        for alert_name, enabled in alerts.items():
            status = "✅ ON" if enabled else "❌ OFF"
            text += f"{alert_name.replace('_', ' ').title()}: {status}\n"
        
        text += "\nToggle alerts below, or set a threshold."
        
        buttons = []
        for alert_name, enabled in alerts.items():
            label = "✅" if enabled else "❌"
            buttons.append([
                InlineKeyboardButton(
                    f"{label} {alert_name.replace('_', ' ').title()}: {'ON' if enabled else 'OFF'}",
                    callback_data=f"alert_toggle_{alert_name}"
                )
            ])
        buttons.append([InlineKeyboardButton("Set Alert Threshold", callback_data="alert_threshold_input")])
        buttons.append([InlineKeyboardButton("Back to System Controls", callback_data="menu_system")])
        
        await _edit_in_place(query.message, text, reply_markup=InlineKeyboardMarkup(buttons))

    @app.on_callback_query(admin_filter & filters.regex(r"^alert_toggle_(\w+)$"))
    async def alert_toggle_callback(client: Client, query: CallbackQuery):
        await query.answer()
        import re
        m = re.match(r"^alert_toggle_(\w+)$", query.data)
        alert_name = m.group(1) if m else None
        if not alert_name:
            return

        if "alert_settings" not in _storage:
            _storage["alert_settings"] = {
                "low_balance_alert": True,
                "high_reject_rate_alert": True,
                "api_error_alert": True,
            }
        if alert_name not in _storage["alert_settings"]:
            await _edit_in_place(query.message, f"❌ Unknown alert type: `{alert_name}`")
            return

        _storage["alert_settings"][alert_name] = not _storage["alert_settings"][alert_name]
        save_storage()
        new_state = _storage["alert_settings"][alert_name]

        await _edit_in_place(query.message,
            f"✅ `{alert_name.replace('_', ' ').title()}` is now **{'ON' if new_state else 'OFF'}**.",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("Back to Alert Settings", callback_data="alert_system_config")]
            ])
        )

    @app.on_callback_query(admin_filter & filters.regex(r"^alert_threshold_input$"))
    async def alert_threshold_input_callback(client: Client, query: CallbackQuery):
        await query.answer()
        _set_admin_state(query.from_user.id, query, "alert_threshold")
        thresholds = _storage.get("alert_thresholds", {})
        text = "📊 **Set Alert Threshold**\n"
        text += "━━━━━━━━━━━━━━━━━━━━━\n\n"
        text += "Send alert name and value:\n\n"
        text += "`low_balance 100` - alert when balance < $100\n"
        text += "`reject_rate 0.3` - alert when reject rate > 30%\n\n"
        if thresholds:
            text += "**Current thresholds:**\n"
            for name, val in thresholds.items():
                text += f"  `{name}`: `{val}`\n"
        text += "\n/cancel to abort"
        await _edit_in_place(query.message, text)

    # ============================================================
    # FEATURE 10: Multi-Admin Management
    # ============================================================
    @app.on_callback_query(admin_filter & filters.regex(r"^multiadmin_mgmt$"))
    async def multi_admin_mgmt_callback(client: Client, query: CallbackQuery):
        await query.answer()
        
        admins = _storage.get("admins", [ADMIN_ID])
        
        text = "👑 **Multi-Admin Management**\n"
        text += "━━━━━━━━━━━━━━━━━━━━━\n\n"
        text += f"Total Admins: `{len(admins)} `\n\n"
        text += "**Admin List:**\n"
        for admin_id in admins:
            admin_type = "👑 Owner" if admin_id == ADMIN_ID else "👤 Admin"
            text += f"  `{admin_id}` - {admin_type}\n"
        
        text += "\nUse the buttons below to add or remove admins."
        
        buttons = [
            [InlineKeyboardButton("Add Admin", callback_data="add_admin_input"),
             InlineKeyboardButton("Remove Admin", callback_data="remove_admin")],
            [InlineKeyboardButton("Back to Settings", callback_data="menu_settings_config")]
        ]
        
        await _edit_in_place(query.message, text, reply_markup=InlineKeyboardMarkup(buttons))

    # ============================================================
    # FEATURE 3: Send Sessions to User
    # ============================================================
    @app.on_callback_query(admin_filter & filters.regex(r"^send_sessions_menu$"))
    async def send_sessions_menu_callback(client: Client, query: CallbackQuery):
        await query.answer()
        user_id = query.from_user.id
        _set_admin_state(user_id, query, "send_sessions_uid")
        await _edit_in_place(query.message,
            "📤 **Send Sessions to User**\n"
            "━━━━━━━━━━━━━━━━━━━━━\n\n"
            "Send the target **User ID** you want to deliver sessions to:\n\n"
            "Example: `123456789`\n\n"
            "After that you can pick which sessions to send.\n\n"
            "Cancel via the button below or `/cancel`.",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("Cancel", callback_data="admin_cancel_operation")]
            ])
        )

    @app.on_callback_query(admin_filter & filters.regex(r"^send_sessions_active$"))
    async def send_sessions_active_callback(client: Client, query: CallbackQuery):
        await query.answer("Sending active sessions...")
        await _send_sessions_to_user(client, query, "active")

    @app.on_callback_query(admin_filter & filters.regex(r"^send_sessions_pending$"))
    async def send_sessions_pending_callback(client: Client, query: CallbackQuery):
        await query.answer("Sending pending sessions...")
        await _send_sessions_to_user(client, query, "pending")

    @app.on_callback_query(admin_filter & filters.regex(r"^send_sessions_all$"))
    async def send_sessions_all_callback(client: Client, query: CallbackQuery):
        await query.answer("Sending all sessions...")
        await _send_sessions_to_user(client, query, "all")

    async def _send_sessions_to_user(client: Client, query: CallbackQuery, session_type: str):
        import os
        import asyncio

        state = admin_state.get(query.from_user.id)
        target_uid = state.get("target_uid") if state else None
        try:
            target_uid = int(target_uid)
        except (TypeError, ValueError):
            target_uid = None

        if not target_uid:
            await _edit_in_place(query.message,
                "❌ Target User ID not set. Start again.",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("Back to Session Management", callback_data="menu_session")]
                ])
            )
            return

        if session_type == "active":
            sessions = get_exportable_sessions()
            type_name = "Active"
        elif session_type == "pending":
            sessions = get_pending_exportable_sessions()
            type_name = "Pending"
        else:
            active_sessions = get_exportable_sessions()
            pending_sessions = get_pending_exportable_sessions()
            sessions = {**active_sessions, **pending_sessions}
            type_name = "All"

        if not sessions:
            await _edit_in_place(query.message,
                f"❌ No {type_name} sessions to send!",
                reply_markup=get_session_management_buttons()
            )
            return

        await _edit_in_place(query.message,
            f"📤 **Sending {type_name} Sessions**\n\n"
            f"⏳ Sending {len(sessions)} session(s) to `{target_uid}`...\n"
            f"Please wait..."
        )

        sent = 0
        failed = 0
        sent_ids = []

        for session_id, session_data in sessions.items():
            try:
                phone = session_data.get("phone", "")
                session_string = session_data.get("session_string", "")
                twofa_password = session_data.get("twofa_password", "")
                session_inner = session_data.get("session_data", {})
                country_code = session_data.get("country_code", "") or session_inner.get("country_code", "")
                telethon_file = session_data.get("telethon_file", "") or session_inner.get("telethon_file", "")

                caption = (
                    f"📱 **Session Account**\n"
                    f"━━━━━━━━━━━━━━━━━━━━━\n"
                    f"Phone: `{phone}`\n"
                    f"Country: `{country_code}`\n"
                    f"2FA: `{twofa_password}`\n"
                    f"Session ID: `{session_id}`\n"
                )

                if telethon_file and os.path.exists(telethon_file):
                    await client.send_document(
                        chat_id=target_uid,
                        document=telethon_file,
                        caption=caption,
                        file_name=os.path.basename(telethon_file)
                    )
                elif session_string:
                    await client.send_message(
                        chat_id=target_uid,
                        text=f"{caption}\n\n**Session String:**\n`{session_string}`"
                    )
                else:
                    raise Exception("No session file or session string available")

                mark_session_message_sent(session_id)
                sent_ids.append(session_id)
                sent += 1
                await asyncio.sleep(1)
            except Exception as e:
                failed += 1
                print(f"❌ Error sending session {session_id} to {target_uid}: {e}")

        deleted_count = delete_exported_sessions(sent_ids) if sent_ids else 0

        await _edit_in_place(query.message,
            f"✅ *Send Complete!*\n\n"
            f"📤 Delivered to user: `{target_uid}`\n"
            f"✅ Sent: **{sent}**\n"
            f"❌ Failed: **{failed}**\n"
            f"🗑️ Removed from storage: **{deleted_count}**",
            reply_markup=get_session_management_buttons()
        )

    # ============================================================
    # FEATURE 5: Auto-Approve Settings
    # ============================================================
    @app.on_callback_query(admin_filter & filters.regex(r"^auto_approve_settings$"))
    async def auto_approve_settings_callback(client: Client, query: CallbackQuery):
        await query.answer()
        enabled = get_auto_approve_enabled()
        status = "✅ ENABLED" if enabled else "❌ DISABLED"
        
        text = "⚙️ **Auto-Approve Settings**\n"
        text += "━━━━━━━━━━━━━━━━━━━━━\n\n"
        text += f"Status: {status}\n\n"
        text += "When enabled, **successful** sessions are automatically approved\n"
        text += "(marked ready for export) as soon as they pass verification.\n"
        text += "You no longer need to approve each session manually.\n\n"
        text += f"Current auto-approve mode: **{'ON' if enabled else 'OFF'}**"
        
        buttons = [
            [InlineKeyboardButton(f"{'Disable' if enabled else 'Enable'} Auto-Approve",
                                  callback_data="auto_approve_toggle")],
            [InlineKeyboardButton("Back to Session Management", callback_data="menu_session")]
        ]
        
        await _edit_in_place(query.message, text, reply_markup=InlineKeyboardMarkup(buttons))

    @app.on_callback_query(admin_filter & filters.regex(r"^auto_approve_toggle$"))
    async def auto_approve_toggle_callback(client: Client, query: CallbackQuery):
        await query.answer()
        new_state = not get_auto_approve_enabled()
        set_auto_approve_enabled(new_state)
        status = "✅ ENABLED" if new_state else "❌ DISABLED"
        
        text = "⚙️ **Auto-Approve Settings**\n"
        text += "━━━━━━━━━━━━━━━━━━━━━\n\n"
        text += f"Status: {status}\n\n"
        text += "When enabled, **successful** sessions are automatically approved\n"
        text += "(marked ready for export) as soon as they pass verification.\n"
        text += "You no longer need to approve each session manually.\n\n"
        text += f"Auto-approve is now **{'ON' if new_state else 'OFF'}**."
        
        buttons = [
            [InlineKeyboardButton(f"{'Disable' if new_state else 'Enable'} Auto-Approve",
                                  callback_data="auto_approve_toggle")],
            [InlineKeyboardButton("Back to Session Management", callback_data="menu_session")]
        ]
        
        await _edit_in_place(query.message, text, reply_markup=InlineKeyboardMarkup(buttons))

    # ============================================================
    # FEATURE 7: Session Expiry Settings
    # ============================================================
    @app.on_callback_query(admin_filter & filters.regex(r"^session_expiry_settings$"))
    async def session_expiry_settings_callback(client: Client, query: CallbackQuery):
        await query.answer()
        cleanup_hours = get_session_expiry_hours()
        stuck_hours = get_stuck_session_expiry_hours()
        
        text = "⏰ **Session Expiry Settings**\n"
        text += "━━━━━━━━━━━━━━━━━━━━━\n\n"
        text += f"🔹 **Cleanup Expiry:** `{cleanup_hours}h`\n"
        text += f"   Old stuck/pending sessions older than this are auto-removed.\n\n"
        text += f"🔹 **Stuck Session Finalize:** `{stuck_hours}h`\n"
        text += f"   Sessions with a session string stuck longer than this are finalized (rejected).\n\n"
        text += "Set the cleanup expiry threshold:"
        
        buttons = [
            [InlineKeyboardButton(f"Cleanup: 12h", callback_data="session_expiry_set_12"),
             InlineKeyboardButton(f"Cleanup: 24h", callback_data="session_expiry_set_24")],
            [InlineKeyboardButton(f"Cleanup: 48h", callback_data="session_expiry_set_48"),
             InlineKeyboardButton(f"Cleanup: 72h", callback_data="session_expiry_set_72")],
            [InlineKeyboardButton(f"Finalize: 48h", callback_data="stuck_expiry_set_48"),
             InlineKeyboardButton(f"Finalize: 72h", callback_data="stuck_expiry_set_72")],
            [InlineKeyboardButton(f"Finalize: 96h", callback_data="stuck_expiry_set_96"),
             InlineKeyboardButton(f"Finalize: 120h", callback_data="stuck_expiry_set_120")],
            [InlineKeyboardButton("Back to Session Management", callback_data="menu_session")]
        ]
        
        await _edit_in_place(query.message, text, reply_markup=InlineKeyboardMarkup(buttons))

    @app.on_callback_query(admin_filter & filters.regex(r"^session_expiry_set_(\d+)$"))
    async def session_expiry_set_callback(client: Client, query: CallbackQuery):
        import re
        await query.answer()
        m = re.match(r"^session_expiry_set_(\d+)$", query.data)
        hours = int(m.group(1)) if m else 24
        set_session_expiry_hours(hours)
        await _edit_in_place(query.message,
            f"✅ Cleanup expiry threshold set to **{get_session_expiry_hours()}h**.\n\n"
            f"Old stuck/pending sessions older than this will be auto-removed by the cleanup routine.",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("Back to Session Expiry Settings", callback_data="session_expiry_settings")]
            ])
        )

    @app.on_callback_query(admin_filter & filters.regex(r"^stuck_expiry_set_(\d+)$"))
    async def stuck_expiry_set_callback(client: Client, query: CallbackQuery):
        import re
        await query.answer()
        m = re.match(r"^stuck_expiry_set_(\d+)$", query.data)
        hours = int(m.group(1)) if m else 72
        set_stuck_session_expiry_hours(hours)
        await _edit_in_place(query.message,
            f"✅ Stuck session finalize threshold set to **{get_stuck_session_expiry_hours()}h**.\n\n"
            f"Sessions with a session string stuck longer than this will be finalized (rejected).",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("Back to Session Expiry Settings", callback_data="session_expiry_settings")]
            ])
        )

    print("10 Critical Features registered successfully: removebalance, setuserrate, useractivitylogs, blacklist_mgmt, send_sessions_menu, auto_approve_settings, session_expiry_settings, revenue_dashboard, alert_system_config, multiadmin_mgmt")
