from pyrogram.client import Client
from pyrogram import filters
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery
from bot.utils.storage import get_min_withdraw_for_method, get_required_channel, try_deduct_balance_for_withdraw
from bot.config import CHANNEL_WITHDRAW_REPORT, ADMIN_ID
import asyncio
import re
import threading
import logging
from typing import Tuple

logger = logging.getLogger(__name__)

withdraw_sessions = {}
withdraw_lock = threading.RLock()


def validate_wallet_address(address: str, method: str) -> Tuple[bool, str]:
    """
    Validate wallet address based on withdrawal method.
    
    Args:
        address: The wallet address to validate
        method: The withdrawal method (USDT, TRX, BINANCE, CARDNAME)
    
    Returns:
        Tuple of (is_valid, error_message or sanitized_address)
    """
    address = address.strip()
    
    if not address:
        return False, "Wallet address cannot be empty"
    
    if len(address) < 5:
        return False, "Wallet address is too short"
    
    if len(address) > 200:
        return False, "Wallet address is too long (max 200 characters)"
    
    dangerous_chars = ['<', '>', '"', "'", '\\', '\n', '\r', '\t', ';', '`', '$', '|', '&']
    for char in dangerous_chars:
        address = address.replace(char, '')
    
    method_upper = method.upper()
    
    if method_upper == "USDT":
        if address.startswith("0x") and len(address) == 42:
            if re.match(r'^0x[a-fA-F0-9]{40}$', address):
                return True, address
            return False, "Invalid BEP20 address format. Should be 0x followed by 40 hex characters."
        
        if address.startswith("T") and len(address) == 34:
            if re.match(r'^T[a-zA-Z0-9]{33}$', address):
                return True, address
            return False, "Invalid TRC20 address format."
        
        return False, "Invalid USDT address. Use BEP20 (0x...) or TRC20 (T...) format."
    
    elif method_upper == "TRX":
        if address.startswith("T") and len(address) == 34:
            if re.match(r'^T[a-zA-Z0-9]{33}$', address):
                return True, address
        return False, "Invalid TRX address. Should start with 'T' and be 34 characters."
    
    elif method_upper == "BINANCE":
        if re.match(r'^[a-zA-Z0-9@._-]{5,100}$', address):
            return True, address
        return False, "Invalid Binance ID. Use alphanumeric characters only."
    
    elif method_upper == "CARDNAME":
        name_pattern = r'^[a-zA-Z\s\.\-]{3,100}$'
        if re.match(name_pattern, address):
            return True, address
        return False, "Invalid card name. Use letters, spaces, dots, or hyphens only."
    
    return True, address

async def register_withdraw(client: Client, message: Message):
    """
    Handles /withdraw command - WITH CHANNEL GUARD
    Shows user balance and withdrawal options
    """
    user_id = message.chat.id
    
    from bot.utils.fast_cache import (
        is_user_banned_fast,
        get_cached_template,
        get_user_balance_fast,
        is_withdraw_enabled_fast,
        background_refresh_withdraw_status,
        sync_user_from_storage,
        format_message_fast
    )
    
    sync_user_from_storage(user_id)
    
    if is_user_banned_fast(user_id):
        await message.reply(get_cached_template("banned_user_message"))
        return
    
    if not is_withdraw_enabled_fast():
        await message.reply(get_cached_template("withdraw_disabled_message"))
        asyncio.create_task(background_refresh_withdraw_status())
        return
    
    balance = get_user_balance_fast(user_id)
    
    from bot.utils.storage import get_user_withdraw_config
    user_config = get_user_withdraw_config(user_id)
    
    if user_config.get("disabled"):
        await message.reply("❌ *Withdraw Disabled*\n\nYour withdrawals have been temporarily disabled by admin.")
        return
    
    if balance <= 0:
        await message.reply(get_cached_template("no_balance_message"))
        return
    
    text = format_message_fast("withdraw_method_message", balance=balance)
    buttons = [
        [InlineKeyboardButton("USDT (BEP20)", callback_data="withdraw_usdt")],
        [InlineKeyboardButton("TRX", callback_data="withdraw_trx")],
        [InlineKeyboardButton("CARD NAME", callback_data="withdraw_cardname")],
        [InlineKeyboardButton("Binance", callback_data="withdraw_binance")]
    ]
    await message.reply(text, reply_markup=InlineKeyboardMarkup(buttons))
    
    with withdraw_lock:
        withdraw_sessions[user_id] = {"balance": balance, "step": "waiting_method"}


def register_withdraw_handlers(app: Client):
    """Register all withdraw-related handlers - WITH CHANNEL GUARD"""

    @app.on_callback_query(filters.regex(r"^withdraw_(usdt|trx|cardname|binance)$"))
    async def handle_withdraw_selection(client: Client, query: CallbackQuery):
        """Withdraw selection - Universal guard already enforces channel membership with force_check=True"""
        user_id = query.from_user.id

        with withdraw_lock:
            if user_id not in withdraw_sessions:
                await query.answer("Please use /withdraw to start a request.", show_alert=True)
                return

            data_str = str(query.data) if query.data else "withdraw_unknown"
            parts = data_str.split("_")
            method = parts[1].upper() if len(parts) > 1 else "UNKNOWN"
            
            from bot.utils.fast_cache import get_user_balance_fast
            current_balance = get_user_balance_fast(user_id)
            
            withdraw_sessions[user_id]["balance"] = current_balance
            
            min_amount = get_min_withdraw_for_method(method.lower())
            
            from bot.utils.storage import get_user_withdraw_config
            user_config = get_user_withdraw_config(user_id)
            
            custom_min = user_config.get("min")
            if custom_min is not None:
                min_amount = custom_min
                
            custom_max = user_config.get("max")
            if custom_max is not None and current_balance > custom_max:
                await query.answer(f"Max withdraw limit is ${custom_max}", show_alert=True)
                return

            if current_balance < min_amount:
                await query.answer(f"Insufficient Balance\n\nMinimum withdraw: ${min_amount}\nYour balance: ${current_balance}", show_alert=True)
                return
            
            if current_balance <= 0:
                await query.answer("You have no balance to withdraw.", show_alert=True)
                return
            
            withdraw_sessions[user_id]["method"] = method
            withdraw_sessions[user_id]["step"] = "waiting_wallet"

        from bot.utils.fast_cache import format_message_fast as fmt_msg
        await query.message.edit_text(fmt_msg("enter_wallet_message", method=method))
        await query.answer()

    @app.on_message(filters.private & filters.text & ~filters.command(["start", "account", "withdraw", "cap", "admin", "support", "cancel"]))
    async def handle_wallet_input(client: Client, message: Message):
        """Wallet input - Universal guard already enforces channel membership with force_check=True"""
        user_id = message.chat.id

        with withdraw_lock:
            if user_id not in withdraw_sessions or withdraw_sessions[user_id].get("step") != "waiting_wallet":
                return

            wallet_address = message.text.strip()

            if user_id not in withdraw_sessions:
                return

            data = withdraw_sessions[user_id]
            method = data.get("method", "UNKNOWN")

            is_valid, result = validate_wallet_address(wallet_address, method)

            if not is_valid:
                from bot.utils.fast_cache import format_message_fast as fmt_msg
                await message.reply(fmt_msg("invalid_wallet_message", error=result, method=method))
                message.stop_propagation()
                return

            wallet_address = result
            balance = data["balance"]

            deducted = try_deduct_balance_for_withdraw(user_id, balance)
            if not deducted:
                await message.reply("❌ *Withdraw Failed*\n\nYour balance is insufficient or has already been deducted.\n\nPlease use /withdraw to try again.")
                message.stop_propagation()
                return

            data = withdraw_sessions.pop(user_id)
            method = data["method"]

        from bot.utils.fast_cache import format_message_fast
        await message.reply(format_message_fast("withdraw_success_message", amount=balance, method=method))
        
        asyncio.create_task(
            process_withdraw_background(client, user_id, balance, method, wallet_address)
        )
        
        message.stop_propagation()


async def process_withdraw_background(client: Client, user_id: int, balance: float, method: str, wallet_address: str):
    """Process withdraw in background - balance already deducted atomically in handle_wallet_input"""
    withdraw_recorded = False
    try:
        from datetime import datetime
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        logger.info(f"Processing withdraw: user={user_id}, amount=${balance}, method={method}")
        from bot.utils.storage import record_withdraw_request_only
        record_withdraw_request_only(user_id, method, balance, wallet_address)
        withdraw_recorded = True
        logger.info(f"Withdraw request recorded in storage for user {user_id}")
        
        try:
            from bot.utils import database as db
            await db.log_withdrawal(user_id, method, balance, wallet_address, "pending")
            logger.info(f"Withdraw logged to PostgreSQL database")
        except Exception as db_err:
            logger.warning(f"DB logging unavailable: {db_err}")
        
        withdraw_message = (
            f"💸 *New Withdraw Request*\n\n"
            f"👤 User ID: `{user_id}`\n"
            f"💰 Amount: *${balance}*\n"
            f"💳 Method: *{method}*\n"
            f"📬 Wallet: `{wallet_address}`\n"
            f"⏰ Time: {current_time}"
        )
        
        if CHANNEL_WITHDRAW_REPORT:
            try:
                logger.info(f"Sending withdraw report to channel: {CHANNEL_WITHDRAW_REPORT}")
                from pyrogram.errors import FloodWait
                for attempt in range(3):
                    try:
                        await client.send_message(
                            chat_id=CHANNEL_WITHDRAW_REPORT,
                            text=withdraw_message
                        )
                        logger.info("Withdraw report sent to channel successfully")
                        break
                    except FloodWait as fw:
                        wait = int(fw.value) if isinstance(fw.value, (int, float)) else 2
                        logger.warning(f"FloodWait: waiting {wait}s before retry")
                        await asyncio.sleep(wait)
                    except Exception as attempt_err:
                        if attempt < 2:
                            logger.warning(f"Retry {attempt+1}/3: channel send failed: {attempt_err}")
                            await asyncio.sleep(0.5)
                        else:
                            raise
            except Exception as channel_error:
                logger.error(f"Failed to send withdraw report to channel after retries: {channel_error}")
        else:
            logger.warning("CHANNEL_WITHDRAW_REPORT not configured")
            
        from bot.utils.fast_cache import sync_user_from_storage_async
        await sync_user_from_storage_async(user_id)
        logger.info(f"User cache synced after withdraw for user {user_id}")
        
    except Exception as e:
        logger.error(f"Error processing withdraw: {e}", exc_info=True)
        if not withdraw_recorded:
            try:
                from bot.utils.storage import add_balance_for_user
                add_balance_for_user(user_id, balance)
                logger.info(f"REFUNDED ${balance} to user {user_id} due to withdraw processing failure")
            except Exception as refund_err:
                logger.error(f"CRITICAL: Failed to refund balance to user {user_id}: {refund_err}")
