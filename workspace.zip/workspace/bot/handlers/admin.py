# bot/handlers/admin.py
from pyrogram.client import Client
from pyrogram import filters
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery
from pyrogram.errors import MessageNotModified
from bot.utils.storage import (
    get_user_info,
    update_user_info,
    get_all_users,
    ban_user,
    unban_user,
    set_country_rates,
    set_country_rate_by_type,
    get_country_rates,
    set_country_timeout,
    add_balance_for_user,
    get_user_stats,
    zero_all_balances,
    toggle_withdraw,
    get_total_users,
    get_all_users_list,
    get_pending_withdraw_requests,
    get_withdraw_logs,
    approve_withdraw_request,
    reject_withdraw_request,
    disable_all_countries,
    toggle_country_status,
    get_required_channel,
    set_required_channel,
    get_min_withdraw_amounts,
    set_min_withdraw_for_method,
    get_all_message_templates,
    set_message_template,
    reset_message_template,
    DEFAULT_MESSAGE_TEMPLATES,
    get_all_balances_report,
    toggle_verification_pause,
    is_verification_paused,
    is_spam_check_enabled,
    toggle_spam_check,
    get_exportable_sessions,
    get_pending_exportable_sessions,
    get_session_export_counts,
    delete_exported_sessions,
    get_all_pending_sessions,
    cleanup_old_stuck_sessions,
    _storage,
    save_storage,
)
from bot.config import ADMIN_ID, SESSION_2FA_PASSWORD, get_2fa_password, CHANNEL_WITHDRAW_REPORT
import os
import json
import logging
from datetime import datetime

logger = logging.getLogger(__name__)

# ---------------- Admin State Storage ----------------
import threading
from dataclasses import dataclass, field
from typing import Dict, Optional, Any, List

# ============================================================
# MULTI-ADMIN SYSTEM - Custom Filter for All Admins
# ============================================================

def is_admin(user_id: int) -> bool:
    """
    Check if a user is an admin.
    Returns True if user is in admin list or is the primary ADMIN_ID.
    """
    if user_id == ADMIN_ID:
        return True
    admins = _storage.get("admins", [])
    return user_id in admins

def get_all_admins() -> List[int]:
    """Get list of all admin IDs including primary admin."""
    admins = list(_storage.get("admins", []))
    if ADMIN_ID not in admins:
        admins.insert(0, ADMIN_ID)
    return admins

def admin_filter_func(_, __, update) -> bool:
    """
    Custom filter function to check if user is an admin.
    Works with both Message and CallbackQuery.
    """
    if hasattr(update, 'from_user') and update.from_user:
        return is_admin(update.from_user.id)
    return False

# Create custom admin filter that works for all admins
admin_filter = filters.create(admin_filter_func, name="AdminFilter")

@dataclass
class AdminStateManager:
    """Thread-safe admin state manager."""
    _states: Dict[int, Dict[str, Any]] = field(default_factory=dict)
    _monitor_enabled: bool = True
    _lock: threading.RLock = field(default_factory=threading.RLock)
    
    def get_state(self, user_id: int) -> Optional[Dict[str, str]]:
        """Get state for a specific admin user."""
        with self._lock:
            return self._states.get(user_id)
    
    def set_state(self, user_id: int, state: Dict[str, str]) -> None:
        """Set state for a specific admin user."""
        with self._lock:
            self._states[user_id] = state
    
    def clear_state(self, user_id: int) -> None:
        """Clear state for a specific admin user."""
        with self._lock:
            self._states.pop(user_id, None)
    
    def get_monitor_status(self) -> bool:
        """Get current monitor status."""
        with self._lock:
            return self._monitor_enabled
    
    def set_monitor_status(self, enabled: bool) -> None:
        """Set monitor status."""
        with self._lock:
            self._monitor_enabled = enabled

    def toggle_monitor_status(self) -> bool:
        """Atomically toggle monitor status and return new state."""
        with self._lock:
            self._monitor_enabled = not self._monitor_enabled
            return self._monitor_enabled

_admin_manager = AdminStateManager()
class _AdminStateProxy:
    """Thread-safe proxy for admin state dict that enforces RLock."""
    def __init__(self, manager: AdminStateManager):
        self._manager = manager
    
    def __contains__(self, user_id: int) -> bool:
        return self._manager.get_state(user_id) is not None
    
    def __getitem__(self, user_id: int):
        state = self._manager.get_state(user_id)
        if state is None:
            raise KeyError(user_id)
        return state
    
    def __setitem__(self, user_id: int, value: Dict[str, str]) -> None:
        self._manager.set_state(user_id, value)
    
    def __delitem__(self, user_id: int) -> None:
        self._manager.clear_state(user_id)
    
    def get(self, user_id: int, *args):
        state = self._manager.get_state(user_id)
        if state is not None:
            return state
        if args:
            return args[0]
        return None

admin_state = _AdminStateProxy(_admin_manager)

# ============================================================
# IN-PLACE PANEL EDITING HELPERS
# The admin panel uses ONE message that edits in place instead
# of stacking new messages below.
# ============================================================

def _set_admin_state(user_id: int, query, action: str, **extra) -> None:
    """Set an admin's pending action and remember which message is the panel."""
    state = {
        "action": action,
        "panel_chat_id": query.message.chat.id,
        "panel_msg_id": query.message.id,
    }
    state.update(extra)
    admin_state[user_id] = state

def _get_panel_ref(user_id: int) -> Optional[tuple]:
    """Return (chat_id, message_id) of the admin panel message, if known."""
    state = admin_state.get(user_id)
    if not state:
        return None
    cid = state.get("panel_chat_id")
    mid = state.get("panel_msg_id")
    if cid and mid:
        return cid, mid
    return None

async def _edit_in_place(message, text, reply_markup=None, **kwargs):
    """Edit the panel message in place; fall back to a new message when impossible."""
    if not text:
        return None
    if len(text) > 4096:
        try:
            return await message.reply(text, reply_markup=reply_markup, **kwargs)
        except Exception:
            return None
    try:
        return await message.edit_text(text, reply_markup=reply_markup, **kwargs)
    except MessageNotModified:
        try:
            return await message.edit_reply_markup(reply_markup)
        except Exception:
            return None
        return None
    except Exception:
        try:
            return await message.reply(text, reply_markup=reply_markup, **kwargs)
        except Exception:
            return None

async def _edit_by_ids(client, chat_id, message_id, text, reply_markup=None, **kwargs):
    """Edit a message by ids; fall back to sending a new message when impossible."""
    if not text or not chat_id or not message_id:
        return None
    if len(text) > 4096:
        try:
            return await client.send_message(chat_id, text, reply_markup=reply_markup, **kwargs)
        except Exception:
            return None
    try:
        return await client.edit_message_text(chat_id, message_id, text, reply_markup=reply_markup, **kwargs)
    except MessageNotModified:
        try:
            return await client.edit_message_reply_markup(chat_id, message_id, reply_markup=reply_markup)
        except Exception:
            return None
        return None
    except Exception:
        try:
            return await client.send_message(chat_id, text, reply_markup=reply_markup, **kwargs)
        except Exception:
            return None

async def _panel_reply(client, user_id: int, fallback_message, text, reply_markup=None, **kwargs):
    """Reply to an admin action by editing the panel message in place."""
    ref = _get_panel_ref(user_id)
    if ref:
        cid, mid = ref
        res = await _edit_by_ids(client, cid, mid, text, reply_markup=reply_markup, **kwargs)
        if res is not None:
            return res
    try:
        return await fallback_message.reply(text, reply_markup=reply_markup, **kwargs)
    except Exception:
        return None

def get_monitor_status() -> bool:
    """Get current monitor status."""
    return _admin_manager.get_monitor_status()

def set_monitor_status(enabled: bool) -> None:
    """Set monitor status."""
    _admin_manager.set_monitor_status(enabled)

def toggle_monitor_status() -> bool:
    """Atomically toggle monitor status and return new state."""
    return _admin_manager.toggle_monitor_status()

# ---------------- Admin Panel Builder ----------------

def _build_dashboard_message() -> str:
    """Build the rich admin dashboard message with live stats."""
    try:
        user_count, active_count = get_total_users()
    except Exception:
        user_count, active_count = 0, 0
    
    try:
        pending = get_all_pending_sessions()
        pending_sessions = len(pending)
    except Exception:
        pending_sessions = 0
    
    try:
        _, _, _, total_balance = get_all_balances_report()
    except Exception:
        total_balance = 0.0
    
    try:
        withdraw_reqs = get_pending_withdraw_requests()
        pending_withdraws = len(withdraw_reqs)
    except Exception:
        pending_withdraws = 0
    
    try:
        tracker = _storage.get("session_tracker", {})
        today_sessions = sum(len(s) for s in tracker.values())
    except Exception:
        today_sessions = 0
    
    monitor = "RUNNING" if get_monitor_status() else "PAUSED"
    verification = "ACTIVE" if not is_verification_paused() else "PAUSED"
    spam = "ENABLED" if is_spam_check_enabled() else "DISABLED"
    wd_status = "OPEN" if not _storage.get("withdraw_disabled", False) else "CLOSED"

    countries_configured = len(_storage.get("countries", {}))
    countries_open = sum(1 for d in _storage.get("countries", {}).values() if d.get("open", False))

    return (
        "━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        "     **ADMIN DASHBOARD**\n"
        "  Session Bot Control Panel\n"
        "━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
        "**STATISTICS**\n"
        f"  Users  {user_count:,} total / {active_count:,} active\n"
        f"  Sessions  {today_sessions} verified today\n"
        f"  Balance  ${total_balance:,.2f} unreleased\n"
        f"  Withdraw  {pending_withdraws} pending requests\n\n"
        "**SYSTEM**\n"
        f"  Monitor  {monitor}\n"
        f"  Verify  {verification}\n"
        f"  Spam  {spam}\n"
        f"  Withdraw  {wd_status}\n\n"
        f"**GEO**  {countries_open}/{countries_configured} countries open  |  Pending Queue  {pending_sessions}\n"
        "━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        "Select from the menu below:"
    )

def get_admin_panel_buttons():
    """Main dashboard buttons - 2 per row layout."""
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("User Management", callback_data="menu_user"),
         InlineKeyboardButton("Country & Pricing", callback_data="menu_country")],
        [InlineKeyboardButton("Withdraw & Finance", callback_data="menu_withdraw"),
         InlineKeyboardButton("Session Management", callback_data="menu_session")],
        [InlineKeyboardButton("System Controls", callback_data="menu_system"),
         InlineKeyboardButton("Messaging & Channel", callback_data="menu_messaging")],
        [InlineKeyboardButton("Advanced Tools", callback_data="menu_advanced_tools"),
         InlineKeyboardButton("Settings & Configuration", callback_data="menu_settings_config")],
        [InlineKeyboardButton("CORE FEATURES v2", callback_data="open_core_features")],
    ])

def get_user_management_buttons():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("Ban User", callback_data="ban"),
         InlineKeyboardButton("Unban User", callback_data="unban")],
        [InlineKeyboardButton("Adjust Balance", callback_data="adjustbalance"),
         InlineKeyboardButton("Remove Balance", callback_data="removebalance")],
        [InlineKeyboardButton("User Stats", callback_data="userstats"),
         InlineKeyboardButton("User Activity Logs", callback_data="useractivitylogs")],
        [InlineKeyboardButton("Zero All Balances", callback_data="zerobalance"),
         InlineKeyboardButton("Total Users", callback_data="totalusers")],
        [InlineKeyboardButton("Blacklist Management", callback_data="blacklist_mgmt")],
        [InlineKeyboardButton("Back to Main Menu", callback_data="back_admin")]
    ])

def get_country_pricing_buttons():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("Set Country Price", callback_data="setrate"),
         InlineKeyboardButton("Set Individual User Rate", callback_data="setuserrate")],
        [InlineKeyboardButton("Set Session Timeout", callback_data="settimeout"),
         InlineKeyboardButton("Toggle Country", callback_data="togglecountry")],
        [InlineKeyboardButton("Auto-Approve Settings", callback_data="auto_approve_settings"),
         InlineKeyboardButton("Disable All Countries", callback_data="disablecountries")],
        [InlineKeyboardButton("Back to Main Menu", callback_data="back_admin")]
    ])

def get_withdraw_finance_buttons():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("Withdraw Toggle", callback_data="togglewithdraw"),
         InlineKeyboardButton("User Specific Control", callback_data="user_withdraw_control")],
        [InlineKeyboardButton("Min Withdraw Settings", callback_data="minwithdraw"),
         InlineKeyboardButton("All Balances Report", callback_data="allbalances")],
        [InlineKeyboardButton("Pending Withdraw", callback_data="pendingwithdraw"),
         InlineKeyboardButton("Withdraw Logs", callback_data="withdrawlogs")],
        [InlineKeyboardButton("Revenue Dashboard", callback_data="revenue_dashboard")],
        [InlineKeyboardButton("Back to Main Menu", callback_data="back_admin")]
    ])

def get_system_controls_buttons():
    monitor_label = "Monitor: ON" if get_monitor_status() else "Monitor: OFF"
    verify_label = "Verification: ON" if not is_verification_paused() else "Verification: OFF"
    spam_label = "Spam Check: ON" if is_spam_check_enabled() else "Spam Check: OFF"
    
    return InlineKeyboardMarkup([
        [InlineKeyboardButton(monitor_label, callback_data="togglemonitor")],
        [InlineKeyboardButton(verify_label, callback_data="toggleverification")],
        [InlineKeyboardButton(spam_label, callback_data="togglespamcheck")],
        [InlineKeyboardButton("Alert System Config", callback_data="alert_system_config")],
        [InlineKeyboardButton("Back to Main Menu", callback_data="back_admin")]
    ])

def get_messaging_buttons():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("Broadcast Message", callback_data="broadcast"),
         InlineKeyboardButton("Send to User", callback_data="sendtouser")],
        [InlineKeyboardButton("Set Channel", callback_data="setchannel"),
         InlineKeyboardButton("Message Templates", callback_data="messagesettings")],
        [InlineKeyboardButton("Back to Main Menu", callback_data="back_admin")]
    ])

def get_advanced_tools_buttons():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("View Pending Sessions", callback_data="view_pending_sessions"),
         InlineKeyboardButton("Cleanup Old Sessions", callback_data="cleanup_old_sessions")],
        [InlineKeyboardButton("Backup / Export Data", callback_data="backup_export_data")],
        [InlineKeyboardButton("Back to Main Menu", callback_data="back_admin")]
    ])

def get_settings_config_buttons():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("Set 2FA Password", callback_data="set_2fa_password"),
         InlineKeyboardButton("Country-wise Stats", callback_data="country_wise_stats")],
        [InlineKeyboardButton("Daily Report Toggle", callback_data="daily_report_toggle"),
         InlineKeyboardButton("View 2FA Password", callback_data="show_2fa_secret")],
        [InlineKeyboardButton("Multi-Admin Management", callback_data="multiadmin_mgmt")],
        [InlineKeyboardButton("Back to Main Menu", callback_data="back_admin")]
    ])

def get_session_management_buttons():
    counts = get_session_export_counts()
    active_count = counts.get("active", 0)
    pending_count = counts.get("pending", 0)
    
    return InlineKeyboardMarkup([
        [InlineKeyboardButton(f"Export Active ({active_count})", callback_data="export_active_sessions"),
         InlineKeyboardButton(f"Export Pending ({pending_count})", callback_data="export_pending_sessions")],
        [InlineKeyboardButton(f"Export All ({active_count + pending_count})", callback_data="export_all_sessions")],
        [InlineKeyboardButton("View Pending Sessions", callback_data="view_pending_sessions"),
         InlineKeyboardButton("Cleanup Old Sessions", callback_data="cleanup_old_sessions")],
        [InlineKeyboardButton("Send Sessions to User", callback_data="send_sessions_menu")],
        [InlineKeyboardButton("Session Expiry Settings", callback_data="session_expiry_settings")],
        [InlineKeyboardButton("Refresh Counts", callback_data="menu_session")],
        [InlineKeyboardButton("Back to Main Menu", callback_data="back_admin")]
    ])

PENDING_WITHDRAW_PER_PAGE = 5

def _build_pending_withdraw_panel(page: int = 0):
    """Build the pending-withdraw panel (text + buttons) for a given page.

    Approve/Reject buttons use the GLOBAL index into the full pending list so
    the existing wapprove_/wreject_ handlers keep working for every request.
    """
    pending = get_pending_withdraw_requests()
    total = len(pending)
    total_pages = max(1, (total + PENDING_WITHDRAW_PER_PAGE - 1) // PENDING_WITHDRAW_PER_PAGE)
    page = max(0, min(page, total_pages - 1))

    header = (
        "--- PENDING WITHDRAW ---\n"
        f"Total Pending: {total}\n"
        "------------------------\n"
    )

    if not pending:
        return (header + "\nNo pending requests.",
            [[InlineKeyboardButton("Back to Withdraw & Finance", callback_data="menu_withdraw")]])

    start = page * PENDING_WITHDRAW_PER_PAGE
    end = min(start + PENDING_WITHDRAW_PER_PAGE, total)
    page_requests = list(enumerate(pending))[start:end]

    details = "\n📋 **Request List:**\n"
    details += "━━━━━━━━━━━━━━━━━━━━━\n"
    for global_idx, req in page_requests:
        req_idx = global_idx + 1
        user_id = req.get('user_id', 'N/A')
        amount = req.get('amount', 0)
        method = req.get('method', 'N/A')
        wallet_address = req.get('wallet_address', 'N/A')
        timestamp = req.get('timestamp', 'N/A')
        details += (
            f"#{req_idx} | User:`{user_id}` | ${amount:.2f} | {method}\n"
            f"  Wallet:`{wallet_address}` | {timestamp}\n"
        )

    buttons = []
    for global_idx, req in page_requests:
        req_idx = global_idx + 1
        buttons.append([
            InlineKeyboardButton(f"Approve #{req_idx}", callback_data=f"wapprove_{global_idx}"),
            InlineKeyboardButton(f"Reject #{req_idx}", callback_data=f"wreject_{global_idx}")
        ])

    nav = []
    if page > 0:
        nav.append(InlineKeyboardButton("◀ Prev", callback_data=f"wpage_{page - 1}"))
    nav.append(InlineKeyboardButton(f"Page {page + 1}/{total_pages}", callback_data="pendingwithdraw"))
    if page < total_pages - 1:
        nav.append(InlineKeyboardButton("Next ▶", callback_data=f"wpage_{page + 1}"))
    if nav:
        buttons.append(nav)

    buttons.append([InlineKeyboardButton("Back to Withdraw & Finance", callback_data="menu_withdraw")])

    return header + details, buttons

# Template names for display
TEMPLATE_DISPLAY_NAMES = {
    "account_received_message": "📲 Account Received Message",
    "success_message": "✅ Success Message",
    "multi_device_message": "⚠️ Multi Device Message",
    "support_message": "🆘 Support Message",
    "account_info_message": "🎰 Account Info Message",
    "verification_failed_message": "🚫 Verification Failed Message",
    "welcome_message": "🎉 Welcome Message",
    "invalid_otp_message": "❌ Invalid OTP Message",
    "processing_message": "🔄 Processing Message",
    "banned_user_message": "🚫 Banned User Message",
    "withdraw_success_message": "✅ Withdraw Success Message",
    "no_balance_message": "❌ No Balance Message",
    "twofa_already_active_message": "❌ 2FA Already Active Message",
    
    "enter_phone_message": "📱 Enter Phone Message",
    "enter_otp_message": "🔢 Enter OTP Message",
    "otp_sent_message": "📤 OTP Sent Message",
    "waiting_verification_message": "⏳ Waiting Verification Message",
    "twofa_setup_message": "🔐 2FA Setup Message",
    "spam_check_message": "🔍 Spam Check Message",
    "withdraw_disabled_message": "❌ Withdraw Disabled Message",
    "withdraw_method_message": "💳 Withdraw Method Message",
    "enter_wallet_message": "📬 Enter Wallet Message",
    "invalid_wallet_message": "❌ Invalid Wallet Message",
    "session_timeout_message": "⏰ Session Timeout Message",
    "country_not_available_message": "🌍 Country Not Available Message",
    "join_channel_message": "📢 Join Channel Message",
    "min_withdraw_message": "⚠️ Min Withdraw Message",
    "enter_2fa_password_message": "🔑 Enter 2FA Password Message"
}

# Placeholder info for each template
TEMPLATE_PLACEHOLDERS = {
    "account_received_message": "{phone}, {flag}, {timeout}",
    "success_message": "{phone}, {price}, {status}",
    "multi_device_message": "{phone}",
    "support_message": "No placeholders",
    "account_info_message": "{user_id}, {balance}, {sessions}, {joined}",
    "verification_failed_message": "{phone}, {country_code}, {flag}",
    "welcome_message": "No placeholders",
    "invalid_otp_message": "No placeholders",
    "processing_message": "No placeholders",
    "banned_user_message": "No placeholders",
    "withdraw_success_message": "{amount}, {method}",
    "no_balance_message": "No placeholders",
    "twofa_already_active_message": "No placeholders",
    
    "enter_phone_message": "No placeholders",
    "enter_otp_message": "{timeout}",
    "otp_sent_message": "{phone}, {country_code}, {flag}, {timeout}",
    "waiting_verification_message": "{phone}, {country_code}, {flag}, {timeout}",
    "twofa_setup_message": "{phone}",
    "spam_check_message": "{phone}",
    "withdraw_disabled_message": "No placeholders",
    "withdraw_method_message": "{balance}",
    "enter_wallet_message": "{method}",
    "invalid_wallet_message": "{error}, {method}",
    "session_timeout_message": "{phone}, {country_code}, {flag}, {timeout}",
    "country_not_available_message": "{country_code}, {flag}",
    "join_channel_message": "{channel}",
    "min_withdraw_message": "{balance}, {min_amount}, {needed}",
    "enter_2fa_password_message": "{phone}"
}

# ---------------- Register Handlers ----------------
def register_admin_handlers(app: Client):
    # ---------------- /admin Command ----------------
    @app.on_message(filters.command("admin") & admin_filter)
    async def open_admin_panel(client: Client, message: Message):
        ref = _get_panel_ref(message.from_user.id)
        _admin_manager.clear_state(message.from_user.id)
        dashboard = _build_dashboard_message()
        if ref:
            cid, mid = ref
            res = await _edit_by_ids(client, cid, mid, dashboard, reply_markup=get_admin_panel_buttons())
            if res is not None:
                return
        await message.reply_text(dashboard, reply_markup=get_admin_panel_buttons())

    # ---------------- Cancel Operation ----------------
    @app.on_callback_query(admin_filter & filters.regex(r"^admin_cancel_operation$"))
    async def admin_cancel_operation_callback(client: Client, query: CallbackQuery):
        await query.answer()
        _admin_manager.clear_state(query.from_user.id)
        await _edit_in_place(query.message, 
            "✅ Operation cancelled.\n\n"
            "Any pending input has been cleared.",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("Open Admin Panel", callback_data="back_admin")]
            ])
        )

    # ---------------- Category Menu Callbacks ----------------
    @app.on_callback_query(admin_filter & filters.regex(r"^menu_user$"))
    async def menu_user_callback(client: Client, query: CallbackQuery):
        await query.answer()
        await _edit_in_place(query.message, 
            "--- USER MANAGEMENT ---\n"
            "All user operations:\n\n"
            "Choose from the buttons below:",
            reply_markup=get_user_management_buttons()
        )

    @app.on_callback_query(admin_filter & filters.regex(r"^menu_country$"))
    async def menu_country_callback(client: Client, query: CallbackQuery):
        await query.answer()
        await _edit_in_place(query.message, 
            "--- COUNTRY & PRICING ---\n"
            "Configure country rates & timeout:\n\n"
            "Choose from the buttons below:",
            reply_markup=get_country_pricing_buttons()
        )

    @app.on_callback_query(admin_filter & filters.regex(r"^menu_withdraw$"))
    async def menu_withdraw_callback(client: Client, query: CallbackQuery):
        await query.answer()
        await _edit_in_place(query.message, 
            "--- WITHDRAW & FINANCE ---\n"
            "Withdraw & finance control:\n\n"
            "Choose from the buttons below:",
            reply_markup=get_withdraw_finance_buttons()
        )

    @app.on_callback_query(admin_filter & filters.regex(r"^menu_system$"))
    async def menu_system_callback(client: Client, query: CallbackQuery):
        await query.answer()
        await _edit_in_place(query.message, 
            "--- SYSTEM CONTROLS ---\n"
            "Bot main control panel:\n\n"
            "Choose from the buttons below:",
            reply_markup=get_system_controls_buttons()
        )

    @app.on_callback_query(admin_filter & filters.regex(r"^menu_messaging$"))
    async def menu_messaging_callback(client: Client, query: CallbackQuery):
        await query.answer()
        await _edit_in_place(query.message, 
            "--- MESSAGING & CHANNEL ---\n"
            "Message & channel tools:\n\n"
            "Choose from the buttons below:",
            reply_markup=get_messaging_buttons()
        )

    @app.on_callback_query(admin_filter & filters.regex(r"^menu_session$"))
    async def menu_session_callback(client: Client, query: CallbackQuery):
        await query.answer()
        counts = get_session_export_counts()
        await _edit_in_place(query.message, 
            "--- SESSION MANAGEMENT ---\n"
            "Session export & management:\n\n"
            f"Active Sessions: {counts.get('active', 0)}\n"
            f"Pending Sessions: {counts.get('pending', 0)}\n\n"
            "Sessions will be deleted after download.\n"
            "Reports will remain in channels.",
            reply_markup=get_session_management_buttons()
        )

    # ---------------- Advanced Tools Menu ----------------
    @app.on_callback_query(admin_filter & filters.regex(r"^menu_advanced_tools$"))
    async def menu_advanced_tools_callback(client: Client, query: CallbackQuery):
        await query.answer()
        await _edit_in_place(query.message, 
            "--- ADVANCED TOOLS ---\n"
            "Advanced tools & data management:\n\n"
            "Choose from the buttons below:",
            reply_markup=get_advanced_tools_buttons()
        )

    # ---------------- Settings & Configuration Menu ----------------
    @app.on_callback_query(admin_filter & filters.regex(r"^menu_settings_config$"))
    async def menu_settings_config_callback(client: Client, query: CallbackQuery):
        await query.answer()
        await _edit_in_place(query.message, 
            "--- SETTINGS & CONFIGURATION ---\n"
            "Bot & admin settings:\n\n"
            "Choose from the buttons below:",
            reply_markup=get_settings_config_buttons()
        )

    # ---------------- Core Features v2 Menu ----------------
    @app.on_callback_query(admin_filter & filters.regex(r"^open_core_features$"))
    async def open_core_features_callback(client: Client, query: CallbackQuery):
        await query.answer()
        from bot.handlers.admin_features import _build_realtime_monitor, get_realtime_buttons
        msg = _build_realtime_monitor()
        await _edit_in_place(query.message, msg, reply_markup=get_realtime_buttons())

    # ============================================================
    # 🛠️ ADVANCED TOOLS - FULLY IMPLEMENTED CALLBACKS
    # ============================================================
    
    @app.on_callback_query(admin_filter & filters.regex(r"^view_all_countries$"))
    async def view_all_countries_callback(client: Client, query: CallbackQuery):
        """📋 View All Countries & Rates"""
        await query.answer()
        try:
            countries = _storage.get("countries", {})
            if not countries:
                await _edit_in_place(query.message, 
                    "📋 **All Countries & Rates**\n\n"
                    "❌ No countries configured.\n\n"
                    "💡 To add countries:\n"
                    "Country & Pricing Controls → Set Country Price",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("🔙 Back to Advanced Tools", callback_data="menu_advanced_tools")]
                    ])
                )
                return
            
            from bot.utils.country_data import get_flag
            
            lines = []
            for code, data in sorted(countries.items()):
                flag = get_flag(code)
                spam_free = data.get("spam_free_rate", data.get("rate", 0))
                spam = data.get("spam_rate", 0)
                limit = data.get("limit_rate", 0)
                timeout = data.get("timeout", 300)
                is_open = data.get("open", False)
                status = "🟢 Open" if is_open else "🔴 Closed"
                
                lines.append(
                    f"{flag} **{code}** {status}\n"
                    f"   ✅ Spam Free: ${spam_free} | ⚠️ Spam: ${spam} | 🔒 Limit: ${limit}\n"
                    f"   ⏰ Timeout: {timeout}s"
                )
            
            total_countries = len(countries)
            open_count = sum(1 for d in countries.values() if d.get("open", False))
            
            header = (
                f"📋 **All Countries & Rates**\n"
                f"━━━━━━━━━━━━━━━━━━━━━\n"
                f"🌍 Total Countries: **{total_countries}**\n"
                f"🟢 Open: **{open_count}** | 🔴 Closed: **{total_countries - open_count}**\n"
                f"━━━━━━━━━━━━━━━━━━━━━\n\n"
            )
            
            full_msg = header + "\n\n".join(lines[:20])
            if len(lines) > 20:
                full_msg += f"\n\n⚠️ {len(lines) - 20} more countries..."
            
            buttons = [[InlineKeyboardButton("🔙 Back to Advanced Tools", callback_data="menu_advanced_tools")]]
            
            if len(full_msg) > 4000:
                await _edit_in_place(query.message, header)
                for i in range(0, len(lines), 10):
                    chunk = "\n\n".join(lines[i:i+10])
                    await query.message.reply(chunk)
                await _edit_in_place(query.message, "✅ All country information displayed.", reply_markup=InlineKeyboardMarkup(buttons))
            else:
                await _edit_in_place(query.message, full_msg, reply_markup=InlineKeyboardMarkup(buttons))
        except Exception as e:
            await _edit_in_place(query.message, f"❌ Error: {str(e)}")

    @app.on_callback_query(admin_filter & filters.regex(r"^search_user$"))
    async def search_user_callback(client: Client, query: CallbackQuery):
        """🔍 Search User"""
        await query.answer()
        uid = query.from_user.id
        _set_admin_state(uid, query, "search_user")
        await _edit_in_place(query.message, 
            "🔍 **Search User**\n\n"
            "Enter the User ID to search:\n\n"
            "Example: `123456789`\n\n"
            "❌ Type /admin to cancel",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🔙 Back to Advanced Tools", callback_data="menu_advanced_tools")]
            ])
        )

    @app.on_callback_query(admin_filter & filters.regex(r"^view_pending_sessions$"))
    async def view_pending_sessions_callback(client: Client, query: CallbackQuery):
        """⏳ View Pending Sessions"""
        await query.answer()
        try:
            pending = get_all_pending_sessions()
            if not pending:
                await _edit_in_place(query.message, 
                    "⏳ **Pending Sessions**\n\n"
                    "✅ No pending sessions.",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("🔙 Back to Advanced Tools", callback_data="menu_advanced_tools")]
                    ])
                )
                return
            
            from bot.utils.country_data import get_flag
            
            lines = []
            status_counts = {"pending": 0, "approved": 0, "rejected": 0, "timeout": 0}
            
            for session_id, data in list(pending.items())[:30]:
                phone = data.get("phone", "N/A")
                country_code = data.get("country_code", "N/A")
                status = data.get("status", "pending")
                submitted = data.get("submitted_at", data.get("created_at", "N/A"))
                user_id = data.get("user_id", "N/A")
                flag = get_flag(country_code) if country_code != "N/A" else "🌍"
                
                status_counts[status] = status_counts.get(status, 0) + 1
                
                status_icon = {"pending": "⏳", "approved": "✅", "rejected": "❌", "timeout": "⏰"}.get(status, "❓")
                
                if submitted != "N/A":
                    try:
                        submitted = submitted[:16].replace("T", " ")
                    except (AttributeError, TypeError):
                        pass
                
                lines.append(
                    f"{status_icon} **{phone}** {flag}\n"
                    f"   👤 User: `{user_id}` | 🌍 {country_code}\n"
                    f"   📅 {submitted}"
                )
            
            header = (
                f"⏳ **Pending Sessions**\n"
                f"━━━━━━━━━━━━━━━━━━━━━\n"
                f"📊 Total: **{len(pending)}**\n"
                f"⏳ Pending: {status_counts.get('pending', 0)} | ✅ Approved: {status_counts.get('approved', 0)}\n"
                f"❌ Rejected: {status_counts.get('rejected', 0)} | ⏰ Timeout: {status_counts.get('timeout', 0)}\n"
                f"━━━━━━━━━━━━━━━━━━━━━\n\n"
            )
            
            full_msg = header + "\n\n".join(lines[:15])
            if len(pending) > 15:
                full_msg += f"\n\n⚠️ {len(pending) - 15} more sessions..."
            
            buttons = [
                [InlineKeyboardButton("🧹 Cleanup Old Sessions", callback_data="cleanup_old_sessions")],
                [InlineKeyboardButton("🔙 Back to Advanced Tools", callback_data="menu_advanced_tools")]
            ]
            
            if len(full_msg) > 4000:
                await _edit_in_place(query.message, header)
                for chunk in lines[:15]:
                    await query.message.reply(chunk)
                await _edit_in_place(query.message, "✅ All sessions displayed.", reply_markup=InlineKeyboardMarkup(buttons))
            else:
                await _edit_in_place(query.message, full_msg, reply_markup=InlineKeyboardMarkup(buttons))
        except Exception as e:
            await _edit_in_place(query.message, f"❌ Error: {str(e)}")

    @app.on_callback_query(admin_filter & filters.regex(r"^cleanup_old_sessions$"))
    async def cleanup_old_sessions_callback(client: Client, query: CallbackQuery):
        """🧹 Cleanup Old Sessions - Confirmation"""
        await query.answer()
        pending = get_all_pending_sessions()
        total_pending = len(pending)
        
        await _edit_in_place(query.message, 
            "--- CLEANUP OLD SESSIONS ---\n\n"
            "Stuck sessions older than 24 hours will be deleted.\n\n"

            "Are you sure?",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("Yes, Cleanup", callback_data="confirm_cleanup_sessions"),
                 InlineKeyboardButton("Cancel", callback_data="menu_advanced_tools")]
            ])
        )

    @app.on_callback_query(admin_filter & filters.regex(r"^confirm_cleanup_sessions$"))
    async def confirm_cleanup_sessions_callback(client: Client, query: CallbackQuery):
        await query.answer()
        try:
            before_count = len(get_all_pending_sessions())
            cleaned = cleanup_old_stuck_sessions(max_age_hours=24)
            after_count = len(get_all_pending_sessions())
            
            await _edit_in_place(query.message, 
                "--- CLEANUP COMPLETE ---\n\n"
                f"Before: {before_count} sessions\n"
                f"Cleaned: {cleaned} sessions\n"
                f"After: {after_count} sessions\n\n"
                "Stuck sessions older than 24 hours have been deleted.",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("Back to Advanced Tools", callback_data="menu_advanced_tools")]
                ])
            )
        except Exception as e:
            await _edit_in_place(query.message, f"Cleanup Error: {str(e)}")

    @app.on_callback_query(admin_filter & filters.regex(r"^backup_export_data$"))
    async def backup_export_data_callback(client: Client, query: CallbackQuery):
        await query.answer("Preparing backup...")
        
        import asyncio
        from datetime import datetime
        
        storage_file = "data/storage.json"
        
        try:
            if not os.path.exists(storage_file):
                await _edit_in_place(query.message, 
                    "❌ **Backup Error**\n\n"
                    "storage.json file not found!\n"
                    "No data in bot.",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("🔙 Back to Advanced Tools", callback_data="menu_advanced_tools")]
                    ])
                )
                return
            
            def _read_and_prepare_backup():
                """Non-blocking file operations in separate thread"""
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                backup_filename = f"backup_storage_{timestamp}.json"
                backup_path = f"/tmp/{backup_filename}"
                
                with open(storage_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                
                stats = {
                    "users": len(data.get("users", {})),
                    "countries": len(data.get("countries", {})),
                    "pending_sessions": len(data.get("pending_sessions", {})),
                    "withdrawals": len(data.get("withdrawals", [])),
                    "admin_logs": len(data.get("admin_logs", []))
                }
                
                with open(backup_path, 'w', encoding='utf-8') as f:
                    json.dump(data, f, ensure_ascii=False, indent=2)
                
                file_size = os.path.getsize(backup_path)
                
                return backup_path, backup_filename, stats, file_size, timestamp
            
            backup_path, backup_filename, stats, file_size, timestamp = await asyncio.to_thread(_read_and_prepare_backup)
            
            file_size_kb = file_size / 1024
            file_size_str = f"{file_size_kb:.1f} KB" if file_size_kb < 1024 else f"{file_size_kb/1024:.2f} MB"
            
            caption = (
                "--- STORAGE BACKUP ---\n"
                f"Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
                f"Size: {file_size_str}\n\n"
                f"Users: {stats['users']}\n"
                f"Countries: {stats['countries']}\n"
                f"Pending: {stats['pending_sessions']}\n"
                f"Withdrawals: {stats['withdrawals']}\n"
                f"Admin Logs: {stats['admin_logs']}\n\n"
                "Backup created successfully."
            )
            
            await client.send_document(
                chat_id=query.message.chat.id,
                document=backup_path,
                caption=caption,
                file_name=backup_filename
            )
            
            try:
                os.remove(backup_path)
            except OSError:
                pass
            
        except FileNotFoundError:
            await _edit_in_place(query.message, 
                "--- BACKUP ERROR ---\nstorage.json file not found.",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("Back to Advanced Tools", callback_data="menu_advanced_tools")]
                ])
            )
        except json.JSONDecodeError as e:
            await _edit_in_place(query.message, 
                f"--- BACKUP ERROR ---\nstorage.json is corrupted.\nError: {str(e)}",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("Back to Advanced Tools", callback_data="menu_advanced_tools")]
                ])
            )
        except Exception as e:
            await _edit_in_place(query.message, 
                f"--- BACKUP ERROR ---\n{str(e)}",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("Back to Advanced Tools", callback_data="menu_advanced_tools")]
                ])
            )

    # ============================================================
    # ⚙️ SETTINGS & CONFIG - FULLY IMPLEMENTED CALLBACKS
    # ============================================================
    
    @app.on_callback_query(admin_filter & filters.regex(r"^set_2fa_password$"))
    async def set_2fa_password_callback(client: Client, query: CallbackQuery):
        """🔑 Set 2FA Password"""
        await query.answer()
        current_password = get_2fa_password()
        masked_password = current_password[:4] + "*" * (len(current_password) - 4) if len(current_password) > 4 else "***"
        
        await _edit_in_place(query.message, 
            "--- 2FA PASSWORD SETTINGS ---\n\n"
            f"Current: `{masked_password}`\n\n"
            "This password is used for 2FA setup during session creation.\n\n"
            "Click the button below to change password.\n"
            "Use a strong password (16+ characters)",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("Set New Password", callback_data="set_2fa_password_input")],
                [InlineKeyboardButton("Back to Settings", callback_data="menu_settings_config")]
            ])
        )
    
    @app.on_callback_query(admin_filter & filters.regex(r"^set_2fa_password_input$"))
    async def set_2fa_password_input_callback(client: Client, query: CallbackQuery):
        """🔑 Set 2FA Password - Input Mode"""
        await query.answer()
        uid = query.from_user.id
        _set_admin_state(uid, query, "set_2fa_password")
        await _edit_in_place(query.message, 
            "🔑 **Set New 2FA Password**\n\n"
            "Enter new password:\n\n"

            "• At least 8 characters\n"
            "• Strong password recommended\n\n"
            "❌ Type /admin to cancel"
        )

    @app.on_callback_query(admin_filter & filters.regex(r"^country_wise_stats$"))
    async def country_wise_stats_callback(client: Client, query: CallbackQuery):
        """🌍 Country-wise Stats - Page 1"""
        await _show_country_stats_page(client, query, page=1)
    
    @app.on_callback_query(admin_filter & filters.regex(r"^country_stats_page_(\d+)$"))
    async def country_stats_page_callback(client: Client, query: CallbackQuery):
        """🌍 Country-wise Stats - Paginated"""
        import re
        data_str = str(query.data) if query.data else ""
        match = re.match(r"^country_stats_page_(\d+)$", data_str)
        page = int(match.group(1)) if match else 1
        await _show_country_stats_page(client, query, page=page)
    
    async def _show_country_stats_page(client: Client, query: CallbackQuery, page: int = 1):
        """Helper function to show country stats with pagination"""
        await query.answer()
        
        ITEMS_PER_PAGE = 10
        
        try:
            from bot.utils.country_data import get_flag
            
            session_tracker = _storage.get("session_tracker", {})
            if session_tracker is None:
                session_tracker = {}
            
            country_stats = {}
            
            for user_id, sessions in session_tracker.items():
                if not isinstance(sessions, list):
                    continue
                    
                for session in sessions:
                    if not isinstance(session, dict):
                        continue
                    
                    cc = session.get("country_code", "other") or "other"
                    
                    try:
                        amount = float(session.get("amount", 0) or 0)
                    except (ValueError, TypeError):
                        amount = 0.0
                    
                    if cc not in country_stats:
                        country_stats[cc] = {"count": 0, "earnings": 0.0}
                    country_stats[cc]["count"] += 1
                    country_stats[cc]["earnings"] += amount
            
            if not country_stats:
                await _edit_in_place(query.message, 
                    "--- COUNTRY-WISE STATS ---\n\n"
                    "No session data yet.\n"
                    "Stats will appear here when users verify.",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("Back to Settings", callback_data="menu_settings_config")]
                    ])
                )
                return
            
            sorted_stats = sorted(country_stats.items(), key=lambda x: x[1].get("count", 0), reverse=True)
            
            total_sessions = sum(s.get("count", 0) for s in country_stats.values())
            total_earnings = sum(s.get("earnings", 0) for s in country_stats.values())
            total_countries = len(country_stats)
            
            total_pages = (total_countries + ITEMS_PER_PAGE - 1) // ITEMS_PER_PAGE
            page = max(1, min(page, total_pages))
            
            start_idx = (page - 1) * ITEMS_PER_PAGE
            end_idx = start_idx + ITEMS_PER_PAGE
            page_stats = sorted_stats[start_idx:end_idx]
            
            lines = []
            for idx, (cc, stats) in enumerate(page_stats, start=start_idx + 1):
                try:
                    flag = get_flag(cc) if cc and cc != "other" else "-"
                except (KeyError, IndexError):
                    flag = "-"
                count = stats.get("count", 0)
                earnings = stats.get("earnings", 0.0)
                lines.append(f"{idx}. {flag} {cc}: {count} sessions | ${earnings:.2f}")
            
            pagination_buttons = []
            if page > 1:
                pagination_buttons.append(InlineKeyboardButton("Previous", callback_data=f"country_stats_page_{page - 1}"))
            if page < total_pages:
                pagination_buttons.append(InlineKeyboardButton("Next", callback_data=f"country_stats_page_{page + 1}"))
            
            buttons = []
            if pagination_buttons:
                buttons.append(pagination_buttons)
            buttons.append([InlineKeyboardButton("Back to Settings", callback_data="menu_settings_config")])
            
            await _edit_in_place(query.message, 
                "--- COUNTRY-WISE STATS ---\n"
                f"Sessions: {total_sessions}\n"
                f"Earnings: ${total_earnings:.2f}\n"
                f"Countries: {total_countries}\n"
                "--------------------------\n\n"
                f"Page {page}/{total_pages}:\n" + "\n".join(lines),
                reply_markup=InlineKeyboardMarkup(buttons)
            )
        except Exception as e:
            await _edit_in_place(query.message, 
                f"--- STATS ERROR ---\n{str(e)}",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("Back to Settings", callback_data="menu_settings_config")]
                ])
            )

    @app.on_callback_query(admin_filter & filters.regex(r"^daily_report_toggle$"))
    async def daily_report_toggle_callback(client: Client, query: CallbackQuery):
        await query.answer()
        try:
            current_status = _storage.get("daily_report_enabled", False)
            new_status = not current_status
            _storage["daily_report_enabled"] = new_status
            save_storage()
            
            status_text = "ON" if new_status else "OFF"
            status_msg = "Enabled" if new_status else "Disabled"
            
            await _edit_in_place(query.message, 
                "--- DAILY REPORT TOGGLE ---\n\n"
                f"Status: {status_text}\n"
                f"Daily Report {status_msg}!\n\n"
                "When ON, auto report will be sent daily at 9 AM.",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton(f"Toggle (Now: {status_text})", callback_data="daily_report_toggle")],
                    [InlineKeyboardButton("Back to Settings", callback_data="menu_settings_config")]
                ])
            )
        except Exception as e:
            await _edit_in_place(query.message, f"Toggle Error: {str(e)}")

    @app.on_callback_query(admin_filter & filters.regex(r"^add_admin_input$"))
    async def add_admin_input_callback(client: Client, query: CallbackQuery):
        await query.answer()
        uid = query.from_user.id
        _set_admin_state(uid, query, "add_new_admin")
        await _edit_in_place(query.message, 
            "--- ADD NEW ADMIN ---\n\n"
            "Enter new admin User ID:\n"
            "Example: 123456789\n\n"
            "Type /admin to cancel"
        )

    # ---------------- Remove Admin Callbacks ----------------
    @app.on_callback_query(admin_filter & filters.regex(r"^remove_admin$"))
    async def remove_admin_callback(client: Client, query: CallbackQuery):
        await query.answer()
        try:
            admins = _storage.get("admins", [ADMIN_ID])
            if ADMIN_ID not in admins:
                admins.append(ADMIN_ID)
                _storage["admins"] = admins
                save_storage()
            
            if len(admins) <= 1:
                await _edit_in_place(query.message, 
                    "--- REMOVE ADMIN ---\n\n"
                    "Only primary admin exists.\n"
                    "No other admins to remove.",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("Back to Settings", callback_data="menu_settings_config")]
                    ])
                )
                return
            
            buttons = []
            for admin_id in admins:
                if admin_id == ADMIN_ID:
                    buttons.append([InlineKeyboardButton(f"{admin_id} (Primary - Protected)", callback_data="protected_admin")])
                else:
                    buttons.append([InlineKeyboardButton(f"Remove {admin_id}", callback_data=f"confirm_remove_admin_{admin_id}")])
            
            buttons.append([InlineKeyboardButton("Back to Settings", callback_data="menu_settings_config")])
            
            await _edit_in_place(query.message, 
                "--- REMOVE ADMIN ---\n\n"
                f"Total Admins: {len(admins)}\n\n"
                "Click the admin to remove:\n"
                "Primary Admin cannot be removed.",
                reply_markup=InlineKeyboardMarkup(buttons)
            )
        except Exception as e:
            await _edit_in_place(query.message, f"❌ Error: {str(e)}")

    @app.on_callback_query(admin_filter & filters.regex(r"^protected_admin$"))
    async def protected_admin_callback(client: Client, query: CallbackQuery):
        """Primary Admin protection notice"""
        await query.answer("⚠️ Primary Admin cannot be removed!", show_alert=True)

    @app.on_callback_query(admin_filter & filters.regex(r"^confirm_remove_admin_(\d+)$"))
    async def confirm_remove_admin_callback(client: Client, query: CallbackQuery):
        """❌ Confirm Remove Admin"""
        await query.answer()
        try:
            match = query.matches[0] if query.matches else None
            if not match:
                await _edit_in_place(query.message, "❌ Invalid request")
                return
            
            admin_to_remove = int(match.group(1))
            
            if admin_to_remove == ADMIN_ID:
                await _edit_in_place(query.message, 
                    "--- RESTRICTED ---\n\n"
                    "Primary Admin cannot be removed!",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("Back to Settings", callback_data="menu_settings_config")]
                    ])
                )
                return
            
            admins = _storage.get("admins", [ADMIN_ID])
            
            if admin_to_remove not in admins:
                await _edit_in_place(query.message, 
                    f"User `{admin_to_remove}` is not in the admin list!",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("Back to Settings", callback_data="menu_settings_config")]
                    ])
                )
                return
            
            admins.remove(admin_to_remove)
            _storage["admins"] = admins
            save_storage()
            
            admin_lines = [f"`{aid}`" + (" (Primary)" if aid == ADMIN_ID else "") for aid in admins]
            
            await _edit_in_place(query.message, 
                "--- ADMIN REMOVED ---\n\n"
                f"Removed: `{admin_to_remove}`\n"
                f"Remaining: {len(admins)}\n\n"
                "Admin List:\n" + "\n".join(admin_lines),
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("Remove Another", callback_data="remove_admin")],
                    [InlineKeyboardButton("Back to Settings", callback_data="menu_settings_config")]
                ])
            )
        except Exception as e:
            await _edit_in_place(query.message, f"Error: {str(e)}")

    # ---------------- Session Export Callbacks ----------------
    @app.on_callback_query(admin_filter & filters.regex(r"^export_active_sessions$"))
    async def export_active_sessions_callback(client: Client, query: CallbackQuery):
        await query.answer("Exporting active sessions...")
        await _export_sessions(client, query, "active")

    @app.on_callback_query(admin_filter & filters.regex(r"^export_pending_sessions$"))
    async def export_pending_sessions_callback(client: Client, query: CallbackQuery):
        await query.answer("Exporting pending sessions...")
        await _export_sessions(client, query, "pending")

    @app.on_callback_query(admin_filter & filters.regex(r"^export_all_sessions$"))
    async def export_all_sessions_callback(client: Client, query: CallbackQuery):
        await query.answer("Exporting all sessions...")
        await _export_sessions(client, query, "all")

    async def _export_sessions(client: Client, query: CallbackQuery, export_type: str):
        import zipfile
        import os
        import asyncio
        from datetime import datetime
        
        if export_type == "active":
            sessions = get_exportable_sessions()
            type_name = "Active"
        elif export_type == "pending":
            sessions = get_pending_exportable_sessions()
            type_name = "Pending"
        else:
            active_sessions = get_exportable_sessions()
            pending_sessions = get_pending_exportable_sessions()
            sessions = {**active_sessions, **pending_sessions}
            type_name = "All"
        
        if not sessions:
            await _edit_in_place(query.message, 
                f"❌ No {type_name} sessions to export!",
                reply_markup=get_session_management_buttons()
            )
            return
        
        await _edit_in_place(query.message, 
            f"📦 **{type_name} Sessions Export**\n\n"
            f"⏳ {len(sessions)} sessions being zipped...\n"
            f"Please wait..."
        )
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        zip_filename = f"sessions_{type_name.lower()}_{timestamp}.zip"
        zip_path = f"/tmp/{zip_filename}"
        upload_success = False
        session_ids_exported = []
        files_added = 0
        
        def _create_zip_blocking():
            """Blocking ZIP creation - runs in separate thread."""
            nonlocal files_added
            local_files_added = 0
            local_session_ids = []
            
            try:
                with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                    for session_id, session_data in sessions.items():
                        local_session_ids.append(session_id)
                        telethon_file = session_data.get("telethon_file", "")
                        
                        if telethon_file and os.path.exists(telethon_file):
                            original_filename = os.path.basename(telethon_file)
                            zipf.write(telethon_file, original_filename)
                            local_files_added += 1
                
                return local_session_ids, local_files_added
            except Exception as e:
                print(f"ZIP creation error: {e}")
                raise
        
        try:
            session_ids_exported, files_added = await asyncio.to_thread(_create_zip_blocking)
            
            if os.path.exists(zip_path):
                zip_size_mb = os.path.getsize(zip_path) / (1024 * 1024)
                if zip_size_mb > 49:
                    await _edit_in_place(query.message, 
                        f"⚠️ *ZIP file too large ({zip_size_mb:.1f} MB)!*\n\n"
                        f"Telegram allows maximum 50 MB.\n"
                        f"Please try with fewer sessions."
                    )
                    return
            
            await _edit_in_place(query.message, 
                f"📦 **{type_name} Sessions Export**\n\n"
                f"⏳ ZIP created ({files_added} files)\n"
                f"📤 Uploading now..."
            )
            
            await client.send_document(
                chat_id=query.from_user.id,
                document=zip_path,
                caption=(
                    f"📦 **{type_name} Sessions Export Complete!**\n\n"
                    f"✅ Sessions: **{len(session_ids_exported)}**\n"
                    f"📁 Files: **{files_added}**\n\n"
                    f"⚠️ Deleting sessions from storage..."
                ),
                file_name=zip_filename
            )
            upload_success = True
            
            deleted_count = delete_exported_sessions(session_ids_exported)
            
            def _cleanup_session_files():
                """Blocking file cleanup - runs in separate thread."""
                for session_id in session_ids_exported:
                    session_data = sessions.get(session_id, {})
                    session_file = session_data.get("session_file", "")
                    telethon_file = session_data.get("telethon_file", "")
                    
                    for file_path in [session_file, telethon_file]:
                        if file_path and os.path.exists(file_path):
                            try:
                                os.remove(file_path)
                            except Exception:
                                pass
            
            await asyncio.to_thread(_cleanup_session_files)
            
            await _edit_in_place(query.message, 
                f"✅ *Export Complete!*\n\n"
                f"📦 {len(session_ids_exported)} {type_name} sessions exported and deleted.\n"
                f"🗑️ Deleted from storage: **{deleted_count}**\n\n"
                f"You can export again when new sessions arrive.",
                reply_markup=get_session_management_buttons()
            )
            
        except Exception as e:
            error_msg = str(e)
            print(f"Session export error: {e}")
            
            if not upload_success:
                try:
                    await _edit_in_place(query.message, 
                        f"❌ **Export Error!**\n\n"
                        f"Error: {error_msg}\n\n"
                        f"Sessions were not deleted, please try again."
                    )
                except Exception:
                    pass
        
        finally:
            if os.path.exists(zip_path):
                try:
                    os.remove(zip_path)
                except Exception:
                    pass

    # ---------------- Approve/Reject Withdraw Callbacks ----------------
    @app.on_callback_query(admin_filter & filters.regex(r"^wapprove_(\d+)$"))
    async def approve_withdraw_callback(client: Client, query: CallbackQuery):
        """Approve a pending withdraw request by index"""
        await query.answer("⏳ Processing...")
        try:
            from bot.utils.storage import approve_withdraw_request
            from bot.utils.fast_cache import invalidate_user_cache
            
            match = query.matches[0] if query.matches else None
            if not match:
                await _edit_in_place(query.message, "❌ Invalid request")
                return
            
            index = int(match.group(1))
            result = approve_withdraw_request(index)
            
            if result.get("success"):
                user_id = result.get("user_id", "N/A")
                amount = result.get("amount", 0)
                method = result.get("method", "N/A")
                wallet = result.get("wallet_address", "N/A")
                timestamp = result.get("timestamp", "")
                
                try:
                    invalidate_user_cache(int(user_id))
                except (ValueError, TypeError):
                    pass
                
                await _edit_in_place(query.message, 
                    "--- WITHDRAW APPROVED ---\n\n"
                    f"User: `{user_id}`\n"
                    f"Amount: ${amount:.2f}\n"
                    f"Method: {method}\n"
                    f"Wallet: `{wallet}`\n\n"
                    "Pay now!",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("View Pending", callback_data="pendingwithdraw")],
                        [InlineKeyboardButton("Back to Withdraw & Finance", callback_data="menu_withdraw")]
                    ])
                )
                
                if CHANNEL_WITHDRAW_REPORT:
                    try:
                        await client.send_message(
                            chat_id=CHANNEL_WITHDRAW_REPORT,
                            text=(
                                f"✅ **Withdraw Approved**\n\n"
                                f"👤 User ID: `{user_id}`\n"
                                f"💰 Amount: *${amount:.2f}*\n"
                                f"💳 Method: *{method}*\n"
                                f"📬 Wallet: `{wallet}`\n"
                                f"🕒 Submitted: {timestamp}\n"
                                f"🕒 Approved: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
                            )
                        )
                    except Exception as channel_err:
                        logger.error(f"Failed to send approve report to channel: {channel_err}")
            else:
                await _edit_in_place(query.message, f"Error: {result.get('error', 'Unknown error')}")
        except Exception as e:
            await _edit_in_place(query.message, f"Approve Error: {str(e)}")

    @app.on_callback_query(admin_filter & filters.regex(r"^wreject_(\d+)$"))
    async def reject_withdraw_callback(client: Client, query: CallbackQuery):
        await query.answer("Processing...")
        try:
            from bot.utils.storage import reject_withdraw_request
            from bot.utils.fast_cache import invalidate_user_cache
            
            match = query.matches[0] if query.matches else None
            if not match:
                await _edit_in_place(query.message, "Invalid request")
                return
            
            index = int(match.group(1))
            result = reject_withdraw_request(index)
            
            if result.get("success"):
                user_id = result.get("user_id", "N/A")
                amount = result.get("amount", 0)
                method = result.get("method", "N/A")
                wallet = result.get("wallet_address", "N/A")
                timestamp = result.get("timestamp", "")
                
                try:
                    invalidate_user_cache(int(user_id))
                except (ValueError, TypeError):
                    pass
                
                await _edit_in_place(query.message, 
                    "--- WITHDRAW REJECTED ---\n\n"
                    f"User: `{user_id}`\n"
                    f"Amount: ${amount:.2f}\n\n"
                    f"Balance Refunded!\n"
                    f"Refunded ${amount:.2f} to user account.",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("View Pending", callback_data="pendingwithdraw")],
                        [InlineKeyboardButton("Back to Withdraw & Finance", callback_data="menu_withdraw")]
                    ])
                )
                
                if CHANNEL_WITHDRAW_REPORT:
                    try:
                        await client.send_message(
                            chat_id=CHANNEL_WITHDRAW_REPORT,
                            text=(
                                f"❌ **Withdraw Rejected**\n\n"
                                f"👤 User ID: `{user_id}`\n"
                                f"💰 Amount: *${amount:.2f}*\n"
                                f"💳 Method: *{method}*\n"
                                f"📬 Wallet: `{wallet}`\n"
                                f"🔄 Refunded: *${amount:.2f}*\n"
                                f"🕒 Submitted: {timestamp}\n"
                                f"🕒 Rejected: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
                            )
                        )
                    except Exception as channel_err:
                        logger.error(f"Failed to send reject report to channel: {channel_err}")
            else:
                await _edit_in_place(query.message, f"Error: {result.get('error', 'Unknown error')}")
        except Exception as e:
            await _edit_in_place(query.message, f"Reject Error: {str(e)}")

    @app.on_callback_query(admin_filter & filters.regex(r"^wpage_(\d+)$"))
    async def pending_withdraw_page_callback(client: Client, query: CallbackQuery):
        await query.answer()
        try:
            match = query.matches[0] if query.matches else None
            page = int(match.group(1)) if match else 0
            text, buttons = _build_pending_withdraw_panel(page)
            await _edit_in_place(query.message, text, reply_markup=InlineKeyboardMarkup(buttons))
        except Exception as e:
            await _edit_in_place(query.message, f"Page Error: {str(e)}")

    # ---------------- Toggle Monitor Callback ----------------
    @app.on_callback_query(admin_filter & filters.regex(r"^togglemonitor$"))
    async def toggle_monitor_callback(client: Client, query: CallbackQuery):
        is_enabled = toggle_monitor_status()
        status = "ON" if is_enabled else "OFF"
        print(f"Session Monitor toggled: {status}")
        await query.answer(f"Session Monitor: {status}", show_alert=True)
        await query.message.edit_reply_markup(reply_markup=get_system_controls_buttons())

    # ---------------- Toggle Verification Callback ----------------
    @app.on_callback_query(admin_filter & filters.regex(r"^toggleverification$"))
    async def toggle_verification_callback(client: Client, query: CallbackQuery):
        is_paused = toggle_verification_pause()
        if is_paused:
            status = "OFF - Users cannot submit numbers"
            print(f"Verification PAUSED by admin")
        else:
            status = "ON - Users can submit numbers"
            print(f"Verification RESUMED by admin")
        await query.answer(f"Verification: {status}", show_alert=True)
        await query.message.edit_reply_markup(reply_markup=get_system_controls_buttons())

    # ---------------- Toggle Spam Check Callback ----------------
    @app.on_callback_query(admin_filter & filters.regex(r"^togglespamcheck$"))
    async def toggle_spam_check_callback(client: Client, query: CallbackQuery):
        is_enabled = toggle_spam_check()
        if is_enabled:
            status = "ON - Spam check active, rate based on status"
            print(f"Spam Check ENABLED by admin")
        else:
            status = "OFF - Spam check disabled, everyone gets full rate"
            print(f"Spam Check DISABLED by admin - All accounts get spam_free rate")
        await query.answer(f"Spam Check: {status}", show_alert=True)
        await query.message.edit_reply_markup(reply_markup=get_system_controls_buttons())

    # ---------------- Quick Ban/Unban from Search User ----------------
    @app.on_callback_query(admin_filter & filters.regex(r"^quick_ban_(\d+)$"))
    async def quick_ban_callback(client: Client, query: CallbackQuery):
        await query.answer()
        data_str = str(query.data) if query.data else ""
        try:
            target_uid = int(data_str.replace("quick_ban_", ""))
            ban_user(target_uid)
            from bot.utils.fast_cache import mark_user_banned
            mark_user_banned(target_uid)
            print(f"User {target_uid} banned via quick action")
            
            await _edit_in_place(query.message, 
                "--- USER BANNED ---\n\n"
                f"User: `{target_uid}`\n"
                f"Status: BANNED\n\n"
                "This user can no longer use the bot.",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("Unban This User", callback_data=f"quick_unban_{target_uid}")],
                    [InlineKeyboardButton("Back to Advanced Tools", callback_data="menu_advanced_tools")]
                ])
            )
        except Exception as e:
            await _edit_in_place(query.message, f"Ban Error: {str(e)}")

    @app.on_callback_query(admin_filter & filters.regex(r"^quick_unban_(\d+)$"))
    async def quick_unban_callback(client: Client, query: CallbackQuery):
        """Quick unban user from search results"""
        await query.answer()
        data_str = str(query.data) if query.data else ""
        try:
            target_uid = int(data_str.replace("quick_unban_", ""))
            unban_user(target_uid)
            from bot.utils.fast_cache import mark_user_unbanned
            mark_user_unbanned(target_uid)
            print(f"✅ User {target_uid} unbanned via quick action")
            
            await _edit_in_place(query.message, 
                "--- USER UNBANNED ---\n\n"
                f"User: `{target_uid}`\n"
                f"Status: ACTIVE\n\n"
                "This user can now use the bot again.",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("Ban This User", callback_data=f"quick_ban_{target_uid}")],
                    [InlineKeyboardButton("Back to Advanced Tools", callback_data="menu_advanced_tools")]
                ])
            )
        except Exception as e:
            await _edit_in_place(query.message, f"Unban Error: {str(e)}")

    # ---------------- Min Withdraw Settings Callbacks ----------------
    @app.on_callback_query(admin_filter & filters.regex(r"^setmin_(usdt|trx|cardname|binance)$"))
    async def set_min_withdraw_callback(client: Client, query: CallbackQuery):
        uid = query.from_user.id
        data_str = str(query.data) if query.data else ""
        method = data_str.replace("setmin_", "")
        method_names = {"usdt": "USDT (BEP20)", "trx": "TRX", "cardname": "CARD NAME", "binance": "Binance"}
        method_name = method_names.get(method, method.upper())
        
        await query.answer()
        await _edit_in_place(query.message, 
            f"--- SET MIN WITHDRAW: {method_name} ---\n\n"
            f"Enter minimum withdraw amount:\n"
            f"Example: 10 (means $10 minimum)"
        )
        _set_admin_state(uid, query, "setmin", method=method)

    @app.on_callback_query(admin_filter & filters.regex(r"^back_admin$"))
    async def back_to_admin_callback(client: Client, query: CallbackQuery):
        await query.answer()
        await _edit_in_place(query.message, _build_dashboard_message(), reply_markup=get_admin_panel_buttons())

    # ---------------- Set Country Rate Type Callbacks ----------------
    @app.on_callback_query(admin_filter & filters.regex(r"^setrate_(spamfree|spam|limit)$"))
    async def set_rate_type_callback(client: Client, query: CallbackQuery):
        uid = query.from_user.id
        data_str = str(query.data) if query.data else "setrate_spamfree"
        rate_type = data_str.split("_")[1] if "_" in data_str else "spamfree"
        
        rate_type_names = {
            "spamfree": ("Spam Free", "spam_free_rate"),
            "spam": ("Spam", "spam_rate"),
            "limit": ("Limit", "limit_rate")
        }
        
        name, storage_key = rate_type_names.get(rate_type, ("Unknown", "rate"))
        
        await query.answer()
        await _edit_in_place(query.message, 
            f"--- SET {name.upper()} RATE ---\n\n"
            f"Enter country code and rate:\n"
            f"Format: +880 30 (means {name} Rate = $30 for +880)"
        )
        _set_admin_state(uid, query, "setrate_type", rate_type=storage_key)

    @app.on_callback_query(admin_filter & filters.regex(r"^setrate_all$"))
    async def set_all_rates_callback(client: Client, query: CallbackQuery):
        uid = query.from_user.id
        
        await query.answer()
        await _edit_in_place(query.message, 
            "--- SET ALL RATES ---\n\n"
            "Enter country code and three rates:\n"
            "Format: +880 30 15 10\n\n"
            "30 = Spam Free Rate (good account)\n"
            "15 = Spam Rate (spam account)\n"
            "10 = Limit Rate (limited account)"
        )
        _set_admin_state(uid, query, "setrate_all")

    # ---------------- Message Settings Callbacks ----------------
    @app.on_callback_query(admin_filter & filters.regex(r"^messagesettings$"))
    async def message_settings_callback(client: Client, query: CallbackQuery):
        await query.answer()
        templates = get_all_message_templates()
        
        buttons = []
        for key, data in templates.items():
            display_name = TEMPLATE_DISPLAY_NAMES.get(key, key)
            status = "✏️" if data["is_custom"] else "📋"
            buttons.append([InlineKeyboardButton(f"{status} {display_name}", callback_data=f"edit_tpl_{key}")])
        
        buttons.append([InlineKeyboardButton("🔙 Back to Messaging", callback_data="menu_messaging")])
        
        await _edit_in_place(query.message, 
            "📝 **Message Settings**\n\n"
            "Edit bot messages here:\n\n"
            "📋 = Default Message\n"
            "✏️ = Custom Message\n\n"
            "Click a button below to edit:",
            reply_markup=InlineKeyboardMarkup(buttons)
        )

    @app.on_callback_query(admin_filter & filters.regex(r"^edit_tpl_(.+)$"))
    async def edit_template_callback(client: Client, query: CallbackQuery):
        uid = query.from_user.id
        data_str = str(query.data) if query.data else ""
        template_key = data_str.replace("edit_tpl_", "")
        
        await query.answer()
        
        templates = get_all_message_templates()
        template_data = templates.get(template_key)
        
        if not template_data:
            await _edit_in_place(query.message, "❌ Template not found!")
            return
        
        display_name = TEMPLATE_DISPLAY_NAMES.get(template_key, template_key)
        placeholders = TEMPLATE_PLACEHOLDERS.get(template_key, "None")
        current = template_data["current"]
        is_custom = template_data["is_custom"]
        
        status_text = "✏️ Custom" if is_custom else "📋 Default"
        
        buttons = [
            [InlineKeyboardButton("✏️ Edit This Message", callback_data=f"start_edit_{template_key}")],
            [InlineKeyboardButton("🔄 Reset to Default", callback_data=f"reset_tpl_{template_key}")],
            [InlineKeyboardButton("🔙 Back to Messages", callback_data="messagesettings")]
        ]
        
        await _edit_in_place(query.message, 
            f"📝 **{display_name}**\n\n"
            f"**Status:** {status_text}\n"
            f"**Placeholders:** `{placeholders}`\n\n"
            f"**Current Message:**\n"
            f"```\n{current[:500]}{'...' if len(current) > 500 else ''}\n```\n\n"
            f"⚠️ **Note:** Placeholders (like {'{phone}'}) will be replaced with actual values.",
            reply_markup=InlineKeyboardMarkup(buttons)
        )

    @app.on_callback_query(admin_filter & filters.regex(r"^start_edit_(.+)$"))
    async def start_edit_template_callback(client: Client, query: CallbackQuery):
        uid = query.from_user.id
        data_str = str(query.data) if query.data else ""
        template_key = data_str.replace("start_edit_", "")
        
        await query.answer()
        
        display_name = TEMPLATE_DISPLAY_NAMES.get(template_key, template_key)
        placeholders = TEMPLATE_PLACEHOLDERS.get(template_key, "None")
        
        await _edit_in_place(query.message, 
            f"✏️ **Edit: {display_name}**\n\n"
            f"Enter new message:\n\n"
            f"**Available Placeholders:** `{placeholders}`\n\n"
            f"⚠️ **Important:**\n"
            f"• Write placeholders exactly as shown: {'{phone}'}, {'{price}'} etc.\n"
            f"• Type /admin to cancel"
        )
        _set_admin_state(uid, query, "edit_template", template_key=template_key)

    @app.on_callback_query(admin_filter & filters.regex(r"^reset_tpl_(.+)$"))
    async def reset_template_callback(client: Client, query: CallbackQuery):
        data_str = str(query.data) if query.data else ""
        template_key = data_str.replace("reset_tpl_", "")
        
        await query.answer()
        
        display_name = TEMPLATE_DISPLAY_NAMES.get(template_key, template_key)
        
        buttons = [
            [InlineKeyboardButton("✅ Yes, Reset", callback_data=f"confirm_reset_{template_key}")],
            [InlineKeyboardButton("❌ Cancel", callback_data=f"edit_tpl_{template_key}")]
        ]
        
        await _edit_in_place(query.message, 
            f"⚠️ **Reset Confirmation**\n\n"
            f"Are you sure you want to reset *{display_name}* to default?",
            reply_markup=InlineKeyboardMarkup(buttons)
        )

    @app.on_callback_query(admin_filter & filters.regex(r"^confirm_reset_(.+)$"))
    async def confirm_reset_template_callback(client: Client, query: CallbackQuery):
        data_str = str(query.data) if query.data else ""
        template_key = data_str.replace("confirm_reset_", "")
        
        if template_key.startswith("tracker"):
            return
        
        await query.answer()
        
        reset_message_template(template_key)
        display_name = TEMPLATE_DISPLAY_NAMES.get(template_key, template_key)
        
        try:
            from bot.utils.fast_cache import refresh_all_templates
            refresh_all_templates()
            print(f"✅ Template '{template_key}' reset and cache refreshed")
        except Exception as cache_error:
            print(f"⚠️ Cache refresh error: {cache_error}")
        
        await _edit_in_place(query.message, 
            f"✅ **{display_name}** successfully reset to default!"
        )

    # ---------------- Callback Queries ----------------
    @app.on_callback_query(admin_filter & filters.regex(r"^(setrate|settimeout|ban|unban|adjustbalance|userstats|totalusers|zerobalance|pendingwithdraw|withdrawlogs|togglewithdraw|togglecountry|disablecountries|broadcast|sendtouser|setchannel|minwithdraw|allbalances|user_withdraw_control|uwc_.*|show_2fa_secret)$"))
    async def admin_callbacks(client: Client, query: CallbackQuery):
        uid = query.from_user.id
        data = str(query.data)
        
        print(f"🔍 Admin callback received: {data} from user {uid}")
        
        await query.answer()

        # ---------------- Actions requiring input ----------------
        if data == "setrate":
            buttons = [
                [InlineKeyboardButton("Spam Free Rate (Clean Account)", callback_data="setrate_spamfree"),
                 InlineKeyboardButton("Spam Rate", callback_data="setrate_spam")],
                [InlineKeyboardButton("Limit Rate", callback_data="setrate_limit"),
                 InlineKeyboardButton("Set All Rates at Once", callback_data="setrate_all")],
                [InlineKeyboardButton("Back to Country & Pricing", callback_data="menu_country")]
            ]
            await _edit_in_place(query.message, 
                "--- SET COUNTRY PRICE ---\n\n"
                "Which account type to set rate for?\n\n"
                "Spam Free = Good account (highest rate)\n"
                "Spam = Spam account (low rate)\n"
                "Limit = Limited account",
                reply_markup=InlineKeyboardMarkup(buttons)
            )

        elif data == "settimeout":
            await _edit_in_place(query.message, 
                "--- SET SESSION TIMEOUT ---\n\n"
                "Enter country code and seconds:\n"
                "Format: +880 60 (60 seconds timeout)"
            )
            _set_admin_state(uid, query, "settimeout")

        elif data == "ban":
            await _edit_in_place(query.message, 
                "--- BAN USER ---\n\n"
                "Enter ID of user to ban:"
            )
            _set_admin_state(uid, query, "ban")

        elif data == "unban":
            await _edit_in_place(query.message, 
                "--- UNBAN USER ---\n\n"
                "Enter ID of user to unban:"
            )
            _set_admin_state(uid, query, "unban")

        elif data == "adjustbalance":
            await _edit_in_place(query.message, 
                "--- ADJUST BALANCE ---\n\n"
                "Enter User ID and Amount:\n"
                "Format: 123456 +10 (add) or 123456 -5 (subtract)"
            )
            _set_admin_state(uid, query, "adjustbalance")

        elif data == "userstats":
            await _edit_in_place(query.message, 
                "--- USER STATS ---\n\n"
                "Enter the User ID to view stats:"
            )
            _set_admin_state(uid, query, "userstats")

        elif data == "totalusers":
            total, active = get_total_users()
            users_list = get_all_users_list()
            
            header = (
                "--- TOTAL USERS REPORT ---\n"
                f"Total Users: {total}\n"
                f"Active (24h): {active}\n"
                "--------------------------\n"
            )
            
            if users_list:
                user_details = "USER LIST:\n"
                for idx, user in enumerate(users_list[:50], 1):
                    uid_val = user.get('user_id', 'N/A')
                    balance = user.get('balance', 0)
                    sessions = user.get('sessions', 0)
                    banned = "BANNED" if user.get('banned') else "ACTIVE"
                    user_details += (
                        f"{idx}. ID:`{uid_val}` | ${balance:.2f} | {sessions} sess | {banned}\n"
                    )
                if len(users_list) > 50:
                    user_details += f"+ {len(users_list) - 50} more users...\n"
            else:
                user_details = "No users found."
            
            response = header + user_details
            
            if len(response) > 4000:
                await _edit_in_place(query.message, response[:4000])
                for i in range(4000, len(response), 4000):
                    await query.message.reply(response[i:i+4000])
            else:
                await _edit_in_place(query.message, response)

        elif data == "zerobalance":
            zero_all_balances()
            await _edit_in_place(query.message, "--- ZERO ALL BALANCES ---\nAll user balances reset to $0.00")

        elif data == "pendingwithdraw":
            text, buttons = _build_pending_withdraw_panel(0)
            if len(text) > 4000:
                await _edit_in_place(query.message, text[:4000])
                for i in range(4000, len(text), 4000):
                    await query.message.reply(text[i:i+4000])
                await _edit_in_place(query.message, "Actions:", reply_markup=InlineKeyboardMarkup(buttons))
            else:
                await _edit_in_place(query.message, text, reply_markup=InlineKeyboardMarkup(buttons))

        elif data == "withdrawlogs":
            logs = get_withdraw_logs()
            
            header = (
                "--- WITHDRAW LOGS ---\n"
                f"Total Logs: {len(logs)}\n"
                "---------------------\n"
            )
            
            if logs:
                details = "RECENT WITHDRAWS:\n"
                for idx, log in enumerate(reversed(logs[-20:]), 1):
                    user_id = log.get('user_id', 'N/A')
                    amount = log.get('amount', 0)
                    method = log.get('method', 'N/A')
                    status = log.get('status', 'N/A')
                    timestamp = log.get('timestamp', 'N/A')
                    wallet_address = log.get('wallet_address', 'N/A')
                    
                    status_text = "APPROVED" if status == "approved" else "PENDING" if status == "pending" else "REJECTED"
                    
                    details += (
                        f"{idx}. User:`{user_id}` | ${amount:.2f} | {method} | {status_text}\n"
                        f"   Wallet:`{wallet_address}` | {timestamp}\n"
                    )
                if len(logs) > 20:
                    details += f"Showing last 20 of {len(logs)}...\n"
            else:
                details = "No withdraw logs found."
            
            response = header + details
            
            if len(response) > 4000:
                await _edit_in_place(query.message, response[:4000])
                for i in range(4000, len(response), 4000):
                    await query.message.reply(response[i:i+4000])
            else:
                await _edit_in_place(query.message, response, reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("Back to Withdraw & Finance", callback_data="menu_withdraw")]
                ]))

        elif data == "togglewithdraw":
            try:
                print(f"Toggling withdraw status...")
                status = toggle_withdraw()
                
                from bot.utils.fast_cache import force_refresh_withdraw_status
                force_refresh_withdraw_status(status)
                
                state = "ENABLED" if status else "DISABLED"
                print(f"Withdraw toggled successfully. New status: {status}")
                await _edit_in_place(query.message, f"--- WITHDRAW TOGGLE ---\nWithdraw is now: {state}")
            except Exception as e:
                print(f"Error toggling withdraw: {e}")
                import traceback
                traceback.print_exc()
                await _edit_in_place(query.message, f"Error: {str(e)}")

        elif data == "togglecountry":
            await _edit_in_place(query.message, 
                "--- TOGGLE COUNTRY ---\n\n"
                "Country code (e.g. +880):"
            )
            _set_admin_state(uid, query, "togglecountry")

        elif data == "disablecountries":
            disable_all_countries()
            await _edit_in_place(query.message, "--- DISABLE ALL COUNTRIES ---\nAll countries disabled. Verification paused.")

        elif data == "broadcast":
            await _edit_in_place(query.message, 
                "--- BROADCAST ---\n\n"
                "Enter the message to broadcast:"
            )
            _set_admin_state(uid, query, "broadcast")

        elif data == "sendtouser":
            await _edit_in_place(query.message, 
                "--- SEND TO USER ---\n\n"
                "Enter the User ID to send message to:\n"
                "Example: 123456789"
            )
            _set_admin_state(uid, query, "sendtouser_step1")

        elif data == "setchannel":
            current = get_required_channel()
            await _edit_in_place(query.message, 
                "--- SET CHANNEL ---\n\n"
                f"Current: {current}\n\n"
                "Enter new channel username (@channel):"
            )
            _set_admin_state(uid, query, "setchannel")

        elif data == "minwithdraw":
            amounts = get_min_withdraw_amounts()
            buttons = [
                [InlineKeyboardButton(f"USDT (BEP20) - ${amounts.get('usdt', 0)}", callback_data="setmin_usdt")],
                [InlineKeyboardButton(f"TRX - ${amounts.get('trx', 0)}", callback_data="setmin_trx")],
                [InlineKeyboardButton(f"CARD NAME - ${amounts.get('cardname', 0)}", callback_data="setmin_cardname")],
                [InlineKeyboardButton(f"Binance - ${amounts.get('binance', 0)}", callback_data="setmin_binance")],
                [InlineKeyboardButton("Back to Withdraw & Finance", callback_data="menu_withdraw")]
            ]
            await _edit_in_place(query.message, 
                "--- MIN WITHDRAW SETTINGS ---\n\n"
                "Which method minimum to edit?",
                reply_markup=InlineKeyboardMarkup(buttons)
            )

        elif data == "user_withdraw_control":
            await _edit_in_place(query.message, 
                "--- USER WITHDRAW CONTROL ---\n\n"
                "Enter the User ID to set withdraw limit:"
            )
            _set_admin_state(uid, query, "user_withdraw_step1")

        elif data.startswith("uwc_"):
            parts = data.split("_")
            target_uid = int(parts[1])
            cmd = parts[2]
            
            if cmd == "toggle":
                from bot.utils.storage import get_user_withdraw_config, set_user_withdraw_config
                current = get_user_withdraw_config(target_uid).get("disabled", False)
                set_user_withdraw_config(target_uid, disabled=not current)
                await query.answer(f"Withdraw {'Disabled' if not current else 'Enabled'} for {target_uid}", show_alert=True)
                
                config = get_user_withdraw_config(target_uid)
                status_text = "OFF" if config.get("disabled") else "ON"
                min_amt = config.get("min", "Default")
                max_amt = config.get("max", "Unlimited")
                buttons = [
                    [InlineKeyboardButton(f"Status: {status_text}", callback_data=f"uwc_{target_uid}_toggle")],
                    [InlineKeyboardButton(f"Min: ${min_amt}", callback_data=f"uwc_{target_uid}_min")],
                    [InlineKeyboardButton(f"Max: ${max_amt}", callback_data=f"uwc_{target_uid}_max")],
                    [InlineKeyboardButton("Back", callback_data="menu_withdraw")]
                ]
                await query.message.edit_text(
                    f"--- USER WITHDRAW SETTINGS ---\n"
                    f"User: `{target_uid}`\n\n"
                    f"Configure from the buttons below:",
                    reply_markup=InlineKeyboardMarkup(buttons)
                )
            elif cmd == "min":
                await _edit_in_place(query.message, f"Enter MINIMUM withdraw for `{target_uid}`:")
                _set_admin_state(uid, query, "user_withdraw_min", target_uid=target_uid)
            elif cmd == "max":
                await _edit_in_place(query.message, f"Enter MAXIMUM withdraw for `{target_uid}`:")
                _set_admin_state(uid, query, "user_withdraw_max", target_uid=target_uid)

        elif data == "allbalances":
            report, total_users, users_with_balance, total_balance = get_all_balances_report()
            
            header = (
                "--- ALL BALANCES REPORT ---\n"
                f"Total Users: {total_users}\n"
                f"Users with Balance: {users_with_balance}\n"
                f"Total Unreleased: ${total_balance:,.2f}\n"
                "---------------------------\n"
            )
            
            if not report:
                await _edit_in_place(query.message, header + "No users with balance.")
            else:
                full_message = header + report
                if len(full_message) > 4000:
                    await _edit_in_place(query.message, header)
                    for i in range(0, len(report), 4000):
                        await query.message.reply(report[i:i+4000])
                else:
                    await _edit_in_place(query.message, full_message)

        elif data == "show_2fa_secret":
            current = get_2fa_password() or ""
            if not current:
                await _edit_in_place(query.message, 
                    "--- 2FA PASSWORD ---\n\n"
                    "❌ No 2FA password is set yet.\n"
                    "Use 'Set 2FA Password' to configure one.",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("Back to Settings", callback_data="menu_settings_config")]
                    ])
                )
            else:
                await _edit_in_place(query.message, 
                    "--- 2FA PASSWORD ---\n\n"
                    f"`{current}`\n\n"
                    "You can login to the account with this password.\n\n"
                    "⚠️ Only share this with trusted users."
                )

        else:
            await query.answer("Feature not implemented yet", show_alert=True)

    # ---------------- Message Handler for Admin Inputs ----------------
    @app.on_message(admin_filter & filters.text & ~filters.command(["admin", "start", "account", "withdraw", "cap", "support", "cancel"]))
    async def handle_admin_actions(client: Client, message: Message):
        user_id = message.from_user.id
        if user_id not in admin_state:
            message.continue_propagation()
            return

        action = admin_state[user_id]["action"]
        text = message.text.strip()

        try:
            if action == "setrate_type":
                parts = text.split()
                if len(parts) < 2:
                    await _panel_reply(client, user_id, message, "❌ Format: +CountryCode Rate (e.g., +880 30)")
                    return
                country = parts[0].strip()
                try:
                    rate = float(parts[1])
                except ValueError:
                    await _panel_reply(client, user_id, message, "❌ Rate must be a number! (e.g., 30)")
                    return
                rate_type = admin_state[user_id].get("rate_type", "spam_free_rate")
                
                rate_type_names = {
                    "spam_free_rate": "Spam Free",
                    "spam_rate": "Spam",
                    "limit_rate": "Limit"
                }
                type_name = rate_type_names.get(rate_type, "Unknown")
                
                set_country_rate_by_type(country, rate_type, rate)
                
                rates = get_country_rates(country)
                await _panel_reply(client, user_id, message, 
                    f"✅ **{type_name} Rate set!**\n\n"
                    f"🌍 Country: {country}\n"
                    f"💵 {type_name} Rate: ${rate}\n\n"
                    f"📊 **All Rates:**\n"
                    f"✅ Spam Free: ${rates['spam_free_rate']}\n"
                    f"⚠️ Spam: ${rates['spam_rate']}\n"
                    f"🔒 Limit: ${rates['limit_rate']}"
                )
            
            elif action == "setrate_all":
                parts = text.split()
                if len(parts) < 4:
                    await _panel_reply(client, user_id, message, 
                        "❌ Format: +CountryCode SpamFreeRate SpamRate LimitRate\n\n"
                        "Example: `+880 30 15 10`"
                    )
                    return
                country = parts[0].strip()
                try:
                    spam_free_rate = float(parts[1])
                    spam_rate = float(parts[2])
                    limit_rate = float(parts[3])
                except ValueError:
                    await _panel_reply(client, user_id, message, "❌ All rates must be numbers!\nExample: `+880 30 15 10`")
                    return
                
                set_country_rates(country, spam_free_rate, spam_rate, limit_rate)
                
                await _panel_reply(client, user_id, message, 
                    f"✅ **All Rates set!**\n\n"
                    f"🌍 Country: {country}\n\n"
                    f"✅ Spam Free Rate: ${spam_free_rate}\n"
                    f"⚠️ Spam Rate: ${spam_rate}\n"
                    f"🔒 Limit Rate: ${limit_rate}\n\n"
                    f"Now when accounts in this country are verified:\n"
                    f"• Good account = ${spam_free_rate}\n"
                    f"• Spam account = ${spam_rate}\n"
                    f"• Limited account = ${limit_rate}"
                )

            elif action == "settimeout":
                parts = text.split()
                if len(parts) < 2:
                    await _panel_reply(client, user_id, message, "❌ Format: country_code seconds (e.g.: +880 60)")
                    return
                country = parts[0].strip()
                try:
                    timeout_seconds = int(parts[1])
                except ValueError:
                    await _panel_reply(client, user_id, message, "❌ Seconds must be a number!")
                    return
                if timeout_seconds <= 0:
                    await _panel_reply(client, user_id, message, "❌ Seconds must be greater than 0!")
                    return
                if timeout_seconds > 3600:
                    await _panel_reply(client, user_id, message, "⚠️ Warning: Setting more than 1 hour!")
                success, msg = set_country_timeout(country, timeout_seconds)
                await _panel_reply(client, user_id, message, f"{msg}\n\n✅ Verification for this country will happen after {timeout_seconds} seconds")


            elif action == "ban":
                print(f"🔍 Attempting to ban user: {text}")
                try:
                    target_uid = int(text)
                except ValueError:
                    await _panel_reply(client, user_id, message, "❌ User ID must be a number!")
                    return
                ban_user(target_uid)
                from bot.utils.fast_cache import mark_user_banned
                mark_user_banned(target_uid)
                print(f"✅ User {text} banned successfully (storage + cache)")
                await _panel_reply(client, user_id, message, f"🚫 User {text} banned")

            elif action == "unban":
                print(f"🔍 Attempting to unban user: {text}")
                try:
                    target_uid = int(text)
                except ValueError:
                    await _panel_reply(client, user_id, message, "❌ User ID must be a number!")
                    return
                unban_user(target_uid)
                from bot.utils.fast_cache import mark_user_unbanned
                mark_user_unbanned(target_uid)
                print(f"✅ User {text} unbanned successfully (storage + cache)")
                await _panel_reply(client, user_id, message, f"✔️ User {text} unbanned")

            elif action == "adjustbalance":
                parts = text.split()
                if len(parts) < 2:
                    await _panel_reply(client, user_id, message, 
                        "❌ **Invalid Format!**\n\n"
                        "Correct Format: `UserID Amount`\n\n"
                        "Examples:\n"
                        "• `123456789 +10` (add $10)\n"
                        "• `123456789 -5` (subtract $5)\n"
                        "• `123456789 25` (add $25)"
                    )
                    return
                try:
                    uid = int(parts[0])
                except ValueError:
                    await _panel_reply(client, user_id, message, "❌ User ID must be a number!")
                    return
                try:
                    amount_str = parts[1].replace("+", "").strip()
                    amount = float(amount_str)
                except ValueError:
                    await _panel_reply(client, user_id, message, "❌ Amount must be a valid number (e.g.: 10, -5, +25)")
                    return
                
                old_info = get_user_info(uid)
                old_balance = old_info.get('balance', 0)
                add_balance_for_user(uid, amount)
                new_info = get_user_info(uid)
                new_balance = new_info.get('balance', 0)
                
                action_text = "added" if amount >= 0 else "subtracted"
                await _panel_reply(client, user_id, message, 
                    f"✅ **Balance Updated Successfully!**\n\n"
                    f"👤 User ID: `{uid}`\n"
                    f"💵 Old Balance: ${old_balance:.2f}\n"
                    f"{'➕' if amount >= 0 else '➖'} Amount: ${abs(amount):.2f} {action_text}\n"
                    f"💰 New Balance: **${new_balance:.2f}**"
                )

            elif action == "userstats":
                try:
                    uid = int(text)
                except ValueError:
                    await _panel_reply(client, user_id, message, "❌ User ID must be a number!")
                    return
                stats = get_user_stats(uid)
                await _panel_reply(client, user_id, message, f"📊 User Stats:\n{stats}")

            elif action == "activity_logs_user":
                try:
                    uid = int(text)
                except ValueError:
                    await _panel_reply(client, user_id, message, "❌ User ID must be a number!")
                    _admin_manager.clear_state(user_id)
                    return

                user_info = get_user_info(uid, create_if_missing=False)
                if not user_info:
                    await _panel_reply(client, user_id, message, f"❌ User `{uid}` not found!")
                    _admin_manager.clear_state(user_id)
                    return

                lines = [f"📋 **Activity Logs for User `{uid}`**\n", "━━━━━━━━━━━━━━━━━━━━━\n"]

                txn_logs = _storage.get("transaction_logs", [])
                user_txns = [t for t in txn_logs if str(t.get("user_id", "")) == str(uid)]
                if user_txns:
                    lines.append(f"\n**Transactions ({len(user_txns)}):**")
                    for t in reversed(user_txns[-10:]):
                        ts = str(t.get("timestamp", "N/A"))[:16].replace("T", " ")
                        action = t.get("action", "N/A")
                        amount = t.get("amount", 0)
                        lines.append(f"  {ts} - {action} (${amount:.2f})")
                else:
                    lines.append("\n**Transactions:** None")

                failed = _storage.get("failed_verifications", [])
                user_fails = [f for f in failed if str(f.get("user_id", "")) == str(uid)]
                if user_fails:
                    lines.append(f"\n**Failed Verifications ({len(user_fails)}):**")
                    for f in reversed(user_fails[-5:]):
                        ts = str(f.get("timestamp", "N/A"))[:16].replace("T", " ")
                        reason = f.get("reason", "N/A")
                        lines.append(f"  {ts} - {reason}")

                lines.append(f"\n**Current Status:**")
                lines.append(f"  Balance: ${user_info.get('balance', 0):.2f}")
                lines.append(f"  Sessions: {user_info.get('sessions', 0)}")
                lines.append(f"  Banned: {'Yes' if user_info.get('banned') else 'No'}")

                await _panel_reply(client, user_id, message, "\n".join(lines))

            elif action == "togglecountry":
                country = text.strip()
                if not country.startswith('+'):
                    await _panel_reply(client, user_id, message, "❌ Country code must start with + (e.g. +880)")
                    return
                country_code, new_status = toggle_country_status(country)
                status_text = "🟢 OPEN" if new_status else "🔴 CLOSED"
                await _panel_reply(client, user_id, message, f"✅ Country {country_code} is now {status_text}")

            elif action == "setchannel":
                new_channel = text.strip()
                if not new_channel.startswith("@"):
                    await _panel_reply(client, user_id, message, "❌ Channel must start with @ (e.g. @newchannel123)")
                    return
                old_channel = get_required_channel()
                set_required_channel(new_channel)
                total_users, _ = get_total_users()
                await _panel_reply(client, user_id, message, 
                    f"✅ Channel updated successfully!\n\n"
                    f"🔴 Old channel: {old_channel}\n"
                    f"🟢 New channel: {new_channel}\n\n"
                    f"👥 All {total_users} users must now join {new_channel} to use the bot."
                )

            elif action == "broadcast":
                from pyrogram.errors import FloodWait
                import asyncio
                users = get_all_users()
                total = len(users)
                sent, failed = 0, 0
                
                if total == 0:
                    await _panel_reply(client, user_id, message, "❌ No users!")
                else:
                    progress_msg = await _panel_reply(client, user_id, message, 
                        f"📢 **Broadcast starting...**\n\n"
                        f"👥 Total Users: {total}\n"
                        f"⏳ Progress: 0%"
                    )
                    if progress_msg is None:
                        progress_msg = await message.reply(
                            f"📢 **Broadcast starting...**\n\n"
                            f"👥 Total Users: {total}\n"
                            f"⏳ Progress: 0%"
                        )
                    
                    for i, user_id_str in enumerate(users):
                        try:
                            await client.send_message(int(user_id_str), text)
                            sent += 1
                        except FloodWait as e:
                            wait_time = int(getattr(e, 'value', 30) or 30)
                            await asyncio.sleep(min(wait_time, 30))
                            try:
                                await client.send_message(int(user_id_str), text)
                                sent += 1
                            except Exception:
                                failed += 1
                        except Exception:
                            failed += 1
                        
                        if (i + 1) % 20 == 0 or i + 1 == total:
                            percent = int((i + 1) / total * 100)
                            try:
                                await progress_msg.edit_text(
                                    f"📢 **Broadcast running...**\n\n"
                                    f"👥 Total: {total}\n"
                                    f"✅ Sent: {sent}\n"
                                    f"❌ Failed: {failed}\n"
                                    f"⏳ Progress: {percent}%"
                                )
                            except Exception:
                                pass  # Edit may fail if too fast
                        
                        await asyncio.sleep(0.05)
                    
                    try:
                        await progress_msg.edit_text(
                            f"📢 **Broadcast Complete!** ✅\n\n"
                            f"👥 Total Users: {total}\n"
                            f"✅ Sent: {sent}\n"
                            f"❌ Failed: {failed}\n"
                            f"📊 Success Rate: {int(sent/total*100) if total > 0 else 0}%"
                        )
                    except Exception:
                        await _panel_reply(client, user_id, message, 
                            f"📢 **Broadcast Complete!** ✅\n\n"
                            f"✅ Sent: {sent}\n"
                            f"❌ Failed: {failed}"
                        )

            elif action == "sendtouser_step1":
                try:
                    target_user_id = int(text)
                    _cur_state = admin_state[user_id]
                    admin_state[user_id] = {
                        "action": "sendtouser_step2",
                        "target_user_id": target_user_id,
                        "panel_chat_id": _cur_state.get("panel_chat_id"),
                        "panel_msg_id": _cur_state.get("panel_msg_id"),
                    }
                    await _panel_reply(client, user_id, message, 
                        f"✅ User ID: `{target_user_id}` set!\n\n"
                        f"Now enter the message to send:\n\n"
                        f"⚠️ Type /admin to cancel"
                    )
                    return
                except ValueError:
                    await _panel_reply(client, user_id, message, "❌ Enter a valid User ID (numbers only)")
                    return

            elif action == "sendtouser_step2":
                target_user_id = admin_state[user_id].get("target_user_id")
                if not target_user_id:
                    await _panel_reply(client, user_id, message, "❌ Error: Target user not found. Try again with /admin")
                else:
                    try:
                        await client.send_message(target_user_id, text)
                        await _panel_reply(client, user_id, message, 
                            f"✅ **Message sent successfully!**\n\n"
                            f"👤 User ID: `{target_user_id}`\n"
                            f"📝 Message:\n```\n{text[:200]}{'...' if len(text) > 200 else ''}\n```"
                        )
                    except Exception as e:
                        await _panel_reply(client, user_id, message, f"❌ Failed to send message!\n\nError: {str(e)}")

            elif action == "setmin":
                method = admin_state[user_id].get("method", "")
                method_names = {"usdt": "USDT (BEP20)", "trx": "TRX", "cardname": "CARD NAME", "binance": "Binance"}
                method_name = method_names.get(method, method.upper())
                
                try:
                    amount = float(text)
                    if amount < 0:
                        await _panel_reply(client, user_id, message, "❌ Amount must be 0 or more!")
                    else:
                        set_min_withdraw_for_method(method, amount)
                        await _panel_reply(client, user_id, message, 
                            f"✅ Successfully set!\n\n"
                            f"💵 **{method_name}** minimum withdraw: **${amount}**"
                        )
                except ValueError:
                    await _panel_reply(client, user_id, message, "❌ Enter a valid number (e.g.: 10 or 15.5)")

            elif action == "edit_template":
                template_key = admin_state[user_id].get("template_key", "")
                display_name = TEMPLATE_DISPLAY_NAMES.get(template_key, template_key)
                
                set_message_template(template_key, text)
                
                try:
                    from bot.utils.fast_cache import update_template_cache
                    update_template_cache(template_key, text)
                    print(f"✅ Template '{template_key}' saved and cache updated")
                except Exception as cache_error:
                    print(f"⚠️ Cache update error: {cache_error}")
                
                await _panel_reply(client, user_id, message, 
                    f"✅ **{display_name}** updated successfully!\n\n"
                    f"**New Message:**\n"
                    f"```\n{text[:500]}{'...' if len(text) > 500 else ''}\n```"
                )

            elif action == "user_withdraw_step1":
                try:
                    target_uid = int(text)
                    from bot.utils.storage import get_user_withdraw_config
                    config = get_user_withdraw_config(target_uid)
                    
                    status = "🔴 OFF" if config.get("disabled") else "🟢 ON"
                    min_amt = config.get("min", "Default")
                    max_amt = config.get("max", "Unlimited")
                    
                    buttons = [
                        [InlineKeyboardButton(f"Status: {status}", callback_data=f"uwc_{target_uid}_toggle")],
                        [InlineKeyboardButton(f"Min: ${min_amt}", callback_data=f"uwc_{target_uid}_min")],
                        [InlineKeyboardButton(f"Max: ${max_amt}", callback_data=f"uwc_{target_uid}_max")],
                        [InlineKeyboardButton("🔙 Back", callback_data="menu_withdraw")]
                    ]
                    await _panel_reply(client, user_id, message, 
                        f"👤 **Settings for User:** `{target_uid}`\n\n"
                    f"Configure from the buttons below:",
                        reply_markup=InlineKeyboardMarkup(buttons)
                    )
                except ValueError:
                    await _panel_reply(client, user_id, message, "❌ Invalid User ID!")

            elif action == "user_withdraw_min":
                target_uid = admin_state[user_id].get("target_uid")
                try:
                    amt = float(text)
                    from bot.utils.storage import set_user_withdraw_config
                    set_user_withdraw_config(target_uid, min_amt=amt)
                    await _panel_reply(client, user_id, message, f"✅ Min withdraw set to ${amt} for `{target_uid}`")
                except (ValueError, TypeError):
                    await _panel_reply(client, user_id, message, "❌ Invalid Amount!")

            elif action == "user_withdraw_max":
                target_uid = admin_state[user_id].get("target_uid")
                try:
                    amt = float(text)
                    from bot.utils.storage import set_user_withdraw_config
                    set_user_withdraw_config(target_uid, max_amt=amt)
                    await _panel_reply(client, user_id, message, f"✅ Max withdraw set to ${amt} for `{target_uid}`")
                except (ValueError, TypeError):
                    await _panel_reply(client, user_id, message, "❌ Invalid Amount!")

            elif action == "set_2fa_password":
                new_password = text.strip()
                if len(new_password) < 8:
                    await _panel_reply(client, user_id, message, 
                        "❌ **Password too short!**\n\n"
                        "Password must be at least 8 characters.\n"
                        "Try again or type /admin to cancel."
                    )
                    return
                
                _storage["_2fa_password_persistent"] = new_password
                save_storage()

                await _panel_reply(client, user_id, message, 
                    f"✅ **2FA Password Updated!**\n"
                    f"━━━━━━━━━━━━━━━━━━━━━\n\n"
                    f"🔑 **New Password:** `{new_password[:4]}{'*' * (len(new_password) - 4)}`\n\n"
                    f"✅ This password is now active immediately for all new verifications.",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("🔙 Back to Settings", callback_data="menu_settings_config")]
                    ])
                )
                _admin_manager.clear_state(user_id)

            elif action == "search_user":
                try:
                    search_uid = int(text.strip())
                    user_info = get_user_info(search_uid, create_if_missing=False)
                    
                    if not user_info:
                        await _panel_reply(client, user_id, message, 
                            f"🔍 **User Not Found!**\n\n"
                            f"👤 User ID `{search_uid}` - No information found.\n"
                            f"This user has not used the bot or has been deleted.",
                            reply_markup=InlineKeyboardMarkup([
                                [InlineKeyboardButton("🔙 Back to Advanced Tools", callback_data="menu_advanced_tools")]
                            ])
                        )
                        _admin_manager.clear_state(user_id)
                        return
                    
                    from bot.utils.country_data import get_flag
                    
                    balance = user_info.get("balance", 0)
                    sessions = user_info.get("sessions", 0)
                    banned = user_info.get("banned", False)
                    joined = user_info.get("joined", "N/A")
                    country_sessions = user_info.get("country_sessions", {})
                    
                    banned_status = "🚫 Banned" if banned else "✅ Active"
                    
                    country_lines = []
                    for cc, count in sorted(country_sessions.items(), key=lambda x: x[1], reverse=True):
                        flag = get_flag(cc) if cc != "other" else "🌍"
                        country_lines.append(f"   {flag} {cc}: {count}")
                    country_text = "\n".join(country_lines) if country_lines else "   No sessions"
                    
                    buttons = [
                        [
                            InlineKeyboardButton("🚫 Ban", callback_data=f"quick_ban_{search_uid}"),
                            InlineKeyboardButton("✅ Unban", callback_data=f"quick_unban_{search_uid}")
                        ],
                        [InlineKeyboardButton("🔙 Back to Advanced Tools", callback_data="menu_advanced_tools")]
                    ]
                    
                    await _panel_reply(client, user_id, message, 
                        f"🔍 **User Found!**\n"
                        f"━━━━━━━━━━━━━━━━━━━━━\n\n"
                        f"👤 **User ID:** `{search_uid}`\n"
                        f"💰 **Balance:** ${balance:.2f}\n"
                        f"✅ **Sessions:** {sessions}\n"
                        f"📌 **Status:** {banned_status}\n"
                        f"📅 **Joined:** {joined[:10] if len(joined) > 10 else joined}\n\n"
                        f"🌍 **Country Sessions:**\n{country_text}",
                        reply_markup=InlineKeyboardMarkup(buttons)
                    )
                    _admin_manager.clear_state(user_id)
                except ValueError:
                    await _panel_reply(client, user_id, message, "❌ Enter a valid User ID (numbers only)")
                    _admin_manager.clear_state(user_id)
                    return

            elif action == "add_new_admin":
                try:
                    new_admin_id = int(text.strip())
                    
                    admins = _storage.get("admins", [ADMIN_ID])
                    if ADMIN_ID not in admins:
                        admins.append(ADMIN_ID)
                    
                    if new_admin_id in admins:
                        await _panel_reply(client, user_id, message, f"⚠️ User `{new_admin_id}` is already an Admin!")
                        _admin_manager.clear_state(user_id)
                        return
                    
                    admins.append(new_admin_id)
                    _storage["admins"] = admins
                    save_storage()
                    
                    admin_lines = [f"👤 `{admin_id}`" for admin_id in admins]
                    
                    await _panel_reply(client, user_id, message, 
                        f"✅ **New Admin Added!**\n"
                        f"━━━━━━━━━━━━━━━━━━━━━\n\n"
                        f"👑 New Admin: `{new_admin_id}`\n\n"
                        f"📊 **Total Admins:** {len(admins)}\n\n"
                        f"**Admin List:**\n" + "\n".join(admin_lines),
                        reply_markup=InlineKeyboardMarkup([
                            [InlineKeyboardButton("🔙 Back to Settings", callback_data="menu_settings_config")]
                        ])
                    )
                    _admin_manager.clear_state(user_id)
                except ValueError:
                    await _panel_reply(client, user_id, message, "❌ Enter a valid User ID (numbers only)")
                    _admin_manager.clear_state(user_id)
                    return

            elif action == "remove_balance":
                try:
                    parts = text.strip().split()
                    if len(parts) == 1:
                        target_uid = user_id
                        amount = float(parts[0])
                    elif len(parts) == 2:
                        target_uid = int(parts[0])
                        amount = float(parts[1])
                    else:
                        raise ValueError()
                    
                    user_info = get_user_info(target_uid, create_if_missing=False)
                    if not user_info:
                        await _panel_reply(client, user_id, message, f"❌ User `{target_uid}` not found!")
                        _admin_manager.clear_state(user_id)
                        return
                    
                    current_balance = user_info.get("balance", 0)
                    if amount > current_balance:
                        await _panel_reply(client, user_id, message, 
                            f"❌ Insufficient balance!\n"
                            f"Current: ${current_balance:.2f}, Requested: ${amount:.2f}"
                        )
                        _admin_manager.clear_state(user_id)
                        return
                    
                    new_balance = current_balance - amount
                    update_user_info(target_uid, balance=new_balance)
                    
                    await _panel_reply(client, user_id, message, 
                        f"✅ **Balance Removed Successfully!**\n"
                        f"━━━━━━━━━━━━━━━━━━━━━\n\n"
                        f"👤 User: `{target_uid}`\n"
                        f"💸 Amount Removed: ${amount:.2f}\n"
                        f"💰 New Balance: ${new_balance:.2f}"
                    )
                    _admin_manager.clear_state(user_id)
                except (ValueError, IndexError):
                    await _panel_reply(client, user_id, message, "❌ Invalid format! Use: `123456789 50.00` or `50.00`")
                    _admin_manager.clear_state(user_id)
                    return

            elif action == "set_user_rate":
                try:
                    parts = text.strip().split()
                    if len(parts) != 3:
                        raise ValueError()
                    
                    target_uid = int(parts[0])
                    country_code = parts[1].upper()
                    price = float(parts[2])
                    
                    if price < 0:
                        await _panel_reply(client, user_id, message, "❌ Price cannot be negative!")
                        _admin_manager.clear_state(user_id)
                        return
                    
                    user_info = get_user_info(target_uid, create_if_missing=False)
                    if not user_info:
                        await _panel_reply(client, user_id, message, f"❌ User `{target_uid}` not found!")
                        _admin_manager.clear_state(user_id)
                        return
                    
                    current_rates = user_info.get("custom_rates", {})
                    if current_rates is None:
                        current_rates = {}
                    current_rates[country_code] = price
                    update_user_info(target_uid, custom_rates=current_rates)
                    
                    await _panel_reply(client, user_id, message, 
                        f"✅ **Individual Rate Set!**\n"
                        f"━━━━━━━━━━━━━━━━━━━━━\n\n"
                        f"👤 User: `{target_uid}`\n"
                        f"🌍 Country: `{country_code}`\n"
                        f"💰 New Price: ${price:.2f}"
                    )
                    _admin_manager.clear_state(user_id)
                except (ValueError, IndexError):
                    await _panel_reply(client, user_id, message, "❌ Invalid format! Use: `123456789 BD 15.50`")
                    _admin_manager.clear_state(user_id)
                    return

            elif action == "send_sessions_uid":
                try:
                    target_uid = int(text.strip())
                except (ValueError, TypeError):
                    await _panel_reply(client, user_id, message, "❌ Enter a valid User ID (numbers only)")
                    return

                _cur_state = admin_state[user_id]
                admin_state[user_id] = {
                    "action": "send_sessions_choice",
                    "target_uid": target_uid,
                    "panel_chat_id": _cur_state.get("panel_chat_id"),
                    "panel_msg_id": _cur_state.get("panel_msg_id"),
                }

                await _panel_reply(
                    client, user_id, message,
                    f"✅ Target user set: `{target_uid}`\n\n"
                    f"📤 **Which sessions do you want to send?**",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("Send Active Sessions", callback_data="send_sessions_active")],
                        [InlineKeyboardButton("Send Pending Sessions", callback_data="send_sessions_pending")],
                        [InlineKeyboardButton("Send All Sessions", callback_data="send_sessions_all")],
                        [InlineKeyboardButton("Cancel", callback_data="admin_cancel_operation")],
                    ])
                )
                return

            elif action == "blacklist_add":
                try:
                    blacklist_uid = int(text.strip())
                except (ValueError, TypeError):
                    await _panel_reply(client, user_id, message, "❌ Enter a valid User ID (numbers only)")
                    return

                if "blacklist" not in _storage:
                    _storage["blacklist"] = []

                if blacklist_uid in _storage["blacklist"]:
                    await _panel_reply(client, user_id, message, f"⚠️ User `{blacklist_uid}` already blacklisted")
                    _admin_manager.clear_state(user_id)
                    return

                _storage["blacklist"].append(blacklist_uid)
                save_storage()
                await _panel_reply(client, user_id, message, f"✅ Added `{blacklist_uid}` to blacklist")
                _admin_manager.clear_state(user_id)
                return

            elif action == "blacklist_remove":
                try:
                    blacklist_uid = int(text.strip())
                except (ValueError, TypeError):
                    await _panel_reply(client, user_id, message, "❌ Enter a valid User ID (numbers only)")
                    return

                if "blacklist" not in _storage:
                    _storage["blacklist"] = []

                if blacklist_uid in _storage["blacklist"]:
                    _storage["blacklist"].remove(blacklist_uid)
                    save_storage()
                    await _panel_reply(client, user_id, message, f"✅ Removed `{blacklist_uid}` from blacklist")
                else:
                    await _panel_reply(client, user_id, message, f"⚠️ User `{blacklist_uid}` not in blacklist")
                _admin_manager.clear_state(user_id)
                return

        except Exception as e:
            await _panel_reply(client, user_id, message, f"❌ Error: {str(e)}")
            _admin_manager.clear_state(user_id)
            return

        FEATURE_ACTIONS = {"search_phone", "search_country", "session_detail", "edit_mod_rules", "import_countries", "alert_threshold"}
        if action in FEATURE_ACTIONS:
            message.continue_propagation()
            return
        _admin_manager.clear_state(user_id)

    # Register Core Features v2
    from bot.handlers.admin_features import register_admin_features
    register_admin_features(app)

    # ============================================================
    # NEW COMMAND HANDLERS FOR 10 CRITICAL FEATURES
    # ============================================================
    
    @app.on_message(filters.command("cancel") & admin_filter)
    async def cancel_command(client: Client, message: Message):
        _admin_manager.clear_state(message.from_user.id)
        try:
            from bot.utils.session_handler import cleanup_session
            await cleanup_session(message.from_user.id)
        except Exception:
            pass
        await message.reply("✅ Operation cancelled.\n\nAny pending input or verification session has been cleared.")
    
    @app.on_message(filters.command("blacklist") & admin_filter)
    async def blacklist_command(client: Client, message: Message):
        args = message.text.split()
        if len(args) < 2:
            await message.reply("Usage:\n`/blacklist add 123456789`\n`/blacklist remove 123456789`\n`/blacklist clear`")
            return
        
        action = args[1].lower()
        
        if "blacklist" not in _storage:
            _storage["blacklist"] = []
        
        if action == "add" and len(args) >= 3:
            try:
                uid = int(args[2])
                if uid not in _storage["blacklist"]:
                    _storage["blacklist"].append(uid)
                    save_storage()
                    await message.reply(f"✅ Added `{uid}` to blacklist")
                else:
                    await message.reply(f"⚠️ User `{uid}` already blacklisted")
            except ValueError:
                await message.reply("❌ Invalid User ID")
        
        elif action == "remove" and len(args) >= 3:
            try:
                uid = int(args[2])
                if uid in _storage["blacklist"]:
                    _storage["blacklist"].remove(uid)
                    save_storage()
                    await message.reply(f"✅ Removed `{uid}` from blacklist")
                else:
                    await message.reply(f"⚠️ User `{uid}` not in blacklist")
            except ValueError:
                await message.reply("❌ Invalid User ID")
        
        elif action == "clear":
            _storage["blacklist"] = []
            save_storage()
            await message.reply("✅ Blacklist cleared")
        
        else:
            await message.reply("Usage:\n`/blacklist add 123456789`\n`/blacklist remove 123456789`\n`/blacklist clear`")
    
    @app.on_message(filters.command("revenue") & admin_filter)
    async def revenue_command(client: Client, message: Message):
        args = message.text.split()
        period = args[1].lower() if len(args) > 1 else "today"
        
        today_revenue = 0.0
        try:
            tracker = _storage.get("session_tracker", {})
            for sessions in tracker.values():
                today_revenue += len(sessions) * 2.0
        except Exception:
            pass
        
        text = "💰 **Revenue Report**\n"
        text += "━━━━━━━━━━━━━━━━━━━━━\n\n"
        
        if period == "today":
            text += f"**Today's Revenue:** `${today_revenue:.2f}`"
        elif period == "week":
            text += f"**This Week's Revenue:** `${today_revenue * 7:.2f}` (estimated)"
        elif period == "month":
            text += f"**This Month's Revenue:** `${today_revenue * 30:.2f}` (estimated)"
        else:
            text += "Usage: `/revenue today|week|month`"
        
        await message.reply(text)
    
    @app.on_message(filters.command("alert") & admin_filter)
    async def alert_command(client: Client, message: Message):
        args = message.text.split()
        if len(args) != 3:
            await message.reply("Usage: `/alert low_balance true` or `/alert high_reject_rate false`")
            return
        
        alert_type = args[1].lower()
        enabled = args[2].lower() == "true"
        
        if "alert_settings" not in _storage:
            _storage["alert_settings"] = {
                "low_balance_alert": True,
                "high_reject_rate_alert": True,
                "api_error_alert": True,
            }
        
        if alert_type in _storage["alert_settings"]:
            _storage["alert_settings"][alert_type] = enabled
            save_storage()
            status = "enabled" if enabled else "disabled"
            await message.reply(f"✅ {alert_type.replace('_', ' ').title()} {status}")
        else:
            await message.reply(f"❌ Unknown alert type: {alert_type}")
    
    @app.on_message(filters.command("alert_threshold") & admin_filter)
    async def alert_threshold_command(client: Client, message: Message):
        args = message.text.split()
        if len(args) != 3:
            await message.reply("Usage: `/alert_threshold low_balance 100`")
            return
        
        alert_type = args[1].lower()
        try:
            threshold = float(args[2])
            
            if "alert_thresholds" not in _storage:
                _storage["alert_thresholds"] = {}
            
            _storage["alert_thresholds"][alert_type] = threshold
            save_storage()
            
            await message.reply(f"✅ {alert_type.replace('_', ' ').title()} threshold set to `{threshold}`")
        except ValueError:
            await message.reply("❌ Invalid threshold value")
    
    @app.on_message(filters.command("addadmin") & admin_filter)
    async def add_admin_command(client: Client, message: Message):
        args = message.text.split()
        if len(args) != 2:
            await message.reply("Usage: `/addadmin 123456789`")
            return
        
        try:
            new_admin_id = int(args[1])
            
            admins = _storage.get("admins", [ADMIN_ID])
            if ADMIN_ID not in admins:
                admins.append(ADMIN_ID)
            
            if new_admin_id in admins:
                await message.reply(f"⚠️ User `{new_admin_id}` is already an Admin!")
                return
            
            admins.append(new_admin_id)
            _storage["admins"] = admins
            save_storage()
            
            await message.reply(f"✅ `{new_admin_id}` added as Admin!")
        except ValueError:
            await message.reply("❌ Invalid User ID")
    
    @app.on_message(filters.command("removeadmin") & admin_filter)
    async def remove_admin_command(client: Client, message: Message):
        args = message.text.split()
        if len(args) != 2:
            await message.reply("Usage: `/removeadmin 123456789`")
            return
        
        try:
            admin_id = int(args[1])
            
            admins = _storage.get("admins", [ADMIN_ID])
            if admin_id not in admins:
                await message.reply(f"⚠️ User `{admin_id}` is not an Admin!")
                return
            
            if admin_id == ADMIN_ID:
                await message.reply("❌ Cannot remove the main admin!")
                return
            
            admins.remove(admin_id)
            _storage["admins"] = admins
            save_storage()
            
            await message.reply(f"✅ `{admin_id}` removed from Admins!")
        except ValueError:
            await message.reply("❌ Invalid User ID")
    
    @app.on_message(filters.command("adminlist") & admin_filter)
    async def admin_list_command(client: Client, message: Message):
        admins = _storage.get("admins", [ADMIN_ID])
        
        text = "👑 **Admin List**\n"
        text += "━━━━━━━━━━━━━━━━━━━━━\n\n"
        text += f"Total Admins: `{len(admins)} `\n\n"
        
        for admin_id in admins:
            admin_type = "👑 Owner" if admin_id == ADMIN_ID else "👤 Admin"
            text += f"  `{admin_id}` - {admin_type}\n"
        
        await message.reply(text)

