from pyrogram.client import Client
from pyrogram import filters
from pyrogram.types import Message
from bot.utils.storage import get_open_countries, is_country_open, get_country_rate, get_country_timeout, is_user_banned, get_user_info, update_user_info, get_required_channel, get_message_template
from bot.utils.country_data import get_flag, get_all_flags
from bot.config import ADMIN_ID

def register_cap_handler(app: Client):
    @app.on_message(filters.command("cap"))
    async def show_capacity(client: Client, message: Message):
        user_id = message.chat.id
        
        if is_user_banned(user_id):
            await message.reply_text(get_message_template("banned_user_message"))
            return
        
        if user_id != ADMIN_ID:
            from bot.middleware.channel_guard import ensure_membership, send_join_prompt
            is_member = await ensure_membership(client, user_id)
            if not is_member:
                await send_join_prompt(client, user_id, message=message)
                return
        
        countries = get_open_countries()

        if not countries:
            await message.reply_text("❌ No available countries at the moment.")
            return

        response = "📋 Available Countries\n```\n"
        total = 0

        for country_code in countries:
            flag = get_flag(country_code)
            rate = get_country_rate(country_code)
            timeout_seconds = get_country_timeout(country_code)
            response += f"{flag} {country_code} | 💰 {rate:.2f}$ | ⏰ {timeout_seconds} sec | 🟢 OPEN\n"
            total += 1

        response += "```"

        response += f"\n\n🌍 Total Countries :{total}"

        await message.reply_text(response)
