"""
Telegram Session Bot - Main Entry Point
========================================
Professional Telegram session verification bot with:
- Channel membership guard
- Anti-spam protection
- Multi-country support
- Device fingerprint generation

Author: Session Bot System
Version: 3.0 (Professional Refactored)
"""

import sys
import os

# Ensure the parent directory is in path for module imports
_project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

import asyncio
import json
import logging
from datetime import datetime, timedelta
from typing import Optional, Tuple, Any, Union

from pyrogram.client import Client
from pyrogram import filters
from pyrogram.types import Message, CallbackQuery
from pyrogram.errors import FloodWait

from bot import config
from bot.config import ADMIN_ID
from bot.constants import get_country_flag as _get_flag
from bot.handlers.start import register_start
from bot.handlers.account import register_account
from bot.handlers.withdraw import register_withdraw, register_withdraw_handlers
from bot.handlers.support import register_support
from bot.utils.session_handler import (
    start_session_verification,
    verify_otp_and_setup_2fa,
    get_session_step,
    validate_session,
    check_account_status,
    get_country_rate,
    get_rotated_api
)
from bot.utils.anti_spam import (
    human_delay, pre_device_check_delay, between_api_calls_delay,
    safe_disconnect, smart_flood_wait_handler
)
from bot.utils.storage import (
    get_all_pending_sessions,
    approve_pending_session,
    reject_pending_session,
    get_user_info,
    is_verification_paused
)
from bot.utils.device_generator import generate_device_info
from bot.handlers import admin as admin_module
from bot.middleware.channel_guard import (
    invalidate_user_membership,
    set_cached_membership
)
from bot.utils import database as db

_high_scale_initialized = False

async def initialize_high_scale_systems():
    """Initialize all high-scale systems (Redis, Memory Manager, etc.)"""
    global _high_scale_initialized
    if _high_scale_initialized:
        return
    
    print("🚀 Initializing high-scale systems...")
    
    try:
        from bot.utils import redis_cache
        redis_ok = await redis_cache.init_redis()
        if redis_ok:
            print("✅ Redis cache initialized")
            from bot.middleware.channel_guard import init_redis_cache
            await init_redis_cache()
        else:
            logger.warning("⚠️ Redis not available, using in-memory fallback")
    except Exception as e:
        logger.warning(f"⚠️ Redis init error (non-fatal): {e}")
    
    try:
        from bot.utils import high_scale_storage
        await high_scale_storage.init_high_scale_storage()
        print("✅ High-scale storage initialized")
    except Exception as e:
        logger.warning(f"⚠️ High-scale storage init error (non-fatal): {e}")
    
    try:
        from bot.utils import memory_manager
        await memory_manager.start_memory_manager()
        print("✅ Memory manager started")
    except Exception as e:
        logger.warning(f"⚠️ Memory manager init error (non-fatal): {e}")
    
    _high_scale_initialized = True
    print("🎉 High-scale systems ready!")


async def shutdown_high_scale_systems():
    """Gracefully shutdown high-scale systems."""
    print("🔄 Shutting down high-scale systems...")
    
    try:
        from bot.utils import memory_manager
        await memory_manager.stop_memory_manager()
    except Exception:
        pass
    
    try:
        from bot.utils import high_scale_storage
        await high_scale_storage.close_high_scale_storage()
    except Exception:
        pass
    
    try:
        from bot.utils import redis_cache
        await redis_cache.close_redis()
    except Exception:
        pass
    
    print("✅ High-scale systems shutdown complete")


# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def parse_verification_result(result: Any) -> Tuple[bool, str, Optional[str]]:
    """
    Safely parse verification result tuple.
    Handles tuples of varying lengths returned by verification functions.
    
    Args:
        result: The result from verification functions (tuple or other)
        
    Returns:
        Tuple of (success: bool, message: str, session_id: Optional[str])
    """
    if isinstance(result, tuple):
        success = result[0] if len(result) > 0 else False
        msg = result[1] if len(result) > 1 else "Error occurred"
        session_id = result[2] if len(result) > 2 else None
        return success, msg, session_id
    return False, str(result) if result else "Error occurred", None


async def _safe_update_pending_session(session_id: str, field: str, value: Any):
    """Safely update pending session field with error handling."""
    try:
        from bot.utils.storage import update_pending_session_field
        await asyncio.to_thread(update_pending_session_field, session_id, field, value)
    except Exception as e:
        logger.warning(f"⚠️ Background update_pending_session_field failed for {session_id}: {e}")


async def send_to_channel_with_retry(
    chat_id: Union[int, str], 
    message: Optional[str] = None, 
    document: Optional[str] = None, 
    caption: Optional[str] = None, 
    max_retries: int = 2
) -> Optional[Message]:
    """
    Send message to channel with fast retry mechanism.
    
    Args:
        chat_id: Channel ID or username
        message: Text message to send
        document: Path to document file
        caption: Caption for document
        max_retries: Maximum retry attempts
        
    Returns:
        Sent message object or None on failure
    """
    if chat_id is None:
        logger.warning("send_to_channel_with_retry: chat_id is None, skipping")
        return None
    
    for attempt in range(max_retries):
        try:
            if document:
                if not os.path.exists(document):
                    logger.error(f"Document file not found: {document}")
                    raise FileNotFoundError(f"Document file not found: {document}")
                return await app.send_document(chat_id=chat_id, document=document, caption=caption or "")
            else:
                if not message:
                    raise ValueError("Message cannot be empty")
                return await app.send_message(chat_id=chat_id, text=message)
        except FloodWait as e:
            wait_time = int(e.value) if isinstance(e.value, (int, float)) else 2
            logger.warning(f"FloodWait: waiting {wait_time}s before retry")
            await asyncio.sleep(wait_time)
        except Exception as e:
            logger.error(f"Send to channel error (attempt {attempt + 1}): {e}")
            if attempt < max_retries - 1:
                await asyncio.sleep(0.5)
            else:
                raise
    return None

# Initialize the bot
app = Client(
    "session_bot_v2",
    api_id=config.API_ID,
    api_hash=config.API_HASH,
    bot_token=config.BOT_TOKEN,
    workdir="bot/"
)

# ========== APPLY UNIVERSAL CHANNEL GUARD ==========
# This MUST be called BEFORE any handlers are registered
# It monkey-patches add_handler to wrap ALL handlers with membership check
from bot.middleware.channel_guard import apply_channel_guard
apply_channel_guard(app)
print("✅ Universal Channel Guard activated on app")

# Register /start command - PROTECTED BY UNIVERSAL CHANNEL GUARD
@app.on_message(filters.command("start") & filters.private)
async def start_handler(client: Client, message: Message):
    """Start handler - Universal guard already enforces channel membership with force_check=True"""
    user_id = message.chat.id
    print(f"RECEIVED /start from user {user_id}")
    
    try:
        from bot.utils.session_handler import cleanup_session
        await cleanup_session(user_id)
        await register_start(client, message)
        print(f"/start handler completed for user {user_id}")
    except Exception as e:
        logger.error(f"ERROR in start_handler: {e}")
        import traceback
        traceback.print_exc()
        try:
            await message.reply("An error occurred. Please try again or contact support.")
        except Exception:
            pass

# Register /account command - PROTECTED BY UNIVERSAL CHANNEL GUARD
@app.on_message(filters.command("account") & filters.private)
async def account_handler(client: Client, message: Message):
    """Account handler - Universal guard already enforces channel membership with force_check=True"""
    try:
        await register_account(client, message)
    except Exception as e:
        logger.error(f"ERROR in account_handler: {e}")
        import traceback
        traceback.print_exc()
        try:
            await message.reply("An error occurred. Please try /start first.")
        except Exception:
            pass

# Register /withdraw command - PROTECTED BY UNIVERSAL CHANNEL GUARD
@app.on_message(filters.command("withdraw") & filters.private)
async def withdraw_handler(client: Client, message: Message):
    """Withdraw handler - Universal guard already enforces channel membership with force_check=True"""
    try:
        await register_withdraw(client, message)
    except Exception as e:
        logger.error(f"ERROR in withdraw_handler: {e}")
        import traceback
        traceback.print_exc()
        try:
            await message.reply("An error occurred. Please try /start first.")
        except Exception:
            pass

# Register /cancel command - PROTECTED BY UNIVERSAL CHANNEL GUARD
# Admins are excluded here so their /cancel reaches the admin cancel handler
# (which clears the admin panel state) instead of the user verification cancel.
@app.on_message(filters.command("cancel") & filters.private & ~admin_module.admin_filter)
async def cancel_handler(client: Client, message: Message):
    """Cancel handler - Universal guard already enforces channel membership with force_check=True"""
    user_id = message.chat.id
    
    from bot.utils.session_handler import cleanup_session
    await cleanup_session(user_id)
    await message.reply("❌ Verification cancelled. Session cleared.\n\nType /start to begin again.")

# Register support handler
register_support(app)

# Register admin and cap handlers
from bot.handlers.admin import register_admin_handlers
from bot.handlers.cap import register_cap_handler

register_admin_handlers(app)
register_cap_handler(app)

# ========== Auto Cache Channel Messages ==========
@app.on_message(filters.channel)
async def auto_cache_channel(client: Client, message: Message):
    """Automatically cache any channel the bot receives messages from"""
    chat_id = message.chat.id
    chat_title = message.chat.title or "Unknown"
    
    channel_names = {
        config.CHANNEL_SUBMIT: "CHANNEL_SUBMIT",
        config.CHANNEL_VERIFIED: "CHANNEL_VERIFIED", 
        config.CHANNEL_REJECTED: "CHANNEL_REJECTED",
        config.CHANNEL_WITHDRAW_REPORT: "CHANNEL_WITHDRAW_REPORT",
        config.CHANNEL_24HR_UP: "CHANNEL_24HR_UP"
    }
    
    config_name = channel_names.get(chat_id, "Other")
    print(f"✅ AUTO-CACHED CHANNEL: {chat_title} (ID: {chat_id}) - {config_name}")

# ========== Channel Cache Handler (Admin only) ==========
@app.on_message(filters.private & filters.forwarded)
async def cache_forwarded_channel(client: Client, message: Message):
    """Cache channel when admin forwards a message from it"""
    user_id = message.chat.id
    
    if user_id != ADMIN_ID:
        return
    
    if message.forward_from_chat:
        chat = message.forward_from_chat
        chat_id = chat.id
        chat_title = chat.title or "Unknown"
        chat_type = chat.type
        
        print(f"✅ FORWARD CACHED: {chat_title} (ID: {chat_id}, Type: {chat_type})")
        
        channel_names = {
            config.CHANNEL_SUBMIT: "CHANNEL_SUBMIT (Pending)",
            config.CHANNEL_VERIFIED: "CHANNEL_VERIFIED",
            config.CHANNEL_REJECTED: "CHANNEL_REJECTED",
            config.CHANNEL_WITHDRAW_REPORT: "CHANNEL_WITHDRAW_REPORT",
            config.CHANNEL_24HR_UP: "CHANNEL_24HR_UP"
        }
        
        config_name = channel_names.get(chat_id, "Unknown Config")
        
        await message.reply(
            f"✅ *Channel Cached*\n\n"
            f"📺 Name: *{chat_title}*\n"
            f"🆔 ID: `{chat_id}`\n"
            f"📋 Type: {chat_type}\n"
            f"⚙️ Config: {config_name}\n\n"
            f"Messages can now be sent to this channel!"
        )
    else:
        await message.reply("⚠️ This is not a forwarded message from a channel/group.")

# ========== Test Channels Command (Admin only) ==========
@app.on_message(filters.command("test_channels") & filters.private)
async def test_channels_handler(client: Client, message: Message):
    """Test all channel connections"""
    if message.chat.id != ADMIN_ID:
        return
    
    await message.reply("🔄 Testing channels...")
    
    channels = {
        "CHANNEL_SUBMIT": config.CHANNEL_SUBMIT,
        "CHANNEL_VERIFIED": config.CHANNEL_VERIFIED,
        "CHANNEL_REJECTED": config.CHANNEL_REJECTED,
        "CHANNEL_WITHDRAW_REPORT": config.CHANNEL_WITHDRAW_REPORT,
        "CHANNEL_24HR_UP": config.CHANNEL_24HR_UP
    }
    
    results = []
    for name, channel_id in channels.items():
        try:
            chat = await client.get_chat(channel_id)
            results.append(f"✅ {name}: {chat.title}")
        except Exception as e:
            results.append(f"❌ {name}: {str(e)[:40]}")
    
    result_text = "\n".join(results)
    await message.reply(f"**Channel Status:**\n\n{result_text}")

# ========== Channel Membership Verification Callback - UNIVERSAL ==========
@app.on_callback_query(filters.regex(r"^(check_membership_verify|channel_joined_verify)$"))
async def handle_channel_membership_callback(client: Client, query: CallbackQuery):
    """
    UNIVERSAL Channel Membership Verification Callback
    
    This handles both:
    - check_membership_verify (new unified callback)
    - channel_joined_verify (legacy callback for backward compatibility)
    
    ALWAYS performs LIVE check (never uses cache for this callback).
    After successful verification, all handlers will work automatically.
    """
    user_id = query.from_user.id
    
    invalidate_user_membership(user_id)
    
    from bot.middleware.channel_guard import check_membership_live
    is_member, error_reason = await check_membership_live(client, user_id)
    
    from bot.utils.storage import get_required_channel
    channel = get_required_channel()
    
    if is_member:
        set_cached_membership(user_id, True)
        
        try:
            from bot.utils.fast_cache import background_save_user
            asyncio.create_task(background_save_user(user_id, channel_joined=True))
        except Exception as e:
            print(f"Background save error: {e}")
        
        await query.answer("Thank you! You can now use all features.", show_alert=True)
        
        try:
            await query.message.edit_text(
                "**Channel Verified!**\n\n"
                "You can now use all bot features.\n\n"
                "/start - Begin\n"
                "/account - View Account\n"
                "/withdraw - Withdraw Funds\n\n"
                "All commands and buttons will now work!"
            )
        except Exception as e:
            print(f"Could not edit message: {e}")
            try:
                await client.send_message(
                    user_id,
                    "**Channel Verified!**\n\n"
                    "You can now use all bot features.\n\n"
                    "/start - Begin"
                )
            except Exception:
                pass
        
        print(f"Channel membership VERIFIED for user {user_id}")
    elif error_reason == "bot_no_access":
        set_cached_membership(user_id, False)
        
        bot_username = (await client.get_me()).username or "the bot"
        await query.answer(
            f"Cannot verify channel membership.\n\n"
            f"The bot (@{bot_username}) must be added as an admin in {channel} channel first.\n"
            f"Please contact the bot administrator.",
            show_alert=True
        )
        
        try:
            await query.message.edit_text(
                f"**Bot Setup Required**\n\n"
                f"The bot cannot verify channel membership because it is not an admin in {channel}.\n\n"
                f"Please contact the administrator to add @{bot_username} as admin in {channel}.\n\n"
                f"Your access has NOT been approved until the bot is properly configured."
            )
        except Exception:
            pass
        
        print(f"BOT NO ACCESS to {channel} - user {user_id} NOT approved (requires bot admin setup)")
    else:
        set_cached_membership(user_id, False)
        
        await query.answer(
            f"You have not joined {channel} channel yet!\n\nPlease join the channel first.",
            show_alert=True
        )
        print(f"Channel membership FAILED for user {user_id}")

# ========== Session Verification Handler - PROTECTED BY UNIVERSAL CHANNEL GUARD ==========
@app.on_message(filters.private & filters.text & ~filters.command(["start", "account", "withdraw", "cap", "admin", "support", "cancel"]), group=1)
async def handle_text_input(client: Client, message: Message):
    """
    Handle text input for phone number and OTP verification
    Universal guard already enforces channel membership with force_check=True
    """
    try:
        user_id = message.chat.id
        text = message.text.strip()
        
        from bot.utils.fast_cache import (
            is_user_banned_fast,
            get_cached_template
        )
        
        if user_id == ADMIN_ID:
            if user_id in admin_module.admin_state:
                return
            
            parts = text.split()
            if len(parts) >= 2 and parts[0].startswith('+'):
                try:
                    float(parts[1])
                    return
                except (ValueError, IndexError):
                    pass
        
        if is_user_banned_fast(user_id):
            await message.reply(get_cached_template("banned_user_message"))
            return
        
        session_step = get_session_step(user_id)
        
        if session_step == "waiting_otp":
            processing_msg = await message.reply(get_cached_template("processing_message"))
            
            result = await verify_otp_and_setup_2fa(user_id, text, client)
            success, msg, task_session_id = parse_verification_result(result)
            
            await processing_msg.delete()
            account_msg = await message.reply(msg)
            
            if success and task_session_id:
                msg_id = account_msg.id
                asyncio.create_task(_safe_update_pending_session(task_session_id, "user_message_id", msg_id))
        
        elif text.startswith('+'):
            if is_verification_paused():
                await message.reply("⏸️ Number submission is temporarily paused.\n\nPlease try again after some time.")
                return
            
            phone_message_id = message.id
            processing_msg = await message.reply(get_cached_template("processing_message"))
            
            result = await start_session_verification(user_id, text, phone_message_id)
            success, msg, task_session_id = parse_verification_result(result)
            
            await processing_msg.delete()
            account_msg = await message.reply(msg or "")
            
            if success and task_session_id:
                msg_id = account_msg.id
                asyncio.create_task(_safe_update_pending_session(task_session_id, "user_message_id", msg_id))
        else:
            pass
    except Exception as e:
        logger.error(f"❌ Error in handle_text_input: {e}")
        try:
            await message.reply("❌ An error occurred. Please try again later.")
        except Exception:
            pass  # Reply failed, but error is logged

# Register withdraw handlers (callback queries and wallet input) - Register AFTER session handler
register_withdraw_handlers(app)

async def expire_multi_device_window(session_id: str, session_data: dict):
    """Expire a multi-device session whose 24h (+grace) verification window was missed.

    Idempotent: guarded by status == pending and the multi_device_expired flag.
    """
    from bot.utils.storage import (
        expire_pending_session,
        set_pending_session_field,
        get_pending_session
    )
    try:
        current = get_pending_session(session_id) or {}
        if current.get("status") != "pending":
            return
        if current.get("multi_device_expired"):
            return

        phone = session_data.get("phone", "Unknown")
        user_id = session_data.get("user_id")
        country_code = session_data.get("country_code", "UNKNOWN")

        expire_pending_session(session_id, "Multi-device 24h window missed (24h + grace exceeded)")
        set_pending_session_field(session_id, "multi_device_expired", True)
        print(f"⏰ EXPIRED: {phone} - 24h multi-device window passed without verification")

        if user_id:
            try:
                await app.send_message(
                    chat_id=int(user_id),
                    text=(
                        f"⏰ *Session Expired*\n\n"
                        f"📱 Phone: {phone}\n\n"
                        f"❌ Multi-device detected but the 24-hour\n"
                        f"verification window has passed.\n"
                        f"📋 Submit again: /start"
                    )
                )
            except Exception:
                pass

        try:
            if config.CHANNEL_REJECTED:
                flag = _get_flag(country_code)
                await send_to_channel_with_retry(
                    chat_id=config.CHANNEL_REJECTED,
                    message=(
                        f"⏰ **Multi-Device 24h Window Missed - Expired**\n\n"
                        f"📱 Phone: {phone}\n"
                        f"🌍 Country: {country_code} {flag}\n"
                        f"❌ 24h verification window passed without balance\n"
                        f"📋 Status: Rejected/Expired"
                    )
                )
        except Exception:
            pass
    except Exception as e:
        logger.warning(f"⚠️ EXPIRED: multi-device window expiry error for {session_id}: {e}")


async def pending_session_monitor():
    """
    Background task to monitor pending sessions and validate them after timeout
    
    RECOVERY MODE: If bot restarts with pending sessions that have already completed
    2FA/spam check/device check, they will be processed immediately (within 60 seconds)
    instead of waiting for the full country timeout.
    """
    print("🔄 Pending session monitor started...")
    startup_time = datetime.now()
    recovery_done = False
    last_cleanup_time = datetime.now()
    last_pending_fetch_time = datetime.min
    pending_sessions_cache = {}
    monitor_first_iteration = True
    PENDING_FETCH_INTERVAL = 3
    
    while True:
        try:
            try:
                if not monitor_first_iteration:
                    await asyncio.sleep(300)
                monitor_first_iteration = False
            except asyncio.CancelledError:
                break
            except Exception:
                await asyncio.sleep(1)
                continue
            
            from bot.handlers.admin import get_monitor_status
            if not get_monitor_status():
                continue
            
            current_time = datetime.now()
            if (current_time - last_pending_fetch_time).total_seconds() >= PENDING_FETCH_INTERVAL:
                pending_sessions_cache = get_all_pending_sessions()
                last_pending_fetch_time = current_time
            pending_sessions = pending_sessions_cache
            
            if (current_time - last_cleanup_time).total_seconds() > 3600:
                try:
                    from bot.utils.pending_recovery import finalize_expired_sessions
                    print("🧹 HOURLY: Running expired session cleanup...")
                    expired_stats = await finalize_expired_sessions(app)
                    total_expired = expired_stats.get("deleted_no_otp", 0) + expired_stats.get("expired_old", 0)
                    if total_expired > 0:
                        print(f"🧹 HOURLY CLEANUP: Finalized {total_expired} expired sessions with user notifications")
                    
                    from bot.utils.storage import cleanup_old_stuck_sessions
                    cleaned = cleanup_old_stuck_sessions(max_age_hours=72)
                    if cleaned > 0:
                        print(f"🧹 AUTO CLEANUP: Removed {cleaned} old stuck sessions")
                    
                    from bot.utils.session_handler import cleanup_stale_active_sessions
                    await cleanup_stale_active_sessions()
                    
                    last_cleanup_time = current_time
                except Exception as cleanup_err:
                    logger.warning(f"⚠️ Cleanup error: {cleanup_err}")
            
            seconds_since_startup = (current_time - startup_time).total_seconds()
            if not recovery_done and seconds_since_startup < 120:
                for session_id, session_data in list(pending_sessions.items()):
                    if session_data.get("status") != "pending":
                        continue
                    
                    session_info = session_data.get("session_data", {})
                    if session_info.get("message_send_success") == True:
                        continue
                    
                    ready_to_send = session_info.get("ready_to_send", False)
                    device_check_done = session_info.get("device_check_completed", False)
                    
                    if ready_to_send and device_check_done:
                        precomputed_message = session_info.get("precomputed_message")
                        message_type = session_info.get("message_type")
                        cached_msg_id = session_info.get("cached_msg_id")
                        user_id = str(session_data.get("user_id", "0"))
                        phone = session_data.get("phone", "UNKNOWN")
                        country_code = session_data.get("country_code", "UNKNOWN")
                        
                        if precomputed_message and message_type:
                            from bot.utils.storage import (
                                try_claim_session_finalization,
                                mark_session_finalization_claimed_by,
                                mark_session_message_sent,
                                is_session_message_already_sent,
                                replace_pending_session_data, get_pending_session
                            )
                            
                            if is_session_message_already_sent(session_id):
                                print(f"⏭️ RECOVERY: Message already sent for {phone} - skipping")
                                continue
                            
                            claimed = try_claim_session_finalization(session_id)
                            if not claimed:
                                print(f"⏭️ RECOVERY: Finalization already claimed for {phone} - skipping")
                                continue
                            
                            mark_session_finalization_claimed_by(session_id, "monitor_recovery")
                            
                            print(f"🔄 RECOVERY MODE: Found interrupted session {session_id} for {phone}")
                            print(f"   - 2FA completed: {session_info.get('twofa_completed', False)}")
                            print(f"   - Spam check completed: {session_info.get('spam_check_completed', False)}")
                            print(f"   - Device check completed: {device_check_done}")
                            print(f"   - Message type: {message_type}")
                            print("   - Processing immediately...")
                            
                            try:
                                if cached_msg_id and cached_msg_id > 0:
                                    await app.edit_message_text(chat_id=int(user_id), message_id=int(cached_msg_id), text=precomputed_message)
                                else:
                                    await app.send_message(chat_id=int(user_id), text=precomputed_message)
                                
                                mark_session_message_sent(session_id, True)
                                
                                print(f"✅ RECOVERY: {message_type} message sent for {phone}")
                                
                                persisted_session = get_pending_session(session_id) or {}
                                persisted_info = persisted_session.get("session_data", {})
                                already_reported = persisted_info.get("channel_report_sent", False)
                                
                                session_info["message_send_success"] = True
                                session_info["message_sent_at"] = datetime.now().isoformat()
                                session_info["recovered_by_monitor"] = True
                                if not already_reported:
                                    session_info["channel_report_sent"] = False
                                else:
                                    session_info["channel_report_sent"] = True
                                replace_pending_session_data(session_id, session_info)
                                
                                if already_reported:
                                    print(f"⏭️ RECOVERY: Channel report already sent for {phone} - skipping report")
                                    continue
                                
                                if message_type == "SUCCESS":
                                    from bot.utils.storage import atomic_credit_balance_for_session
                                    from bot.utils.fast_cache import sync_user_from_storage
                                    
                                    spam_status = session_info.get("spam_status", "limit")
                                    fresh_rate = get_country_rate(country_code, spam_status)
                                    
                                    credit_success = atomic_credit_balance_for_session(session_id, int(user_id), fresh_rate)
                                    if credit_success:
                                        sync_user_from_storage(int(user_id))
                                        print(f"💰 RECOVERY: Balance ${fresh_rate} credited to user {user_id}")
                                        try:
                                            from bot.utils.database import log_transaction
                                            asyncio.create_task(log_transaction(
                                                user_id=int(user_id),
                                                action="session_verified",
                                                amount=fresh_rate,
                                                session_id=session_id,
                                                country_code=country_code,
                                                phone_number=phone,
                                                spam_status=spam_status
                                            ))
                                        except Exception as log_err:
                                            logger.warning(f"⚠️ DB Log error: {log_err}")
                                    
                                    try:
                                        current_status = get_pending_session(session_id) or {}
                                        if current_status.get("status", "pending") == "pending":
                                            approve_pending_session(session_id)
                                    except Exception as verify_err:
                                        logger.warning(f"⚠️ RECOVERY: approve_pending_session failed: {verify_err}")
                                    
                                    if not session_info.get("channel_report_sent"):
                                        try:
                                            await send_to_channel_with_retry(
                                                chat_id=config.CHANNEL_VERIFIED,
                                                message=f"✅ **Session Verified (RECOVERED)**\n\n"
                                                        f"Phone: {phone}\n"
                                                        f"Country: {country_code}\n"
                                                        f"Rate: ${fresh_rate}\n"
                                                        f"Spam: {spam_status}\n"
                                                        f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
                                            )
                                            session_info["channel_report_sent"] = True
                                            replace_pending_session_data(session_id, session_info)
                                            print(f"📤 RECOVERY: SUCCESS report sent to CHANNEL_VERIFIED for {phone}")
                                        except Exception as channel_err:
                                            logger.warning(f"⚠️ RECOVERY: Channel report failed: {channel_err}")
                                
                                elif message_type in ("REJECTED", "REJECTION"):
                                    try:
                                        current_status = get_pending_session(session_id) or {}
                                        if current_status.get("status", "pending") == "pending":
                                            reject_pending_session(session_id, "Device not logged in (recovered)")
                                    except Exception as rej_status_err:
                                        logger.warning(f"⚠️ RECOVERY: reject_pending_session failed: {rej_status_err}")
                                    
                                    if not already_reported:
                                        try:
                                            await send_to_channel_with_retry(
                                                chat_id=config.CHANNEL_REJECTED,
                                                message=f"❌ **Session Rejected (RECOVERED)**\n\n"
                                                        f"Phone: {phone}\n"
                                                        f"Country: {country_code}\n"
                                                        f"Reason: Device not logged in\n"
                                                        f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
                                            )
                                            session_info["channel_report_sent"] = True
                                            replace_pending_session_data(session_id, session_info)
                                            print(f"📤 RECOVERY: Rejection report sent for {phone}")
                                        except Exception as rej_err:
                                            logger.warning(f"⚠️ RECOVERY: Rejection report failed: {rej_err}")
                                
                                elif message_type == "MULTI-DEVICE":
                                    if not already_reported:
                                        try:
                                            await send_to_channel_with_retry(
                                                chat_id=config.CHANNEL_24HR_UP,
                                                message=f"📱 **Multiple Devices Detected (RECOVERED)**\n\n"
                                                        f"Phone: {phone}\n"
                                                        f"Country: {country_code}\n"
                                                        f"ℹ️ Session Valid - Balance NOT added\n"
                                                        f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
                                            )
                                            session_info["channel_report_sent"] = True
                                            replace_pending_session_data(session_id, session_info)
                                            print(f"📤 RECOVERY: Multi-device report sent for {phone}")
                                        except Exception as md_err:
                                            logger.warning(f"⚠️ RECOVERY: Multi-device report failed: {md_err}")
                                
                            except Exception as recovery_err:
                                error_str = str(recovery_err)
                                if "MESSAGE_NOT_MODIFIED" in error_str:
                                    print(f"✅ RECOVERY: Message already sent for {phone} - marking complete")
                                    try:
                                        from bot.utils.storage import replace_pending_session_data, set_pending_session_field
                                        session_info["message_send_success"] = True
                                        session_info["recovered_by_monitor"] = True
                                        session_info["channel_report_sent"] = True
                                        replace_pending_session_data(session_id, session_info)
                                        set_pending_session_field(session_id, "recovered_by_monitor", True)
                                    except Exception as mark_err:
                                        logger.warning(f"⚠️ Could not mark session complete: {mark_err}")
                                else:
                                    logger.warning(f"⚠️ RECOVERY failed for {phone}: {recovery_err}")
                
                if seconds_since_startup >= 60:
                    recovery_done = True
                    print("✅ RECOVERY MODE: Initial recovery scan completed")
            
            for session_id, session_data in list(pending_sessions.items()):
                if session_data.get("status") != "pending":
                    continue
                
                session_info = session_data.get("session_data", {})
                
                ready_to_send = session_info.get("ready_to_send", False)
                device_check_done = session_info.get("device_check_completed", False)
                
                if session_info.get("message_send_success"):
                    continue
                
                if session_data.get("stuck_recovery_processing"):
                    continue
                
                if not ready_to_send or not device_check_done:
                    try:
                        submitted_at_str = session_data.get("submitted_at")
                        if submitted_at_str:
                            submitted_at = datetime.fromisoformat(submitted_at_str)
                            timeout_seconds = session_data.get("timeout_seconds", 600)
                            
                            max_wait_time = timeout_seconds + 180
                            time_since_submit = (current_time - submitted_at).total_seconds()
                            
                            if time_since_submit > max_wait_time and not session_data.get("stuck_recovery_attempted"):
                                # 🔥 CRITICAL FIX: Check if delayed task is still active
                                if session_info.get("delayed_task_active") == True:
                                    print(f"⏭️ STUCK SKIP: delayed_task_active=True, skipping {session_id}")
                                    continue
                                
                                logger.warning(f"⚠️ STUCK SESSION DETECTED: {session_id}")
                                print(f"   - Phone: {session_data.get('phone', 'UNKNOWN')}")
                                print(f"   - Submitted: {time_since_submit:.0f}s ago")
                                print(f"   - Max wait: {max_wait_time}s")
                                print(f"   - ready_to_send: {ready_to_send}, device_check_completed: {device_check_done}")
                                
                                from bot.utils.storage import get_pending_session, set_pending_session_field, replace_pending_session_data, reject_pending_session
                                
                                fresh_session = get_pending_session(session_id)
                                if not fresh_session or fresh_session.get("status") != "pending":
                                    logger.warning(f"⚠️ STUCK RECOVERY: Session {session_id} no longer pending, skipping")
                                    continue
                                
                                fresh_info = fresh_session.get("session_data", {})
                                if fresh_info.get("message_send_success"):
                                    logger.warning(f"⚠️ STUCK RECOVERY: Session {session_id} already sent message, skipping")
                                    continue
                                
                                # CRITICAL: If session has session_string, let pending_recovery handle it
                                # Don't reject sessions that can be verified
                                # Check at ROOT level (where session_string is actually stored)
                                # AND inside session_data dict for backwards compatibility
                                original_session_info = session_data.get("session_data", {})
                                has_session_string = (
                                    # ROOT level - this is where session_string is actually stored!
                                    session_data.get("session_string") or
                                    fresh_session.get("session_string") or
                                    session_data.get("session_file") or
                                    fresh_session.get("session_file") or
                                    # Inside session_data dict (legacy/backup check)
                                    fresh_info.get("session_string") or 
                                    fresh_info.get("session_exported") or
                                    original_session_info.get("session_string") or
                                    original_session_info.get("session_exported")
                                )
                                if has_session_string:
                                    print(f"✅ STUCK SKIP: Session {session_id} has session_string - deferring to pending_recovery")
                                    # Mark for pending_recovery to handle
                                    set_pending_session_field(session_id, "pending_recovery_defer", True)
                                    continue
                                
                                set_pending_session_field(session_id, "stuck_recovery_processing", True)
                                set_pending_session_field(session_id, "stuck_recovery_attempted", True)
                                
                                phone = session_data.get("phone", "UNKNOWN")
                                user_id = session_data.get("user_id", 0)
                                country_code = session_data.get("country_code", "UNKNOWN")
                                
                                try:
                                    from bot.utils.country_data import get_flag
                                    from bot.utils.storage import format_message
                                    flag = get_flag(country_code)
                                    
                                    stuck_message = format_message(
                                        "session_timeout_message",
                                        phone=phone,
                                        country_code=country_code,
                                        flag=flag,
                                        timeout=int(time_since_submit)
                                    )
                                    
                                    session_info["ready_to_send"] = True
                                    session_info["device_check_completed"] = True
                                    session_info["message_type"] = "STUCK_TIMEOUT"
                                    session_info["precomputed_message"] = stuck_message
                                    session_info["stuck_detected_at"] = current_time.isoformat()
                                    
                                    # Use session-specific message ID, not user-level
                                    cached_msg_id = session_info.get("user_message_id") or session_info.get("session_specific_message_id") or session_info.get("cached_msg_id")
                                    if not cached_msg_id:
                                        user_info = get_user_info(str(user_id))
                                        cached_msg_id = user_info.get("pending_message_id") if user_info else None
                                    session_info["cached_msg_id"] = cached_msg_id
                                    
                                    replace_pending_session_data(session_id, session_info)
                                    
                                    message_sent = False
                                    try:
                                        if cached_msg_id and cached_msg_id > 0:
                                            try:
                                                await app.edit_message_text(
                                                    chat_id=int(user_id),
                                                    message_id=int(cached_msg_id),
                                                    text=stuck_message
                                                )
                                                print(f"✅ STUCK RECOVERY: Edited message for {phone}")
                                                message_sent = True
                                            except Exception:
                                                await app.send_message(chat_id=int(user_id), text=stuck_message)
                                                print(f"✅ STUCK RECOVERY: Sent new message for {phone}")
                                                message_sent = True
                                        else:
                                            await app.send_message(chat_id=int(user_id), text=stuck_message)
                                            print(f"✅ STUCK RECOVERY: Sent new message for {phone}")
                                            message_sent = True
                                        
                                        if message_sent:
                                            session_info["message_send_success"] = True
                                            session_info["message_sent_at"] = current_time.isoformat()
                                            replace_pending_session_data(session_id, session_info)
                                    except Exception as stuck_msg_err:
                                        logger.warning(f"⚠️ STUCK RECOVERY: Failed to send message: {stuck_msg_err}")
                                    
                                    try:
                                        await send_to_channel_with_retry(
                                            chat_id=config.CHANNEL_REJECTED,
                                            message=f"❌ **Session Timeout**\n\n"
                                                    f"📱 Phone: {phone}\n"
                                                    f"🌍 Country: {country_code} {flag}\n"
                                                    f"👤 User: {user_id}\n"
                                                    f"⏰ Timeout: {time_since_submit:.0f}s\n"
                                                    f"⏰ Time: {current_time.strftime('%Y-%m-%d %H:%M:%S')}"
                                        )
                                    except Exception as channel_err:
                                        logger.warning(f"⚠️ STUCK RECOVERY: Channel report failed: {channel_err}")
                                    
                                    reject_pending_session(session_id, "Background task timeout (stuck recovery)")
                                    set_pending_session_field(session_id, "stuck_recovery_processing", False)
                                    print(f"✅ STUCK RECOVERY: Session {session_id} marked as rejected")
                                finally:
                                    set_pending_session_field(session_id, "stuck_recovery_processing", False)
                                
                    except Exception as stuck_check_err:
                        logger.warning(f"⚠️ Error checking stuck session: {stuck_check_err}")
            
            for session_id, session_data in list(pending_sessions.items()):
                if session_data.get("status") != "pending":
                    continue
                
                session_info = session_data.get("session_data", {})
                
                # ===== MULTI-DEVICE 24h WINDOW HANDLING =====
                # Multi-device sessions must be fully verified & balance credited within
                # 24h + grace window. They stay pending until that happens or they expire.
                md_ready_for_24h = False
                if session_info.get("has_extra_devices"):
                    already_logged_out = (
                        session_data.get("has_extra_devices_logged_out") or
                        session_info.get("has_extra_devices_logged_out")
                    )
                    md_time_str = (
                        session_data.get("added_at") or
                        session_info.get("added_at") or
                        session_data.get("submitted_at")
                    )
                    md_age_hours = None
                    if md_time_str:
                        try:
                            md_added_dt = datetime.fromisoformat(
                                str(md_time_str).replace("Z", "").replace("+00:00", "")
                            )
                            md_age_hours = (current_time - md_added_dt).total_seconds() / 3600
                        except (ValueError, TypeError):
                            pass
                    
                    if md_age_hours is not None:
                        from bot.utils.pending_recovery import (
                            MULTI_DEVICE_24H_WINDOW_HOURS,
                            MULTI_DEVICE_GRACE_MINUTES,
                            MULTI_DEVICE_LOGOUT_MAX_RETRIES
                        )
                        md_window_hours = MULTI_DEVICE_24H_WINDOW_HOURS + (MULTI_DEVICE_GRACE_MINUTES / 60.0)
                        
                        if md_age_hours >= md_window_hours:
                            # 24h + grace fully passed and the account was never verified.
                            if already_logged_out:
                                # Devices already logged out - finish verify + credit
                                md_ready_for_24h = True
                            else:
                                # Window passed but devices not logged out yet.
                                # Give auto-logout a few bounded chances before expiring.
                                md_logout_attempts = (
                                    session_data.get("md_logout_attempts", 0) or
                                    session_info.get("md_logout_attempts", 0)
                                )
                                if int(md_logout_attempts or 0) < MULTI_DEVICE_LOGOUT_MAX_RETRIES:
                                    print(f"🔄 {session_data.get('phone', 'Unknown')}: window passed but auto-logout retries left ({md_logout_attempts}/{MULTI_DEVICE_LOGOUT_MAX_RETRIES}) - attempting logout before expiry")
                                    md_ready_for_24h = True
                                else:
                                    if not session_data.get("multi_device_expired"):
                                        await expire_multi_device_window(session_id, session_data)
                                    continue
                        elif md_age_hours < MULTI_DEVICE_24H_WINDOW_HOURS and not already_logged_out:
                            # Still inside the 24h hold - message already sent, no balance yet
                            if session_info.get("message_send_success") == True:
                                continue
                            # Message not delivered yet: fall through so it can be sent
                        else:
                            # 24h hold reached (within grace) or devices already logged out
                            md_ready_for_24h = True
                
                if session_data.get("currently_processing") and not md_ready_for_24h:
                    continue
                
                if session_info.get("message_send_success") == True and session_info.get("message_sent_at") and not md_ready_for_24h:
                    continue
                
                # If delayed task is still actively processing, skip (task will handle it)
                # But if deadline has passed, task may be stuck - let monitor handle it
                if session_info.get("delayed_task_active") == True:
                    is_stuck = False
                    try:
                        deadline_at = session_data.get("deadline_at")
                        if deadline_at:
                            deadline = datetime.fromisoformat(deadline_at)
                            if current_time > deadline:
                                is_stuck = True
                    except Exception:
                        pass
                    if not is_stuck:
                        continue  # Task still running, deadline not passed
                    else:
                        logger.warning(f"⚠️ Session {session_id}: delayed_task_active but deadline passed - task may be stuck, monitor processing")
                
                try:
                    deadline_at = session_data.get("deadline_at")
                    if deadline_at:
                        deadline = datetime.fromisoformat(deadline_at)
                    else:
                        submitted_at = datetime.fromisoformat(session_data["submitted_at"])
                        timeout_seconds = session_data["timeout_seconds"]
                        deadline = submitted_at + timedelta(seconds=timeout_seconds)
                    
                    time_remaining = (deadline - current_time).total_seconds()
                except Exception as e:
                    logger.warning(f"⚠️ Error parsing session times: {e}")
                    continue
                
                if time_remaining <= 0:
                    # Mark as currently processing to prevent duplicate checks
                    session_data["currently_processing"] = True
                    from bot.utils.storage import set_pending_session_field
                    set_pending_session_field(session_id, "currently_processing", True)
                    
                    timeout_seconds = session_data.get("timeout_seconds", 0)
                    print(f"⏱️ Session {session_id}: deadline reached at {deadline.strftime('%H:%M:%S')} (timeout: {timeout_seconds}s - READY)")
                    
                    try:
                        session_string = session_data.get("session_string")
                        twofa_password = session_data.get("twofa_password")
                        user_id = str(session_data.get("user_id", "0"))
                        phone = session_data.get("phone", "UNKNOWN")
                        country_code = session_data.get("country_code", "UNKNOWN")
                        rate = float(session_data.get("rate", 0))
                        session_info = session_data.get("session_data", {})
                        
                        precomputed_message = session_info.get("precomputed_message")
                        cached_msg_id = session_info.get("cached_msg_id")
                        message_type = session_info.get("message_type")
                        
                        if precomputed_message and message_type and not md_ready_for_24h:
                            from bot.utils.storage import (
                                try_claim_session_finalization,
                                mark_session_finalization_claimed_by,
                                mark_session_message_sent,
                                is_session_message_already_sent,
                                replace_pending_session_data, get_pending_session
                            )
                            
                            if is_session_message_already_sent(session_id):
                                print(f"⏭️ FAST PATH: Message already sent for {phone} - skipping")
                                continue
                            
                            claimed = try_claim_session_finalization(session_id)
                            if not claimed:
                                print(f"⏭️ FAST PATH: Finalization already claimed for {phone} - skipping")
                                continue
                            
                            mark_session_finalization_claimed_by(session_id, "monitor_fast_path")
                            print(f"🔒 FAST PATH: Claimed finalization rights for {phone}")
                            
                            print(f"⚡ FAST PATH: Using precomputed {message_type} message for {phone}")
                            try:
                                if cached_msg_id and cached_msg_id > 0:
                                    await app.edit_message_text(chat_id=int(user_id), message_id=int(cached_msg_id), text=precomputed_message)
                                else:
                                    await app.send_message(chat_id=int(user_id), text=precomputed_message)
                                
                                mark_session_message_sent(session_id, True)
                                
                                print(f"✅ FAST PATH: {message_type} message sent for {phone}")
                                
                                persisted_session = get_pending_session(session_id) or {}
                                persisted_info = persisted_session.get("session_data", {})
                                already_reported = persisted_info.get("channel_report_sent", False)
                                
                                session_info["message_send_success"] = True
                                session_info["message_sent_at"] = datetime.now().isoformat()
                                if not already_reported:
                                    session_info["channel_report_sent"] = False
                                else:
                                    session_info["channel_report_sent"] = True
                                replace_pending_session_data(session_id, session_info)
                                
                                if already_reported:
                                    print(f"⏭️ FAST PATH: Channel report already sent for {phone} - skipping report")
                                    continue
                                
                                if message_type == "SUCCESS":
                                    from bot.utils.storage import atomic_credit_balance_for_session
                                    from bot.utils.fast_cache import sync_user_from_storage
                                    
                                    spam_status = session_info.get("spam_status", "limit")
                                    fresh_rate = get_country_rate(country_code, spam_status)
                                    
                                    credit_success = atomic_credit_balance_for_session(session_id, int(user_id), fresh_rate)
                                    if credit_success:
                                        sync_user_from_storage(int(user_id))
                                        print(f"💰 Balance ${fresh_rate} credited to user {user_id} (THREAD-SAFE ATOMIC)")
                                        try:
                                            from bot.utils.database import log_transaction
                                            asyncio.create_task(log_transaction(
                                                user_id=int(user_id),
                                                action="session_verified",
                                                amount=fresh_rate,
                                                session_id=session_id,
                                                country_code=country_code,
                                                phone_number=phone,
                                                spam_status=spam_status
                                            ))
                                        except Exception as log_err:
                                            logger.warning(f"⚠️ DB Log error: {log_err}")
                                    else:
                                        logger.warning("⚠️ Balance already credited or session not found - SKIPPING duplicate credit")
                                    
                                    try:
                                        current_status = get_pending_session(session_id) or {}
                                        if current_status.get("status", "pending") == "pending":
                                            approve_pending_session(session_id)
                                    except Exception as verify_err:
                                        logger.warning(f"⚠️ FAST PATH: approve_pending_session failed: {verify_err}")
                                    
                                    if not already_reported:
                                        try:
                                            await send_to_channel_with_retry(
                                                chat_id=config.CHANNEL_VERIFIED,
                                                message=f"✅ **Session Verified (FAST PATH)**\n\n"
                                                        f"Phone: {phone}\n"
                                                        f"Country: {country_code}\n"
                                                        f"Rate: ${fresh_rate}\n"
                                                        f"Spam: {spam_status}\n"
                                                        f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
                                            )
                                            session_info["channel_report_sent"] = True
                                            replace_pending_session_data(session_id, session_info)
                                            print(f"📤 FAST PATH: SUCCESS report sent to CHANNEL_VERIFIED for {phone}")
                                        except Exception as channel_err:
                                            logger.warning(f"⚠️ FAST PATH: Channel report failed: {channel_err}")
                                
                                elif message_type in ("REJECTED", "REJECTION"):
                                    try:
                                        current_status = get_pending_session(session_id) or {}
                                        if current_status.get("status", "pending") == "pending":
                                            reject_pending_session(session_id, "Device not logged in (fast path)")
                                    except Exception as rej_status_err:
                                        logger.warning(f"⚠️ FAST PATH: reject_pending_session failed: {rej_status_err}")
                                    
                                    if not already_reported:
                                        try:
                                            await send_to_channel_with_retry(
                                                chat_id=config.CHANNEL_REJECTED,
                                                message=f"❌ **Session Rejected (FAST PATH)**\n\n"
                                                        f"Phone: {phone}\n"
                                                        f"Country: {country_code}\n"
                                                        f"Reason: Device not logged in\n"
                                                        f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
                                            )
                                            session_info["channel_report_sent"] = True
                                            replace_pending_session_data(session_id, session_info)
                                            print(f"📤 FAST PATH: Rejection report sent for {phone}")
                                        except Exception as rej_err:
                                            logger.warning(f"⚠️ FAST PATH: Rejection report failed: {rej_err}")
                                
                                elif message_type == "MULTI-DEVICE":
                                    if not already_reported:
                                        try:
                                            await send_to_channel_with_retry(
                                                chat_id=config.CHANNEL_24HR_UP,
                                                message=f"📱 **Multiple Devices Detected (FAST PATH)**\n\n"
                                                        f"Phone: {phone}\n"
                                                        f"Country: {country_code}\n"
                                                        f"ℹ️ Session Valid - Balance NOT added\n"
                                                        f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
                                            )
                                            session_info["channel_report_sent"] = True
                                            replace_pending_session_data(session_id, session_info)
                                            print(f"📤 FAST PATH: Multi-device report sent for {phone}")
                                        except Exception as md_err:
                                            logger.warning(f"⚠️ FAST PATH: Multi-device report failed: {md_err}")
                                else:
                                    logger.warning(f"⚠️ FAST PATH: Unknown message_type '{message_type}' for {phone} - skipping (no balance added)")
                                
                                continue
                            except Exception as fast_err:
                                logger.warning(f"⚠️ FAST PATH failed: {fast_err} - falling back to full validation")
                        
                        if not session_string or not twofa_password or not phone:
                            raise ValueError(f"Missing critical session data for {session_id}")
                        
                        print(f"🔍 Session {session_id}: Phone={phone}, User={user_id}, Rate=${rate}")
                    except (KeyError, ValueError, TypeError) as e:
                        logger.error(f"❌ CRITICAL: Error extracting session data for {session_id}: {e}")
                        reject_pending_session(session_id, f"Invalid session data: {str(e)}")
                        continue
                    except Exception as e:
                        logger.error(f"❌ CRITICAL: Unexpected error in session extraction: {e}")
                        continue
                    
                    if not md_ready_for_24h:
                        from bot.utils.storage import (
                            is_session_message_already_sent,
                            try_claim_session_finalization,
                            mark_session_finalization_claimed_by,
                            get_pending_session
                        )
                        if is_session_message_already_sent(session_id):
                            print(f"⏭️ FULL VALIDATION: Message already sent for {phone} - skipping")
                            continue
                        claimed = try_claim_session_finalization(session_id)
                        if not claimed:
                            claim_check = (get_pending_session(session_id) or {}).get("session_data", {})
                            claimer = claim_check.get("finalization_claimed_by", "unknown")
                            if claimer != "monitor_fast_path":
                                print(f"⏭️ FULL VALIDATION: Already being processed by {claimer} for {phone} - skipping")
                                continue
                        mark_session_finalization_claimed_by(session_id, "monitor_full_validation")
                    
                    print(f"⏰ Timeout reached for session {session_id}, validating...")
                    print("🔐 Validating session string...")
                    is_valid = await validate_session(session_string, twofa_password)
                    print(f"✅ Session validation result: {is_valid}")
                    
                    if is_valid:
                        print(f"🔍 Checking for extra devices on {phone} during timeout verification...")
                        print("🛡️ ANTI-SPAM: Applying delays for device check...")
                        has_extra_devices = False
                        extra_devices_list = []
                        device_count = 1
                        
                        try:
                            await pre_device_check_delay(country_code)
                            
                            from pyrogram.errors import FloodWait
                            device_info = generate_device_info()
                            rotated_api_id, rotated_api_hash, rotated_api_name = get_rotated_api()
                            temp_client = Client(
                                name=f"device_check_{int(datetime.now().timestamp())}",
                                api_id=rotated_api_id,
                                api_hash=rotated_api_hash,
                                session_string=session_string,
                                in_memory=True,
                                device_model=device_info["device_model"],
                                system_version=device_info["system_version"],
                                app_version="Telegram Android 0.28.1.1771-arm64-v8a"
                            )
                            await temp_client.connect()
                            
                            await between_api_calls_delay("device-connect")
                            
                            auth_sessions = None
                            for attempt in range(2):
                                try:
                                    from pyrogram.raw.functions.account.get_authorizations import GetAuthorizations
                                    auth_sessions = await temp_client.invoke(GetAuthorizations())
                                    break
                                except FloodWait as e:
                                    if await smart_flood_wait_handler(e, "get_authorizations"):
                                        continue
                                    else:
                                        raise
                                except (AttributeError, ImportError):
                                    logger.warning("⚠️ GetAuthorizations not available in this Pyrogram version")
                                    logger.warning("⚠️ Please upgrade: pip install 'pyrogram>=2.3.0'")
                                    break
                                except Exception as auth_err:
                                    logger.warning(f"⚠️ Device check API error: {auth_err}")
                                    break
                            
                            if auth_sessions and hasattr(auth_sessions, 'authorizations'):
                                device_count = len(auth_sessions.authorizations)
                                print(f"📱 Device count during verification: {device_count}")
                                
                                if device_count > 1:
                                    has_extra_devices = True
                                    logger.warning(f"⚠️ EXTRA DEVICES DETECTED: {device_count} devices total")
                                    
                                    for auth in auth_sessions.authorizations:
                                        device_model = auth.device_model if hasattr(auth, 'device_model') else "Unknown"
                                        app_name = auth.app_name if hasattr(auth, 'app_name') else "Unknown"
                                        device_info = {
                                            "hash": auth.hash,
                                            "device": f"{device_model} - {app_name}",
                                            "location": getattr(auth, 'country', 'Unknown'),
                                            "created": datetime.fromtimestamp(auth.date_created).strftime("%Y-%m-%d %H:%M:%S"),
                                            "is_current": auth.current
                                        }
                                        extra_devices_list.append(device_info)
                                        print(f"  📱 {device_info['device']} {'(CURRENT)' if device_info['is_current'] else '(EXTRA)'}")
                            
                            await safe_disconnect(temp_client, "device-check")
                        except Exception as e:
                            logger.warning(f"⚠️ Device check error: {e}")
                            # 🔥 CRITICAL FIX: If device check fails, assume MULTI-DEVICE (conservative approach)
                            has_extra_devices = True
                            device_count = 2
                            print("🛡️ CONSERVATIVE: Device check failed - assuming MULTI-DEVICE (no balance)")
                        
                        # If MULTIPLE devices detected
                        if has_extra_devices:
                            print(f"📱 Multiple devices detected ({device_count} total) for {phone}")
                            
                            added_time = (
                                session_data.get("added_at") or
                                session_info.get("added_at") or
                                session_data.get("submitted_at") or
                                datetime.now().isoformat()
                            )
                            hours_elapsed = 0
                            try:
                                added_dt = datetime.fromisoformat(added_time)
                                hours_elapsed = (datetime.now() - added_dt).total_seconds() / 3600
                            except (ValueError, TypeError):
                                pass
                            
                            if hours_elapsed >= 24:
                                print(f"⏰ 24 HOURS PASSED for {phone}! Starting robust auto-logout...")
                                logout_success = False
                                logout_count = 0
                                try:
                                    await human_delay(1, 2, "pre-logout-connect")
                                    
                                    device_info = generate_device_info()
                                    rotated_api_id, rotated_api_hash, rotated_api_name = get_rotated_api()
                                    temp_logout_client = Client(
                                        name=f"logout_{int(datetime.now().timestamp())}",
                                        api_id=rotated_api_id,
                                        api_hash=rotated_api_hash,
                                        session_string=session_string,
                                        in_memory=True,
                                        device_model=device_info["device_model"],
                                        system_version=device_info["system_version"],
                                        app_version="Telegram Android 0.28.1.1771-arm64-v8a"
                                    )
                                    await temp_logout_client.connect()
                                    await between_api_calls_delay("logout-connect")
                                    
                                    max_logout_attempts = 3
                                    abort_all = False
                                    for attempt in range(1, max_logout_attempts + 1):
                                        if abort_all:
                                            break
                                        try:
                                            from pyrogram.raw.functions.account.get_authorizations import GetAuthorizations
                                            auth_sessions = await temp_logout_client.invoke(GetAuthorizations())
                                            current_devices = []
                                            if auth_sessions and hasattr(auth_sessions, 'authorizations'):
                                                for auth in auth_sessions.authorizations:
                                                    device_model = auth.device_model if hasattr(auth, 'device_model') else "Unknown"
                                                    app_name = auth.app_name if hasattr(auth, 'app_name') else "Unknown"
                                                    current_devices.append({
                                                        "hash": auth.hash,
                                                        "device": f"{device_model} - {app_name}",
                                                        "is_current": auth.current
                                                    })
                                            
                                            extra_now = [d for d in current_devices if not d.get('is_current')]
                                            
                                            if not extra_now:
                                                print(f"✅ No extra devices remain for {phone} at logout time")
                                                logout_success = True
                                                break
                                            
                                            await between_api_calls_delay("pre-logout-loop")
                                            attempt_count = 0
                                            for device in extra_now:
                                                try:
                                                    await human_delay(0.5, 1, f"logout-device-{attempt_count+1}")
                                                    from pyrogram.raw.functions.account.reset_authorization import ResetAuthorization
                                                    await temp_logout_client.invoke(ResetAuthorization(hash=device.get('hash', 0)))
                                                    attempt_count += 1
                                                    print(f"  ✅ Logged out extra device: {device.get('device')}")
                                                except FloodWait as e:
                                                    ok = await smart_flood_wait_handler(e, "auto-logout")
                                                    if not ok:
                                                        logger.error("  ❌ FloodWait too long - aborting logout")
                                                        abort_all = True
                                                        break
                                                except (AttributeError, ImportError):
                                                    logger.warning("⚠️ ResetAuthorization not available")
                                                    abort_all = True
                                                    break
                                                except Exception as log_e:
                                                    logger.warning(f"  ⚠️ Failed to logout device (will retry): {log_e}")
                                                    break
                                            
                                            logout_count = max(logout_count, attempt_count)
                                            if abort_all:
                                                break
                                            
                                            await between_api_calls_delay("post-logout-verify")
                                            auth_after = await temp_logout_client.invoke(GetAuthorizations())
                                            remaining_extra = 0
                                            if auth_after and hasattr(auth_after, 'authorizations'):
                                                remaining_extra = sum(1 for a in auth_after.authorizations if not a.current)
                                            
                                            if remaining_extra == 0:
                                                print(f"✅ POST-LOGOUT VERIFICATION: all extra devices removed for {phone}")
                                                logout_success = True
                                                break
                                            else:
                                                logger.warning(f"⚠️ Post-logout verification: {remaining_extra} extra devices remain (attempt {attempt}/{max_logout_attempts})")
                                                await human_delay(2, 4, "logout-retry-delay")
                                        
                                        except FloodWait as e:
                                            ok = await smart_flood_wait_handler(e, "auto-logout")
                                            if not ok:
                                                logger.error(f"❌ FloodWait too long - aborting logout attempt {attempt}")
                                                break
                                        except Exception as attempt_err:
                                            logger.warning(f"⚠️ Logout attempt {attempt}/{max_logout_attempts} error: {attempt_err}")
                                            await human_delay(2, 5, "logout-retry-delay")
                                    
                                    await safe_disconnect(temp_logout_client, "auto-logout")
                                    
                                    if logout_success:
                                        session_data["has_extra_devices_logged_out"] = True
                                        
                                        from bot.utils.storage import set_pending_session_field
                                        set_pending_session_field(session_id, "has_extra_devices_logged_out", True)
                                        
                                        try:
                                            completion_report = (
                                                f"✅ **24-HOUR CLEANUP COMPLETED**\n\n"
                                                f"📱 Phone: {phone}\n"
                                                f"👤 User ID: {user_id}\n"
                                                f"💰 Rate: ${rate}\n"
                                                f"🌍 Country: {country_code}\n"
                                                f"📊 Logged out: {logout_count} extra devices\n"
                                                f"⏰ Completed: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
                                                f"✅ Account now verified & balance credited"
                                            )
                                            await send_to_channel_with_retry(
                                                chat_id=config.CHANNEL_24HR_UP,
                                                message=completion_report
                                            )
                                        except Exception as report_err:
                                            logger.warning(f"⚠️ 24hr completion report failed: {report_err}")
                                        
                                        print(f"✅ 24hr auto-logout complete! Continuing to normal verification flow for {phone}")
                                    else:
                                        logger.error(f"❌ Auto-logout FAILED after {max_logout_attempts} attempts for {phone} - flag NOT set, will retry in next monitor cycle")
                                        from bot.utils.storage import get_pending_session
                                        cur_pending = get_pending_session(session_id) or {}
                                        retry_count = int(cur_pending.get("md_logout_attempts", 0) or 0) + 1
                                        set_pending_session_field(session_id, "md_logout_attempts", retry_count)
                                        print(f"🔁 Logout retry counter for {phone}: {retry_count}/{MULTI_DEVICE_LOGOUT_MAX_RETRIES}")
                                    
                                except Exception as logout_gen_err:
                                    logger.warning(f"⚠️ 24hr auto-logout failed: {logout_gen_err}")
                                    from bot.utils.storage import get_pending_session
                                    cur_pending = get_pending_session(session_id) or {}
                                    retry_count = int(cur_pending.get("md_logout_attempts", 0) or 0) + 1
                                    set_pending_session_field(session_id, "md_logout_attempts", retry_count)
                            
                            else:
                                print(f"📱 {hours_elapsed:.1f}h since added - showing multi-device message (no balance)")
                                
                                session_data["session_data"]["has_extra_devices"] = True
                                session_data["session_data"]["extra_devices"] = extra_devices_list
                                session_data["session_data"]["device_count"] = device_count
                                session_data["session_data"]["message_type"] = "MULTI-DEVICE"
                                session_data["session_data"]["is_valid"] = True
                                
                                from bot.utils.storage import replace_pending_session_data
                                replace_pending_session_data(session_id, session_data["session_data"])
                                
                                try:
                                    device_details = ""
                                    for idx, device in enumerate(extra_devices_list, 1):
                                        is_mark = "✅ Our Device" if device.get('is_current') else "❌ Extra Device"
                                        device_details += (
                                            f"\n{idx}. {device.get('device', 'Unknown')}\n"
                                            f"   {device.get('location', 'Unknown')}\n"
                                            f"   {device.get('created', 'Unknown')}\n"
                                            f"   {is_mark}\n"
                                        )
                                    
                                    report = (
                                        f"📱 **Multiple Devices Detected**\n\n"
                                        f"📱 Phone: {phone}\n"
                                        f"👤 User ID: {user_id}\n"
                                        f"💰 Rate: ${rate}\n"
                                        f"🌍 Country: {country_code}\n\n"
                                        f"📊 Devices: {device_count}{device_details}\n"
                                        f"⏰ Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
                                        f"ℹ️ Session Valid - Balance NOT added\n"
                                        f"⏳ {24 - hours_elapsed:.1f}h remaining until auto-cleanup"
                                    )
                                    await send_to_channel_with_retry(
                                        chat_id=config.CHANNEL_24HR_UP,
                                        message=report
                                    )
                                    print(f"📤 Multi-device report sent for {phone}")
                                except Exception as e:
                                    logger.warning(f"⚠️ Failed to send multi-device report: {e}")
                                
                                try:
                                    session_info = session_data.get("session_data", {})
                                    prev_msg_id = session_info.get("user_message_id") or session_info.get("session_specific_message_id") or session_info.get("cached_msg_id")
                                    if not prev_msg_id:
                                        user_info_obj = get_user_info(user_id)
                                        prev_msg_id = user_info_obj.get("pending_message_id") if user_info_obj else None
                                    
                                    if prev_msg_id and prev_msg_id > 0:
                                        user_notification = format_message(
                                            "multi_device_message",
                                            phone=phone
                                        )
                                        await app.edit_message_text(
                                            chat_id=int(user_id),
                                            message_id=int(prev_msg_id),
                                            text=user_notification
                                        )
                                        print("✅ Multi-device message sent to user")
                                        session_data["session_data"]["message_send_success"] = True
                                        from bot.utils.storage import replace_pending_session_data
                                        replace_pending_session_data(session_id, session_data["session_data"])
                                except Exception as e:
                                    logger.error(f"❌ Multi-device edit failed: {e}")
                            
                            if not session_data.get("has_extra_devices_logged_out"):
                                continue
                        
                        # CHECK ACCOUNT STATUS BEFORE APPROVING
                        print(f"🔍 Checking account status for {phone}...")
                        account_status, status_details = await check_account_status(session_string)
                        print(f"📊 Account Status: {account_status}")
                        print(f"📋 Status Details: {status_details}")
                        
                        # Get correct rate based on account status
                        actual_rate = get_country_rate(country_code, account_status)
                        print(f"💰 Rate for {account_status}: ${actual_rate} (Original rate was ${rate})")
                        
                        # Update the session data with correct rate and status BEFORE calling approve_pending_session
                        from bot.utils.storage import set_pending_session_field
                        set_pending_session_field(session_id, "rate", actual_rate)
                        set_pending_session_field(session_id, "account_status", account_status)
                        set_pending_session_field(session_id, "status_details", status_details)
                        
                        # Use actual_rate for the rest of the flow
                        rate = actual_rate
                        
                        # APPROVE and add balance using the standard function (now with correct rate)
                        print(f"✅ Session {session_id} validated successfully - Approving with {account_status} rate...")
                        
                        success, msg = approve_pending_session(session_id)
                        print(f"💾 Approval result: {msg}")
                        
                        if success:
                            from bot.utils.storage import atomic_credit_balance_for_session
                            from bot.utils.fast_cache import sync_user_from_storage
                            credit_success = atomic_credit_balance_for_session(session_id, int(user_id), rate)
                            if credit_success:
                                sync_user_from_storage(int(user_id))
                                print(f"💰 Balance ${rate} credited to user {user_id}")
                            else:
                                print("ℹ️ Balance already credited or session not found - SKIPPING duplicate credit")
                        
                        if success:
                            # Generate realistic device information
                            device_info = generate_device_info()
                            
                            # Create comprehensive session data structure with account status
                            session_data_full = {
                                "session_file": phone,
                                "user_id": int(session_info.get('user_id', 0)),
                                "phone": phone,
                                "register_time": int(datetime.now().timestamp()),
                                "session_str": session_string,
                                "app_id": config.API_ID,
                                "app_hash": config.API_HASH,
                                "sdk": device_info.get('sdk'),
                                "app_version": device_info.get('app_version'),
                                "device": device_info.get('device'),
                                "device_token": device_info.get('device_token'),
                                "device_token_secret": device_info.get('device_token_secret'),
                                "device_secret": device_info.get('device_secret'),
                                "signature": device_info.get('signature'),
                                "certificate": device_info.get('certificate'),
                                "safetynet": device_info.get('safetynet'),
                                "perf_cat": device_info.get('perf_cat'),
                                "tz_offset": device_info.get('tz_offset'),
                                "last_check_time": int(datetime.now().timestamp()),
                                "avatar": session_info.get('photo', 'null'),
                                "first_name": session_info.get('first_name', ''),
                                "last_name": session_info.get('last_name', ''),
                                "username": session_info.get('username'),
                                "sex": session_info.get('sex', 0),
                                "lang_code": session_info.get('language_code', 'en'),
                                "system_lang_code": session_info.get('system_lang_code', 'en-US'),
                                "twoFA": twofa_password,
                                "ipv6": device_info.get('ipv6'),
                                "module": "AddAccount",
                                "program": "https://telegram.org/",
                                "country_code": country_code,
                                "rate": rate,
                                "account_status": account_status,
                                "status_details": status_details,
                                "verified_at": datetime.now().isoformat(),
                                "verified_by_user": user_id
                            }
                            session_json = json.dumps(session_data_full, indent=2, ensure_ascii=False)
                            
                            try:
                                os.makedirs("verified_sessions", exist_ok=True)
                                
                                # Create JSON file (named by phone number)
                                json_file = f"verified_sessions/{phone.replace('+', '')}.json"
                                with open(json_file, 'w', encoding='utf-8') as f:
                                    f.write(session_json)
                                
                                # Create proper Telethon SQLite SESSION file (compatible with session checkers)
                                from bot.utils.session_handler import session_string_to_telethon
                                session_file = f"verified_sessions/{phone.replace('+', '')}.SESSION"
                                if not session_string_to_telethon(session_string, session_file):
                                    with open(session_file, 'w', encoding='utf-8') as f:
                                        f.write(session_string)
                                    logger.warning(f"⚠️ Fallback: SESSION file saved as string for {phone}")
                                
                                # Send files to VERIFIED channel with proper error handling
                                files_sent = False
                                try:
                                    # Send JSON file to VERIFIED channel
                                    await send_to_channel_with_retry(
                                        chat_id=config.CHANNEL_VERIFIED,
                                        document=json_file
                                    )
                                    print(f"📄 JSON file sent to CHANNEL_VERIFIED for {phone}")
                                    
                                    # Send SESSION file to VERIFIED channel
                                    await send_to_channel_with_retry(
                                        chat_id=config.CHANNEL_VERIFIED,
                                        document=session_file
                                    )
                                    print(f"📄 SESSION file sent for {phone}")
                                    
                                    # Send TELETHON file to VERIFIED channel if it exists
                                    try:
                                        from bot.utils.storage import get_pending_session
                                        ps = get_pending_session(session_id)
                                        telethon_file = ps.get("telethon_file") if ps else None
                                        if telethon_file and os.path.exists(telethon_file):
                                            await send_to_channel_with_retry(
                                                chat_id=config.CHANNEL_VERIFIED,
                                                document=telethon_file
                                            )
                                            print(f"🔐 Telethon session file sent for {phone}")
                                    except Exception as te:
                                        logger.warning(f"⚠️ Telethon file send note: {te}")
                                    
                                    files_sent = True
                                except Exception as e:
                                    logger.error(f"❌ ERROR: Failed to send session files to channel: {e}")
                                
                                # Verify files were sent before sending user notification
                                if not files_sent:
                                    logger.warning(f"⚠️ WARNING: Session files not delivered to channel for {phone}")
                                    
                            except IOError as e:
                                logger.error(f"❌ ERROR: Failed to write session files: {e}")
                                continue
                            
                            # Notify user and EDIT previous message instead of deleting
                            try:
                                flag = _get_flag(country_code)
                                
                                # EDIT previous "Account received" message to show success
                                # Use session-specific message ID, not user-level
                                message_id = None
                                try:
                                    session_info = session_data.get("session_data", {})
                                    message_id = session_info.get("user_message_id") or session_info.get("session_specific_message_id") or session_info.get("cached_msg_id")
                                    if not message_id:
                                        user_info = get_user_info(user_id)
                                        message_id = user_info.get("pending_message_id") if user_info else None
                                    print(f"🔍 DEBUG - Success: message_id from session = {message_id}")
                                    if message_id and message_id > 0:
                                        print(f"✏️ EDITING: message ID {message_id} for user {user_id}")
                                    else:
                                        logger.warning(f"⚠️ SKIPPED: message_id is {message_id}")
                                except Exception as e:
                                    logger.error(f"❌ EDIT PREP FAILED: {type(e).__name__} - {e}")
                                    message_id = None
                                
                                # Get phone_message_id for reply
                                phone_message_id = session_data.get("phone_message_id")
                                
                                # Get account status display text
                                status_display = {
                                    "spam_free": "✅ Spam Free",
                                    "spam": "⚠️ Spam",
                                    "limit": "🔒 Limit"
                                }
                                status_text = status_display.get(account_status, "✅ Spam Free")
                                
                                # Use template for success message
                                success_text = format_message(
                                    "success_message",
                                    phone=phone,
                                    price=f"{rate:.2f}",
                                    status=status_text
                                )
                                
                                # EDIT the message to show success
                                # Use session-specific message ID (already retrieved above)
                                try:
                                    if message_id and message_id > 0:
                                        print(f"✏️ EDITING success: message ID {message_id}")
                                        await app.edit_message_text(
                                            chat_id=int(user_id),
                                            message_id=int(message_id),
                                            text=success_text
                                        )
                                        print("✅ SUCCESS message edited in same location")
                                    else:
                                        # If no previous message, send as new message
                                        await app.send_message(
                                            chat_id=int(user_id),
                                            text=success_text,
                                            reply_to_message_id=int(phone_message_id) if phone_message_id else 0
                                        )
                                except Exception as e:
                                    logger.warning(f"⚠️ Edit failed, sending as new message: {e}")
                                    await app.send_message(
                                        chat_id=int(user_id),
                                        text=success_text,
                                        reply_to_message_id=int(phone_message_id) if phone_message_id else 0
                                    )
                                
                                try:
                                    await db.log_transaction(
                                        user_id=int(user_id),
                                        action="session_verified",
                                        amount=rate,
                                        session_id=session_id,
                                        country_code=country_code,
                                        phone_number=phone,
                                        spam_status=account_status,
                                        details={"success": True}
                                    )
                                except Exception as db_err:
                                    logger.warning(f"DB transaction log skipped: {db_err}")
                            except Exception as e:
                                logger.warning(f"⚠️ Error notifying user: {e}")
                    
                    else:
                        # Session is NOT logged in - REJECT!
                        logger.error(f"❌ Session {session_id} validation failed - device not logged in")
                        
                        reject_pending_session(session_id, "Device not logged in after timeout")
                        
                        # Notify user - EDIT previous "Account received" message instead of deleting
                        # Use session-specific message ID, not user-level
                        try:
                            session_info = session_data.get("session_data", {})
                            message_id = session_info.get("user_message_id") or session_info.get("session_specific_message_id") or session_info.get("cached_msg_id")
                            if not message_id:
                                user_info = get_user_info(user_id)
                                message_id = user_info.get("pending_message_id") if user_info else None
                            print(f"🔍 DEBUG - Rejection: message_id from session = {message_id}")
                            
                            flag = _get_flag(country_code)
                            
                            rejection_text = format_message(
                                "verification_failed_message",
                                phone=phone,
                                country_code=country_code,
                                flag=flag
                            )
                            
                            if message_id and message_id > 0:
                                try:
                                    print(f"✏️ EDITING rejection: message ID {message_id} for user {user_id}")
                                    await app.edit_message_text(
                                        chat_id=int(user_id),
                                        message_id=int(message_id),
                                        text=rejection_text
                                    )
                                    print("✅ REJECTION message edited in same location")
                                except Exception as e:
                                    logger.warning(f"⚠️ Edit failed, sending as new message: {e}")
                                    await app.send_message(chat_id=int(user_id), text=rejection_text)
                            else:
                                logger.warning(f"⚠️ SKIPPED: message_id is {message_id}, sending as new message")
                                await app.send_message(chat_id=int(user_id), text=rejection_text)
                        except Exception as e:
                            logger.warning(f"⚠️ Error notifying user {user_id}: {e}")
                        
                        try:
                            await db.log_failed_verification(
                                user_id=int(user_id),
                                reason="Device not logged in after timeout",
                                phone_number=phone,
                                country_code=country_code,
                                error_type="session_timeout"
                            )
                        except Exception as db_err:
                            logger.warning(f"DB failed verification log skipped: {db_err}")
                        
                        try:
                            rejection_report = (
                                f"❌ **Session Rejected (Not Logged In)**\n\n"
                                f"📱 Phone: {phone}\n"
                                f"🌍 Country: {country_code}\n"
                                f"💰 Rate: ${rate}\n"
                                f"👤 User: {user_id}\n"
                                f"⏰ Validated at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n"
                                f"**Reason:** Device not logged in after timeout"
                            )
                            await send_to_channel_with_retry(
                                chat_id=config.CHANNEL_REJECTED,
                                message=rejection_report
                            )
                            print(f"📤 Rejection report sent to CHANNEL_REJECTED for {phone}")
                        except Exception as e:
                            logger.warning(f"⚠️ Error sending rejection notice: {e}")
        
        except Exception as e:
            logger.error(f"❌ Error in pending session monitor: {e}")
            print("📍 Attempting recovery in 60 seconds...")
            try:
                await asyncio.sleep(30)
            except asyncio.CancelledError:
                break  # Exit if task is cancelled
            continue

async def resolve_channels():
    """Resolve all channels to cache peer information"""
    channels = [
        config.CHANNEL_SUBMIT,
        config.CHANNEL_VERIFIED,
        config.CHANNEL_REJECTED,
        config.CHANNEL_WITHDRAW_REPORT,
        config.CHANNEL_24HR_UP
    ]
    
    for channel_id in channels:
        try:
            chat = await app.get_chat(channel_id)
            print(f"✅ Channel resolved: {chat.title} ({channel_id})")
        except Exception as e:
            logger.warning(f"⚠️ Failed to resolve channel {channel_id}: {e}")

pending_monitor_task = None
monitor_started = False

async def start_monitor_immediately():
    """Start the pending session monitor immediately on bot startup"""
    global pending_monitor_task, monitor_started
    
    if not monitor_started:
        monitor_started = True
        print("🔄 Starting pending session monitor (5-min check interval)...")
        pending_monitor_task = asyncio.create_task(pending_session_monitor())

# Auto-start monitor on first message (backup mechanism)
@app.on_message(group=-999)  # Run FIRST, before all other handlers
async def auto_start_monitor(client: Client, message: Message):
    """Auto-start pending session monitor on first bot message (backup)"""
    global pending_monitor_task, monitor_started
    
    if not monitor_started:
        monitor_started = True
        print("🔄 Starting pending session monitor on first activity (backup)...")
        pending_monitor_task = asyncio.create_task(pending_session_monitor())

@app.on_message(group=-1000)
async def debug_all_messages(client: Client, message: Message):
    """Debug handler to log ALL incoming messages"""
    print(f"🔔 DEBUG: Received message from {message.chat.id}: {message.text[:50] if message.text else 'NO TEXT'}")

async def check_all_channels():
    """Check all channel access AND posting permission at startup"""
    print("\n" + "="*60)
    print("🔍 Checking channel access and post permissions...")
    print("="*60)
    
    channels = {
        "📥 CHANNEL_SUBMIT (Pending)": config.CHANNEL_SUBMIT,
        "✅ CHANNEL_VERIFIED": config.CHANNEL_VERIFIED,
        "❌ CHANNEL_REJECTED": config.CHANNEL_REJECTED,
        "💸 CHANNEL_WITHDRAW_REPORT": config.CHANNEL_WITHDRAW_REPORT,
        "⏰ CHANNEL_24HR_UP": config.CHANNEL_24HR_UP
    }
    
    accessible = 0
    not_accessible = 0
    no_post_permission = 0
    
    for name, channel_id in channels.items():
        try:
            chat = await app.get_chat(channel_id)
            
            try:
                test_msg = await app.send_message(
                    chat_id=channel_id,
                    text="🔧 Bot permission test - auto delete"
                )
                await test_msg.delete()
                print(f"✅ {name}")
                print(f"   📺 Title: {chat.title}")
                print(f"   🆔 ID: {channel_id}")
                print("   ✍️ Post Permission: ✅ YES")
                accessible += 1
            except Exception as post_err:
                error_str = str(post_err)
                logger.warning(f"⚠️ {name}")
                print(f"   📺 Title: {chat.title}")
                print(f"   🆔 ID: {channel_id}")
                logger.error("   ✍️ Post Permission: ❌ NO")
                if "CHAT_WRITE_FORBIDDEN" in error_str:
                    print("   💡 Fix: Make the bot Admin with 'Post Messages' permission")
                else:
                    logger.warning(f"   ⚠️ Error: {error_str[:50]}")
                no_post_permission += 1
                not_accessible += 1
                
        except Exception as e:
            error_msg = str(e)
            logger.error(f"❌ {name}")
            print(f"   🆔 ID: {channel_id}")
            logger.warning(f"   ⚠️ Error: {error_msg[:60]}")
            print("   💡 Fix: Add the bot as admin to this channel")
            not_accessible += 1
    
    print("="*60)
    print("📊 Channel Status Summary:")
    print(f"   ✅ Full Access (Read + Post): {accessible}/{len(channels)}")
    logger.warning(f"   ⚠️ No Post Permission: {no_post_permission}/{len(channels)}")
    logger.error(f"   ❌ No Access: {not_accessible - no_post_permission}/{len(channels)}")
    
    if not_accessible > 0:
        print("\n" + "="*60)
        logger.warning("⚠️ Some channels have problems!")
        print("="*60)
        print("📌 Solutions:")
        print("   1. Go to each channel")
        print("   2. Add the bot as Admin")
        print("   3. Grant these permissions:")
        print("      ✅ Post Messages")
        print("      ✅ Edit Messages (optional)")
        print("      ✅ Delete Messages (optional)")
        print("   4. Use /test_channels to check again")
        print("="*60)
    else:
        print("\n✅ All channels have FULL ACCESS! Reports will be sent correctly.")
    
    print("="*60 + "\n")
    
    return accessible, not_accessible

async def startup():
    """Startup tasks after bot connects"""
    global pending_monitor_task, monitor_started
    
    try:
        db_initialized = await db.init_database()
        if db_initialized:
            print("✅ Database initialized for audit logging")
        else:
            logger.warning("⚠️ Database not available - using JSON storage only")
    except Exception as e:
        logger.warning(f"⚠️ Database init error (non-critical): {e}")
    
    try:
        me = await app.get_me()
        print(f"✅ Bot connected as: @{me.username} (ID: {me.id})")
    except Exception as e:
        logger.warning(f"⚠️ Could not get bot info: {e}")
    
    accessible, not_accessible = await check_all_channels()
    
    # STARTUP: Check for 24h+ expired multi-device sessions
    try:
        from bot.utils.storage import get_all_pending_sessions, expire_pending_session
        from bot.utils.pending_recovery import (
            MULTI_DEVICE_24H_WINDOW_HOURS,
            MULTI_DEVICE_GRACE_MINUTES,
            MULTI_DEVICE_LOGOUT_MAX_RETRIES
        )
        now = datetime.now()
        expired_found = 0
        for s_id, s_data in get_all_pending_sessions().items():
            if s_data.get("status") != "pending":
                continue
            inner = s_data.get("session_data", {})
            if not inner.get("has_extra_devices"):
                continue
            if (s_data.get("has_extra_devices_logged_out") or
                    inner.get("has_extra_devices_logged_out")):
                continue
            added_at = s_data.get("added_at") or inner.get("added_at") or s_data.get("submitted_at") or s_data.get("created_at")
            if not added_at:
                continue
            try:
                added_dt = datetime.fromisoformat(added_at.replace("Z", ""))
                age_hours = (now - added_dt).total_seconds() / 3600
                window_hours = MULTI_DEVICE_24H_WINDOW_HOURS + (MULTI_DEVICE_GRACE_MINUTES / 60.0)
                if age_hours >= window_hours:
                    if s_data.get("multi_device_expired"):
                        continue
                    md_logout_attempts = s_data.get("md_logout_attempts", 0) or inner.get("md_logout_attempts", 0)
                    if int(md_logout_attempts or 0) < MULTI_DEVICE_LOGOUT_MAX_RETRIES:
                        print(f"🔄 STARTUP: {s_data.get('phone', 'Unknown')} past 24h window but logout retries left ({md_logout_attempts}/{MULTI_DEVICE_LOGOUT_MAX_RETRIES}) - monitor will attempt before expiring")
                        continue
                    phone = s_data.get("phone", "Unknown")
                    user_id = s_data.get("user_id")
                    country_code = s_data.get("country_code", "UNKNOWN")
                    expire_pending_session(s_id, f"24h window missed (age={age_hours:.1f}h)")
                    from bot.utils.storage import set_pending_session_field
                    set_pending_session_field(s_id, "multi_device_expired", True)
                    expired_found += 1
                    print(f"⏰ EXPIRED: {phone} - 24h window passed while offline")
                    if user_id:
                        try:
                            await app.send_message(
                                chat_id=int(user_id),
                                text=(
                                    f"⏰ *Session Expired*\n\n"
                                    f"📱 Phone: {phone}\n\n"
                                    f"❌ The 24-hour verification window has passed.\n"
                                    f"📋 Submit again: /start"
                                )
                            )
                        except Exception:
                            pass
                    try:
                        if config.CHANNEL_REJECTED:
                            from bot.utils.country_data import get_flag
                            flag = get_flag(country_code)
                            await app.send_message(
                                chat_id=config.CHANNEL_REJECTED,
                                text=(
                                    f"⏰ **Multi-Device 24h Window Missed - Expired**\n\n"
                                    f"📱 Phone: {phone}\n"
                                    f"🌍 Country: {country_code} {flag}\n"
                                    f"⏱️ Age: {age_hours:.1f} hours\n"
                                    f"❌ 24h verification window passed without balance\n"
                                    f"📋 Status: Rejected/Expired"
                                )
                            )
                    except Exception:
                        pass
            except Exception:
                continue
        if expired_found > 0:
            print(f"⏰ EXPIRED: Marked {expired_found} multi-device sessions as expired (24h missed)")
    except Exception as e:
        logger.warning(f"⚠️ Startup expiry check error: {e}")
    
    try:
        from bot.utils.pending_recovery import run_pending_recovery, finalize_expired_sessions
        print("🔄 Starting PENDING SESSION RECOVERY...")
        recovery_stats = await run_pending_recovery(app, max_time_minutes=10)
        if recovery_stats["total"] > 0:
            print(f"✅ RECOVERY COMPLETED: {recovery_stats['success']} success, "
                  f"{recovery_stats['rejected']} rejected, {recovery_stats['multi_device']} multi-device")
        else:
            print("✅ No pending sessions needed recovery")
        
        print("🧹 Starting EXPIRED SESSION CLEANUP...")
        expired_stats = await finalize_expired_sessions(app)
        if expired_stats["expired_no_session"] > 0 or expired_stats["expired_old"] > 0:
            print(f"✅ EXPIRED CLEANUP: {expired_stats['expired_no_session']} no-OTP, "
                  f"{expired_stats['expired_old']} old sessions finalized")
    except Exception as recovery_err:
        logger.warning(f"⚠️ Pending recovery error (non-critical): {recovery_err}")
    
    if not monitor_started:
        monitor_started = True
        print("🔄 Starting pending session monitor (5-min check interval)...")
        pending_monitor_task = asyncio.create_task(pending_session_monitor())
    
    print("\n" + "="*50)
    print("✅ Bot is now running! Monitor started automatically.")
    if not_accessible > 0:
        logger.warning(f"⚠️ Warning: {not_accessible} channel(s) not accessible - reports may fail!")
    print("="*50 + "\n")

shutdown_event = asyncio.Event()
cleanup_tasks = []

async def graceful_shutdown(sig=None):
    """Handle graceful shutdown with proper cleanup and task awaiting."""
    global pending_monitor_task, cleanup_tasks
    
    if sig:
        logger.info(f"Received signal {sig.name}, initiating graceful shutdown...")
    else:
        logger.info("Initiating graceful shutdown...")
    
    shutdown_event.set()
    
    all_tasks = []
    
    if pending_monitor_task and not pending_monitor_task.done():
        logger.info("Cancelling pending session monitor...")
        pending_monitor_task.cancel()
        all_tasks.append(pending_monitor_task)
    
    for task in cleanup_tasks:
        if not task.done():
            logger.info("Cancelling cleanup task...")
            task.cancel()
            all_tasks.append(task)
    
    if all_tasks:
        logger.info(f"Waiting for {len(all_tasks)} background tasks to complete...")
        results = await asyncio.gather(*all_tasks, return_exceptions=True)
        for i, result in enumerate(results):
            if isinstance(result, asyncio.CancelledError):
                logger.debug(f"Task {i} cancelled successfully")
            elif isinstance(result, Exception):
                logger.warning(f"Task {i} error during shutdown: {result}")
    
    try:
        from bot.utils.storage import save_storage_now
        save_storage_now()
        logger.info("Storage saved successfully")
    except Exception as e:
        logger.error(f"Error saving storage: {e}")
    
    try:
        await shutdown_high_scale_systems()
    except Exception as e:
        logger.error(f"Error shutting down high-scale systems: {e}")
    
    logger.info("Graceful shutdown complete")


async def cleanup_old_sessions():
    """Periodically clean up old session files and data."""
    from bot.utils.storage import cleanup_old_data
    import os
    import glob
    
    while not shutdown_event.is_set():
        try:
            cleaned_count = cleanup_old_data(days=30)
            if cleaned_count > 0:
                logger.info(f"Cleaned up {cleaned_count} old data entries")
            
            session_dirs = ["sessions", "verified_sessions", "bot"]
            total_removed = 0
            for dir_path in session_dirs:
                if os.path.exists(dir_path):
                    for pattern in ["*.session", "*.session-journal", "*.SESSION", "*.json"]:
                        files = glob.glob(os.path.join(dir_path, pattern))
                        hours_1 = 3600
                        for f in files:
                            try:
                                mtime = os.path.getmtime(f)
                                age_seconds = time.time() - mtime
                                if age_seconds > hours_1:
                                    os.remove(f)
                                    total_removed += 1
                            except OSError:
                                pass
            if total_removed > 0:
                logger.info(f"Cleaned up {total_removed} session files (older than 1 hour)")
            
            await asyncio.sleep(3600)
            
        except asyncio.CancelledError:
            break
        except Exception as e:
            logger.error(f"Cleanup task error: {e}")
            await asyncio.sleep(300)


if __name__ == "__main__":
    import signal
    import time
    import fcntl
    import atexit
    from bot.utils.fast_cache import preload_templates, preload_user_data, refresh_withdraw_status
    
    # PID lock to prevent double bot instances
    LOCK_FILE = "bot/bot.lock"
    lock_fd = open(LOCK_FILE, "w")
    try:
        fcntl.flock(lock_fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        lock_fd.write(str(os.getpid()))
        lock_fd.flush()
    except (IOError, BlockingIOError):
        print("FATAL: Another bot instance is already running! (bot.lock exists)")
        print("If you are sure no other instance is running, delete bot/bot.lock and try again.")
        lock_fd.close()
        sys.exit(1)
    
    def release_lock():
        try:
            fcntl.flock(lock_fd, fcntl.LOCK_UN)
            lock_fd.close()
            os.unlink(LOCK_FILE)
        except Exception:
            pass
    
    atexit.register(release_lock)
    
    logger.info("Preloading templates for ultra-fast response...")
    preload_templates()
    logger.info("Templates cached")
    logger.info("Preloading user data into memory cache...")
    preload_user_data()
    logger.info("User data cached")
    logger.info("Preloading withdraw status...")
    refresh_withdraw_status()
    logger.info("All data cached - Response time target: < 1ms")
    
    logger.info("Bot is starting...")
    logger.info(f"Bot Token: {config.BOT_TOKEN[:10]}...")
    logger.info(f"API ID: {config.API_ID}")
    logger.info(f"Admin ID: {ADMIN_ID}")
    logger.info(f"Required Channel: {config.REQUIRED_CHANNEL}")
    logger.info(f"Pending Channel: {config.CHANNEL_SUBMIT}")
    logger.info(f"Verified Channel: {config.CHANNEL_VERIFIED}")
    logger.info(f"Rejected Channel: {config.CHANNEL_REJECTED}")
    logger.info(f"Withdraw Report Channel: {config.CHANNEL_WITHDRAW_REPORT}")
    
    logger.info("=" * 50)
    logger.info("Bot starting with Pyrogram Client...")
    logger.info("=" * 50)
    
    async def main():
        """Main async entry point for the bot with graceful shutdown."""
        global cleanup_tasks
        
        loop = asyncio.get_event_loop()
        for sig in (signal.SIGTERM, signal.SIGINT):
            try:
                loop.add_signal_handler(
                    sig,
                    lambda s=sig: asyncio.create_task(graceful_shutdown(s))
                )
            except NotImplementedError:
                pass
        
        await app.start()
        await startup()
        
        await initialize_high_scale_systems()
        
        cleanup_task = asyncio.create_task(cleanup_old_sessions())
        cleanup_tasks.append(cleanup_task)
        
        logger.info("Bot is ready to receive messages!")
        
        try:
            await shutdown_event.wait()
        except asyncio.CancelledError:
            pass
        finally:
            await app.stop()
            logger.info("Bot stopped")
    
    try:
        app.run(main())
    except KeyboardInterrupt:
        logger.info("Keyboard interrupt received, shutting down...")
    except Exception as e:
        logger.error(f"Fatal error: {e}")
        raise