#!/usr/bin/env python3
"""Health check script to ensure bot is running"""
import time
import sys

def check_bot_health():
    """Check if bot is healthy and running"""
    try:
        import sqlite3
        sqlite3.sqlite_version_info
    except (ImportError, AttributeError):
        print("HEALTH FAIL: sqlite3 unavailable")
        return False

    try:
        from pyrogram import __version__
    except ImportError:
        print("HEALTH FAIL: pyrogram unavailable")
        return False

    try:
        from bot.utils.storage import _storage
        if _storage is None:
            print("HEALTH WARN: storage not loaded")
    except Exception:
        print("HEALTH FAIL: storage module import failed")
        return False

    return True

if __name__ == "__main__":
    try:
        while True:
            if check_bot_health():
                time.sleep(300)  # Check every 5 minutes
            else:
                sys.exit(1)
    except KeyboardInterrupt:
        print("🛑 Health check stopped")
        sys.exit(0)
