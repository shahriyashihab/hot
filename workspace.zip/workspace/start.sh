#!/bin/bash
# ===================================================
#  Bot Auto-Start Script
#  VPS / Linux / Replit / 
# ===================================================

# Script location
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

echo "========================================="
echo "  Telegram Session Bot - Starting..."
echo "========================================="

# Auto-load .env if exists
if [ -f ".env" ]; then
    echo "Loading .env file..."
    set -a
    source .env
    set +a
fi

REQUIRED_PYROGRAM_VERSION="2.0.106"

check_and_install_deps() {
    local need_install=false
    
    if ! pip show pyrogram > /dev/null 2>&1; then
        need_install=true
    else
        local installed_version
        installed_version=$(pip show pyrogram 2>/dev/null | grep "^Version:" | awk '{print $2}')
        if [ "$installed_version" != "$REQUIRED_PYROGRAM_VERSION" ]; then
            echo "WARNING: Pyrogram version $installed_version installed, but $REQUIRED_PYROGRAM_VERSION is required!"
            echo "Reinstalling dependencies to fix version mismatch..."
            need_install=true
        fi
    fi
    
    if [ "$need_install" = true ]; then
        echo "Installing dependencies..."
        pip install -r requirements.txt --break-system-packages
        if [ $? -ne 0 ]; then
            echo "ERROR: Failed to install dependencies!"
            exit 1
        fi
        echo "Dependencies installed successfully!"
    else
        echo "All dependencies OK (Pyrogram $REQUIRED_PYROGRAM_VERSION)"
    fi
}

check_and_install_deps

# Start the bot
echo "Starting bot..."
python bot/main.py
